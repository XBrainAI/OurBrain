// diagnose-runtime.mjs
// 运行时快速确诊脚本（v5.18 P0-B2）— 90 秒级定位 D3/D6/D9/D10 失效，替代"跑 16 分钟全量审计试错"
//
// 设计目标：
//   A/B 测试暴露的最大耗时源是"盲修循环"：agent 禁止读 run-audit 源码，只能猜根因 → 修 →
//   跑 4-16m 全量审计验证 → 没修中 → 再猜。本脚本提供 sanctioned 确诊通道：
//   Playwright 打开 demo，对 D3（弹窗闭环）/D6（按钮响应）/D9（标注协同）/D10（标注激活）
//   做确定性检测，<90 秒输出：逐元素失败清单（选择器）+ 根因分类 + fix_pattern。
//
//   检测谓词来自 lib/audit-probes.mjs（单一事实源，run-audit.mjs v5.18 P0-A2 已接入同一 lib），
//   保证"诊断过 = 审计过"。检测的是真实功能缺陷（按钮真没绑定、弹窗真关不掉、标注真没激活），
//   修复即真实质量提升，不属于定向骗过审计。
//
// 用法：
//   node scripts/diagnose-runtime.mjs --demo <demo-path> [--port 8802] [--deep]
//   --deep：逐页遍历全部 [data-page-id] 页面（v5.18 P0-A8 实现，更全但更慢，预算放宽至 240s）；
//           默认 fast 模式 <90s：D3 触发器自 v2.2 起也逐页收集（上限 20），D9/D10 检测当前可见页
//
// 退出码：0=0 失效（可进 run-audit 验收），1=有失效（需修复），2=Playwright 不可用
//
// 流程定位（v5.18 P0-B3）：
//   enhance-prototype → diagnose-runtime（须 0 失效）→ pre-audit-check → run-audit（一次验收）
//
// v5.18 P0-A8：实现真正逐页遍历逻辑（--deep 模式下遍历全部 [data-page-id] 页面，替代旧的"仅扩大抽样上限"）
//
// v2.1：修复 D9/D10 [SKIP] 短路（面板未激活计失效）+ D3 全量触发器 + deep pages_tested 恒 0
//   背景：v2 回归发现 diagnose-audit 一致率仅 79.3%（D10 40.7% / D3 63.0%），根因三项：
//   1) 面板未激活时 [SKIP] 短路计 0 失效 → 改为点击 [data-annotation-toggle] 主动激活（对齐 run-audit
//      "启用标注模式"流程），激活失败计入失效（ANNOTATION_PANEL_ACTIVATE_FAIL）
//   2) D3 仅测首屏前 10 个触发器 → deep 模式逐页收集触发器全量检测（上限 40），fast 维持 10 保 <90s
//   3) deep 模式 pages_tested 恒 0（早退/页面列表为空时不赋值）→ 所有路径 pages_tested ≥ 1；
//      页面列表为空时先 goto 根 URL 重取，仍为空回退首屏模式
//
// v2.2：D10 逐元素 rect 校验 + D3 fast 逐页收集（上限20）+ 触发器选择器口径对齐 run-audit
//   背景：v2.1 回归一致率 93.3%，残余 8 个不一致维度对 = D3×4（fast 只测首屏可见触发器）
//   + D10×4（diagnose 逐页汇总"标注状态正常"弱于 audit 逐元素 rect 校验，rect=0x0 漏检，
//   如 p1:17628、p8:14471）。三项升级：
//   1) D10：D9/D10 循环内逐页调用 probes.checkAnnotationElementsVisible 逐元素校验
//      （.l2-marker/.l3-dot 的 rect + display/visibility/opacity），不可见 >0 计失效
//      （root_cause=ANNOTATION_ELEMENT_INVISIBLE）；fast 至少检测当前可见页，deep 逐页
//   2) D3：fast 模式也逐页切换收集各页触发器（上限 10→20，每页切换等待 300ms 保 <90s，
//      输出注明；deep 维持 40 上限 / 500ms 不变）。v2.1 实证：p10 曾"触发器共 20 个，
//      仅检测前 10 个"——升级后 fast 覆盖翻倍且含非首屏页
//   3) D3：collectModalTriggers 选择器对齐 run-audit allOpenBtns（27 个候选选择器 + 同口径
//      去重/排除），闭环检测改用 openModalViaTrigger/closeVisibleModal（precise 弹窗优先 +
//      modalSelectors 兜底扫描 + flaky 重试，对齐 run-audit D3 Evaluate 1/2）
//
// v2.3：D10 数量一致性 + 激活断言抽样 + fast 逐页可见性（子任务 C）
//   背景：v2.2 实证 p10 首轮 audit D10 fail 27（8 页全部"声明 4，DOM 8"DOM 标注翻倍）
//   + 二轮 fail 2（zoneHigh=true, cardActive=false 卡片联动失败）——两类失效 diagnose 均漏检：
//   前者只查可见性不查数量，后者激活类失败无探针。三项升级：
//   1) D10 静态数量一致性：__ANNOTATION_DATA__ 声明 L2/L3 id vs DOM data-zone-id/
//      data-element-id 逐页对比（querySelectorAll 元素级计数，天然剥离 script/style 内代码
//      字符串，规避 v2.1 innerHTML 正则计数污染教训），不一致计失效（ANNOTATION_COUNT_MISMATCH），
//      置于面板激活判断之前（不依赖面板激活）
//   2) D10 激活断言抽样：fast 起始页前 3 个 / deep 每页 1 个可见 .l2-marker 逐个点击，
//      断言 zone is-highlighted + 面板 card active（同构 probes.clickFirstMarkerAndObserve
//      成功判定），失败计失效（ANNOTATION_ACTIVATE_FAIL）；抽样后 toggle 关闭面板复位
//   3) fast 模式 D10 可见性也逐页遍历（每页切换 300ms，8 页 ≈ 4s，<90s 无压力），
//      pages_tested 记实际遍历页数（不再恒 1；无页面 demo 记 1）
//
// v2.4：激活抽样 L2/L3 分层按页配额 + 分页序列探针（SEQ_REGRESSION）+ D9.3 遮挡检测点 + D3 双计数输出
//   背景：v2.3 回归实证（p6 案例）——P02 分页与筛选共用 style.display 的状态污染反模式，
//   5 个表格行内 L3（P02-C-007~011）在"D6 点分页 2→离开→返回"序列后 rect=0x0，audit 检出
//   但 diagnose 两轮漏检（判 74/74 全可见）。漏检三重机制（旧 activateSampleMarkers）：
//   ①抽样只查 .l2-marker（5 个失败全为 L3 一个抽不到）②全局前 3 个 slice(0,3) 非按页分层
//   ③纯导航态不触发序列依赖缺陷；配对的 D9.3 面板遮挡（paddingRight=320px 让位加在
//   内层容器）在 diagnose 无检测点。四项升级：
//   1) activateSampleMarkers 改 L2/L3 分层 + 按页配额：当前可见页 L2×1 + L3×2
//      （.l3-dot 优先，回退带 data-element-id 的可见标注元素），L3 优先抽"表格行内/
//      分页容器邻近"的标注（closest('tr, [data-page], .pagination, [class*=page]') 命中者
//      优先）；fast 起始页执行一轮（总抽样 3 个预算不变），deep 每页执行
//   2) 序列探针：含分页/筛选/tab 控件的页执行最小回归序列（点分页→离页→返回→复查
//      rect，对齐 p6 agent probe2 实证序列 3.9s 复现），出现新的 rect=0x0 计失效
//      （ANNOTATION_SEQ_REGRESSION）；fast 限前 2 个命中页控预算
//   3) D9.3 面板遮挡检测点：面板激活后取首个视口内可见交互元素 rect 与 .annotation-panel
//      rect 求交（对齐 run-audit L2656-2671 判定，含 paddingRight 让位检查），相交计失效
//      （ANNOTATION_PANEL_OCCLUDE）
//   4) D3 双计数输出：显式触发器（带 data-open-modal）+ 启发式命中分开计数（纯输出增强，
//      不改收集/判定逻辑，供 L3 归因）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { spawn } from 'child_process';
import http from 'http';
import { findFreePort } from './lib/port-utils.mjs';
import * as probes from './lib/audit-probes.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const skillDirRequire = createRequire(path.join(__dirname, 'dummy.js'));

function log(msg) { process.stdout.write(msg + '\n'); }

// ===== 根因 → fix_pattern 映射（供 agent 直接修复）=====
const FIX_PATTERNS = {
  MODAL_NO_TRIGGER: '弹窗容器存在但无 [data-open-modal] 触发器：为触发按钮添加 data-open-modal="<modalId>"（enhance C12 已自动归一 onclick/data-action，剩余需手动补）',
  MODAL_OPEN_FAIL: '点击触发器后弹窗未显示：检查 app.js 是否有 openModal() 且委托处理 data-open-modal（v5.18 骨架已默认可用，若被覆盖需恢复委托）',
  MODAL_NO_CLOSE: '弹窗内无关闭控件：在弹窗内添加 <button data-close>×</button>（样式/位置由你设计）',
  MODAL_CLOSE_FAIL: '点击关闭后弹窗仍显示：检查 closeModal() 是否将该 modal display 设为 none',
  BUTTON_NO_BINDING: '按钮无响应且未绑定事件（无 onclick/data-action）：用 v5.18 骨架的 data-* 契约绑定（data-nav/data-open-modal/data-action），或定义 window.handleDemoAction',
  BUTTON_INIT_EXCEPTION: '按钮无响应且伴随 init 异常：修复 init 序列首个异常（常见根因：对不存在的元素赋值 onclick，先判空再绑定）',
  ANNOTATION_NO_DATA: '无 __ANNOTATION_DATA__ 或无标注元素：按 annotation-spec 生成 L2/L3 标注数据',
  ANNOTATION_HIDDEN: '标注 marker/dot 不可见（display:none/hidden）：标注元素须放在可见容器内，避免落在 display:none 的页面碎片',
  ANNOTATION_NO_ACTIVATE: '点击标注 marker 无激活反馈：检查标注引擎事件绑定与面板协同（确保 data-zone-id/element-id 唯一）',
  ANNOTATION_PANEL_ACTIVATE_FAIL: '点击 [data-annotation-toggle] 后标注面板仍不可见：检查标注引擎加载（demora-annotation-host / Shadow DOM 挂载）与面板 display 切换（对齐 run-audit D9.2：toggle 点击 500ms 后穿透 Shadow DOM 查 .annotation-panel computed display）',
  ANNOTATION_ELEMENT_INVISIBLE: '检查标注锚点是否位于隐藏容器/内联元素，rect=0x0：.l2-marker/.l3-dot 须挂在可见页面容器内（祖先无 display:none/[hidden]），内联空元素需显式设置宽高（对齐 run-audit D10 逐元素 rect 校验）',
  ANNOTATION_COUNT_MISMATCH: '检查 __ANNOTATION_DATA__ 声明与 DOM data-zone-id/data-element-id 一一对应（重复注入/漏注）：每页 L2[].id/L3[].id 数量须与该页 DOM 属性数量一致，缺失补 data-* 属性、多余/重复则删除（v2.3 p10 实证：声明 4 DOM 8 翻倍→audit D10 全页 FAIL）',
  ANNOTATION_ACTIVATE_FAIL: '检查 zone 与 card 的联动选择器/id 绑定：点击 .l2-marker 后对应 [data-zone-id] 须加 is-highlighted 且面板内对应 .anno-card 须加 is-active（同页 id 重复/引擎未刷新时联动断裂，改后调 window.__ANNOTATION_ENGINE__.refresh()）',
  ANNOTATION_SEQ_REGRESSION: '分页/筛选控件与标注显隐共用 style.display 状态位（v2.3 p6 P02 实证：翻页往返后表格行内标注 rect=0x0）：显隐状态必须用独立 data-* 状态位（如 data-anno-visible="1"）驱动，禁止读取 style.display 反推业务状态；在分页/筛选 change 回调中按状态位恢复标注显示（见 SKILL 显隐状态位规范）',
  ANNOTATION_PANEL_OCCLUDE: '面板激活后页面交互元素被遮挡：将 data-annotation-root 提升到包含侧栏/顶栏的外层容器，使 padding-right 让位作用于整个 shell（v2.3 p6 实证修法：让位 padding 加在内层容器时，外层侧栏/顶栏交互元素仍与面板 rect 相交）',
  CONSOLE_404: 'console 有 404/error：favicon 用 <link rel="icon" href="data:,">（generate-demo 已注入），其余 404 检查资源路径',
  // v5.20.2（UAT 四轮）新增失效键
  NAV_COLLAPSE_OCCLUDE: '折叠唤出的侧栏遮盖常驻 topbar（v5.20.2 codex-p10 实证）：折叠态侧栏 fixed top 不得为 0——骨架 app.js 已预置 [data-nav-toggle] 委托（切换时测量展开态侧栏 getBoundingClientRect().top 即 topbar 底部，写入内联 style.top），勿覆盖/删除该委托；若自写折叠逻辑须对齐同一测量',
  PANEL_CARD_ORDER: '标注面板卡片徽章乱序（v5.20.2 codex-p10 实证：AI 声明顺序与 DOM 顺序错位导致卡片序≠编码序）：annotation-engine.js renderL2List/renderL3List 已按引擎编码升序渲染（v5.20.2 修复）——乱序说明 demo 注入的引擎为旧版，剥离旧注入块后重跑 enhance-prototype.mjs 更新',
};

// ===== 参数解析 =====
function parseArgs(argv) {
  const args = { demo: null, port: 8802, deep: false, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') args.help = true;
    else if (a === '--demo') args.demo = argv[++i];
    else if (a === '--port') args.port = parseInt(argv[++i], 10);
    else if (a === '--deep') args.deep = true;
  }
  return args;
}

function showHelp() {
  console.log(`Demora 运行时快速确诊 (v5.18 P0-B2) — <90 秒定位 D3/D6/D9/D10 失效

用法：
  node scripts/diagnose-runtime.mjs --demo <demo-path> [--port 8802] [--deep]

参数：
  --demo <path>    demo 目录路径（包含 index.html）
  --port <num>     起始端口（默认 8802，被占自动累加找空闲）
  --deep           逐页遍历全部 [data-page-id] 页面（v5.18 P0-A8 实现，更全但更慢，预算放宽至 240s）；默认 fast <90s（D3 触发器自 v2.2 起逐页收集上限 20；D10 可见性自 v2.3 起逐页 + 数量一致性/激活断言抽样；v2.4 起激活抽样 L2/L3 分层 + 分页序列探针 fast 限 2 页 + D9.3 面板遮挡检测）

输出：
  - 控制台打印逐维度失败清单（含选择器/根因/fix_pattern）
  - demo/diagnose-result.json 结构化结果（供 agent 读取）

退出码：0=0 失效（可进 run-audit 验收），1=有失效，2=Playwright 不可用`);
}

// ===== HTTP 服务器（Node 原生静态服务，无需 Python）=====
let httpServer = null;
function startNodeServer(demoDir, port) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let urlPath = req.url.split('?')[0];
      if (urlPath === '/') urlPath = '/index.html';
      const filePath = path.join(demoDir, decodeURIComponent(urlPath));
      if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
        res.writeHead(404); res.end('Not Found'); return;
      }
      const ext = path.extname(filePath).toLowerCase();
      const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon' };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
      fs.createReadStream(filePath).pipe(res);
    });
    server.listen(port, '127.0.0.1', () => { httpServer = server; resolve(true); });
    server.on('error', () => resolve(false));
  });
}
function stopServer() { try { if (httpServer) { httpServer.close(); httpServer = null; } } catch (e) {} }

// ===== v2.1 辅助函数（Node 侧；传入 page.evaluate 的回调均自包含，满足 probes 序列化约束）=====

// 切换到指定 [data-page-id] 页面：优先 window.route；fallback 直接切 display/hidden
//   （fallback 同时移除/设置 hidden 属性，对齐 probes D9.3/D9.4 的可见页判定 [data-page-id]:not([hidden])）
// v2.2：waitMs 可调（默认 500 不变）——D3 fast 逐页收集传 300ms 控制预算，D9/D10 维持默认
async function switchToPage(page, pid, waitMs = 500) {
  await page.evaluate((id) => {
    if (typeof window.route === 'function') {
      window.route(id);
    } else {
      document.querySelectorAll('[data-page-id]').forEach((p) => {
        if (p.getAttribute('data-page-id') === id) {
          p.style.display = '';
          p.removeAttribute('hidden');
        } else {
          p.style.display = 'none';
          p.setAttribute('hidden', '');
        }
      });
    }
  }, pid);
  await page.waitForTimeout(waitMs); // 等待页面切换完成
}

// 点击 [data-annotation-toggle] 激活标注面板，500ms 后复查面板可见性（v2.1 修复 #1）
//   对齐 run-audit"启用标注模式"流程（toggle.click() + 500ms）与 D9.2 面板判定：
//   面板可能在 light DOM，也可能挂载在 #demora-annotation-host 的 Shadow DOM 内
//   （collectAnnotationState 的 hasPanel 只查 light DOM，会漏 Shadow DOM 面板 → 误判"未激活"）
async function tryActivatePanel(page) {
  const clicked = await page.evaluate(() => {
    const btn = document.querySelector('[data-annotation-toggle]');
    if (btn) { btn.click(); return true; }
    return false;
  });
  await page.waitForTimeout(500); // 等待面板 display 切换
  const panel = await page.evaluate(() => {
    let el = document.querySelector('.annotation-panel');
    if (!el) {
      const host = document.getElementById('demora-annotation-host');
      if (host && host.shadowRoot) el = host.shadowRoot.querySelector('.annotation-panel');
    }
    if (!el) return { found: false, visible: false, display: 'N/A' };
    const s = window.getComputedStyle(el);
    return { found: true, visible: s.display !== 'none' && s.visibility !== 'hidden', display: s.display };
  });
  return { clicked, ...panel, ok: clicked && panel.visible };
}

// ===== v2.3 改动 1：D10 静态数量一致性检查（不依赖面板激活）=====
// 背景：v2.2 实证 p10 首轮 audit D10 fail 27——8 页全部"L2 数量不一致：声明 4，DOM 8"
//   （DOM 标注翻倍），diagnose 旧版只查可见性（18/18 可见 OK）漏检。本谓词对比
//   __ANNOTATION_DATA__ 声明的 L2/L3 id 与 DOM data-zone-id/data-element-id 属性。
//
// 口径说明：
//   1. 声明数据取 window.__ANNOTATION_DATA__（包装结构 {pages:{}} / 扁平结构均兼容，
//      对齐 run-audit navReport 的 rawData 归一）；window 上缺失时回退解析 DOM 内
//      script 标签文本（沙箱 Function 执行后取值，仅诊断 demo 自身脚本，无安全面）
//   2. DOM 计数用 querySelectorAll 元素级查询——天然不含 script/style 内代码字符串，
//      规避 v2.1 教训（innerHTML/正则计数会被引擎注入的代码字符串污染计数）
//   3. 归组：DOM 元素按 closest('[data-page-id]') 归页；无页归属（弹窗/全局容器）
//      记入 __global__ 组，不参与"多余"判定；声明 id 在本页 DOM 找不到但在 __global__
//      找到时不判缺失（弹窗标注声明挂页、DOM 在 body 下的常见结构），但其数量计入
//      有效 DOM 数（effDomCount = 页内数 + 全局兜底命中数）
//   4. 失败判定（任一页任一类命中即 mismatch）：
//      数量不一致（declaredCount !== effDomCount，含同 id 重复注入的翻倍场景）
//      / 缺失（声明有、页内+全局 DOM 均无）/ 多余（页内 DOM 有、本页声明无）
function checkAnnotationCountConsistency() {
  // 1. 取声明数据：window 优先，script 标签回退
  let data = null;
  if (typeof window.__ANNOTATION_DATA__ !== 'undefined' && window.__ANNOTATION_DATA__ &&
      typeof window.__ANNOTATION_DATA__ === 'object') {
    data = window.__ANNOTATION_DATA__;
  } else {
    for (const s of Array.from(document.querySelectorAll('script'))) {
      const t = s.textContent || '';
      if (t.indexOf('__ANNOTATION_DATA__') === -1) continue;
      try {
        const box = {};
        const fn = new Function('window', t + '\n;return window.__ANNOTATION_DATA__;');
        const v = fn(box);
        if (v && typeof v === 'object') { data = v; break; }
      } catch (e) { /* 该 script 解析失败，继续找下一个 */ }
    }
  }
  if (!data) return { hasData: false };
  const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
    ? data.pages : data;

  // 2. 声明侧：pid -> { zones:[id], elements:[id] }
  const declared = {};
  const idsOf = (arr) => (Array.isArray(arr) ? arr : [])
    .map((it) => (it && it.id != null ? String(it.id) : null)).filter(Boolean);
  for (const pid of Object.keys(rawData)) {
    const po = rawData[pid];
    if (!po || typeof po !== 'object') continue;
    declared[pid] = { zones: idsOf(po.L2), elements: idsOf(po.L3) };
  }

  // 3. DOM 侧：pid -> { zones:[id], elements:[id] }（querySelectorAll 元素级查询，天然剥离 script/style）
  const GLOBAL = '__global__';
  const dom = {};
  const pidOf = (el) => {
    const pw = el.closest('[data-page-id]');
    return pw ? pw.getAttribute('data-page-id') : GLOBAL;
  };
  document.querySelectorAll('[data-zone-id]').forEach((el) => {
    const pid = pidOf(el);
    if (!dom[pid]) dom[pid] = { zones: [], elements: [] };
    dom[pid].zones.push(String(el.getAttribute('data-zone-id')));
  });
  document.querySelectorAll('[data-element-id]').forEach((el) => {
    const pid = pidOf(el);
    if (!dom[pid]) dom[pid] = { zones: [], elements: [] };
    dom[pid].elements.push(String(el.getAttribute('data-element-id')));
  });
  const g = dom[GLOBAL] || { zones: [], elements: [] };

  // 4. 逐页对比（声明页 + DOM 独有页都覆盖）
  const pageIds = Array.from(new Set(Object.keys(declared).concat(Object.keys(dom).filter((p) => p !== GLOBAL))));
  let mismatch = false;
  let decZones = 0, decElems = 0, domZones = 0, domElems = 0;
  const pages = [];
  for (const pid of pageIds) {
    const dec = declared[pid] || { zones: [], elements: [] };
    const d = dom[pid] || { zones: [], elements: [] };
    decZones += dec.zones.length; decElems += dec.elements.length;
    domZones += d.zones.length; domElems += d.elements.length;
    const diff = (decIds, domIds, gIds) => {
      const missing = decIds.filter((id) => domIds.indexOf(id) === -1 && gIds.indexOf(id) === -1);
      const extra = domIds.filter((id) => decIds.indexOf(id) === -1);
      const rescued = decIds.filter((id) => domIds.indexOf(id) === -1 && gIds.indexOf(id) !== -1);
      return { missing, extra, declaredCount: decIds.length, domCount: domIds.length,
        effDomCount: domIds.length + rescued.length };
    };
    const z = diff(dec.zones, d.zones, g.zones);
    const e = diff(dec.elements, d.elements, g.elements);
    const zBad = z.declaredCount !== z.effDomCount || z.missing.length > 0 || z.extra.length > 0;
    const eBad = e.declaredCount !== e.effDomCount || e.missing.length > 0 || e.extra.length > 0;
    if (zBad || eBad) mismatch = true;
    pages.push({ pid, zones: z, elements: e, mismatch: zBad || eBad });
  }
  return {
    hasData: true, mismatch,
    declaredZones: decZones, declaredElements: decElems,
    domZones, domElems,
    globalDomZones: g.zones.length, globalDomElements: g.elements.length,
    pages,
  };
}

// ===== v2.3 改动 2 / v2.4 改动 1：D10 激活断言抽样谓词（L2/L3 分层 + 按页配额）=====
// 背景：v2.2 实证 p10 二轮 audit fail 2——zoneHigh=true,cardActive=false（卡片联动失败），
//   激活类失败旧版 diagnose 无探针（D9.3 只点首个 marker，且 fast 只测首屏）。
// v2.4 背景：v2.3 回归实证（p6 案例）漏检三重机制——旧版只抽 .l2-marker 全局前 3 个：
//   ①5 个失败标注全为表格行内 L3，一个抽不到 ②slice(0,3) 非按页分层 ③纯导航态不触发
//   序列依赖缺陷。现改为分层 + 按页配额：
//   - 配额：当前可见页 L2×1 + L3×2（总抽样 3 个，与旧版 fast 前 3 个持平，预算不变）
//   - L3 候选：.l3-dot 优先（对齐 checkAnnotationElementsVisible 元素口径）；无 .l3-dot 时
//     回退"带 data-element-id 的可见标注元素"（覆盖 dot 类名变体）
//   - L3 优先级：closest('tr, [data-page], .pagination, [class*=page]') 命中者优先
//     （p6 实证失效集中在表格行内/分页容器邻近的 L3；sort 稳定，同组保持 DOM 序）
// 判定：L2 同构 clickFirstMarkerAndObserve 成功语义（zone is-highlighted + card active）；
//   L3 同构 clickFirstDotAndObserve 成功语义（dot is-active + card active）；
//   poll 2000ms + 300ms fallback 节奏不变。
// 副作用说明：点击会打开面板/高亮 zone，调用方在全部抽样完成后统一复位（toggle 关闭）。
function activateSampleMarkers() {
  const L2_QUOTA = 1;
  const L3_QUOTA = 2;
  // scope：当前可见页（对齐 checkAnnotationElementsVisible，切页由调用方负责）
  const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
  const scope = visiblePage || document;
  const isVisible = (el) => {
    const r = el.getBoundingClientRect();
    const s = window.getComputedStyle(el);
    // 对齐 clickFirstDotAndObserve：opacity 检查用 !== '0'（L3 dot 常用 opacity 控制可见性）
    return r.width > 0 && r.height > 0 && s.display !== 'none' &&
           s.visibility !== 'hidden' && s.opacity !== '0';
  };
  const collectVisible = (sel) => Array.from(scope.querySelectorAll(sel)).filter(isVisible);
  // L3 候选：.l3-dot 优先；无则回退带 data-element-id 的可见标注元素（排除 L2 marker 自身）
  let l3 = collectVisible('.l3-dot');
  if (l3.length === 0) {
    l3 = collectVisible('[data-element-id]').filter((el) => !el.classList.contains('l2-marker'));
  }
  // L3 优先抽"表格行内/分页容器邻近"的标注（命中者排前，同组保持 DOM 序）
  const nearList = (el) => !!(el.closest && el.closest('tr, [data-page], .pagination, [class*="page"]'));
  l3 = l3.slice().sort((a, b) => (nearList(b) ? 1 : 0) - (nearList(a) ? 1 : 0));
  const sample = []
    .concat(collectVisible('.l2-marker').slice(0, L2_QUOTA).map((el) => ({ el, kind: 'L2' })))
    .concat(l3.slice(0, L3_QUOTA).map((el) => ({ el, kind: 'L3' })));
  const results = [];
  // 面板宿主（Shadow DOM）：poll 判定 .anno-card 是否出现（宿主引用稳定，querySelector 动态查）
  const cardHost = document.getElementById('demora-annotation-host');
  const cardSr0 = cardHost ? cardHost.shadowRoot : null;
  const getPanelBody = () => {
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const panel = sr ? sr.querySelector('.annotation-panel') : document.querySelector('.annotation-panel');
    return panel ? panel.querySelector('.panel-body') : null;
  };
  const waitCard = async () => {
    const start = Date.now();
    while (Date.now() - start < 2000) {
      if (cardSr0 && cardSr0.querySelector('.anno-card')) return;
      await new Promise((r) => setTimeout(r, 50));
    }
    await new Promise((r) => setTimeout(r, 300)); // fallback 对齐 clickFirstMarker/DotAndObserve
  };
  return (async () => {
    for (let i = 0; i < sample.length; i++) {
      const target = sample[i].el;
      const kind = sample[i].kind;
      if (kind === 'L2') {
        // L2 断言：zone is-highlighted + 面板 .anno-card.is-active（同构 clickFirstMarkerAndObserve）
        const zoneWrap = target.closest('[data-zone-id]');
        const zoneId = zoneWrap ? zoneWrap.getAttribute('data-zone-id') : null;
        target.click();
        await waitCard();
        let targetZoneHighlighted = false;
        if (zoneId) {
          const vp = document.querySelector('[data-page-id]:not([hidden])');
          const sc = vp || document;
          const zoneEl = sc.querySelector('[data-zone-id="' + zoneId + '"]');
          targetZoneHighlighted = zoneEl ? zoneEl.classList.contains('is-highlighted') : false;
        }
        const panelBody = getPanelBody();
        const activeCardCount = panelBody ? panelBody.querySelectorAll('.anno-card.is-active').length : 0;
        results.push({ idx: i + 1, kind, zoneId, targetZoneHighlighted, activeCardCount,
          activated: targetZoneHighlighted && activeCardCount > 0 });
      } else {
        // L3 断言：dot is-active + 面板 .anno-card.is-active（同构 clickFirstDotAndObserve）
        const elemWrap = target.closest('[data-element-id]');
        const elemId = elemWrap ? elemWrap.getAttribute('data-element-id') : null;
        target.click();
        await waitCard();
        let targetDotActive = false;
        if (elemId) {
          const vp = document.querySelector('[data-page-id]:not([hidden])');
          const sc = vp || document;
          const elemEl = sc.querySelector('[data-element-id="' + elemId + '"]');
          const dot = elemEl ? elemEl.querySelector('.l3-dot') : null;
          targetDotActive = dot ? dot.classList.contains('is-active') : false;
        }
        const panelBody = getPanelBody();
        const activeCardCount = panelBody ? panelBody.querySelectorAll('.anno-card.is-active').length : 0;
        results.push({ idx: i + 1, kind, elementId: elemId, targetDotActive, activeCardCount,
          activated: targetDotActive && activeCardCount > 0 });
      }
    }
    return {
      tested: sample.length,
      testedL2: results.filter((r) => r.kind === 'L2').length,
      testedL3: results.filter((r) => r.kind === 'L3').length,
      results,
    };
  })();
}

// 抽样后复位：点击 [data-annotation-toggle] 关闭标注面板（等效 closePanel），
//   消除激活抽样的副作用（面板打开/zone 高亮残留），不影响后续 Node 侧汇总输出
async function resetAnnotationPanel(page) {
  await page.evaluate(() => {
    const root = document.querySelector('[data-annotation-root]') || document.body;
    if (root.hasAttribute('data-annotation-active')) {
      const btn = document.querySelector('[data-annotation-toggle]');
      if (btn) btn.click();
    }
  });
  await page.waitForTimeout(200);
}

// ===== v2.4 改动 2：序列探针（分页/筛选控件页的最小回归序列）=====
// 背景：v2.3 回归实证（p6 案例）——P02 分页与筛选共用 style.display 的状态污染反模式，
//   5 个表格行内 L3 在"D6 点分页 2→离开→返回"序列后 rect=0x0，audit 检出但 diagnose 两轮
//   漏检（纯导航态不触发序列依赖缺陷）。本探针在逐页可见性之后补一个最小交互回归序列，
//   对齐 p6 agent probe2 实证序列（3.9s 复现）。

// 控件探测谓词：当前可见页是否存在分页/筛选/tab 控件（候选特征任一命中即算）。
//   特征：.pagination / [class*="page-"] 按钮 / class 含 tab 的按钮 /
//   含"下一页|上一页|第 N 页"文本的按钮 / id|class 含 filter|status 的 select
function detectNavControls() {
  const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
  const scope = visiblePage || document;
  const hits = [];
  if (scope.querySelector('.pagination')) hits.push('.pagination');
  const btns = Array.from(scope.querySelectorAll('button, a, [role="button"]'));
  if (btns.some((b) => typeof b.className === 'string' && b.className.indexOf('page-') !== -1)) hits.push('[class*="page-"]');
  if (btns.some((b) => typeof b.className === 'string' && /tab/i.test(b.className))) hits.push('tab');
  if (btns.some((b) => /下一页|上一页|第\s*\d+\s*页/.test(b.textContent || ''))) hits.push('pager-text');
  if (Array.from(scope.querySelectorAll('select')).some((s) =>
    /filter|status/i.test((s.id || '') + ' ' + (typeof s.className === 'string' ? s.className : '')))) hits.push('filter-select');
  return { hasControls: hits.length > 0, hits };
}

// 序列探针执行（Node 侧编排，点击/复查全在浏览器内完成）：
//   1. 记录基线（本页全部 .l2-marker/.l3-dot 可见性）+ 点击分页控件"第 2 页/下一页"按钮
//   2. 切相邻 data-page-id 页（离页；无相邻页时跳过——单页 demo 只测分页点击影响）
//   3. 切回本页
//   4. 复查：基线中"此前可见"的标注出现 rect=0x0/不可见（或元素丢失）→ 序列回归
//   5. 复位：best-effort 点回"第 1 页"按钮
// v2.4 预验修正：step2/3 切页改用"真实导航模拟"（location.hash → data-nav 点击 → route() → display 兜底），
//   而非 switchToPage 的 display 兜底优先——程序化 display 切换绕过应用 hash 路由（handleRoute 不触发），
//   会把"route 进页会重置分页"的 demo 误判为序列回归（p6 预验实证：route 重置逻辑被绕过致 5 个误报）
async function runSequenceProbe(page, pageId, allPages) {
  // 真实导航切页：优先 hash 变化（触发 hashchange→handleRoute，与用户点击导航一致），次 data-nav 点击/ route()，最后 display 兜底
  const navigateReal = async (pid) => {
    await page.evaluate((target) => {
      const applyFallback = () => {
        document.querySelectorAll('[data-page-id]').forEach((p) => {
          p.hidden = p.getAttribute('data-page-id') !== target;
        });
        if (typeof window.route === 'function') { try { window.route(target); } catch (e) {} }
      };
      // 1) hash 导航（应用路由正常时触发 hashchange → handleRoute → 应用状态管理生效）
      const targetHash = '#' + target;
      if (location.hash !== targetHash) {
        location.hash = targetHash;
        return; // hashchange 异步触发，等待即可
      }
      // 2) hash 已在目标页（无变化不触发事件）→ 点击 data-nav / a[href] 模拟真实导航
      const nav = document.querySelector('[data-nav="' + target + '"]') ||
        document.querySelector('a[href="#' + target + '"]');
      if (nav) { nav.click(); return; }
      // 3) 兜底：display 切换 + route()
      applyFallback();
    }, pid);
    await page.waitForTimeout(300);
  };
  // step1：基线 + 点击分页按钮（优先"第 2 页"，次"下一页"，再次 class 含 page- 的"2"页码）
  const start = await page.evaluate(() => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
    const scope = visiblePage || document;
    // 收集本页全部标注的可见性快照（kind+id+idx 定位，复查时同 key 对比）
    const collect = () => {
      const out = [];
      const add = (kind, sel, attr) => scope.querySelectorAll(sel).forEach((el, i) => {
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        const wrap = el.closest('[' + attr + ']');
        out.push({
          kind, id: wrap ? wrap.getAttribute(attr) : null, idx: i,
          visible: r.width > 0 && r.height > 0 && s.display !== 'none' &&
                   s.visibility !== 'hidden' && s.opacity !== '0',
        });
      });
      add('L2', '.l2-marker', 'data-zone-id');
      add('L3', '.l3-dot', 'data-element-id');
      return out;
    };
    const isVisible = (el) => {
      const r = el.getBoundingClientRect();
      const s = window.getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
    };
    const btns = Array.from(scope.querySelectorAll('button, a, [role="button"]')).filter(isVisible);
    let target = btns.find((b) => /^第\s*2\s*页$/.test((b.textContent || '').trim()));
    if (!target) target = btns.find((b) => /下一页|next/i.test(b.textContent || ''));
    if (!target) target = btns.find((b) => typeof b.className === 'string' &&
      b.className.indexOf('page-') !== -1 && /^\s*2\s*$/.test(b.textContent || ''));
    if (!target) return { clicked: false };
    const btnText = (target.textContent || '').trim().slice(0, 12);
    const baseline = collect(); // 基线须在点击前记录（纯导航态快照）
    target.click();
    return { clicked: true, btnText, baseline };
  });
  if (!start.clicked) return { skipped: true }; // 控件存在但无可点页码（如仅 tab/select）
  await page.waitForTimeout(300);
  // step2：切相邻页（真实导航离页）
  const curIdx = pageId != null ? allPages.indexOf(pageId) : -1;
  const neighbor = curIdx >= 0
    ? (allPages[curIdx + 1] != null ? allPages[curIdx + 1] : (curIdx > 0 ? allPages[curIdx - 1] : null))
    : null;
  if (neighbor != null) await navigateReal(neighbor);
  // step3：切回本页（真实导航；未离页时仅补等待，保证点击后状态稳定）
  if (pageId != null && neighbor != null) await navigateReal(pageId);
  else await page.waitForTimeout(300);
  // step4：复查——基线中"此前可见"的标注现在不可见（或丢失）即序列回归
  const after = await page.evaluate((baseline) => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
    const scope = visiblePage || document;
    const cur = [];
    const add = (kind, sel, attr) => scope.querySelectorAll(sel).forEach((el, i) => {
      const r = el.getBoundingClientRect();
      const s = window.getComputedStyle(el);
      const wrap = el.closest('[' + attr + ']');
      cur.push({ kind, id: wrap ? wrap.getAttribute(attr) : null, idx: i,
        visible: r.width > 0 && r.height > 0 && s.display !== 'none' &&
                 s.visibility !== 'hidden' && s.opacity !== '0' });
    });
    add('L2', '.l2-marker', 'data-zone-id');
    add('L3', '.l3-dot', 'data-element-id');
    const keyOf = (e) => e.kind + ':' + (e.id != null ? e.id : 'idx' + e.idx);
    const map = new Map(cur.map((e) => [keyOf(e), e]));
    const regressions = [];
    for (const b of baseline) {
      if (!b.visible) continue; // 只关注"此前可见 → 现在不可见"的新增失效
      const a = map.get(keyOf(b));
      if (!a) regressions.push({ kind: b.kind, id: b.id, reason: 'lost' });
      else if (!a.visible) regressions.push({ kind: a.kind, id: a.id, reason: 'invisible' });
    }
    const total = baseline.filter((b) => b.visible).length;
    return { total, kept: total - regressions.length, regressions };
  }, start.baseline);
  // step5：复位（best-effort 点回第 1 页，避免残留第 2 页状态污染后续检测）
  await page.evaluate(() => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
    const scope = visiblePage || document;
    const isVisible = (el) => {
      const r = el.getBoundingClientRect();
      const s = window.getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
    };
    const btns = Array.from(scope.querySelectorAll('button, a, [role="button"]')).filter(isVisible);
    const home = btns.find((b) => /^第\s*1\s*页$/.test((b.textContent || '').trim())) ||
      btns.find((b) => typeof b.className === 'string' &&
        b.className.indexOf('page-') !== -1 && /^\s*1\s*$/.test(b.textContent || ''));
    if (home) home.click();
  });
  await page.waitForTimeout(200);
  return { skipped: false, btnText: start.btnText, ...after };
}



// ===== v2.2 升级 3：D3 弹窗/关闭选择器（Node 侧常量，经 evaluate 参数传入浏览器上下文）=====
// 与 run-audit D3 单一事实源对齐（run-audit.mjs L1164-1167，勿增删/重排）；
// probes 的 openModalViaTrigger/closeVisibleModal 保持自包含，不引用本模块常量
const MODAL_SELECTORS = ['#modalMask', '.modal-mask', '.modal', '#modal', '[role="dialog"]', '.dialog-mask', '.dialog',
  '.modal-overlay', '.pg-modal-mask', '.modal-wrap', '.modal-container', '.modal-backdrop', '.layui-layer', '.ant-modal'];
const MODAL_CLOSE_SELECTORS = ['#modalClose', '.modal-close', '.close-btn', '[data-close]', '[aria-label="close"]', '[aria-label="Close"]', '.modal-close-btn', '.modal-cancel', 'button.btn-cancel'];

// 强制隐藏全部弹窗（close-fail 后兜底清理，避免残留弹窗污染后续触发器检测；
// 选择器对齐 run-audit D3 强制清理逻辑 run-audit.mjs L1375-1380）
async function forceHideModals(page) {
  await page.evaluate(() => {
    document.querySelectorAll('.modal, [role="dialog"], .dialog-mask, #modalMask, .modal-overlay, .pg-modal-mask, .modal-wrap, .modal-container, .modal-backdrop').forEach((el) => {
      el.hidden = true;
      el.style.display = 'none';
    });
  });
}

// ===== 主流程 =====
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.demo) { showHelp(); process.exit(args.help ? 0 : 1); }

  const demoDir = path.resolve(args.demo);
  if (!fs.existsSync(path.join(demoDir, 'index.html'))) {
    log('[FAIL] demo/index.html 不存在: ' + demoDir);
    process.exit(1);
  }

  // 加载 Playwright
  let chromium;
  try { chromium = skillDirRequire('playwright').chromium; }
  catch (e) {
    try { chromium = skillDirRequire('playwright-core').chromium; }
    catch (e2) { log('[FAIL] Playwright 不可用: ' + e2.message); process.exit(2); }
  }

  // v5.18 D3 端口治理：Node 原生 findFreePort（不 kill 进程），替代历史 PowerShell 清理脚本
  const port = await findFreePort(args.port, 20);
  if (port === null) { log('[FAIL] 无可用端口（' + args.port + ' 起连续 20 个被占用）'); process.exit(1); }
  const URL = `http://127.0.0.1:${port}/`;

  log('======================================================================');
  log('diagnose-runtime.mjs — 运行时快速确诊 (v5.18 P0-B2)');
  log('======================================================================');
  log(`  demo:  ${demoDir}`);
  log(`  URL:   ${URL}（端口 ${port}）`);
  log(`  模式:  ${args.deep ? 'deep（逐页，预算放宽至 240s）' : 'fast（首屏，<90s）'}`);

  const serverOk = await startNodeServer(demoDir, port);
  if (!serverOk) { log('[FAIL] HTTP 服务器启动失败'); process.exit(1); }

  let browser;
  try { browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-setuid-sandbox'] }); }
  catch (e) { log('[FAIL] 浏览器启动失败: ' + e.message); stopServer(); process.exit(2); }

  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });

  // 异常捕获
  const pageErrors = [];
  const consoleErrors = [];
  const console404 = [];
  page.on('pageerror', (e) => pageErrors.push(e.message));
  page.on('console', (m) => {
    if (m.type() === 'error') {
      const t = m.text();
      consoleErrors.push(t);
      if (/404|Failed to load resource/i.test(t)) console404.push(t);
    }
  });
  page.on('response', (r) => { if (r.status() === 404) console404.push('HTTP 404: ' + r.url()); });

  await page.goto(URL, { waitUntil: 'networkidle', timeout: 20000 }).catch(() => {});
  await page.waitForTimeout(1500);

  // 失败清单（逐维度）
  const failures = [];
  const addFail = (dim, rootCause, selector, detail) => {
    failures.push({ dim, root_cause: rootCause, selector: selector || '-', detail: detail || '', fix_pattern: FIX_PATTERNS[rootCause] || '' });
  };

  // ---- D0: console 404/error ----
  log('\n--- D0: console 资源/异常 ---');
  if (console404.length > 0) {
    console404.slice(0, 5).forEach(t => addFail('D0_console', 'CONSOLE_404', '-', t.slice(0, 80)));
    log(`  [FAIL] ${console404.length} 个 404/error`);
  } else { log('  [OK] 无 404/error'); }

  // ---- D6: 按钮响应 ----
  log('\n--- D6: 按钮响应 ---');
  const buttons = await page.evaluate(probes.collectButtons);
  log(`  [INFO] 可见可交互按钮 ${buttons.length} 个`);
  // v5.18 P0-A8：抽样上限统一保持 10（逐页遍历由 D9/D10 块负责，按钮抽样不再随 --deep 扩大）
  const btnSample = buttons.slice(0, 10);
  let btnNoResponse = 0;
  let btnSkippedDisabled = 0;
  for (const b of btnSample) {
    const res = await page.evaluate(probes.clickButtonAndObserve, b.index);
    // v5.22.1：中途变 disabled 的按钮豁免（对齐 run-audit D6 'button became disabled' 跳过口径，不计失效）
    if (res.found && res.skipped) { btnSkippedDisabled++; continue; }
    if (res.found && !res.responded) {
      btnNoResponse++;
      const hasInitErr = pageErrors.length > 0;
      addFail('D6_button_responsiveness', hasInitErr ? 'BUTTON_INIT_EXCEPTION' : 'BUTTON_NO_BINDING',
        `按钮"${b.text}"`, `无响应 (onclick=${b.hasOnclick}, data-action=${b.hasDataAction})`);
    }
  }
  if (btnNoResponse === 0) log(`  [OK] ${btnSample.length} 个抽样按钮均响应` + (btnSkippedDisabled ? `（另 ${btnSkippedDisabled} 个中途变 disabled 已豁免）` : ''));
  else log(`  [FAIL] ${btnNoResponse}/${btnSample.length} 个按钮无响应`);

  // ---- D6.5: 导航折叠唤出位置（v5.20.2 UAT 四轮新增——codex-p10 实证唤出侧栏遮盖 topbar）----
  log('\n--- D6.5: 导航折叠唤出位置 ---');
  const collapseApplicable = await page.evaluate(() => {
    const btn = document.querySelector('[data-nav-toggle]');
    const sb = document.querySelector('.sidebar, [class*="sidebar"]');
    if (!btn || !sb) return false;
    const br = btn.getBoundingClientRect();
    const r = sb.getBoundingClientRect();
    // 按钮与侧栏均可见且具尺寸才适用（防 page.click 对不可见元素超时）
    return br.width > 0 && br.height > 0 && r.width > 0 && r.height > 0;
  });
  if (!collapseApplicable) {
    log('  [INFO] 无导航折叠体系（[data-nav-toggle]+.sidebar 缺失或侧栏不可见），跳过');
  } else {
    // 折叠 → 验证完全收起 → 悬停左缘热区唤出 → 断言不遮盖 topbar → 复原展开
    // 注意：D6 按钮抽样可能已点击过 nav-toggle（折叠态进入本检测），先读状态再决定是否点击
    const preCollapsed = await page.evaluate(() => document.body.classList.contains('nav-collapsed'));
    if (!preCollapsed) {
      await page.click('[data-nav-toggle]');
      await page.waitForTimeout(450); // 等 transform .2s 过渡
    } else {
      // 折叠态进入：鼠标可能停在按钮上（若旧实现 fixed top:0 覆盖按钮区会触发 hover 唤出）
      // 移开鼠标让侧栏回落收起态，保证收起测量准确
      await page.mouse.move(640, 400);
      await page.waitForTimeout(450);
    }
    const collapsedState = await page.evaluate(() => {
      const sb = document.querySelector('.sidebar, [class*="sidebar"]');
      const r = sb.getBoundingClientRect();
      return { right: r.right, collapsed: document.body.classList.contains('nav-collapsed') };
    });
    if (!collapsedState.collapsed || collapsedState.right > 1) {
      log(`  [INFO] 折叠后侧栏未完全收起（right=${Math.round(collapsedState.right)}px）——非骨架折叠契约，跳过唤出位置检测`);
    } else {
      await page.mouse.move(8, 400); // 悬停屏幕左缘热区（::before 14px）
      await page.waitForTimeout(450); // 等 hover 滑入过渡
      const revealState = await page.evaluate(() => {
        const sb = document.querySelector('.sidebar, [class*="sidebar"]');
        const tb = document.querySelector('.topbar, [class*="topbar"]');
        const sr = sb.getBoundingClientRect();
        const tr = tb ? tb.getBoundingClientRect() : null;
        return {
          sbTop: Math.round(sr.top), sbRight: Math.round(sr.right),
          tbBottom: tr ? Math.round(tr.bottom) : null, tbTop: tr ? Math.round(tr.top) : null,
          hasTopbar: !!tb,
        };
      });
      const revealed = revealState.sbRight > 100;
      if (!revealed) {
        log('  [INFO] 悬停左缘未唤出侧栏（无热区实现），跳过遮挡判定');
      } else if (revealState.hasTopbar && revealState.sbTop < revealState.tbBottom - 1) {
        addFail('D6_nav_collapse', 'NAV_COLLAPSE_OCCLUDE', '.sidebar',
          `唤出侧栏 top=${revealState.sbTop}px 遮盖 topbar（topbar bottom=${revealState.tbBottom}px，重叠 ${revealState.tbBottom - revealState.sbTop}px）`);
        log(`  [FAIL] 唤出的侧栏遮盖 topbar（sidebar top=${revealState.sbTop} < topbar bottom=${revealState.tbBottom}）`);
      } else {
        log(`  [OK] 唤出侧栏不遮盖 topbar（sidebar top=${revealState.sbTop}px${revealState.hasTopbar ? `，topbar bottom=${revealState.tbBottom}px` : '，无 topbar'}）`);
      }
    }
    // 复原：移开鼠标（脱离热区 hover）→ 强制恢复展开态（幂等，防 D6/D6.5 状态耦合）
    await page.mouse.move(640, 400);
    await page.waitForTimeout(300);
    await page.evaluate(() => {
      if (document.body.classList.contains('nav-collapsed')) {
        document.body.classList.remove('nav-collapsed');
        const sb = document.querySelector('.sidebar, [class*="sidebar"]');
        if (sb) sb.style.top = '';
        const btn = document.querySelector('[data-nav-toggle]');
        if (btn) btn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // ---- D3: 弹窗闭环 ----
  log('\n--- D3: 弹窗闭环 ---');
  // v2.2 升级 3：collectModalTriggers 选择器已对齐 run-audit allOpenBtns（27 个候选选择器 +
  //   同口径可见过滤/标注排除/去重），modalId 可能为 null（启发式按钮），闭环检测改用
  //   openModalViaTrigger/closeVisibleModal（precise 弹窗优先 + modalSelectors 兜底 + flaky 重试）
  const triggers = await page.evaluate(probes.collectModalTriggers);
  log(`  [INFO] 首屏弹窗触发器 ${triggers.length} 个`);
  let modalFail = 0;
  let modalTested = 0;
  // v2.1 修复 #2 + v2.2 升级 2：触发器逐页收集 + 合计截断
  //   v2.1：deep 逐页收集（上限 40），fast 仅首屏前 10 → v2.1 回归残余 D3×4 不一致
  //        （非首屏页触发器漏检，fast 只测首屏可见触发器）
  //   v2.2：fast 也逐页收集，上限 10→20（覆盖翻倍且含非首屏页）；每页切换等待降为 300ms
  //        控制 fast <90s 预算（deep 维持 500ms / 40 上限不变）
  //   v2.1 实证参照：p10 曾输出 "[WARN] 触发器共 20 个，仅检测前 10 个"
  //   注：collectModalTriggers 只返回当前可见页的可见触发器（非当前页 display:none 被过滤），
  //       故必须逐页切换收集（首屏单次收集取不到非首屏页触发器）
  const D3_CAP = args.deep ? 40 : 20;
  const d3PageWait = args.deep ? 500 : 300;
  const d3Groups = []; // [{ pageId: string|null, triggers: 该页可见触发器 }]
  const allPageIds = await page.evaluate(() => Array.from(document.querySelectorAll('[data-page-id]')).map((p) => p.getAttribute('data-page-id')));
  if (allPageIds.length === 0) {
    log('  [WARN] 未检测到 [data-page-id] 页面，D3 回退首屏模式');
    d3Groups.push({ pageId: null, triggers });
  } else {
    log(`  [INFO] 逐页收集触发器：${allPageIds.length} 页，每页切换等待 ${d3PageWait}ms（合计上限 ${D3_CAP}）`);
    for (const pid of allPageIds) {
      await switchToPage(page, pid, d3PageWait);
      const pageTriggers = await page.evaluate(probes.collectModalTriggers);
      if (pageTriggers.length > 0) d3Groups.push({ pageId: pid, triggers: pageTriggers });
    }
    // 跨页去重：固定工具栏触发器（页面容器之外）会在每页重复收集，同 selector+text 只保留首次
    const seenTriggers = new Set();
    for (const g of d3Groups) {
      g.triggers = g.triggers.filter((t) => {
        const key = t.selector + '|' + t.text;
        if (seenTriggers.has(key)) return false;
        seenTriggers.add(key);
        return true;
      });
    }
    for (let i = d3Groups.length - 1; i >= 0; i--) {
      if (d3Groups[i].triggers.length === 0) d3Groups.splice(i, 1);
    }
  }
  // 合计截断到上限（逐组顺序分配预算）
  const d3Total = d3Groups.reduce((n, g) => n + g.triggers.length, 0);
  // v2.4 改动 4：D3 双计数输出——显式触发器（带 data-open-modal）vs 启发式命中（其余选择器）。
  //   纯输出增强（不改收集/判定逻辑）：启发式占比高 → L3 归因应指向"补显式 data-open-modal 契约"
  {
    const d3Explicit = d3Groups.reduce((n, g) => n + g.triggers.filter((t) => t.modalId != null).length, 0);
    const d3Heuristic = d3Total - d3Explicit;
    log(`  [INFO] D3 触发器：显式 ${d3Explicit} 个 + 启发式 ${d3Heuristic} 个 = 合计 ${d3Total}`);
  }
  if (d3Total > D3_CAP) {
    log(`  [WARN] 触发器共 ${d3Total} 个，仅检测前 ${D3_CAP} 个`);
    let budget = D3_CAP;
    for (const g of d3Groups) {
      const take = Math.min(g.triggers.length, budget);
      g.triggers = g.triggers.slice(0, take);
      budget -= take;
      if (budget <= 0) break;
    }
  }
  // 闭环检测节奏：对齐 run-audit D3（precise 弹窗优先 + modalSelectors 兜底 + flaky 重试一次）；
  //   fast 收紧轮询预算（showMs 400 / 重试 300+800 / 关闭 1200）保 <90s，
  //   deep 对齐 run-audit 量级（MODAL_SHOW 2000 / 重试 500+2000 / 关闭 2000）
  const d3OpenCfg = args.deep
    ? { showMs: 2000, retryWaitMs: 500, retryPollMs: 2000, hidePollMs: 2000 }
    : { showMs: 400, retryWaitMs: 300, retryPollMs: 800, hidePollMs: 1200 };
  for (const g of d3Groups) {
    if (g.pageId !== null) await switchToPage(page, g.pageId, d3PageWait); // 检测时切回触发器所在页，保证可见可点击
    for (const t of g.triggers) {
      // 打开阶段（对齐 run-audit D3 Evaluate 1：点击 → precise 定位 → 兜底扫描 → flaky 重试）
      const openRes = await page.evaluate(probes.openModalViaTrigger, {
        selector: t.selector, text: t.text, modalId: t.modalId,
        modalSels: MODAL_SELECTORS,
        showMs: d3OpenCfg.showMs, retryWaitMs: d3OpenCfg.retryWaitMs, retryPollMs: d3OpenCfg.retryPollMs,
      });
      if (!openRes.found) {
        // 按钮已不在 DOM：跳过不计失效（对齐 run-audit "按钮已不在 DOM，跳过"）
        log(`  [WARN] 触发器"${t.text}"（${t.selector}）已不在 DOM，跳过`);
        continue;
      }
      modalTested++;
      if (!openRes.modalSel) {
        // 失败归因：modalId 精确弹窗是否存在于 DOM（区分 MODAL_NO_TRIGGER / MODAL_OPEN_FAIL）
        let rootCause = 'MODAL_OPEN_FAIL';
        let detail = `点击后无可见弹窗（modalId=${t.modalId ?? '-'}, retried=${openRes.retried}）`;
        if (t.modalId) {
          const mv = await page.evaluate(probes.isModalVisible, t.modalId);
          if (!mv.found) { rootCause = 'MODAL_NO_TRIGGER'; detail = `modal ${t.modalId} 不存在（触发器 ${t.selector}）`; }
          else detail = `点击后 modal ${t.modalId} 未显示 (display=${mv.display})`;
        }
        addFail('D3_modal_close', rootCause, `触发器"${t.text}"`, detail);
        modalFail++;
        continue;
      }
      // 关闭阶段（对齐 run-audit D3 Evaluate 2：弹窗内优先找关闭控件 → 全局兜底 → 轮询隐藏）
      const closeRes = await page.evaluate(probes.closeVisibleModal, {
        modalSel: openRes.modalSel, closeSels: MODAL_CLOSE_SELECTORS, modalSels: MODAL_SELECTORS,
        hidePollMs: d3OpenCfg.hidePollMs,
      });
      if (!closeRes.closeBtnFound) {
        addFail('D3_modal_close', 'MODAL_NO_CLOSE', `弹窗(${openRes.modalSel})`, `触发器"${t.text}"打开后无关闭控件`);
        modalFail++;
        // ESC 兜底关闭以免阻塞后续触发器（对齐 run-audit）
        await page.keyboard.press('Escape').catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }
      if (closeRes.stillVisible) {
        addFail('D3_modal_close', 'MODAL_CLOSE_FAIL', `弹窗(${openRes.modalSel})`, `点击关闭(${closeRes.closeSelector})后仍可见`);
        modalFail++;
        await forceHideModals(page); // 强制隐藏以继续后续触发器（对齐 run-audit）
        await page.waitForTimeout(200);
      }
    }
  }
  if (modalTested === 0) log('  [SKIP] 无弹窗触发器（或均不可见）');
  else if (modalFail === 0) log(`  [OK] ${modalTested} 个弹窗闭环正常`);
  else log(`  [FAIL] ${modalFail}/${modalTested} 个弹窗闭环断裂`);

  // ---- D9/D10: 标注协同/激活（须先激活标注模式，否则 marker/dot 本就隐藏，直接判 FAIL 会误报）----
  log('\n--- D9/D10: 标注协同与激活 ---');
  const gotoAnnotationPage = async () => {
    await page.goto(URL + '?annotations=1', { waitUntil: 'networkidle', timeout: 20000 }).catch(() => {});
    await page.waitForTimeout(1500);
    return page.evaluate(probes.collectAnnotationState);
  };
  const logAnnoState = (st) => {
    log(`  [INFO] L2 zone=${st.zoneCount}, L3 element=${st.elementCount}, marker=${st.markerCount}(可见${st.visibleMarkers}), dot=${st.dotCount}(可见${st.visibleDots}), 面板=${st.hasPanel}, __ANNOTATION_DATA__=${st.annotationDataPresent}`);
  };
  let anno = await gotoAnnotationPage();
  logAnnoState(anno);

  // v2.3 改动 1：D10 静态数量一致性检查（声明 vs DOM）——置于面板激活判断之前，不依赖面板激活。
  //   背景：p10 首轮 audit D10 fail 27（8 页全部"声明 4，DOM 8"翻倍）旧版漏检，只查可见性不查数量
  {
    const cc = await page.evaluate(checkAnnotationCountConsistency);
    if (!cc.hasData) {
      log('  [SKIP] 数量一致性检查：window/script 均未解析到 __ANNOTATION_DATA__');
    } else if (!cc.mismatch) {
      log(`  [OK] D10: 标注数量一致（声明=DOM: zones ${cc.declaredZones}, elements ${cc.declaredElements}）`);
    } else {
      const N = cc.declaredZones + cc.declaredElements;
      const M = cc.domZones + cc.domElems;
      log(`  [FAIL] D10: 标注数量不一致——声明 ${N}（zones:${cc.declaredZones}, elements:${cc.declaredElements}），DOM ${M}（zones:${cc.domZones}, elements:${cc.domElems}）`);
      const lines = [];
      for (const p of cc.pages) {
        if (!p.mismatch) continue;
        if (p.zones.declaredCount !== p.zones.effDomCount) lines.push(`页面 ${p.pid} L2: 声明 ${p.zones.declaredCount} vs DOM ${p.zones.domCount}`);
        if (p.zones.missing.length > 0) lines.push(`页面 ${p.pid} L2 缺失: ${p.zones.missing.join(', ')}`);
        if (p.zones.extra.length > 0) lines.push(`页面 ${p.pid} L2 多余/重复: ${p.zones.extra.join(', ')}`);
        if (p.elements.declaredCount !== p.elements.effDomCount) lines.push(`页面 ${p.pid} L3: 声明 ${p.elements.declaredCount} vs DOM ${p.elements.domCount}`);
        if (p.elements.missing.length > 0) lines.push(`页面 ${p.pid} L3 缺失: ${p.elements.missing.join(', ')}`);
        if (p.elements.extra.length > 0) lines.push(`页面 ${p.pid} L3 多余/重复: ${p.elements.extra.join(', ')}`);
      }
      log('         差异明细（前 10 条）:');
      lines.slice(0, 10).forEach((l) => log('           - ' + l));
      const badPages = cc.pages.filter((p) => p.mismatch).map((p) => p.pid).join(', ');
      addFail('D10_full_activation', 'ANNOTATION_COUNT_MISMATCH', `页 ${badPages}`,
        `声明 ${N}（zones:${cc.declaredZones}, elements:${cc.declaredElements}）≠ DOM ${M}（zones:${cc.domZones}, elements:${cc.domElems}），不一致页: ${badPages}`);
    }
    if (cc.hasData && (cc.globalDomZones > 0 || cc.globalDomElements > 0)) {
      log(`  [INFO] 检测到无页归属标注（弹窗/全局容器）: zones ${cc.globalDomZones}, elements ${cc.globalDomElements}（P020 建议移入 [data-page-id] 内）`);
    }
  }

  // v5.18 P0-A8：pages_tested 记录实际测试的页面数（供 diagnose-result.json 输出）
  // v2.1 修复 #3：所有路径 pages_tested ≥ 1（fast=1，deep=实际遍历页数）——旧版数据缺失/面板未激活
  //   早退与页面列表为空时均不赋值（恒 0），导致 p4/p9 mode=deep 但 pages_tested=0、逐页遍历实际未执行
  let pagesTested = 0;

  // v2.2 升级 1：D10 逐元素可见性校验聚合（probes.checkAnnotationElementsVisible 逐页累计，
  //   修复 v2.1 残余 D10×4 不一致：diagnose 汇总"标注状态正常"弱于 audit 逐元素 rect 校验）
  let d10ElemTotal = 0;
  let d10ElemInvisible = 0;
  const d10InvisibleDetails = [];

  const noAnnotationData = !anno.annotationDataPresent && anno.zoneCount === 0 && anno.elementCount === 0;
  let panelReady = anno.hasPanel;

  if (noAnnotationData) {
    addFail('D10_full_activation', 'ANNOTATION_NO_DATA', '-', '无 __ANNOTATION_DATA__ 且无 L2/L3 标注元素');
    pagesTested = 1; // 数据缺失早退：仍记录首屏已测（v2.1 修复 #3）
  } else if (!panelReady) {
    // v2.1 修复 #1：面板未激活不再 [SKIP] 短路——旧版此处直接跳过激活检测并输出"[OK] 标注状态正常"
    //   （计 0 失效），而 run-audit 点击 [data-annotation-toggle] 激活后逐页检出 D9/D10 FAIL，
    //   diagnose-audit D10 一致率仅 40.7%。现对齐 run-audit"启用标注模式"流程：
    //   点击 toggle → 500ms → 复查 .annotation-panel 可见性（穿透 Shadow DOM），失败计入失效
    log('  [INFO] 标注面板未激活，尝试点击 [data-annotation-toggle] 激活');
    const act = await tryActivatePanel(page);
    if (act.ok) {
      log('  [OK] 面板激活成功（toggle 点击后 .annotation-panel 可见），继续 D9/D10 检测');
      anno = await page.evaluate(probes.collectAnnotationState);
      logAnnoState(anno);
      panelReady = true;
    } else {
      const detail = !act.clicked
        ? '无 [data-annotation-toggle] 且面板未激活（?annotations=1 未生效或引擎未加载）'
        : `点击 [data-annotation-toggle] 后 .annotation-panel 仍不可见 (found=${act.found}, display=${act.display})`;
      addFail('D10_full_activation', 'ANNOTATION_PANEL_ACTIVATE_FAIL', '-', detail);
      pagesTested = 1; // 激活失败早退：仍记录首屏已测（v2.1 修复 #3）
    }
  }

  if (!noAnnotationData && panelReady) {
    // ---- 面板卡片序检测（v5.20.2 UAT 四轮新增——codex-p10 实证 L3 卡片徽章乱序）----
    // 卡片徽章须按引擎编码升序（与页面 dot/marker 圆内序号一致）；
    // 旧引擎按声明序渲染，AI 声明序与 DOM 序错位时徽章乱序（8/8 页面实证）
    const cardOrderProbe = await page.evaluate(() => {
      const host = document.getElementById('demora-annotation-host');
      const root = host && host.shadowRoot;
      if (!root) return { ok: false };
      const activeTabBtn = root.querySelector('.panel-tabs .tab-btn.active');
      const prevTab = activeTabBtn ? activeTabBtn.getAttribute('data-tab') : null;
      const CODE_RE = /^P\d+-L[23]-\d{3}$/;
      const readTags = (tabName, tagSel) => {
        const tab = root.querySelector('.panel-tabs .tab-btn[data-tab="' + tabName + '"]');
        if (!tab) return [];
        tab.click(); // renderPanel 同步重渲染
        return Array.from(root.querySelectorAll('.panel-body ' + tagSel))
          .map((t) => (t.textContent || '').trim());
      };
      const l3Tags = readTags('L3', '.l3-tag');
      const l2Tags = readTags('L2', '.l2-tag');
      // 恢复原 active tab（防影响后续 D9.3/D9.4 协同检测）
      if (prevTab) {
        const prev = root.querySelector('.panel-tabs .tab-btn[data-tab="' + prevTab + '"]');
        if (prev) prev.click();
      }
      const isAsc = (arr) => arr.every((v, i) => i === 0 || arr[i - 1] <= v);
      const l3Codes = l3Tags.filter((t) => CODE_RE.test(t));
      const l2Codes = l2Tags.filter((t) => CODE_RE.test(t));
      return { ok: true, l3Codes, l2Codes, l3Asc: isAsc(l3Codes), l2Asc: isAsc(l2Codes) };
    });
    if (cardOrderProbe.ok) {
      const l3c = cardOrderProbe.l3Codes;
      const l2c = cardOrderProbe.l2Codes;
      if (l3c.length >= 2 && !cardOrderProbe.l3Asc) {
        addFail('D9_panel_card_order', 'PANEL_CARD_ORDER', '.l3-tag',
          `L3 卡片徽章非升序: [${l3c.join(' → ')}]`);
        log(`  [FAIL] L3 面板卡片序乱序（${l3c.join(' → ')}）`);
      } else if (l2c.length >= 2 && !cardOrderProbe.l2Asc) {
        addFail('D9_panel_card_order', 'PANEL_CARD_ORDER', '.l2-tag',
          `L2 卡片徽章非升序: [${l2c.join(' → ')}]`);
        log(`  [FAIL] L2 面板卡片序乱序（${l2c.join(' → ')}）`);
      } else {
        log(`  [OK] 面板卡片序升序（L3 ${l3c.length} 张${l3c.length >= 2 ? '：' + l3c[0] + ' → ' + l3c[l3c.length - 1] : ''}；L2 ${l2c.length} 张）`);
      }
    }

    // 标注已激活：检测点击 marker/dot 是否有激活反馈（D9/D10 核心，可见性统计仅作 INFO 不判 FAIL，
    //   因为非当前页的 marker/dot 在逐页切换时本就 display:none，判 FAIL 会误报）
    // v5.18 P0-A2：D9.3/D9.4 双侧检测（与 run-audit D9_l2_coop / D9_l3_coop 对齐），
    //   对称检测 L3 dot 的 targetDotActive 身份校验
    //
    // v5.18 P0-A8：逐页遍历实现（--deep：D9.3/D9.4 + 激活抽样逐页执行，预算 240s）
    //
    // v2.3 改动 3：fast 模式 D10 可见性也逐页遍历（每页切换 300ms，8 页 ≈ 4s，<90s 无压力）
    //   背景：旧版 fast 仅测首屏可见性（pageIdsToTest=[null]），D3 已自 v2.2 逐页收集，
    //   本次让 D10 可见性对齐——可见性逐页（全页收集），激活抽样回起始页（见改动 2）
    let pageIdsToTest;
    const getPageIds = () => page.evaluate(() => Array.from(document.querySelectorAll('[data-page-id]')).map((p) => p.getAttribute('data-page-id')));
    let allPageIds = await getPageIds();
    if (allPageIds.length === 0) {
      // v2.1 修复 #3：?annotations=1 页取不到页面列表时，先 goto 根 URL 等 networkidle 再取
      //   （覆盖初始 HTML 无 data-page-id / JS 延迟渲染 / query 变体导致列表为空的场景）
      log('  [WARN] 标注页未检测到 [data-page-id]，尝试根 URL 重新获取页面列表');
      await page.goto(URL, { waitUntil: 'networkidle', timeout: 20000 }).catch(() => {});
      await page.waitForTimeout(800);
      allPageIds = await getPageIds();
      if (allPageIds.length > 0) {
        // 中途离开过标注页：重新进入标注模式并确保面板激活
        log(`  [INFO] 根 URL 检测到 ${allPageIds.length} 个页面，重新进入标注模式`);
        anno = await gotoAnnotationPage();
        logAnnoState(anno);
        panelReady = anno.hasPanel;
        if (!panelReady) {
          const act2 = await tryActivatePanel(page);
          if (act2.ok) panelReady = true;
          else addFail('D10_full_activation', 'ANNOTATION_PANEL_ACTIVATE_FAIL', '-', '根 URL 重取页面列表后，重新激活标注面板失败');
        }
      }
    }
    const d10PageWait = args.deep ? 500 : 300; // fast 300ms 控预算（对齐 D3 fast 口径），deep 维持 500ms
    if (allPageIds.length === 0) {
      // v2.1 修复 #3：仍为空则回退首屏模式（pagesTested=1，而非 0）
      log('  [WARN] 未检测到 [data-page-id] 页面，回退首屏模式');
      pageIdsToTest = [null];
    } else {
      pageIdsToTest = allPageIds;
    }
    // v2.3 改动 3：pages_tested 口径同步——fast 也记实际遍历页数（不再恒 1）；无页面 demo 记 1
    pagesTested = pageIdsToTest.length;
    if (pageIdsToTest[0] === null) log('  [INFO] D10 可见性逐页：1 页（首屏模式，无 [data-page-id]）');
    else log(`  [INFO] D10 可见性逐页：${pagesTested} 页（每页切换等待 ${d10PageWait}ms）`);

    if (panelReady) {
      // v2.3 改动 2：记录起始页——激活抽样在逐页可见性之后回此页执行（fast 抽前 3 个 marker）
      const startPageId = await page.evaluate(() => {
        const vp = document.querySelector('[data-page-id]:not([hidden])');
        return vp ? vp.getAttribute('data-page-id') : null;
      });
      // v2.3 改动 2 / v2.4 改动 1：激活断言抽样统计（v2.4 起分层：fast 起始页一轮 L2×1+L3×2，
      //   deep 每页同配额；actPassL2/actPassL3 分层计数供输出"L2×a, L3×b"）
      let actSampleTotal = 0;
      let actSamplePass = 0;
      let actSampleL2 = 0;
      let actSampleL3 = 0;
      let actPassL2 = 0;
      let actPassL3 = 0;
      const actSampleFailDetails = [];
      // v2.4 改动 2：随页记录含分页/筛选/tab 控件的页（循环后对命中页执行序列探针）
      const seqProbePages = [];

      // 对每个页面执行检测：可见性逐页（v2.3 改动 3 起 fast 也逐页）；
      //   D9.3/D9.4 deep 每页执行、fast 仅起始轮一次（首屏协同检测保 <90s，激活覆盖由抽样补足）
      for (let pi = 0; pi < pageIdsToTest.length; pi++) {
        const pageId = pageIdsToTest[pi];
        if (pageId !== null) {
          log(`  [INFO] 切换到页面: ${pageId}`);
          await switchToPage(page, pageId, d10PageWait);
        }

        // v2.2 升级 1 + v2.3 改动 3：D10 逐元素可见性谓词校验（当前可见页内全部
        //   .l2-marker/.l3-dot 的 rect + display/visibility/opacity，对齐 run-audit
        //   'marker/dot not visible' 判定）。fast/deep 均逐页累计。
        //   置于 D9.3/D9.4 之前，保证在无点击副作用的原始状态下采样
        const elemVis = await page.evaluate(probes.checkAnnotationElementsVisible);
        d10ElemTotal += elemVis.length;
        for (const ev of elemVis) {
          if (!ev.visible) { d10ElemInvisible++; d10InvisibleDetails.push(ev); }
        }

        // v2.4 改动 2：随页探测分页/筛选/tab 控件（命中页在循环后执行序列探针；
        //   探测本身单次 evaluate，成本可忽略，无控件页循环后直接跳过）
        const navCtl = await page.evaluate(detectNavControls);
        if (navCtl.hasControls) seqProbePages.push(pageId);

        // D9.3/D9.4：deep 每页；fast 仅第一轮（pi===0）执行一次
        if (args.deep || pi === 0) {
          // D9.3：L2 marker 协同检测（在当前页面执行）
          const actTest = await page.evaluate(probes.clickFirstMarkerAndObserve);
          if (actTest.tested && !actTest.activated) {
            // v5.18 P0-A2：失败明细包含 targetZoneHighlighted 身份校验结果（便于定位是身份不匹配还是数量为 0）
            const detail = `点击 L2 marker(zone=${actTest.targetZoneId})后协同缺失: highlightedZones=${actTest.highlightedZoneCount}, activeCards=${actTest.activeCardCount}, targetZoneHighlighted=${actTest.targetZoneHighlighted}`;
            addFail('D9_l2_coop', 'ANNOTATION_NO_ACTIVATE', '首个可见 marker', detail);
          } else if (!actTest.tested) {
            log('  [SKIP] 无可见 marker 可点击（' + (actTest.reason || '') + '）');
          }
          // v2.4 改动 3：D9.3 面板遮挡检测点（对齐 run-audit L2656-2671 判定）
          //   背景：v2.3 回归 p6 配对的 D9.3 面板遮挡（paddingRight=320px 让位加在内层
          //   容器，外层交互元素仍与面板 rect 相交）在 diagnose 无检测点。判定：面板激活后
          //   取首个视口内可见交互元素（button/a[href]/input/select/[role=button]，排除
          //   面板内/宿主元素）rect 与 .annotation-panel rect 求交，相交即让位未生效 → FAIL
          if (actTest.tested) {
            const occ = await page.evaluate(() => {
              const host = document.getElementById('demora-annotation-host');
              const sr = host ? host.shadowRoot : null;
              const panel = sr ? sr.querySelector('.annotation-panel') : document.querySelector('.annotation-panel');
              if (!panel) return { hasPanel: false };
              const ps = window.getComputedStyle(panel);
              if (ps.display === 'none') return { hasPanel: false };
              // 让位检查：data-annotation-root 的 computed padding-right（audit 同款口径）
              const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
              const cs = window.getComputedStyle(contentRoot);
              const paddingRight = parseInt(cs.paddingRight || '0', 10);
              // 首个视口内可见交互元素（对齐 run-audit L2660-2666：排除面板内元素与标注宿主）
              const visibleInteractive = Array.from(document.querySelectorAll('button, a[href], input, select, [role="button"]'))
                .filter((el) => {
                  if (el.closest('.annotation-panel')) return false;
                  if (el.id === 'demora-annotation-host') return false;
                  const r = el.getBoundingClientRect();
                  return r.width > 0 && r.height > 0 && r.top >= 0 && r.top < window.innerHeight;
                })[0];
              const interactiveRect = visibleInteractive ? visibleInteractive.getBoundingClientRect() : null;
              const panelRect = panel.getBoundingClientRect();
              const overlapDetected = interactiveRect && panelRect
                ? (interactiveRect.right > panelRect.left && interactiveRect.left < panelRect.right)
                : false;
              return {
                hasPanel: true, overlapDetected, paddingRight,
                interactiveText: visibleInteractive ? (visibleInteractive.textContent || '').trim().slice(0, 20) : null,
              };
            });
            if (occ.hasPanel && occ.overlapDetected) {
              log(`  [FAIL] D9.3: 面板激活后页面交互元素被遮挡（与面板 rect 相交，paddingRight=${occ.paddingRight}px 未有效让位）`);
              addFail('D9_l2_coop', 'ANNOTATION_PANEL_OCCLUDE',
                occ.interactiveText ? `交互元素"${occ.interactiveText}"` : '首个视口内交互元素',
                `面板激活后交互元素与 .annotation-panel rect 相交（paddingRight=${occ.paddingRight}px 让位未作用于该元素所在容器）`);
            } else if (occ.hasPanel) {
              log('  [OK] D9.3: 面板无遮挡');
            }
          }
          // D9.4：L3 dot 协同检测（与 run-audit D9.4 对称，在当前页面执行）
          const dotTest = await page.evaluate(probes.clickFirstDotAndObserve);
          if (dotTest.tested && !dotTest.activated) {
            const detail = `点击 L3 dot(elem=${dotTest.targetElementId})后协同缺失: activeDots=${dotTest.activeDotCount}, activeCards=${dotTest.activeCardCount}, targetDotActive=${dotTest.targetDotActive}`;
            addFail('D9_l3_coop', 'ANNOTATION_NO_ACTIVATE', '首个可见 dot', detail);
          } else if (!dotTest.tested) {
            log('  [SKIP] 无可见 dot 可点击（' + (dotTest.reason || '') + '）');
          }
        }

        // v2.3 改动 2 / v2.4 改动 1（deep 路径）：每页执行一轮分层激活断言
        //   （L2×1 + L3×2，L3 优先表格行内/分页容器邻近标注，对齐 run-audit D10 激活判定）
        if (args.deep) {
          const s = await page.evaluate(activateSampleMarkers);
          actSampleTotal += s.tested;
          actSampleL2 += s.testedL2;
          actSampleL3 += s.testedL3;
          for (const r of s.results) {
            if (r.activated) {
              actSamplePass++;
              if (r.kind === 'L2') actPassL2++; else actPassL3++;
            } else {
              actSampleFailDetails.push(`页面 ${pageId ?? '(首屏)'} ${r.kind}#${r.idx}(${r.kind === 'L2' ? 'zone=' + r.zoneId : 'elem=' + r.elementId}): ${r.kind === 'L2' ? 'zoneHighlighted=' + r.targetZoneHighlighted : 'dotActive=' + r.targetDotActive}, activeCards=${r.activeCardCount}`);
            }
          }
        }
      }

      // v2.4 改动 2：序列探针——对"含分页/筛选/tab 控件"的页执行最小回归序列
      //   （点分页→离页→返回→复查 rect；p6 P02 分页污染实证序列）。
      //   置于逐页可见性之后、激活抽样之前：序列探针要求纯导航态原始状态（激活抽样点击
      //   marker 会开面板产生副作用）；探针结束 best-effort 复位回第 1 页。
      //   预算：fast 限前 2 个命中页（通常 1-2 页，单页 ~1.5-4s），deep 全部命中页（240s 预算）
      if (seqProbePages.length > 0) {
        const seqTargets = args.deep ? seqProbePages : seqProbePages.slice(0, 2);
        for (const pid of seqTargets) {
          if (pid !== null) await switchToPage(page, pid, d10PageWait);
          const res = await runSequenceProbe(page, pid, allPageIds);
          if (res.skipped) continue; // 控件存在但无可点页码（如仅 tab/select），不计失效
          if (res.regressions.length > 0) {
            log(`  [FAIL] D10: 序列回归失效——${res.regressions.length} 个标注在翻页往返后变为不可见（分页/筛选状态污染嫌疑，见 SKILL 显隐状态位规范）`);
            res.regressions.slice(0, 5).forEach((g) => {
              log(`         - [${g.kind}] ${g.id ?? '(无id)'} ${g.reason === 'lost' ? '元素丢失' : 'rect=0x0/不可见'}（页 ${pid ?? '(首屏)'}）`);
            });
            addFail('D10_full_activation', 'ANNOTATION_SEQ_REGRESSION',
              `页 ${pid ?? '(首屏)'} 标注 ${res.regressions.slice(0, 5).map((g) => g.kind + ':' + (g.id ?? '?')).join(', ')}`,
              `"点分页(${res.btnText})→离页→返回"序列后 ${res.regressions.length} 个此前可见标注不可见：` +
              res.regressions.slice(0, 3).map((g) => `[${g.kind}] ${g.id ?? '(无id)'} ${g.reason}`).join('; '));
          } else {
            log(`  [OK] D10: 分页往返序列探针通过（页 ${pid ?? '首屏'}，${res.kept}/${res.total} 保持可见）`);
          }
        }
      }

      // v2.3 改动 2 / v2.4 改动 1（fast 路径）：回起始页执行一轮分层激活断言
      //   （L2×1 + L3×2，总抽样 3 个与旧版预算持平；序列探针可能已切页，此处回起始页复位）
      if (!args.deep) {
        if (startPageId) await switchToPage(page, startPageId, d10PageWait);
        const s = await page.evaluate(activateSampleMarkers);
        actSampleTotal = s.tested;
        actSampleL2 = s.testedL2;
        actSampleL3 = s.testedL3;
        for (const r of s.results) {
          if (r.activated) {
            actSamplePass++;
            if (r.kind === 'L2') actPassL2++; else actPassL3++;
          } else {
            actSampleFailDetails.push(`起始页(${startPageId ?? '首屏'}) ${r.kind}#${r.idx}(${r.kind === 'L2' ? 'zone=' + r.zoneId : 'elem=' + r.elementId}): ${r.kind === 'L2' ? 'zoneHighlighted=' + r.targetZoneHighlighted : 'dotActive=' + r.targetDotActive}, activeCards=${r.activeCardCount}`);
          }
        }
      }

      // 激活抽样汇总输出（v2.3 改动 2 输出信号 / v2.4 改动 1 分层计数 L2×a, L3×b）
      if (actSampleTotal > 0) {
        if (actSamplePass === actSampleTotal) {
          log(`  [OK] D10: 激活断言抽样 ${actSamplePass}/${actSampleTotal} 通过（L2×${actPassL2}, L3×${actPassL3}）`);
        } else {
          log(`  [FAIL] D10: 标注激活断言失败（${actSampleTotal - actSamplePass}/${actSampleTotal} 个标注点击后未激活：L2 ${actSampleL2 - actPassL2}/${actSampleL2}, L3 ${actSampleL3 - actPassL3}/${actSampleL3}）`);
          actSampleFailDetails.slice(0, 10).forEach((d) => log('         - ' + d));
          addFail('D10_full_activation', 'ANNOTATION_ACTIVATE_FAIL', `标注抽样 ${actSamplePass}/${actSampleTotal}（L2×${actPassL2}, L3×${actPassL3}）`,
            actSampleFailDetails[0] + (actSampleFailDetails.length > 1 ? `（共 ${actSampleFailDetails.length} 个失败）` : ''));
        }
        // 抽样有副作用（面板打开/zone 高亮）：统一复位关闭面板（等效 closePanel）
        await resetAnnotationPanel(page);
      } else {
        log('  [WARN] 无可见 .l2-marker/.l3-dot，激活断言抽样无对象');
      }
    } else {
      pagesTested = 1; // 重新激活失败：实际仅首屏完成检测
    }
  }

  // v2.2 升级 1 汇总：输出形态对齐 run-audit D10（[FAIL] N 个不可见 + 前 10 个明细）；
  //   不可见 >0 计入失效（ANNOTATION_ELEMENT_INVISIBLE）。仅在 D9/D10 检测实际执行时输出
  //   （无标注数据/面板激活失败路径已各自计失效，此处不重复判）
  if (!noAnnotationData && panelReady) {
    if (d10ElemTotal === 0) {
      log('  [WARN] 未检测到 .l2-marker/.l3-dot 标注元素，D10 逐元素校验无对象');
    } else if (d10ElemInvisible === 0) {
      log(`  [OK] 标注元素全部可见（${d10ElemTotal}/${d10ElemTotal}）`);
    } else {
      log(`  [FAIL] D10: ${d10ElemInvisible} 个标注元素不可见（rect=0x0 或 display:none）`);
      log('         失败明细（前 10 个）:');
      d10InvisibleDetails.slice(0, 10).forEach((d) => {
        log(`           - [${d.kind}] 页面=${d.pageId ?? '-'}, ${d.id ?? '(无id)'}, 不可见: display=${d.display}, visibility=${d.visibility}, opacity=${d.opacity}, rect=${d.rect.width}x${d.rect.height}`);
      });
      d10InvisibleDetails.slice(0, 10).forEach((d) => {
        addFail('D10_full_activation', 'ANNOTATION_ELEMENT_INVISIBLE', `${d.kind} ${d.id ?? '(无id)'}`,
          `页面=${d.pageId ?? '-'}, 不可见: display=${d.display}, visibility=${d.visibility}, rect=${d.rect.width}x${d.rect.height}（共 ${d10ElemInvisible} 个不可见）`);
      });
    }
  }
  const d9d10Fails = failures.filter(f => f.dim.startsWith('D9') || f.dim.startsWith('D10')).length;
  if (d9d10Fails === 0) log('  [OK] 标注状态正常'); else log(`  [FAIL] ${d9d10Fails} 个标注问题`);

  // ===== 汇总 =====
  const totalFail = failures.length;
  log('\n======================================================================');
  log('[SUMMARY] 确诊结论');
  log('======================================================================');
  log(`  失效总数: ${totalFail}`);
  log(`  init/全局异常: ${pageErrors.length}, console.error: ${consoleErrors.length}, 404: ${console404.length}`);

  if (totalFail > 0) {
    log('\n[逐元素失败清单 + fix_pattern]');
    failures.forEach((f, i) => {
      log(`  ${i + 1}. [${f.dim}] ${f.selector}`);
      log(`     根因: ${f.root_cause} | ${f.detail}`);
      log(`     修复: ${f.fix_pattern}`);
    });
  } else {
    log('  ✓ 0 失效，可进入 run-audit 做最终验收（全量审计只需跑 1 次）');
  }

  // 写结构化结果
  const result = {
    timestamp: new Date().toISOString(),
    demo: demoDir,
    mode: args.deep ? 'deep' : 'fast',
    pages_tested: pagesTested,
    total_failures: totalFail,
    page_errors: pageErrors,
    console_404: console404.slice(0, 20),
    failures,
    gate: totalFail === 0 ? 'PASS' : 'FAIL',
  };
  fs.writeFileSync(path.join(demoDir, 'diagnose-result.json'), JSON.stringify(result, null, 2), 'utf-8');
  log('\n[INFO] 结构化结果写入: demo/diagnose-result.json');

  await browser.close();
  stopServer();
  process.exit(totalFail === 0 ? 0 : 1);
}

main().catch(e => {
  console.error('[FAIL] 诊断异常: ' + e.message);
  try { stopServer(); } catch (_) {}
  process.exit(1);
});
