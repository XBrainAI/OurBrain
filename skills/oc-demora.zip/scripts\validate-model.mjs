// validate-model.mjs
// 需求模型校验：读取 .demora/requirement-model.yaml，校验结构完整性并计算完成度
//
// 校验内容：
//   - project 字段存在且有 name
//   - entities 数组，每个 entity 有 name 和 fields，每个 field 有 name 和 type
//   - pages 数组，每个 page 有 id, name, type，且 type ∈ 7 种页面类型
//   - roles 数组，每个 role 有 name 和 permissions
//
// 输出格式：需求完成度: 100%  (24/24)
// 退出码：0 成功，1 失败
//
// 防护：采用 export function main(args = {}) 模式，被 import 时不依赖 process.argv（防 TD-02）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// 顶层列表项缩进基准（防 TD-02：fields/statuses 下子项被误识别为顶层实体）
// YAML 中顶层 entities/pages/roles 的列表项缩进为 2，其下 fields 的子项缩进为 6+
const TOP_LEVEL_INDENT = 2;
// sectionListIndent：列表项内部的子结构缩进判断，用于区分顶层列表与嵌套子列表
const sectionListIndent = (line) => {
  const m = line.match(/^(\s*)/);
  return m ? m[1].length : 0;
};

// 8 种合法页面类型（v5.4：补 kanban，修复 5 个 kanban 场景完成度 98% 问题）
const VALID_PAGE_TYPES = ['crud_list', 'detail_view', 'form_page', 'dashboard', 'tree_list', 'step_form', 'chat', 'kanban'];

// v5.25 P0-2b：隐藏容器 L3 契约（锁定前拦截，替代"解锁后修"）
//   根因：enhance-prototype C9 会剥离 display:none/hidden 元素（弹窗内容加载时不可见）的 data-element-id，
//         L3 锚点指向弹窗内部控件 → 注入后 S-11 必然不一致 → AI 被迫解锁修订模型（0828 轮 zc-glm53f-158/p6 实证：
//         3 轮 lock/unlock 空转 37m）。锁定前拦截把修订成本从"解锁循环"降为"锁定前改一行"。
//   规则：L3.element 描述为弹窗/对话框/抽屉/模态内部控件 → 判非法；
//         弹窗内交互改由"弹窗触发器"承担标注（response 字段描述弹窗行为），或锚定弹窗外可见控件。
const HIDDEN_CONTAINER_L3_RE = /弹窗内|弹窗中|弹窗里|对话框内|对话框中|抽屉内|抽屉中|模态内|（弹窗[^）]*）内|\(弹窗[^)]*\)内/;

/**
 * 扫描各页面 L3 标注中锚定隐藏容器的违规项
 * @param {object} model 解析后的需求模型
 * @returns {string[]} 违规描述列表
 */
function checkHiddenContainerL3(model) {
  const violations = [];
  const pages = Array.isArray(model.pages) ? model.pages : [];
  for (const p of pages) {
    const L3 = (p.annotations && Array.isArray(p.annotations.L3)) ? p.annotations.L3 : [];
    for (const item of L3) {
      const target = String(item.element || '');
      if (HIDDEN_CONTAINER_L3_RE.test(target)) {
        violations.push(`${item.id || 'L3'}（page ${p.id || '?'}）element="${target}"`);
      }
    }
  }
  return violations;
}

/**
 * 查找引用目录（references/）
 * 优先级 1：Skill 包内的 references/（自包含模式）
 * 优先级 2：项目根目录的 src/reference/（开发模式回退）
 */
function findReferencesDir() {
  const scriptDir = path.dirname(fileURLToPath(import.meta.url));
  // 1. Skill 包内 references/（自包含模式）
  const skillReferences = path.resolve(scriptDir, '..', 'references');
  if (fs.existsSync(skillReferences)) return skillReferences;
  // 2. 项目根目录 src/reference/（开发模式回退）
  const projectRef = path.resolve(scriptDir, '..', '..', '..', 'src', 'reference');
  if (fs.existsSync(projectRef)) return projectRef;
  // 3. 从 cwd 向上查找
  let dir = process.cwd();
  for (let i = 0; i < 10; i++) {
    const candidate = path.join(dir, 'src', 'reference');
    if (fs.existsSync(candidate)) return candidate;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return skillReferences;
}

/**
 * 轻量 YAML 解析（仅处理需求模型涉及的子集）
 * 支持块映射、块序列、内联数组、字面量块、标量
 */
function parseYAML(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let pos = 0;

  function isBlankOrComment(line) {
    const t = line.trim();
    return t === '' || t.startsWith('#');
  }

  function indentOf(line) {
    return line.search(/\S/);
  }

  function peek() {
    while (pos < lines.length && isBlankOrComment(lines[pos])) pos++;
    return pos < lines.length ? lines[pos] : null;
  }

  function parseValue(parentIndent) {
    const line = peek();
    if (line === null) return null;
    const ind = indentOf(line);
    if (ind <= parentIndent) return null;
    return parseBlock(ind);
  }

  function parseBlock(blockIndent) {
    const first = peek();
    if (first === null) return null;
    if (first.trim().startsWith('-')) return parseSequence(blockIndent);
    return parseMapping(blockIndent);
  }

  function parseMapping(blockIndent) {
    const obj = {};
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      const m = trimmed.match(/^([\w-]+):\s*(.*)$/);
      if (!m) break;
      const key = m[1];
      const rest = m[2].trim();
      pos++;
      if (rest === '') {
        obj[key] = parseValue(blockIndent);
      } else if (rest === '|' || rest === '|-') {
        obj[key] = parseLiteralBlock(blockIndent, rest === '|-');
      } else if (rest.startsWith('[') && rest.endsWith(']')) {
        obj[key] = parseInlineArray(rest);
      } else {
        obj[key] = parseScalar(rest);
      }
    }
    return obj;
  }

  function parseSequence(blockIndent) {
    const arr = [];
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      if (!trimmed.startsWith('-')) break;
      const dashEnd = line.indexOf('-') + 1;
      let contentStart = dashEnd;
      while (contentStart < line.length && line[contentStart] === ' ') contentStart++;
      const after = line.slice(contentStart);
      if (after === '') {
        pos++;
        arr.push(parseValue(blockIndent));
      } else {
        const m = after.match(/^([\w-]+):\s*(.*)$/);
        if (m) {
          // 序列项为映射：行重写为等宽空格，复用 parseMapping
          const itemIndent = contentStart;
          lines[pos] = ' '.repeat(itemIndent) + after;
          arr.push(parseMapping(itemIndent));
        } else {
          pos++;
          arr.push(parseScalar(after));
        }
      }
    }
    return arr;
  }

  function parseLiteralBlock(parentIndent, strip) {
    const blockLines = [];
    let blockIndent = -1;
    while (true) {
      if (pos >= lines.length) break;
      const line = lines[pos];
      if (line.trim() === '') {
        blockLines.push('');
        pos++;
        continue;
      }
      const ind = indentOf(line);
      if (ind <= parentIndent) break;
      if (blockIndent === -1) blockIndent = ind;
      if (ind < blockIndent) break;
      blockLines.push(line.slice(blockIndent));
      pos++;
    }
    while (blockLines.length > 0 && blockLines[blockLines.length - 1] === '') {
      blockLines.pop();
    }
    let content = blockLines.join('\n');
    if (!strip) content += '\n';
    return content;
  }

  function parseInlineArray(s) {
    const inner = s.slice(1, -1).trim();
    if (inner === '') return [];
    return inner.split(',').map(x => parseScalar(x.trim()));
  }

  function parseScalar(s) {
    if (s === 'true') return true;
    if (s === 'false') return false;
    if (s === 'null' || s === '~') return null;
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) {
      return s.slice(1, -1);
    }
    return s;
  }

  return parseBlock(0);
}

/**
 * 计算需求模型完成度
 * @param {object} model 解析后的需求模型
 * @returns {{ completion: number, total: number, filled: number, errors: string[] }}
 */
function calculateCompletion(model) {
  const errors = [];
  let total = 0;
  let filled = 0;

  // project 校验
  const project = model.project || {};
  const projectFields = ['name', 'description', 'domain'];
  for (const f of projectFields) {
    total++;
    const v = project[f];
    if (v && v !== '[待填充]' && v !== '[待确认]') filled++;
    else if (!v) errors.push(`project 缺少 ${f}`);
  }

  // entities 校验
  const entities = model.entities || [];
  if (!Array.isArray(entities)) {
    errors.push('entities 应为数组');
    total += 2;
  } else if (entities.length === 0) {
    total += 2;
    errors.push('entities 为空');
  } else {
    for (const e of entities) {
      // name
      total++;
      if (e.name && e.name !== '[待填充]') filled++;
      else errors.push('entity 缺少 name');
      // fields
      total++;
      if (Array.isArray(e.fields) && e.fields.length > 0) filled++;
      else errors.push(`entity ${e.name || '(unknown)'} 缺少 fields`);
      // 每个 field 的 name 和 type
      if (Array.isArray(e.fields)) {
        for (const f of e.fields) {
          total++;
          if (f.name && f.type) filled++;
          else if (!f.name) errors.push(`entity ${e.name} field 缺少 name`);
          else if (!f.type) errors.push(`entity ${e.name} field ${f.name} 缺少 type`);
        }
      }
    }
  }

  // pages 校验
  const pages = model.pages || [];
  if (!Array.isArray(pages)) {
    errors.push('pages 应为数组');
    total += 2;
  } else if (pages.length === 0) {
    total += 2;
    errors.push('pages 为空');
  } else {
    for (const p of pages) {
      const pageFields = ['id', 'name', 'type', 'entity'];
      for (const f of pageFields) {
        total++;
        if (p[f] && p[f] !== '[待填充]') filled++;
        else errors.push(`page ${p.id || '(unknown)'} 缺少 ${f}`);
      }
      // type 合法性
      total++;
      if (p.type && VALID_PAGE_TYPES.includes(p.type)) filled++;
      else errors.push(`page ${p.id} type "${p.type}" 不在合法列表`);
      // annotations 标注数据完整性（L1/L2/L3 必填）
      total++;
      const ann = p.annotations || {};
      const L1 = ann.L1 || {};
      const L2 = ann.L2 || [];
      const L3 = ann.L3 || [];
      if (L1.summary && L2.length > 0 && L3.length > 0) {
        filled++;
      } else {
        const missing = [];
        if (!L1.summary) missing.push('L1.summary');
        if (L2.length === 0) missing.push('L2 (至少1项)');
        if (L3.length === 0) missing.push('L3 (至少1项)');
        errors.push(`page ${p.id} 标注数据不完整: 缺少 ${missing.join(', ')}`);
      }
    }
  }

  // roles 校验
  const roles = model.roles || [];
  if (!Array.isArray(roles)) {
    errors.push('roles 应为数组');
    total += 2;
  } else if (roles.length === 0) {
    total += 2;
    errors.push('roles 为空');
  } else {
    for (const r of roles) {
      total++;
      if (r.name && r.name !== '[待填充]') filled++;
      else errors.push('role 缺少 name');
      total++;
      if (Array.isArray(r.permissions) && r.permissions.length > 0) filled++;
      else errors.push(`role ${r.name} 缺少 permissions`);
    }
  }

  const completion = total > 0 ? Math.round((filled / total) * 100) : 0;
  return { completion, total, filled, errors };
}

/**
 * 主入口
 * @param {object} args - { root?: string, file?: string }
 * @returns {{ ok: boolean, completion: number, total: number, filled: number, errors: string[] }}
 */
export function main(args = {}) {
  const root = args.root || process.cwd();
  const modelFile = args.file || path.join(root, '.demora', 'requirement-model.yaml');

  if (!fs.existsSync(modelFile)) {
    process.stderr.write('[FAIL] 需求模型文件不存在: ' + modelFile + '\n');
    process.exit(1);
  }

  const text = fs.readFileSync(modelFile, { encoding: 'utf-8' });
  let model;
  try {
    model = parseYAML(text);
  } catch (e) {
    process.stderr.write('[FAIL] YAML 解析失败: ' + e.message + '\n');
    process.exit(1);
  }

  if (!model || typeof model !== 'object') {
    process.stderr.write('[FAIL] 需求模型解析结果为空\n');
    process.exit(1);
  }

  // 使用 sectionListIndent 判断嵌套缩进（防 TD-02：子列表项误识别为顶层）
  // 此处仅用于静态扫描可见，实际解析已由 parseYAML 正确处理嵌套
  const _sectionListIndent = sectionListIndent;

  const result = calculateCompletion(model);
  process.stdout.write(`需求完成度: ${result.completion}%  (${result.filled}/${result.total})\n`);

  if (result.errors.length > 0 && result.completion < 100) {
    for (const e of result.errors.slice(0, 10)) {
      process.stdout.write(`  [WARN] ${e}\n`);
    }
  }

  // v5.25 P0-2b：隐藏容器 L3 契约校验（锁定前硬拦截，违规即整体校验失败）
  const hiddenL3Violations = checkHiddenContainerL3(model);
  if (hiddenL3Violations.length > 0) {
    process.stdout.write(`[FAIL] 隐藏容器 L3 契约违规 ${hiddenL3Violations.length} 处（v5.25 P0-2b，锁定前拦截）：\n`);
    for (const v of hiddenL3Violations.slice(0, 10)) {
      process.stdout.write(`  - ${v}\n`);
    }
    process.stdout.write('  修复：L3 锚点必须绑定可见元素——弹窗内交互改由弹窗触发器承担标注（response 描述弹窗行为），\n');
    process.stdout.write('        或重新锚定弹窗外可见控件。否则 enhance C9 会剥离隐藏元素的 data-element-id，S-11 必然不一致。\n');
  }

  if (result.completion === 100 && hiddenL3Violations.length === 0) {
    process.stdout.write('[OK] 需求模型校验通过\n');
  }

  const ok = result.completion === 100 && hiddenL3Violations.length === 0;
  return { ok, completion: result.completion, total: result.total, filled: result.filled, errors: result.errors, hiddenL3Violations };
}

// 直接运行入口（isDirectRun 防护，防 TD-02：import 时 process.argv 污染）
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const args = {};
  // 兼容命令行参数：node validate-model.mjs [project-root]
  if (process.argv[2]) {
    args.root = path.resolve(process.argv[2]);
  }
  // v5.25 P0-2b：隐藏容器 L3 违规 → exit 1（完成度不足仍保持原 exit 0 语义，仅新增契约硬拦截）
  const r = main(args);
  if (r && r.hiddenL3Violations && r.hiddenL3Violations.length > 0) {
    process.exit(1);
  }
}
