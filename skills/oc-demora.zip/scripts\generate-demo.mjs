// generate-demo.mjs
// Phase 1 Demo 目录结构生成器（v5.0）
// v5.22：单次派发幂等（dispatchDemoAction + e._demoDispatched，根治 v5.18 P0-A7 与委托共存的双触发）+ input 实时通道
// v5.20 P1-4：route() 置顶语义修正（最近滚动祖先复位，保持公共区域 topbar 常驻，U6 澄清）
// v5.20 P1-5：导航折叠重构为 codex 风格（顶栏最左 .nav-toggle 图标按钮 + 悬停屏幕左侧唤出，U5）
// v5.20.1（UAT 三轮 U5）：折叠改完全收起（translateX -100% + 左缘 14px 悬停热区，废止 3.5rem 窄条残留）
// v5.25 P1-1（0828/0829 轮归因——审计修复循环占单案例 ~90m）：骨架预置"正确样板"原语
//   demoraApplyFilter / demoraBindFilter / demoraResetPageState / demoraSyncAnnotations，
//   语义与 run-audit 探针逐字对齐（D6_filter_consistency / D8_element_coverage / D10_full_activation），
//   route() 切页自动复位筛选/分页状态——AI 复用样板即默认正确，不再靠记住文字契约（tw-dsf-v3 RC1/RC3 实证纯契约失效）
// v5.20 P1-4：STYLE 骨架新增 app-shell 布局契约（topbar 常驻 + .content 业务滚动容器）
// v5.19 P1-2：route() 切页硬置顶（scrollTop 硬复位 + instant 兜底，替代 smooth scrollIntoView）
// v5.19 D-2：骨架预置导航折叠体系（.sidebar + [data-nav-toggle] + body.nav-collapsed，悬停自动弹出预览）
// v5.18 P0-A6/A7：route hidden 双切换 + 元素级幂等绑定
// v2.3：样式骨架预置 .btn-accent 按钮契约（.btn-primary 为弹窗触发器保留类，D3 启发式探测所致）
//
// 设计理念：
//   仅创建空目录结构和空文件，不生成任何 HTML/JS/CSS 内容。
//   Demo 的完整内容由 AI 基于 frontend-design skill 方法论从零设计。
//
// 流程：
//   1. 读取 .demora/requirement-model.yaml（验证存在）
//   2. 创建 demo/ 目录结构（空文件 + start.bat + README）
//   3. 更新 state.yaml 的 demo_protected 字段
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoraDir = path.join(projectRoot, '.demora');
  const demoDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('generate-demo.mjs — 创建 Demo 目录结构 (v5.0)');
  log('======================================================================');

  // 1. 验证需求模型存在
  const modelPath = path.join(demoraDir, 'requirement-model.yaml');
  if (!fs.existsSync(modelPath)) {
    log('[FAIL] .demora/requirement-model.yaml 不存在，请先完成 Phase 1 需求澄清');
    return { ok: false, error: 'requirement-model.yaml not found' };
  }

  // 2. 前置校验：需求模型必须已锁定（model_locked: true）
  const statePath = path.join(demoraDir, 'state.yaml');
  if (fs.existsSync(statePath)) {
    const stateText = fs.readFileSync(statePath, 'utf-8');
    const m = stateText.match(/^model_locked:\s*['"]?(\w+)['"]?/m);
    if (!m || m[1] !== 'true') {
      log('[FAIL] 需求模型未锁定，请先执行 lock-model.mjs --lock --confirm');
      process.exit(1);
    }
  } else {
    log('[FAIL] 需求模型未锁定，请先执行 lock-model.mjs --lock --confirm');
    process.exit(1);
  }

  // 3. demo_protected 检查已移除（rk3 P-1 修复）
  //   根因：lock-model --confirm 设 demo_protected=true，generate-demo 读取该标志即拒绝
  //         → Phase 1→2 转换 100% 死锁。generate-demo 仅在 Phase 2 开始时运行一次，
  //         model_locked 前置校验（步骤 2）已足够保证阶段顺序。
  //   demo 保护统一由 lock-model 管理，generate-demo 不再读取 demo_protected。

  // 4. 创建 demo/ 目录结构
  const dirs = [
    demoDir,
    path.join(demoDir, 'assets'),
  ];
  for (const d of dirs) {
    if (!fs.existsSync(d)) {
      fs.mkdirSync(d, { recursive: true });
      log(`  [OK] 创建目录: ${path.relative(projectRoot, d)}/`);
    }
  }

  // 5. 创建空文件（AI 填充）
  //    v5.15 rk3 P-5 修复：事件委托骨架在空 app.js 创建时写入（而非 enhance-prototype 阶段）
  //    根因：enhance-prototype 在 AI 填充 app.js 之后运行，isPlaceholder(length<200) 恒 false
  //          → 骨架注入永不命中。移到 generate-demo 创建空文件时写入，AI 在骨架基础上填充。
  const APP_JS_SKELETON = `// Demora 事件委托骨架（v5.18 默认可用）— 开箱处理导航/弹窗，AI 仅需扩展业务 action
// 设计定位：JS 管道层安全网（route/openModal/closeModal 默认可用）。
//   HTML 结构 / 视觉 / 内容 / 业务交互仍由 AI 基于 frontend-design skill 自由设计，本骨架不加任何设计约束。
//   即使 AI 一行 JS 不写，页面导航（data-nav/data-route）与弹窗闭环（data-open-modal/data-close）也可用，
//   从根源消除 D3 弹窗闭环 / D5 路由 / D6 导航无响应的结构性失败。
// AI 扩展业务逻辑的方式（可选，二选一或并存）：
//   1. 定义 window.handleDemoAction = function (action, target, event) { ... } 处理 data-action 业务操作
//   2. 或在本文件追加自己的 addEventListener（骨架不拦截事件，多个委托可共存）
// 按钮类契约（v2.3）：.btn-primary 为弹窗触发器保留类（D3 启发式探测 .btn-primary 为弹窗触发候选，
//   业务主按钮误用会在点击无弹窗弹出时被判 D3 FAIL——p6/p7/p4 实证）；业务主按钮（导航/提交/筛选等）
//   用 .btn-accent（style.css 骨架已预置同视觉样式）或带 data-route/data-action 属性；
//   弹窗触发按钮必须带 data-open-modal 属性

// 路由：display:none 切换 + 切页硬置顶（v5.19 P1-2）+ 高亮导航项
//   （v5.18 P0-A6：display + hidden 双切换同步维护，确保 [data-page-id]:not([hidden]) 与 display 语义一致）
//   原 v5.18 注释"禁 hidden 属性切换"已更新：双切换后 display 同步置 none，flex/grid 覆盖问题不再触发
function route(pageId) {
  document.querySelectorAll('[data-page-id]').forEach(p => {
    const isActive = (p.getAttribute('data-page-id') === pageId);
    p.style.display = isActive ? '' : 'none';
    // v5.18 P0-A6：同步维护 hidden 属性（与 display 双切换）
    //   约束：display 同步置 none 后，flex/grid 覆盖 [hidden] UA 样式的问题不再触发
    //   审计侧 [data-page-id]:not([hidden]) 与 display 语义一致
    if (isActive) {
      p.removeAttribute('hidden');
    } else {
      p.setAttribute('hidden', '');
    }
  });
  const active = document.querySelector('[data-page-id="' + pageId + '"]');
  // v5.20 P1-4 切页置顶语义修正（U6 澄清）：置顶 = 保持公共区域（topbar/标注 header），
  //   仅业务页面区域置顶。v5.19 版缺陷：scrollIntoView 兜底条件 r.top > 8 在 document 复位后
  //   仍触发（topbar 占位使 r.top = topbar 高度），把 in-flow 公共 header 顶出视口。
  //   优先级：①业务滚动容器（最近可滚祖先）scrollTop=0 —— 公共区域在容器外天然常驻；
  //           ②无滚动容器（整页滚动布局）退回 document 复位 + active 自身复位；
  //             仅 r.top < 0（真不可见）才 instant scrollIntoView 兜底（去 r.top > 8 误触发）
  var scrollParent = null;
  var node = active && active.parentElement;
  while (node && node !== document.body && node !== document.documentElement) {
    var st = window.getComputedStyle ? getComputedStyle(node) : null;
    if (st && /(auto|scroll)/.test(st.overflowY) && node.scrollHeight > node.clientHeight) { scrollParent = node; break; }
    node = node.parentElement;
  }
  if (scrollParent) {
    scrollParent.scrollTop = 0; // 业务容器置顶：公共 topbar 不参与业务滚动，保持可视
  } else {
    var sc = document.scrollingElement || document.documentElement;
    if (sc && sc.scrollTop > 0) sc.scrollTop = 0;
    if (active && active.scrollTop) active.scrollTop = 0; // section 自身可滚动时
    if (active) { var r = active.getBoundingClientRect(); if (r.top < 0) active.scrollIntoView({ behavior: 'auto', block: 'start' }); }
  }
  // v5.25 P1-1：切页后复位该页临时状态（筛选控件回默认值并触发 change/input 事件 →
  //   过滤态与分页不跨页遗留；D6_filter_consistency 遗留过滤态 / D10 分页往返序列回归的结构性根治）
  if (active) demoraResetPageState(active);
  // 导航项高亮：active class + aria-current（导航项带 data-nav 时生效）
  document.querySelectorAll('[data-nav]').forEach(n => {
    const on = n.getAttribute('data-nav') === pageId;
    n.classList.toggle('active', on);
    if (on) n.setAttribute('aria-current', 'page'); else n.removeAttribute('aria-current');
  });
  // 页面切换后重新绑定新页面元素
  document.querySelectorAll('[data-action]:not([data-demo-bound])').forEach(function (el) {
    el.setAttribute('data-demo-bound', '1');
    if (!el.onclick) {
      el.onclick = function (e) {
        dispatchDemoAction(el, e);
      };
    }
  });
}

// ============================================================
// v5.25 P1-1 正确样板（骨架默认正确——AI 业务代码必须复用以下原语，禁止删除/重写）
//   与 run-audit 探针逐字对齐：D6_filter_consistency / D8_element_coverage / D10_full_activation
//   0828/0829 轮实证：这些缺陷族的修复循环占单案例 ~90m；样板化后 AI 复用即默认正确。
// ============================================================

// [P1-1-a] 筛选全量重算（D6_filter_consistency 探针断言口径）
//   状态位（data-demora-filtered）与 style.display 由【同一行集一次遍历】写入（v2.4 显隐单轨制，
//   根治"计数变了但表格行不变"的半吊子筛选）；可选分页 pageState={page,pageSize}；
//   计数文本数字 = 可见行数（探针断言"共 N 条/行/个/件/家/项"与可见表格行一致）。
//   AI 一般不直接调用本函数，用 [P1-1-b] demoraBindFilter 绑定即可。
function demoraApplyFilter(table, matchRow, counterEl, pageState) {
  if (!table) return 0;
  var rows = table.querySelectorAll('tbody tr');
  var pageSize = (pageState && pageState.pageSize) || 0; // 0 = 不分页
  var page = (pageState && pageState.page) || 1;
  var matchedIdx = 0;
  var visible = 0;
  rows.forEach(function (tr) {
    var matched = matchRow ? !!matchRow(tr) : true;
    var onPage = matched;
    if (matched && pageSize > 0) {
      onPage = (matchedIdx >= (page - 1) * pageSize) && (matchedIdx < page * pageSize);
    }
    if (matched) matchedIdx++;
    tr.setAttribute('data-demora-filtered', onPage ? '0' : '1');
    tr.style.display = onPage ? '' : 'none';
    if (onPage) visible++;
  });
  // 注意：本常量是模板字面量，正则中的 \d 必须写成 \\d（否则生成物里 \d 被转义为字面 d，
  //   0830 构建实证：/d/ 匹配字母 d 导致筛选计数永不更新——P1-1 浏览器行为回归测试拦截）
  if (counterEl && /\\d/.test(counterEl.textContent || '')) {
    counterEl.textContent = counterEl.textContent.replace(/\\d+/, String(visible));
  }
  return visible;
}

// [P1-1-b] 筛选控件绑定（业务入口）
//   用法：demoraBindFilter(控件, { table: 表格或选择器, counterEl: 计数元素或选择器,
//         match: function(tr, control){ return 该行是否应可见（业务过滤，读 control.value） },
//         pageState: {page,pageSize} 或 function(){return {page,pageSize}}（可选）,
//         event: 'change'|'input'（可选，默认 change） })
//   绑定后控件自动标记 data-demora-filter（route() 切页时自动复位默认值并回触发 handler），
//   并立即执行一次初始筛选（显隐态与控件默认值一致，D6 遗留过滤态根治）。
function demoraBindFilter(control, opts) {
  if (!control || !opts) return;
  control.setAttribute('data-demora-filter', '1');
  var handler = function () {
    var table = typeof opts.table === 'string' ? document.querySelector(opts.table) : opts.table;
    var counterEl = typeof opts.counterEl === 'string' ? document.querySelector(opts.counterEl) : opts.counterEl;
    var pageState = typeof opts.pageState === 'function' ? opts.pageState() : opts.pageState;
    demoraApplyFilter(table, function (tr) { return opts.match(tr, control); }, counterEl, pageState);
  };
  control.addEventListener(opts.event || 'change', handler);
  if (!control.hasAttribute('data-demora-bound')) {
    control.setAttribute('data-demora-bound', '1');
    handler();
  }
}

// [P1-1-c] 切页状态复位（由骨架 route() 自动调用，AI 无需手动调用）
//   筛选控件复位默认值（data-demora-default 可自定义，缺省 select=首项 / input=空）并回触发
//   change/input 事件——业务 handler 收到事件后按默认值重算，过滤态与分页不跨页遗留。
function demoraResetPageState(pageEl) {
  if (!pageEl) return;
  pageEl.querySelectorAll('[data-demora-filter]').forEach(function (c) {
    var isSelect = c.tagName === 'SELECT';
    var def = c.getAttribute('data-demora-default');
    var defaultValue = (def !== null) ? def : (isSelect ? (c.options[0] ? c.options[0].value : '') : '');
    try { c.value = defaultValue; } catch (e) { /* 只读等异常防御 */ }
    try { c.dispatchEvent(new Event(isSelect ? 'change' : 'input', { bubbles: true })); } catch (e) {}
  });
  pageEl.querySelectorAll('[data-demora-page-of]').forEach(function (el) {
    el.setAttribute('data-demora-page', '1'); // 分页状态复位（D5 分页往返序列回归根治）
  });
}

// [P1-1-d] 动态行标注同步（D8 全实例标注 / D10 全量激活根治）
//   动态新增带 data-element-id 的元素后调用：向 __ANNOTATION_DATA__ 当前页 L3 幂等补条目
//   （element 语义键与审计 D8 对齐：aria-label → data-action → 文本截断 30），
//   并调用标注引擎 refresh()。用法：tbody.appendChild(newTr); demoraSyncAnnotations(tbody);
function demoraSyncAnnotations(scope) {
  try {
    var pageEl = (scope && scope.closest) ? scope.closest('[data-page-id]')
      : document.querySelector('[data-page-id]:not([hidden])');
    if (!pageEl) return;
    var pageId = pageEl.getAttribute('data-page-id');
    var data = window.__ANNOTATION_DATA__;
    if (!data) return;
    var pages = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages)) ? data.pages : data;
    if (!pages[pageId]) return;
    var L3 = pages[pageId].L3 = (pages[pageId].L3 || []);
    var seen = {};
    L3.forEach(function (c) { seen[c.id] = 1; });
    scope.querySelectorAll('[data-element-id]').forEach(function (el) {
      var id = el.getAttribute('data-element-id');
      if (!id || seen[id]) return;
      var label = el.getAttribute('aria-label') || el.getAttribute('data-action')
        || (el.textContent || '').trim().slice(0, 30);
      L3.push({ id: id, element: label || id, dynamic: true });
      seen[id] = 1;
    });
    if (window.__ANNOTATION_ENGINE__ && typeof window.__ANNOTATION_ENGINE__.refresh === 'function') {
      window.__ANNOTATION_ENGINE__.refresh();
    }
  } catch (e) { /* 标注同步失败不阻塞业务 */ }
}

// [P1-1-e] 审计安全契约（注释约定，违反项由 D6/D8/D10 运行时 FAIL 兜底）：
//   1. 会改变表格行数/列表长度的操作（新增/导入/生成）必须经弹窗两步确认（data-open-modal），
//      禁止单击直接改表——审计 D6 逐个点击启用按钮，中途行数增长会连锁触发 D8 覆盖率与 D10 序列回归
//      （0829 轮 zc/p6 实证：改两步弹窗确认后 D8/D10 一轮通过）
//   2. 行级同类按钮共用同一 data-action（动词），实体标识放 data-id/data-<entity> 等自有属性
//      （D8 语义键按 tagName+aria-label/data-action/文本分组，每行唯一 data-action 会被判为独立类型）
//   3. ≤4 实例的同类组全部标注；>4 实例标首个可见实例 + 卡片 element 名含"同类"说明（v5.24 契约）

// 弹窗：display 切换（避免 flex/grid 覆盖 hidden 的陷阱）
function openModal(modalId) {
  const modal = document.getElementById(modalId) || document.querySelector('[data-modal-id="' + modalId + '"]');
  if (modal) modal.style.display = '';
}
function closeModal(modal) {
  if (typeof modal === 'string') modal = document.getElementById(modal) || document.querySelector('[data-modal-id="' + modal + '"]');
  if (modal) modal.style.display = 'none';
}

// v5.22 单次派发幂等：统一派发管道——元素级 onclick（target 阶段）与 document 委托（bubble 阶段）
//   互为冗余、经 e._demoDispatched 幂等标志保证同一事件完整管道恰好执行一次。
//   冗余保障：AI 在祖先容器 stopPropagation 时，元素级 onclick 仍完成导航/弹窗/action 派发。
//   P008 组合语义：data-action 与 data-open-modal/data-nav/data-route 并存时按优先级链短路，
//   data-action 仅作静态线索（对齐 SKILL.md P008 文档契约）。
function dispatchDemoAction(target, e) {
  if (e._demoDispatched) return; // 幂等：先到的路径放行，后到的拦截
  e._demoDispatched = true;
  // v2.1 标注点击 guard：.l3-dot/.l2-marker 的点击交给标注引擎处理，不进入 demo 派发
  //   根因（ab-test P01-C-004）：dot 落在 [data-action] 容器内，点击冒泡触发导航 → 中断标注激活
  if (e.target && e.target.closest && e.target.closest('.l3-dot, .l2-marker')) return;
  if (target.hasAttribute('data-nav')) { route(target.getAttribute('data-nav')); return; }
  if (target.hasAttribute('data-route')) { route(target.getAttribute('data-route')); return; }
  if (target.hasAttribute('data-open-modal')) { openModal(target.getAttribute('data-open-modal')); return; }
  if (target.hasAttribute('data-close')) {
    const m = target.closest('.modal, [data-modal-id], [role="dialog"]');
    if (m) m.style.display = 'none';
    return;
  }
  if (target.hasAttribute('data-action')) {
    if (typeof window.handleDemoAction === 'function') {
      window.handleDemoAction(target.getAttribute('data-action'), target, e);
    }
  }
}

// 统一事件委托：closest 匹配目标，经 dispatchDemoAction 单次派发（v5.22 幂等化）
document.addEventListener('click', (e) => {
  const target = e.target.closest ? e.target.closest('[data-nav], [data-route], [data-open-modal], [data-close], [data-action]') : null;
  if (target) dispatchDemoAction(target, e);
});

// v5.20 P1-5 导航折叠（U5 重构，codex 风格）：顶栏最左 .nav-toggle 图标按钮（内联 SVG）
//   带 data-nav-toggle 属性，点击切换 body.nav-collapsed 折叠态；折叠态侧栏完全移出
//   （translateX，零残留），悬停屏幕左缘热区自动唤出完整导航（style.css 骨架接管）。
//   注意（v5.20）：按钮内为 SVG 图标，委托仅同步 aria-expanded，不覆盖按钮 DOM
//   （v5.19 的 textContent «/» 更新已随图标化移除）
// v5.20.2（UAT 四轮 U-B）：折叠唤出位置对齐侧栏原 top（topbar 底部）——
//   CSS 折叠态 top:0 会让唤出的导航从视口顶开始、遮盖 app-shell 常驻 topbar
//   （codex-p10 实证：悬停唤出的侧栏跑到 header 位置并遮盖 header）。
//   测量时机必须在 classList.toggle 之前——折叠规则 position:fixed;top:0 同步生效，
//   切换后测量恒为 0（top:0 覆盖 topbar 区域还会令鼠标停留处被侧栏覆盖、误触发
//   :hover 唤出，即 UAT 截图"跑到 header 位置遮盖 header"的直接成因）。
//   切换前测展开态 layout top（= topbar 底部）写入内联 top；无 topbar 布局测量值
//   为 0 时清空（回落 CSS 默认），展开态同样清除（防非 static 定位受残留干扰）
document.addEventListener('click', function (e) {
  var t = e.target.closest('[data-nav-toggle]');
  if (!t) return;
  var sb = document.querySelector('.sidebar, [class*="sidebar"]');
  // 切换前测量（展开态 layout top；折叠态 fixed+内联 top 下 rect.top 同值，幂等）
  var expandTop = sb ? Math.round(sb.getBoundingClientRect().top) : 0;
  var collapsed = document.body.classList.toggle('nav-collapsed');
  t.setAttribute('aria-expanded', collapsed ? 'true' : 'false');
  if (sb) {
    if (collapsed && expandTop > 0) {
      sb.style.top = expandTop + 'px';
    } else {
      sb.style.top = '';
    }
  }
});

// v5.22 P0-A7：元素级 onclick 全管道派发（在 click 委托基础上加固 D6/D3）
//   机制：为含 data-action 的元素绑定 onclick，onclick 体经 dispatchDemoAction 完成完整管道派发
//   （含导航/弹窗/close/action 优先级链）；与 document click 委托经 e._demoDispatched 幂等标志
//   单次执行（根治 v5.18 双触发）；data-action 与 data-open-modal/data-nav/data-route 并存时
//   按优先级链短路（P008）。data-demo-bound 标记防重复绑定；内联 onclick 跳过逻辑保留。
document.querySelectorAll('[data-action]:not([data-demo-bound])').forEach(function (el) {
  el.setAttribute('data-demo-bound', '1');
  // 仅对无内联 onclick 的元素绑定（保留 AI 自定义逻辑）
  if (!el.onclick) {
    el.onclick = function (e) {
      dispatchDemoAction(el, e);
    };
  }
});

// v5.22 文本筛选实时通道：input 事件逐键派发（仅 INPUT/TEXTAREA；SELECT 由 change 语义覆盖，
//   排除以防 input+change 双触发）。命中 [data-action] 即派发——文本搜索/筛选实时生效，
//   AI 无需自建 input 监听（避免双通道，契约见 SKILL.md R-11）。
document.addEventListener('input', function (e) {
  var t = e.target;
  if (!t || (t.tagName !== 'INPUT' && t.tagName !== 'TEXTAREA')) return;
  var host = t.closest ? t.closest('[data-action]') : null;
  if (host) dispatchDemoAction(host, e);
});
`;
  // v2.3 改动 4：样式骨架预置 .btn-accent（按钮类契约）
  //   背景：p6/p7/p4 的 btn-primary 误判教训——D3 启发式把 .btn-primary 当弹窗触发器探测，
  //   业务主按钮误用 .btn-primary 且点击无弹窗时被判 D3 FAIL（骨架此前未显式约定保留类）。
  //   契约：.btn-primary 为弹窗触发器保留类；业务主按钮用 .btn-accent（与 .btn-primary 同视觉，
  //   AI 重写样式时保持两类同视觉或自行统一设计 token 即可，类名语义勿混用）。
  //   输出信号：生成的 demo/assets/style.css 含 .btn-accent。
  const STYLE_CSS_SKELETON = `/* Demora 样式骨架（v2.3/v5.19）— AI 基于 frontend-design skill 方法论自由重写，
   以下预置按钮类契约占位样式（可调整视觉值，勿混用类名语义）与 v5.19 导航折叠体系 */

/* ===== 按钮类契约（v2.3）=====
   .btn-primary 为弹窗触发器保留类：D3 启发式会把它当弹窗触发候选探测，
   业务主按钮误用 .btn-primary 会在点击后无弹窗弹出时被判 D3 FAIL（p6/p7/p4 实证）。
   业务主按钮（导航/提交/筛选等）使用 .btn-accent（视觉与 .btn-primary 相同，见下），
   或自行命名并带 data-route/data-action 属性。
   弹窗触发按钮必须带 data-open-modal="<modalId>" 属性。
*/
.btn-primary,
.btn-accent {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 8px 18px;
  border: none;
  border-radius: 6px;
  background: #2563eb;
  color: #fff;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
}

/* ===== v5.20 P1-4 app-shell 布局契约（切页置顶 = 保持公共区域，仅业务区滚动）=====
   背景（U6 澄清）：v5.19 置顶把公共 topbar 顶出视口。契约化布局——公共 header
   不参与业务滚动，业务内容在 .content 内滚动，route() 自动定位滚动容器复位。
   AI 采用顶栏+侧栏布局时建议对齐类名（或复制规则到实际类名，route() 靠最近
   可滚祖先探测，不强依赖类名）：
     <div class="app-shell">
       <header class="topbar">…公共区…</header>   ← 常驻视口（不随业务滚动）
       <div class="layout">
         <aside class="sidebar">…导航…</aside>
         <main class="content">…业务页面…</main>   ← overflow-y:auto 业务滚动容器
       </div>
     </div>
*/
.app-shell {
  height: 100vh;
  display: flex;
  flex-direction: column;
  overflow: hidden;            /* 业务滚动收敛到 .content，document 不滚 */
}
.app-shell .topbar { flex: none; }
.app-shell .layout {
  flex: 1;
  min-height: 0;
  display: flex;
  overflow: hidden;
}
.app-shell .content {
  flex: 1;
  min-width: 0;
  overflow-y: auto;            /* 业务滚动容器：切页置顶复位目标 */
}
/* scrollIntoView 兜底时业务页不让位公共 header（整页滚动布局的 AI 自定义形态） */
[data-page-id] { scroll-margin-top: 64px; }

/* ===== v5.20.1 骨架预置导航折叠体系（U5；三轮修正：透明底图标 + 折叠完全收起 + 左缘热区）=====
   交互形态（codex 风格）：
     - 顶栏最左预置图标按钮 .nav-toggle（内联用户给定 SVG，透明底——SKILL.md 契约）
     - 打开态：点击图标 → 折叠导航（body.nav-collapsed，侧栏 translateX 完全移出，零残留）
     - 折叠态：鼠标悬停屏幕左缘（侧栏 ::before 14px 热区）→ 完整导航自动唤出
     - 折叠态：点击图标 → 打开导航
   使用示例：
     <header class="topbar">
       <button type="button" class="nav-toggle" data-nav-toggle aria-expanded="false"
               aria-label="折叠导航" title="折叠/展开导航">
         <svg …用户给定透明底图标…></svg>
       </button>
       …品牌（建议与图标组成左组合，勿用 space-between 三段布局）…
     </header>
     <div class="layout">
       <aside class="sidebar"><nav>…</nav></aside>
       <main class="content">…</main>
     </div>
   app.js 骨架已预置 [data-nav-toggle] 点击委托（切换 body.nav-collapsed + aria 同步，
   不覆盖按钮内 SVG）；规则仅匹配含 .sidebar 的结构，顶栏无侧栏布局零副作用。
   命名注意：折叠选择器含 [class*="sidebar"] 通配（兼容 .app-sidebar 等变体），
   侧栏子元素类名请避免包含 "sidebar" 字样（如用 .side-head 而非 .sidebar-head）。
*/
.sidebar {
  --sidebar-w: 16rem;               /* 完整宽度默认值，AI 按自身设计覆盖 */
  transition: transform .2s ease;   /* 折叠滑出/悬停滑入过渡（v5.20.1：width → transform） */
}

/* v5.20 P1-5 顶栏折叠图标按钮：位于 topbar 最左，承载内联 SVG（24×24） */
.nav-toggle {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  padding: 0;
  border: none;
  border-radius: 6px;
  background: transparent;
  cursor: pointer;
  flex: none;
}
.nav-toggle:hover { background: rgba(127, 127, 127, .15); }
.nav-toggle svg { display: block; width: 24px; height: 24px; }

/* v5.20.1（UAT 三轮 U5-B）折叠态：完全收起——translateX(-100%) 整体移出，零窄条残留
   （v5.20 的 3.5rem 窄条会遗留残缺导航：图标/半个汉字外露）
   注意①：此处禁用 overflow:hidden——热区 ::before 外挂于侧栏边界之外（left:100%），
   overflow:hidden 会将其整体裁剪导致悬停唤出失效（F10 探针实证）；折叠态与展开态
   同宽（内容不重排），展开态本就 overflow:visible，折叠态无额外溢出风险
   注意②（v5.20.2 UAT 四轮 U-B）：top:0 仅为无 topbar 布局的默认——app-shell 布局下
   唤出的侧栏会遮盖常驻 topbar；app.js 骨架在切换折叠时动态测量侧栏原 top（topbar
   底部）写入内联 style.top 覆盖此默认值，唤出位置恒与展开态对齐 */
body.nav-collapsed .sidebar,
body.nav-collapsed [class*="sidebar"] {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  width: var(--sidebar-w, 16rem);
  transform: translateX(-100%);
  transition: transform .2s ease;
  z-index: 40;
}

/* v5.20.1 左缘悬停热区：侧栏右缘外挂 14px 透明条（贴屏幕左缘），悬停即唤出完整导航
   （伪元素命中测试归属宿主元素——侧栏本体已移出屏外，热区承担 hover 触发） */
body.nav-collapsed .sidebar::before,
body.nav-collapsed [class*="sidebar"]::before {
  content: "";
  position: absolute;
  left: 100%;
  top: 0;
  bottom: 0;
  width: 14px;
}

/* v5.20.1 悬停屏幕左侧自动唤出：滑入完整导航 + 阴影高置顶（fixed 覆盖层，内容不回流） */
body.nav-collapsed .sidebar:hover,
body.nav-collapsed [class*="sidebar"]:hover {
  transform: translateX(0);
  box-shadow: 4px 0 16px rgba(0, 0, 0, .18);
  z-index: 50;
}

/* v5.20.1 主内容：折叠态侧栏完全移出，无需让位（原 3.5rem 让位随窄条形态一并废止） */
body.nav-collapsed .main,
body.nav-collapsed .content {
  margin-left: 0;
}
`;
  const emptyFiles = [
    // v5.18 P0-C2：注入 <link rel="icon" href="data:,"> 确定性消灭 favicon 404
    //   根因：favicon 404 是 D0_console 不可接受 warn 的最高频来源（3+ 案例各浪费 1 轮审计）
    //   一行模板改动，零设计影响（data: URL 不加载任何资源，浏览器不再请求 /favicon.ico）
    { path: path.join(demoDir, 'index.html'), content: '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <link rel="icon" href="data:,">\n  <title>Demo</title>\n</head>\n<body>\n  <!-- AI: 基于 frontend-design skill 方法论从零设计完整 HTML -->\n</body>\n</html>\n' },
    { path: path.join(demoDir, 'assets', 'app.js'), content: APP_JS_SKELETON },
    { path: path.join(demoDir, 'assets', 'style.css'), content: STYLE_CSS_SKELETON },
  ];

  for (const f of emptyFiles) {
    if (!fs.existsSync(f.path)) {
      fs.writeFileSync(f.path, f.content, 'utf-8');
      log(`  [OK] 创建文件: ${path.relative(projectRoot, f.path)}`);
    } else {
      log(`  [INFO] 文件已存在，跳过: ${path.relative(projectRoot, f.path)}`);
    }
  }

  // 6. 创建 start.bat（默认内容，不再引用已 DROP 的 demo-framework 模板）
  const startBatPath = path.join(demoDir, 'start.bat');
  if (!fs.existsSync(startBatPath)) {
    fs.writeFileSync(startBatPath, '@echo off\nstart "" "index.html"\n', 'utf-8');
    log('  [OK] 创建默认 start.bat');
  }

  // 7. 创建 README.txt
  const readmePath = path.join(demoDir, 'README.txt');
  if (!fs.existsSync(readmePath)) {
    fs.writeFileSync(readmePath, 'Demora Demo\n============\n\n由 AI 基于 frontend-design skill 方法论设计。\n双击 start.bat 或直接在浏览器中打开 index.html 查看。\n', 'utf-8');
    log('  [OK] 创建 README.txt');
  }

  // 8. 更新 state.yaml：仅标记 demo_created（demo_protected/current_phase 由 lock-model.mjs 统一管理）
  if (fs.existsSync(statePath)) {
    let stateContent = fs.readFileSync(statePath, 'utf-8');
    if (/^demo_created:\s*.*$/m.test(stateContent)) {
      stateContent = stateContent.replace(/^demo_created:\s*.*$/m, 'demo_created: true');
    } else {
      stateContent = stateContent.replace(/\n*$/, '\n') + 'demo_created: true\n';
    }
    fs.writeFileSync(statePath, stateContent, 'utf-8');
    log('  [OK] 更新 state.yaml: demo_created = true');
  }

  log('\n======================================================================');
  log('[SUMMARY] Demo 目录结构已创建');
  log('======================================================================');
  log('  demo/index.html          — AI 填充完整 HTML');
  log('  demo/assets/app.js       — AI 填充应用逻辑');
  log('  demo/assets/style.css    — AI 填充样式');
  log('  demo/start.bat           — 启动脚本');
  log('\n>>> AI 下一步：读取 skills/frontend-design/SKILL.md，从零设计 Demo');

  return { ok: true };
}

// 直接运行守卫
const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('generate-demo.mjs') || process.argv[1].endsWith('generate-demo'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
