// check-requirement-fidelity.mjs
// 需求保真校验（v5.26 — 原始需求无损保真传递 Task 2）
//
// 用途：Phase 1 锁定前的需求保真门禁——确保 PM 原始需求在传递链路
//       inbox/documents/<原文归档> → inbox/text/requirement-scenario-brief.md →
//       inbox/text/requirement-input.md 上无损：
//         校验一·归档一致性：
//           1a: brief 存在且正文非空壳（cleanText >= 50 字符）
//           1b: brief 来源引用行（> 来源：inbox/documents/<文件名>）指向的归档存在；
//               documents/ 有归档但 brief 未引用 → WARN
//           1c: brief 正文包含原文全文（逐行 bigram 覆盖率占比 >= 0.9，防摘要替代）
//         校验二·结构覆盖：原文的 ## / ### 标题行与 markdown 表头行（结构指纹），
//                          每条在 requirement-input.md 全文中 bigram 覆盖率 >= 0.6；
//                          未达阈值时启用短语回退（合理改写不误报，见 phraseFallbackCovered）
//         校验三·开放问题保留：原文疑问标记行（？/?/待定/待补充/待确认/后续制定/还是）
//                              在 input 第 7 章『PM 原文开放问题』登记且标注「待确认」
//
// 输入形式约定：
//   形式 A（对话输入）：brief 无来源行且 inbox/documents/ 为空，仅 1a 生效
//   形式 B（归档输入）：brief 含来源行，原文以文件形式归档于 inbox/documents/
//
// 调用：
//   node scripts/check-requirement-fidelity.mjs [--root <项目根>]
//   （未传 --root 时按 findProjectRoot() 从 cwd 推导；--root 优先）
//
// 退出码：0 全部通过，1 存在 FAIL
// main 返回 { ok, pass, fail, warn, fails }，供 lock-model.mjs import 调用

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

// ===========================================================================
// 通用文本工具（bigram 指纹比对）
// ===========================================================================

// cleanText(s)：去除 markdown 井号/竖线/反引号/标点，仅保留中日韩字符+字母+数字，返回拼接串
function cleanText(s) {
  return String(s == null ? '' : s)
    .replace(/[^\p{Script=Han}\p{Script=Hiragana}\p{Script=Katakana}\p{Script=Hangul}A-Za-z0-9]/gu, '');
}

// bigrams(s)：cleanText 结果的相邻字符二元组集合（Set 天然去重）
function bigrams(s) {
  const cleaned = cleanText(s);
  const set = new Set();
  for (let i = 0; i + 1 < cleaned.length; i++) {
    set.add(cleaned.slice(i, i + 2));
  }
  return set;
}

// coverage(fpText, docText)：指纹二元组在文档 cleanText 中出现（子串包含）的比例
function coverage(fpText, docText) {
  const fpSet = bigrams(fpText);
  if (fpSet.size === 0) return 1; // 无信号（过短）视为全覆盖
  const docClean = cleanText(docText);
  let hit = 0;
  for (const bg of fpSet) {
    if (docClean.includes(bg)) hit++;
  }
  return hit / fpSet.size;
}

// ===========================================================================
// 短语回退（v5.26 校准增强：合理改写标题/表头/疑问引句不误报）
// 主判定 bigram >= 0.6 阈值不变；仅在未达阈值时作回退补充：
//   a) 表头指纹（| 开头）逐单元格判定：bigram >= 0.6 的单元格数 >= 2 且达半数 → 覆盖
//   b) 指纹中 >= 2 个不同短语（连续中文/字母数字串，>= 3 字符）在文档中精确出现 → 覆盖
//   c) 出现短语累计字符量 >= 6（至少一个足够长的实质短语被逐字承载）→ 覆盖
// ===========================================================================

// extractPhrases(text, minLen)：按非中文非字母数字字符切分，保留 cleanText 长度 >= minLen 的连续串
function extractPhrases(text, minLen = 3) {
  const parts = String(text == null ? '' : text).split(/[^\p{Script=Han}A-Za-z0-9]+/u);
  return parts.filter(p => cleanText(p).length >= minLen);
}

function phraseFallbackCovered(fpText, docText) {
  const docClean = cleanText(docText);
  // a) 表头逐单元格
  if (/^\s*\|/.test(fpText)) {
    const cells = String(fpText).split('|').map(s => s.trim()).filter(s => cleanText(s).length >= 2);
    if (cells.length >= 2) {
      let coveredCells = 0;
      for (const cell of cells) {
        if (coverage(cell, docText) >= 0.6) coveredCells++;
      }
      if (coveredCells >= 2 && coveredCells * 2 >= cells.length) return true;
    }
  }
  // b)/c) 短语级
  const phrases = extractPhrases(fpText, 3);
  if (phrases.length === 0) return false;
  const seen = new Set();
  let hitCount = 0, hitChars = 0;
  for (const p of phrases) {
    const c = cleanText(p);
    if (!seen.has(c) && docClean.includes(c)) {
      seen.add(c);
      hitCount++;
      hitChars += c.length;
    }
  }
  if (hitCount >= 2) return true;
  if (hitCount >= 1 && hitChars >= 6) return true;
  return false;
}

// ===========================================================================
// 行级判定工具
// ===========================================================================

function isHeadingLine(line) { return /^#{1,6}\s/.test(line); }
function isH2Line(line) { return /^##\s/.test(line); }
function isSourceRefLine(line) { return /^>\s*来源\s*[:：]/.test(line); }

// 表格分隔行：trim 后仅由 | : - 空格组成且含 --（如 |---|---|）
function isTableSeparatorLine(line) {
  const t = line.trim();
  return t.length > 0 && /^[|:\-\s]+$/.test(t) && /--/.test(t);
}

function trunc60(s) {
  const t = String(s).trim();
  return t.length > 60 ? t.slice(0, 60) + '...' : t;
}

function pct(x) { return Math.round(x * 100) + '%'; }

// 疑问标记行：非空内容行（排除标题行/来源行/表格分隔行）含疑问标记词之一
const QUESTION_MARKERS = ['？', '?', '待定', '待补充', '待确认', '后续制定', '还是'];
function isQuestionLine(line) {
  if (!line.trim()) return false;
  if (isHeadingLine(line) || isSourceRefLine(line) || isTableSeparatorLine(line)) return false;
  return QUESTION_MARKERS.some(m => line.includes(m));
}

// ===========================================================================
// 文档结构工具
// ===========================================================================

// 解析 brief 中 `> 来源：inbox/documents/<文件名>` 引用行，返回引用路径（相对项目根）
function parseSourceRef(briefText) {
  for (const line of briefText.split('\n')) {
    const m = line.match(/^>\s*来源\s*[:：]\s*(.+?)\s*$/);
    if (m) return m[1].trim();
  }
  return null;
}

// brief 正文 = brief 全文去掉首行标题与 `> 来源：` 引用行
function extractBriefBody(briefText) {
  const lines = briefText.split('\n');
  const out = [];
  for (let i = 0; i < lines.length; i++) {
    if (i === 0 && /^#\s/.test(lines[i])) continue; // 首行一级标题
    if (isSourceRefLine(lines[i])) continue;         // 来源引用行
    out.push(lines[i]);
  }
  return out.join('\n');
}

// 从 originalText 提取结构指纹：
//   a) `##` 与 `###` 标题行（`#` 一级标题视为文档标题，跳过）
//   b) markdown 表头行（以 | 开头且下一行是 |--- 分隔行）
function extractStructFingerprints(text) {
  const lines = text.split('\n');
  const fps = [];
  for (let i = 0; i < lines.length; i++) {
    if (/^#{2,3}\s/.test(lines[i])) {
      fps.push(lines[i].trim());
      continue;
    }
    if (/^\s*\|/.test(lines[i]) && i + 1 < lines.length && isTableSeparatorLine(lines[i + 1])) {
      fps.push(lines[i].trim());
    }
  }
  return fps;
}

// 定位 input 第 7 章：标题行同时含「开放问题」的二级标题起，至下一二级标题或文件尾
function extractChapter7(inputText) {
  const lines = inputText.split('\n');
  let start = -1;
  for (let i = 0; i < lines.length; i++) {
    if (isH2Line(lines[i]) && lines[i].includes('开放问题')) { start = i; break; }
  }
  if (start < 0) return null;
  const body = [];
  for (let i = start + 1; i < lines.length; i++) {
    if (isH2Line(lines[i])) break;
    body.push(lines[i]);
  }
  return { heading: lines[start], lines: body };
}

// ===========================================================================
// 主入口
// @param {object} args - { root? }
// ===========================================================================
export function main(args = {}) {
  const projectRoot = args.root || findProjectRoot();
  const briefPath = path.join(projectRoot, 'inbox', 'text', 'requirement-scenario-brief.md');
  const inputPath = path.join(projectRoot, 'inbox', 'text', 'requirement-input.md');

  log('======================================================================');
  log('check-requirement-fidelity.mjs — 需求保真校验 (v5.26)');
  log('======================================================================');

  let pass = 0, fail = 0, warn = 0;
  const fails = [];
  const addFail = (msg) => { fail++; fails.push(msg); log('  [FAIL] ' + msg); };

  const briefExists = fs.existsSync(briefPath);
  const inputExists = fs.existsSync(inputPath);
  const briefText = briefExists ? fs.readFileSync(briefPath, 'utf-8') : '';
  const inputText = inputExists ? fs.readFileSync(inputPath, 'utf-8') : '';

  // -----------------------------------------------------------------------
  // 校验一：归档一致性
  // -----------------------------------------------------------------------
  log('\n--- 校验一：归档一致性 ---');

  // 1a：brief 存在且正文非空壳
  let briefBody = '';
  if (!briefExists) {
    addFail('requirement-scenario-brief.md 缺失');
  } else {
    briefBody = extractBriefBody(briefText);
    const bodyLen = cleanText(briefBody).length;
    if (bodyLen < 50) {
      addFail('brief 为空壳/摘要占位');
    } else {
      log('  [OK] 1a: requirement-scenario-brief.md 存在且正文充实（' + bodyLen + ' 字符）');
      pass++;
    }
  }

  // 1b：来源引用的原文归档存在性（形式判定）
  let hasTextOriginal = false;
  let originalText = '';
  if (briefExists) {
    const sourceRef = parseSourceRef(briefText);
    const documentsDir = path.join(projectRoot, 'inbox', 'documents');
    const hasDocuments = fs.existsSync(documentsDir) &&
      fs.readdirSync(documentsDir).some(name => !name.startsWith('.'));

    if (sourceRef) {
      // 形式 B：brief 含来源引用行
      const refPath = path.resolve(projectRoot, sourceRef);
      const rel = path.relative(projectRoot, refPath);
      const inRoot = !rel.startsWith('..') && !path.isAbsolute(rel);
      // 路径越界（..）视为归档不存在，防止任意路径读取
      const refExists = inRoot && fs.existsSync(refPath) && fs.statSync(refPath).isFile();
      if (!refExists) {
        addFail('brief 引用的原文归档不存在: ' + sourceRef);
      } else {
        const ext = path.extname(refPath).toLowerCase();
        if (ext === '.md' || ext === '.txt' || ext === '.markdown') {
          originalText = fs.readFileSync(refPath, 'utf-8');
          hasTextOriginal = true;
          log('  [OK] 1b: 原文归档存在且为文本（' + sourceRef + '）');
          pass++;
        } else {
          originalText = briefBody;
          log('  [OK] 1b: 原文归档存在（' + sourceRef + '，非 .md/.txt/.markdown 跳过 1c）');
          pass++;
        }
      }
    } else if (hasDocuments) {
      log('  [WARN] 1b: documents/ 有归档但 brief 未引用');
      warn++;
      originalText = briefBody;
    } else {
      // 形式 A：对话输入（无来源行且 documents 空），仅 1a 生效
      log('  [INFO] 1b: 形式 A（对话输入），跳过 1b/1c');
      originalText = briefBody;
    }
  }
  // brief 缺失时 originalText 保持 ''（校验二/三按无信号处理）

  // 1c：brief 正文包含原文全文（hasTextOriginal 时）
  if (hasTextOriginal) {
    const contentLines = [];
    for (const line of originalText.split('\n')) {
      if (!line.trim()) continue;
      if (cleanText(line).length >= 4) contentLines.push(line);
    }
    if (contentLines.length === 0) {
      log('  [OK] 1c: 原文无有效内容行，跳过全文包含校验');
      pass++;
    } else {
      let covered = 0;
      for (const line of contentLines) {
        if (coverage(line, briefBody) >= 0.6) covered++;
      }
      const ratio = covered / contentLines.length;
      if (ratio < 0.9) {
        addFail('brief.md 未包含原文全文（疑似摘要替代），原文内容行覆盖率 ' + pct(ratio));
      } else {
        log('  [OK] 1c: brief.md 包含原文全文（内容行覆盖率 ' + pct(ratio) + '，' + covered + '/' + contentLines.length + ' 行）');
        pass++;
      }
    }
  }

  // -----------------------------------------------------------------------
  // 校验二：结构覆盖
  // -----------------------------------------------------------------------
  log('\n--- 校验二：结构覆盖 ---');

  if (!inputExists) {
    addFail('requirement-input.md 缺失');
  } else {
    // 指纹 cleanText 后 <4 字符的跳过（无信号）
    const effective = extractStructFingerprints(originalText)
      .filter(fp => cleanText(fp).length >= 4);
    if (effective.length === 0) {
      log('  [INFO] 2: 原文无结构指纹，跳过');
    } else {
      let uncovered = 0;
      for (const fp of effective) {
        const cov = coverage(fp, inputText);
        if (cov < 0.6 && !phraseFallbackCovered(fp, inputText)) {
          addFail('结构指纹未覆盖: ' + trunc60(fp) + '（覆盖率 ' + pct(cov) + '）');
          uncovered++;
        }
      }
      if (uncovered === 0) {
        log('  [OK] 2: 结构指纹全部覆盖（' + effective.length + ' 条）');
        pass++;
      }
    }
  }

  // -----------------------------------------------------------------------
  // 校验三：开放问题保留
  // -----------------------------------------------------------------------
  log('\n--- 校验三：开放问题保留 ---');

  if (inputExists) {
    const questionLines = originalText.split('\n').filter(isQuestionLine);
    const chapter = extractChapter7(inputText);

    if (questionLines.length === 0) {
      if (chapter) {
        if (chapter.lines.join('\n').includes('无')) {
          log('  [OK] 3: 原文无开放问题，第 7 章已显式写「无」');
          pass++;
        } else {
          log('  [WARN] 3: 原文无开放问题，第 7 章存在但未显式写「无」');
          warn++;
        }
      } else {
        addFail('原文无开放问题但缺第 7 章（应显式写“无”）');
      }
    } else if (!chapter) {
      addFail('requirement-input.md 缺第 7 章『PM 原文开放问题』');
      for (const q of questionLines) {
        log('         - ' + trunc60(q));
      }
    } else {
      const chapterText = chapter.lines.join('\n');
      let lost = 0, unmarked = 0;
      for (const q of questionLines) {
        const cov = coverage(q, chapterText);
        if (cov < 0.6 && !phraseFallbackCovered(q, chapterText)) {
          addFail('开放问题丢失: ' + trunc60(q));
          lost++;
          continue;
        }
        // 已登记：定位章节内最佳匹配行，检查行内及其前后 2 行是否标注「待确认」
        let bestIdx = -1, bestCov = -1;
        for (let i = 0; i < chapter.lines.length; i++) {
          const c = coverage(q, chapter.lines[i]);
          if (c > bestCov) { bestCov = c; bestIdx = i; }
        }
        const from = Math.max(0, bestIdx - 2);
        const to = Math.min(chapter.lines.length - 1, bestIdx + 2);
        let marked = false;
        for (let i = from; i <= to; i++) {
          if (chapter.lines[i].includes('待确认')) { marked = true; break; }
        }
        if (!marked) {
          log('  [WARN] 3: 开放问题状态未标注待确认: ' + trunc60(q));
          warn++;
          unmarked++;
        }
      }
      if (lost === 0 && unmarked === 0) {
        log('  [OK] 3: 开放问题全部登记并标注待确认（' + questionLines.length + ' 条）');
        pass++;
      }
    }
  }
  // input 缺失时已在校验二报 FAIL，此处跳过避免 FAIL 雪崩

  log('\n======================================================================');
  log(`[SUMMARY] check-requirement-fidelity: ${pass} pass / ${fail} fail / ${warn} warn`);
  log('======================================================================');

  if (fail > 0) {
    log('>>> 需求保真校验失败，请修正后重新运行');
    return { ok: false, pass, fail, warn, fails };
  }
  log('>>> 需求保真校验通过');
  return { ok: true, pass, fail, warn, fails };
}

// 直接运行守卫（--root 优先于 findProjectRoot，防止仓库根 .demora/ 残根误命中）
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const argv = process.argv.slice(2);
  const args = {};
  const rootIdx = argv.indexOf('--root');
  if (rootIdx >= 0 && argv[rootIdx + 1]) args.root = path.resolve(argv[rootIdx + 1]);
  try {
    const result = main(args);
    process.exit(result && result.ok ? 0 : 1);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
}
