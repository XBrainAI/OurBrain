// scaffold-project.mjs
// 初始化 Demora 项目结构：在用户当前工作目录下创建标准目录与初始文件
//
// 创建内容：
//   - .demora/ 7 个初始 YAML 文件（state/context/conversation-log/requirement-model/model-lock/decisions/traceability）
//   - inbox/ 三个子目录（text/documents/screenshots），各放 .gitkeep
//   - demo/、delivery/ 目录骨架
//   - docs/prd/ 14 个文档（00-13）+ docs/prd/06-page-details/_page-template.md
//   - docs/spec/ 7 个文档（00-06）
//   - docs/test/ 3 个文档（00-02）
//   - docs/handoff/review-notes.md
//   - IDE rules 自动注入（v5.1）：.cursor/rules/demora.mdc + .windsurf/rules/demora.md + AGENTS.md
//
// 调用约定：node scaffold-project.mjs，cwd 为用户工作目录（项目将创建于 cwd/<slug>/ 子目录）
// v5.12 新增：--project-slug <slug> --project-name <name>
//   - 提供 --project-slug 时，在 cwd 下创建 <slug>/ 子目录作为项目根
//   - 同时预填 requirement-model.yaml 的 project.name 和 project.slug
// v5.19 P0-3（U9/U10 根治）：slug 必填化，机制上消灭"项目文件平铺 cwd"默认
//   - 未提供 --project-slug 时不再默认 root=cwd，而是按优先级自动推导 slug：
//     ① cwd 下 requirement-input.md（或 inbox/requirement-input.md）文件名去扩展名 slug 化
//     ② cwd 目录名同法 slug 化
//     ③ 仍推导不出有效 slug 时兜底 demora-project
//   - 无论显式传入还是推导，项目根一律 = cwd/<slug>/（永远建子目录）
//   - 例外：--root <path> 显式指定路径时保持向后兼容（root = <path>，不推导、不建子目录）
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * 查找 IDE rules 模板目录
 * 构建包：scripts/ → ../ide-rules/
 * 源码：scripts/ → ../ide-rules/（skill-template 内）
 */
function findIdeRulesDir() {
  const candidate = path.join(__dirname, '..', 'ide-rules');
  if (fs.existsSync(candidate)) return candidate;
  return null;
}

/**
 * 备份已存在的目标文件（复制为 .bak，不覆盖原文件）
 * @returns {boolean} 是否执行了备份
 */
function backupIfExists(targetPath) {
  if (fs.existsSync(targetPath)) {
    const bakPath = targetPath + '.bak';
    fs.copyFileSync(targetPath, bakPath);
    return true;
  }
  return false;
}

/**
 * 注入 IDE rules（v5.1）：backup 后注入 Cursor / Windsurf / AGENTS.md
 * - .cursor/rules/demora.mdc（从 cursor-demora.mdc 复制）
 * - .windsurf/rules/demora.md（从 windsurf-demora.md 复制）
 * - AGENTS.md（从 agents-demora.md 复制）
 */
function injectIdeRules(root, ideRulesDir, created) {
  const targets = [
    { src: 'cursor-demora.mdc', dstDir: path.join(root, '.cursor', 'rules'), dstFile: 'demora.mdc' },
    { src: 'windsurf-demora.md', dstDir: path.join(root, '.windsurf', 'rules'), dstFile: 'demora.md' },
    { src: 'agents-demora.md', dstDir: root, dstFile: 'AGENTS.md' },
  ];
  let injected = 0;
  for (const t of targets) {
    const srcPath = path.join(ideRulesDir, t.src);
    if (!fs.existsSync(srcPath)) continue;
    fs.mkdirSync(t.dstDir, { recursive: true });
    const dstPath = path.join(t.dstDir, t.dstFile);
    // backup 已有文件
    if (backupIfExists(dstPath)) {
      process.stdout.write(`  [INFO] 已备份: ${t.dstFile} -> ${t.dstFile}.bak\n`);
    }
    fs.copyFileSync(srcPath, dstPath);
    created.push(dstPath);
    injected++;
  }
  return injected;
}

// 占位内容（所有 docs 文档初始内容）
const DOC_PLACEHOLDER = '> 本文档将在 Phase 2 中由系统自动生成。当前为占位状态。';

// docs/prd 14 个文档清单（00-13，06 为目录）
const PRD_DOCS = [
  '00-overview.md',
  '01-background.md',
  '02-target-audience.md',
  '03-user-roles.md',
  '04-business-flow.md',
  '05-page-list.md',
  // 06-page-details/ 是目录，单独处理
  '07-fields.md',
  '08-permissions.md',
  '09-user-stories.md',
  '10-success-metrics.md',
  '11-timeline.md',
  '12-risk-assumptions.md',
  '13-open-questions.md',
];

const SPEC_DOCS = [
  '00-project-overview.md',
  '01-page-architecture.md',
  '02-interaction-flow.md',
  '03-state-matrix.md',
  '04-route-table.md',
  '05-api-contract-draft.md',
  '06-error-and-empty-states.md',
];

const TEST_DOCS = [
  '00-acceptance-criteria.md',
  '01-test-suggestions.md',
  '02-permission-matrix.md',
];

/**
 * v5.19 P0-3：slug 化工具（用于自动推导项目根子目录名）
 * 规则：小写、非字母数字转连字符、去首尾连字符、截断 40 字符
 * 注意：中文字符属于"非字母数字"，会被转为连字符（中文文件名/目录名通常推导为空，落入下一优先级）
 * @param {string} name - 原始名称（文件名去扩展名或目录名）
 * @returns {string} slug 化结果（可能为空字符串，由调用方校验有效性）
 */
function slugifyForProjectRoot(name) {
  return String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40)
    .replace(/-+$/g, '');  // 截断可能产生尾部连字符，再去除一次
}

/**
 * v5.19 P0-3：校验推导/传入的 slug 格式（与 --project-slug 显式校验、package-delivery isValidSlug 同款规则）
 * 格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符
 * 用途：推导出的 slug 不合法（如空、以数字开头）时视为"推导不出"，落入下一优先级
 */
function isValidSlugFormat(slug) {
  return typeof slug === 'string' && /^[a-z][a-z0-9-]{2,63}$/.test(slug);
}

/**
 * 初始化项目结构
 * @param {object} args - 参数对象
 *   - root?: string 项目根目录（向后兼容显式路径；提供时直接作为 root，不推导、不建子目录）
 *   - projectSlug?: string 英文 slug，提供时在 cwd 下创建 <slug>/ 子目录作为项目根；
 *                   v5.19 P0-3：未提供且未提供 root 时按优先级自动推导（输入文件名 → 目录名 → 兜底）
 *   - projectName?: string 项目中文名，预填 requirement-model.yaml 的 project.name
 *   - cwd?: string 工作目录（用于计算 projectSlug 子目录路径，默认 process.cwd()）
 * @returns {{ ok: boolean, created: string[] }}
 */
export function main(args = {}) {
  const cwd = args.cwd || process.cwd();
  let root;

  // v5.14.17 批次4 R-1（P1）— scaffold 路径检测：禁止在技能包目录内创建项目
  //   根因：wb-dsf agent 将技能目录 oc-demora/ 当作 cwd，在 oc-demora/patent-precheck/ 创建项目
  //         违反"在 agent 工作路径根路径下创建项目目录"约定，污染 dist 目录结构
  //   修复 R-1：检测 cwd 是否同时含 SKILL.md + skill-manifest.json（技能包特征），若是则 FAIL
  //   例外：args.root 显式指定路径时不触发此检测（向后兼容）
  if (!args.root) {
    const isSkillPackageDir = fs.existsSync(path.join(cwd, 'SKILL.md')) &&
                              fs.existsSync(path.join(cwd, 'skill-manifest.json'));
    if (isSkillPackageDir) {
      process.stderr.write('[FAIL] 当前工作目录是技能包目录（含 SKILL.md + skill-manifest.json），禁止在此创建项目\n');
      process.stderr.write('       v5.14.17 R-1 硬门禁：项目目录必须创建在 agent 工作路径根路径下，而非技能包目录内\n');
      process.stderr.write('       正确示例: cwd/patent-precheck/\n');
      process.stderr.write('       错误示例: cwd/oc-demora/patent-precheck/\n');
      process.stderr.write('       修复方案：退出技能包目录，在技能包外的工作目录运行 scaffold\n');
      process.exit(1);
    }
  }

  // v5.19 P0-3（U9/U10 根治）— slug 必填化：项目根永远是 cwd/<slug>/ 子目录
  //   根因：v5.12 默认行为（未传 --project-slug 时 root=cwd）使"项目文件平铺 cwd"零成本，
  //         wb 10 案例中 9 个项目目录不规范（8 平铺 + 1 杂散文件夹），仅 1 个正确建子目录。
  //         SKILL:178 契约已有，但默认路径使违反零成本 → 机制上消灭平铺默认。
  //   修复：--project-slug 缺失时按优先级自动推导 slug——
  //     ① cwd 下 requirement-input.md（或 inbox/requirement-input.md）文件名去扩展名 slug 化
  //     ② 推导不出时用 cwd 目录名同法 slug 化
  //     ③ 仍为空（或 slug 化后格式无效）则兜底 demora-project
  //   无论显式传入还是推导，root 一律 = cwd/<slug>/（永远建子目录）。
  //   例外：args.root 显式指定路径时保持 v5.12 向后兼容（root = args.root，不推导、不建子目录）。
  let resolvedSlug = null;  // 最终生效的 slug（显式传入或自动推导）
  let slugSource = '';      // slug 来源（用于 INFO 输出）
  if (args.projectSlug) {
    // v5.12 原行为：显式传入时校验格式（小写字母开头，仅含小写字母/数字/连字符，3-64 字符）
    if (!/^[a-z][a-z0-9-]{2,63}$/.test(args.projectSlug)) {
      process.stderr.write('[FAIL] project-slug 格式错误：必须以小写字母开头，仅含小写字母/数字/连字符，3-64 字符\n');
      process.exit(1);
    }
    resolvedSlug = args.projectSlug;
    slugSource = '显式参数';
  } else if (!args.root) {
    // v5.19 P0-3：未传 slug 且未传 root 时自动推导（不再默认 root=cwd）
    // 优先级①：cwd 下 requirement-input.md（或 inbox/requirement-input.md）文件名
    // v5.20 P0-1：候选补 inbox/text/requirement-input.md（Phase 1 标准归档路径，与 derive-project-name 扫描口径一致）
    const inputCandidates = [
      path.join(cwd, 'inbox', 'text', 'requirement-input.md'),
      path.join(cwd, 'requirement-input.md'),
      path.join(cwd, 'inbox', 'requirement-input.md'),
    ];
    const foundInput = inputCandidates.find(p => fs.existsSync(p));
    let derived = '';
    if (foundInput) {
      const candidate = slugifyForProjectRoot(path.basename(foundInput, path.extname(foundInput)));
      if (isValidSlugFormat(candidate)) {
        derived = candidate;
        slugSource = '输入文件名推导';
      }
    }
    // 优先级②：cwd 目录名同法 slug 化
    if (!derived) {
      const candidate = slugifyForProjectRoot(path.basename(cwd));
      if (isValidSlugFormat(candidate)) {
        derived = candidate;
        slugSource = '目录名推导';
      }
    }
    // 优先级③：兜底
    if (!derived) {
      derived = 'demora-project';
      slugSource = '兜底';
    }
    resolvedSlug = derived;
  }

  if (resolvedSlug) {
    // v5.19 P0-3：无论显式还是推导，项目根一律 = cwd/<slug>/ 子目录
    root = path.join(cwd, resolvedSlug);
    process.stdout.write(`[INFO] v5.19 P0-3 项目根：${resolvedSlug}/（来源：${slugSource}）\n`);
    // 已存在且非空则报错（避免覆盖已有项目）— v5.12 原行为
    if (fs.existsSync(root) && fs.readdirSync(root).length > 0) {
      process.stderr.write(`[FAIL] 目录已存在且非空: ${root}\n`);
      process.exit(1);
    }
    fs.mkdirSync(root, { recursive: true });
    process.stdout.write(`[OK] 创建项目目录: ${root}\n`);
    // v5.19 P0-3 R-1 门禁扩展：cwd 已含项目产物特征时 WARN（不 FAIL，仅警示历史上的错误用法）
    //   背景：U9/U10 平铺案例的 cwd 下已存在 demo/ 或 delivery/，说明历史上曾在此平铺项目；
    //         新项目已强制建于子目录，此处仅警示"请勿在当前目录平铺项目文件"
    if (fs.existsSync(path.join(cwd, 'demo')) || fs.existsSync(path.join(cwd, 'delivery'))) {
      process.stdout.write(`[WARN] 当前目录已含项目产物（demo/ 或 delivery/），新项目已创建于子目录 ${resolvedSlug}/——请勿在当前目录平铺项目文件\n`);
    }
  } else {
    // v5.12 向后兼容：args.root 显式指定路径时直接作为项目根（不推导、不建子目录）
    root = args.root;
  }

  const created = [];

  // 创建目录辅助函数
  function mkdirp(p) {
    fs.mkdirSync(p, { recursive: true });
  }

  // 写入文件辅助函数（UTF-8 编码）
  function writeFile(p, content) {
    fs.writeFileSync(p, content, { encoding: 'utf-8' });
    created.push(p);
  }

  try {
    // ===== 1. .demora/ 目录及 7 个 YAML 文件 =====
    const reqDir = path.join(root, '.demora');
    mkdirp(reqDir);

    // state.yaml：阶段与保护状态（v5.6 新增 5 个状态机字段）
    // 字段语义：
    //   - model_locked: Phase 1 末尾由 lock-model.mjs 设为 true，表示"需求模型已锁定"
    //   - demo_protected: Phase 1 末尾由 lock-model.mjs 设为 true，仅表示"可以开始 Phase 2"
    //                    ⚠️ v5.6 语义澄清：此字段不是 package-delivery 的门禁！
    //                    v5.5 缺陷：package-delivery 把 demo_protected: true 当作"Phase 2 已完成"
    //                    v5.6 修复：package-delivery 改为检查 runtime_audit_passed（audit 模式）
    //                              或 final_approved（非 audit 模式）
    //   - ai_html_designed: AI 阶段 2 完成（demo/index.html 是真实 HTML，由 check-structure.mjs 写入）
    //   - annotation_injected: AI 阶段 3 完成（enhance-prototype.mjs 写入）
    //   - structure_check_passed: AI 阶段 4 完成（check-structure.mjs 10/10 PASS 时写入）
    //   - runtime_audit_passed: AI 阶段 5 完成（run-audit.mjs A/B 评级时写入）
    //                         ⚠️ 这是 package-delivery 在 audit 模式下的真实门禁
    //   - delivery_consistency_verified: delivery 内容一致性校验通过（verify-delivery.mjs 写入）
    //   - final_approved: PM 最终验收通过（render-card final-approval 写入）
    //                    ⚠️ 这是 package-delivery 在非 audit 模式下的门禁之一
    // 门禁时序（v5.6 强约束）：
    //   package-delivery.mjs 在 audit 模式：必须 runtime_audit_passed: true
    //   package-delivery.mjs 非 audit 模式：必须 final_approved: true 或 demo_protected: true（向后兼容）
    const now = new Date().toISOString();
    const stateYaml = [
      '# Demora 项目状态文件（scaffold-project.mjs 自动生成）',
      'current_phase: 1',
      'model_locked: false',
      'demo_protected: false',
      'ai_html_designed: false',
      'annotation_injected: false',
      'structure_check_passed: false',
      'runtime_audit_passed: false',
      'delivery_consistency_verified: false',
      'final_approved: false',
      'delivery_packaged: false',
      `pages_generated: []`,
      `docs_generated: []`,
      `created_at: ${now}`,
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'state.yaml'), stateYaml);

    // context.yaml：跨会话上下文
    const contextYaml = [
      '# 跨会话上下文（领域术语、组件清单、样式约束快照）',
      'domain_terms: {}',
      'component_inventory: []',
      'style_constraints: {}',
      '# v5.0 新增：标记 AI 是否已读取 frontend-design 方法论',
      'design_methodology_read: false',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'context.yaml'), contextYaml);

    // conversation-log.yaml：对话历史（append-only）
    // v5.25 P1-2：创建后置只读（0o444）——AI 直接编辑/重写会 EPERM，
    //             必须通过 scripts/append-conversation-log.mjs 追加（lib/conversation-log.mjs 统一通道）
    const conversationLogYaml = [
      '# 对话历史（append-only，仅允许通过 scripts/append-conversation-log.mjs 追加；直接编辑会 EPERM）',
      'entries:',
      '',
    ].join('\n');
    const conversationLogPath = path.join(reqDir, 'conversation-log.yaml');
    writeFile(conversationLogPath, conversationLogYaml);
    try { fs.chmodSync(conversationLogPath, 0o444); } catch (e) { /* 平台差异防御 */ }

    // requirement-model.yaml：需求模型（Phase 1 填充）
    // v5.11 新增：project.slug 字段（PM 可手工填写英文 slug，留空时 package-delivery 自动生成）
    // v5.12 新增：scaffold 时通过 --project-slug / --project-name 预填
    const projectNameValue = args.projectName ? `"${args.projectName}"` : '"[待填充]"';
    // v5.19 P0-3：slug 必填化——自动推导出的 slug 同样预填（不再留空给 package-delivery 兜底生成）
    const projectSlugValue = resolvedSlug ? `"${resolvedSlug}"` : '""';
    const modelYaml = [
      '# 需求模型（Phase 1 由 AI 与 PM 对话填充，Phase 2 锁定后只读）',
      'project:',
      `  name: ${projectNameValue}`,
      '  description: "[待填充]"',
      '  domain: "[待填充]"',
      '  # v5.11: 英文 slug，用于公网发布路径 https://demora.ipsunlight.com/<slug>/',
      '  # 留空时 package-delivery 会按字典/拼音/兜底策略自动生成',
      '  # 格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符',
      `  slug: ${projectSlugValue}`,
      'entities: []',
      'pages: []',
      'roles: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'requirement-model.yaml'), modelYaml);

    // model-lock.yaml：锁定状态与变更日志
    const modelLockYaml = [
      '# 需求模型锁定状态（lock-model.mjs 维护）',
      'locked: false',
      'change_log: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'model-lock.yaml'), modelLockYaml);

    // decisions.yaml：决策记录
    const decisionsYaml = [
      '# 评审决策记录（Phase 3 由 PM 转述评审意见后生成）',
      'decisions: []',
      '# v2.7 新增：设计决策记录（AI 应用 frontend-design 方法论后的设计选择，含 signature_element/typography 等）',
      'design_decisions: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'decisions.yaml'), decisionsYaml);

    // traceability.yaml：追溯链
    const traceabilityYaml = [
      '# 追溯链（generate-traceability.mjs 生成）',
      'traces: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'traceability.yaml'), traceabilityYaml);

    // ===== 2. inbox/ 三个子目录，各放 .gitkeep =====
    const inboxSubDirs = ['text', 'documents', 'screenshots'];
    for (const sub of inboxSubDirs) {
      const subDir = path.join(root, 'inbox', sub);
      mkdirp(subDir);
      writeFile(path.join(subDir, '.gitkeep'), '');
    }

    // ===== 3. demo/、delivery/ 目录骨架 =====
    mkdirp(path.join(root, 'demo'));
    mkdirp(path.join(root, 'delivery'));

    // ===== 4. docs/prd/ 文档（14 个 + _page-template.md）=====
    const prdDir = path.join(root, 'docs', 'prd');
    mkdirp(prdDir);
    for (const doc of PRD_DOCS) {
      writeFile(path.join(prdDir, doc), DOC_PLACEHOLDER + '\n');
    }
    // 06-page-details 目录与模板
    const pageDetailsDir = path.join(prdDir, '06-page-details');
    mkdirp(pageDetailsDir);
    writeFile(path.join(pageDetailsDir, '_page-template.md'), DOC_PLACEHOLDER + '\n');

    // ===== 5. docs/spec/ 文档（7 个）=====
    const specDir = path.join(root, 'docs', 'spec');
    mkdirp(specDir);
    for (const doc of SPEC_DOCS) {
      writeFile(path.join(specDir, doc), DOC_PLACEHOLDER + '\n');
    }

    // ===== 6. docs/test/ 文档（3 个）=====
    const testDir = path.join(root, 'docs', 'test');
    mkdirp(testDir);
    for (const doc of TEST_DOCS) {
      writeFile(path.join(testDir, doc), DOC_PLACEHOLDER + '\n');
    }

    // ===== 7. docs/handoff/review-notes.md =====
    const handoffDir = path.join(root, 'docs', 'handoff');
    mkdirp(handoffDir);
    writeFile(path.join(handoffDir, 'review-notes.md'), DOC_PLACEHOLDER + '\n');

    // ===== 8. IDE rules 自动注入（v5.1）=====
    const ideRulesDir = findIdeRulesDir();
    if (ideRulesDir) {
      const injected = injectIdeRules(root, ideRulesDir, created);
      process.stdout.write(`  [OK] IDE rules 注入: ${injected} 项（.cursor/rules + .windsurf/rules + AGENTS.md）\n`);
    } else {
      process.stdout.write('  [WARN] ide-rules 目录未找到，跳过 IDE rules 注入\n');
    }

    // ===== 9. v5.20 P2-3：cwd 级 inbox 自动迁移至项目目录（U9/U10）=====
    //   背景：Phase 1 契约要求先在 cwd 级归档需求文件（derive-project-name 扫描 ./inbox/text），
    //         scaffold 建项目子目录后若无迁移环节，cwd 级 inbox 永久残留（codex-dsf-p10 双 inbox 实证）。
    //   行为：cwd 与项目根不同时，将 cwd/inbox/ 内实际文件（跳过 .gitkeep）复制到 <root>/inbox/
    //         对应子目录（同名跳过），随后删除 cwd 级 inbox/ 整目录。无文件时不动作。
    if (root !== cwd && fs.existsSync(path.join(cwd, 'inbox'))) {
      let migrated = 0;
      for (const sub of inboxSubDirs) {
        const srcSub = path.join(cwd, 'inbox', sub);
        if (!fs.existsSync(srcSub)) continue;
        const dstSub = path.join(root, 'inbox', sub);
        for (const name of fs.readdirSync(srcSub)) {
          if (name === '.gitkeep') continue;
          const srcFile = path.join(srcSub, name);
          if (!fs.statSync(srcFile).isFile()) continue;
          const dstFile = path.join(dstSub, name);
          if (!fs.existsSync(dstFile)) {
            fs.copyFileSync(srcFile, dstFile);
            migrated++;
          }
        }
      }
      // 仅当 inbox 内无子目录外的散落文件时整目录删除（防御性：散落文件仅 WARN 不删）
      const looseFiles = fs.readdirSync(path.join(cwd, 'inbox'))
        .filter(n => fs.statSync(path.join(cwd, 'inbox', n)).isFile());
      if (migrated > 0 && looseFiles.length === 0) {
        fs.rmSync(path.join(cwd, 'inbox'), { recursive: true, force: true });
        process.stdout.write(`  [OK] v5.20 P2-3 已迁移 cwd 级 inbox ${migrated} 个文件至项目目录并清理（U9/U10）\n`);
      } else if (migrated > 0) {
        process.stdout.write(`  [WARN] 已复制 cwd 级 inbox ${migrated} 个文件至项目目录，但存在子目录外散落文件（${looseFiles.join(', ')}），请手动清理 cwd/inbox/\n`);
      }
    }

    process.stdout.write('[OK] scaffold 完成（创建 ' + created.length + ' 个文件）\n');
    return { ok: true, created };
  } catch (e) {
    process.stderr.write('[FAIL] scaffold 失败: ' + e.message + '\n');
    process.exit(1);
  }
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  // v5.12: 解析 CLI 参数
  //   --project-slug <slug>   英文 slug，创建 <slug>/ 子目录作为项目根
  //   --project-name <name>   项目中文名，预填 requirement-model.yaml
  //   --root <path>           项目根目录（向后兼容显式路径；v5.19 P0-3：提供时跳过 slug 推导直接使用，
  //                           未提供任何参数时按优先级自动推导 slug 并永远建 <slug>/ 子目录）
  const args = {};
  for (let i = 2; i < process.argv.length; i++) {
    const a = process.argv[i];
    if (a === '--project-slug') args.projectSlug = process.argv[++i];
    else if (a === '--project-name') args.projectName = process.argv[++i];
    else if (a === '--root') args.root = process.argv[++i];
  }
  main(args);
}
