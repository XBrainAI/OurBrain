// summarize-state.mjs — Demora 项目状态摘要（v5.18 P0-C1）
// 一条命令输出 state.yaml + model-lock + audit-result + diagnose-result 摘要
// 用法：node scripts/summarize-state.mjs --demo <demo-dir>
//      node scripts/summarize-state.mjs --project <project-root>
//
// 设计目标：
//   替代 agent 每次 4-8 次 `node -e readFileSync(...)` 的零散读取，一条命令输出
//   项目全状态摘要（state/model-lock/audit/diagnose 四源合一），降低上下文碎片。
//
// 实现约束：
//   - 仅用 Node 内置模块（fs/path），不依赖外部 npm 包
//   - YAML 解析为内置轻量实现（state.yaml/model-lock.yaml 均为简单结构）
//   - 文件缺失输出 [WARN] 而非崩溃
//   - 输出标记：[INFO]/[OK]/[WARN]/[FAIL]，禁止 emoji（遵循 project_rules §1.3）
//   - 文件读写显式指定 encoding: "utf-8"
//
// 退出码：0（只读摘要工具，缺失文件仅告警，不阻断流程）

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 三阶段名称映射（与 AGENTS.md §二 一致）
const PHASE_NAMES = {
  1: 'Phase 1 想清楚',
  2: 'Phase 2 做精致',
  3: 'Phase 3 改到位',
};

function log(msg) { process.stdout.write(msg + '\n'); }

// ===== 参数解析（参考 diagnose-runtime.mjs 的 process.argv 风格）=====
function parseArgs(argv) {
  const args = { demo: null, project: null, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') args.help = true;
    else if (a === '--demo') args.demo = argv[++i];
    else if (a === '--project') args.project = argv[++i];
  }
  return args;
}

function showHelp() {
  log(`Demora 项目状态摘要 (v5.18 P0-C1) — 一条命令读取四源状态

用法：
  node scripts/summarize-state.mjs --demo <demo-dir>
  node scripts/summarize-state.mjs --project <project-root>

参数：
  --demo <path>     demo 目录路径（含 audit-result.json / diagnose-result.json）
                    项目根推断为该目录的父目录
  --project <path>  项目根路径（含 .demora/）；demo 目录推断为 <project>/demo

读取来源：
  <project>/.demora/state.yaml        — 项目阶段与各门禁状态
  <project>/.demora/model-lock.yaml   — 需求模型锁定状态
  <demo>/audit-result.json            — 审计结果摘要
  <demo>/diagnose-result.json         — 运行时确诊结果

输出：控制台打印人类可读摘要（[INFO]/[OK]/[WARN]/[FAIL] 标记）
退出码：0（缺失文件仅 [WARN]，不阻断）`);
}

// ===== 轻量 YAML 解析（仅支持 state.yaml / model-lock.yaml 的简单结构）=====
// 支持：注释、标量(bool/number/string/timestamp)、内联数组 [a, b]、块序列(对象数组)
// 不支持：复杂嵌套/锚点/多行字符串（这两个文件用不到）

function parseScalar(raw) {
  if (raw === undefined || raw === null) return null;
  const v = raw.trim();
  if (v === '') return '';
  // 去引号
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
    return v.slice(1, -1);
  }
  // 内联数组
  if (v.startsWith('[') && v.endsWith(']')) {
    const inner = v.slice(1, -1).trim();
    if (inner === '') return [];
    return inner.split(',').map(s => parseScalar(s));
  }
  // bool / null
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (v === 'null' || v === '~') return null;
  // number
  if (/^-?\d+$/.test(v)) return parseInt(v, 10);
  if (/^-?\d+\.\d+$/.test(v)) return parseFloat(v);
  // string（含 ISO timestamp 原样保留）
  return v;
}

// 解析块序列行（形如 "  - action: lock" + "    timestamp: ..."）为对象数组
function parseBlockSequence(blockLines) {
  const items = [];
  let currentItem = null;
  for (const line of blockLines) {
    const dashMatch = line.match(/^\s*-\s+(.*)$/);
    if (dashMatch) {
      if (currentItem !== null) items.push(currentItem);
      const rest = dashMatch[1];
      const km = rest.match(/^([A-Za-z_][\w]*):\s*(.*)$/);
      if (km) {
        currentItem = {};
        currentItem[km[1]] = parseScalar(km[2]);
      } else {
        // 纯标量项
        currentItem = parseScalar(rest);
      }
    } else if (currentItem !== null && typeof currentItem === 'object') {
      // 当前项的后续字段
      const km = line.trim().match(/^([A-Za-z_][\w]*):\s*(.*)$/);
      if (km) currentItem[km[1]] = parseScalar(km[2]);
    }
  }
  if (currentItem !== null) items.push(currentItem);
  return items;
}

function parseSimpleYAML(text) {
  const lines = text.split(/\r?\n/);
  const result = {};
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const trimmed = line.trim();
    // 跳过注释与空行
    if (!trimmed || trimmed.startsWith('#')) { i++; continue; }
    // 顶层键（行首无缩进）
    if (!/^\s/.test(line)) {
      const m = line.match(/^([A-Za-z_][\w]*):\s*(.*)$/);
      if (m) {
        const key = m[1];
        const val = m[2];
        if (val === '') {
          // 值为空 → 块序列或块映射，向前收集缩进行
          const blockLines = [];
          let j = i + 1;
          while (j < lines.length && /^\s/.test(lines[j]) && lines[j].trim() !== '') {
            blockLines.push(lines[j]);
            j++;
          }
          if (blockLines.length > 0 && blockLines.some(l => l.trim().startsWith('- '))) {
            result[key] = parseBlockSequence(blockLines);
          } else if (blockLines.length > 0) {
            const sub = {};
            for (const bl of blockLines) {
              const bm = bl.trim().match(/^([A-Za-z_][\w]*):\s*(.*)$/);
              if (bm) sub[bm[1]] = parseScalar(bm[2]);
            }
            result[key] = sub;
          } else {
            result[key] = null;
          }
          i = j;
        } else {
          result[key] = parseScalar(val);
          i++;
        }
      } else {
        i++;
      }
    } else {
      i++;
    }
  }
  return result;
}

// ===== 文本对齐辅助 =====
function pad(str, len) {
  str = String(str);
  return str.length >= len ? str : str + ' '.repeat(len - str.length);
}
function row(key, value) {
  return `  ${pad(key, 26)} ${value}`;
}

// ===== 安全读取（缺失/异常 → 返回 null + warn 信息）=====
function readText(filePath) {
  try {
    return fs.readFileSync(filePath, { encoding: 'utf-8' });
  } catch (e) {
    return null;
  }
}

// ===== 各源摘要输出 =====

function printState(projectRoot) {
  const rel = '.demora/state.yaml';
  const abs = path.join(projectRoot, '.demora', 'state.yaml');
  log(`\n[State] ${rel}`);
  const text = readText(abs);
  if (text === null) {
    log(`  [WARN] 文件不存在: ${abs}`);
    return;
  }
  let state;
  try {
    state = parseSimpleYAML(text);
  } catch (e) {
    log(`  [FAIL] YAML 解析失败: ${e.message}`);
    return;
  }
  // project_name 在 state.yaml 中不存在，从项目根目录名推导
  const projectName = path.basename(projectRoot);
  log(row('project_name', projectName + '  (derived from dir)'));
  const phase = state.current_phase;
  const phaseName = (typeof phase === 'number' && PHASE_NAMES[phase]) ? PHASE_NAMES[phase] : null;
  log(row('current_phase', phaseName ? `${phase} (${phaseName})` : (phase ?? '(unset)')));

  // 关键 bool 门禁字段（全量输出，便于 agent 一眼掌握进度）
  const boolFields = [
    'model_locked', 'demo_protected', 'ai_html_designed', 'annotation_injected',
    'structure_check_passed', 'runtime_audit_passed', 'delivery_consistency_verified',
    'final_approved', 'delivery_packaged', 'lock_card_shown',
  ];
  for (const k of boolFields) {
    if (k in state) log(row(k, state[k]));
  }
  // 数组字段输出长度
  if ('pages_generated' in state) log(row('pages_generated', Array.isArray(state.pages_generated) ? state.pages_generated.length : state.pages_generated));
  if ('docs_generated' in state) log(row('docs_generated', Array.isArray(state.docs_generated) ? state.docs_generated.length : state.docs_generated));
  if ('created_at' in state) log(row('created_at', state.created_at));
  // v5.25 P1-3：计时埋点时间线（分解 Phase 1→设计→注入→校验→审计各段耗时）
  const timelineFields = [
    'phase2_started_at', 'phase2_enhance_completed_at', 'phase2_check_completed_at',
    'audit_started_at', 'delivery_packaged_at',
  ];
  const timelineShown = timelineFields.filter(k => k in state);
  if (timelineShown.length > 0) {
    log('\n  [Timeline] 计时埋点（v5.25 P1-3）:');
    for (const k of timelineShown) log(row(k, state[k]));
    if ('phase2_started_at' in state && 'phase2_enhance_completed_at' in state) {
      const d = (new Date(state.phase2_enhance_completed_at) - new Date(state.phase2_started_at)) / 60000;
      if (isFinite(d)) log(row('└ 设计生成段耗时', `${d.toFixed(1)} min（lock → enhance）`));
    }
    if ('phase2_enhance_completed_at' in state && 'phase2_check_completed_at' in state) {
      const d = (new Date(state.phase2_check_completed_at) - new Date(state.phase2_enhance_completed_at)) / 60000;
      if (isFinite(d)) log(row('└ 校验修复段耗时', `${d.toFixed(1)} min（enhance → check-structure）`));
    }
  }
}

function printModelLock(projectRoot) {
  const rel = '.demora/model-lock.yaml';
  const abs = path.join(projectRoot, '.demora', 'model-lock.yaml');
  log(`\n[Model] ${rel}`);
  const text = readText(abs);
  if (text === null) {
    log(`  [WARN] 文件不存在: ${abs}`);
    return;
  }
  let ml;
  try {
    ml = parseSimpleYAML(text);
  } catch (e) {
    log(`  [FAIL] YAML 解析失败: ${e.message}`);
    return;
  }
  log(row('locked', ml.locked ?? '(unset)'));
  // 部分版本可能写入 model 字段，存在则输出
  if ('model' in ml) log(row('model', ml.model));
  // change_log 取最后一条
  const logArr = Array.isArray(ml.change_log) ? ml.change_log : [];
  if (logArr.length > 0) {
    const last = logArr[logArr.length - 1];
    if (last && typeof last === 'object') {
      log(row('last_action', last.action ?? '-'));
      log(row('last_timestamp', last.timestamp ?? '-'));
      log(row('last_reason', last.reason ?? '-'));
    }
  } else {
    log(row('change_log', '(empty)'));
  }
}

function printAudit(demoDir) {
  const rel = 'demo/audit-result.json';
  const abs = path.join(demoDir, 'audit-result.json');
  log(`\n[Audit] ${rel}`);
  const text = readText(abs);
  if (text === null) {
    log(`  [WARN] 文件不存在: ${abs}`);
    return;
  }
  let data;
  try {
    data = JSON.parse(text);
  } catch (e) {
    log(`  [FAIL] JSON 解析失败: ${e.message}`);
    return;
  }
  log(row('overall', data.overall ?? '-'));
  const s = data.summary || {};
  log(row('summary', `pass: ${s.pass ?? 0}  fail: ${s.fail ?? 0}  warn: ${s.warn ?? 0}  total: ${s.total ?? 0}`));

  // 维度逐项解析：值形如 "pass" / "warn: msg" / "fail: msg"
  const dims = data.dimensions || {};
  const failDims = [];
  const warnDims = [];
  for (const [dim, raw] of Object.entries(dims)) {
    const v = String(raw);
    const idx = v.indexOf(':');
    const status = (idx >= 0 ? v.slice(0, idx) : v).trim();
    const msg = idx >= 0 ? v.slice(idx + 1).trim() : '';
    if (status === 'fail') failDims.push({ dim, msg });
    else if (status === 'warn') warnDims.push({ dim, msg });
  }
  if (failDims.length === 0) {
    log(row('失败维度', '(无)'));
  } else {
    log(row('失败维度', `${failDims.length} 项`));
    for (const f of failDims) {
      log(`    - ${f.dim}${f.msg ? ' — ' + f.msg : ''}`);
    }
  }
  if (warnDims.length > 0) {
    log(row('警告维度', `${warnDims.length} 项`));
    for (const w of warnDims) {
      log(`    - ${w.dim}${w.msg ? ' — ' + w.msg : ''}`);
    }
  }
}

function printDiagnose(demoDir) {
  const rel = 'demo/diagnose-result.json';
  const abs = path.join(demoDir, 'diagnose-result.json');
  log(`\n[Diagnose] ${rel}`);
  const text = readText(abs);
  if (text === null) {
    log(`  [WARN] 文件不存在: ${abs}`);
    return;
  }
  let data;
  try {
    data = JSON.parse(text);
  } catch (e) {
    log(`  [FAIL] JSON 解析失败: ${e.message}`);
    return;
  }
  log(row('mode', data.mode ?? '-'));
  // exitCode 不入文件（为进程退出码），此处输出 gate 字段作为等效判定
  log(row('gate', data.gate ?? '-'));
  const total = data.total_failures ?? (Array.isArray(data.failures) ? data.failures.length : 0);
  log(row('total_failures', total));
  const failures = Array.isArray(data.failures) ? data.failures : [];
  if (failures.length > 0) {
    log(row('失效清单', `${failures.length} 项`));
    failures.forEach((f, i) => {
      const dim = f.dim ?? '?';
      const root = f.root_cause ?? '-';
      const sel = f.selector ?? '-';
      log(`    ${i + 1}. [${dim}] ${root} — ${sel}`);
    });
  }
}

// ===== 主流程 =====
function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) { showHelp(); return; }

  // 推断 projectRoot 与 demoDir
  let projectRoot, demoDir;
  if (args.project) {
    projectRoot = path.resolve(args.project);
    demoDir = args.demo ? path.resolve(args.demo) : path.join(projectRoot, 'demo');
  } else if (args.demo) {
    demoDir = path.resolve(args.demo);
    projectRoot = path.dirname(demoDir);
  } else {
    log('[FAIL] 缺少参数：请指定 --demo <demo-dir> 或 --project <project-root>');
    log('[INFO] 使用 --help 查看用法');
    process.exit(1);
  }

  log('======================================================================');
  log('Demora 项目状态摘要');
  log('======================================================================');
  log(`[INFO] project_root: ${projectRoot}`);
  log(`[INFO] demo_dir:     ${demoDir}`);

  printState(projectRoot);
  printModelLock(projectRoot);
  printAudit(demoDir);
  printDiagnose(demoDir);

  log('\n======================================================================');
  log('>>> 状态摘要完成');
  log('======================================================================');
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === __filename;
if (isDirectRun) {
  main();
}
