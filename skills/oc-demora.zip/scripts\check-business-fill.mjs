// check-business-fill.mjs
// 业务填充完整性校验（v5.13.5 — 4 项）
//
// 校验项：
//   BF-1: 通用占位 Mock 数据检测（__FILL_BUSINESS__ 标记残留）
//   BF-2: 空标注数据检测（annotationData 未定义或为空）
//   BF-3 (v5.13.3): page.name 字段存在性 — 每个页面对象应有 name 或 title 字段
//   BF-4 (v5.13.3): L2/L3 数据完整性 — 每个页面应有 L2 数组且非空、L3 数组且非空
//
// v5.13.4 修复：
//   - BF-3/BF-4 仅在实际 __ANNOTATION_DATA__ = { ... } 赋值块内搜索页面 key
//     （之前在整个 HTML 搜索，会匹配内联 annotation-engine.js 注释中的 "P01: {...}" 导致误报）
//   - DEMORA_SIM_MODE=1 时 BF-2/BF-4 的 critical 降级为 WARN（sim-runner 不模拟 AI 业务填充）
//
// v5.19 P2-1 扩展（BF-4 两级细化，十案例标注说明质量问题）：
//   - L3 字段完整性（FAIL，契约）：每条 L3 需 id/element/function/trigger/response 五字段齐全且非空字符串
//     （背景：p6 案例 L3 条目仅 function/trigger/response 3 字段缩水无人拦截）
//   - L2 description 详尽度（WARN，软契约）：剥空白后 ≥30 字，须含"功能 + 数据来源/业务规则"两要素
//     （背景：十案例 L2 description 平均 19.2 字，全为一句话标签）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

// v5.13.4: sim-runner 设置 DEMORA_SIM_MODE=1，表示 sim-project 未由真实 AI 填充业务数据
// 此时 BF-2/BF-4 的 critical 失败降级为 WARN（不阻塞流水线）
const SIM_MODE = process.env.DEMORA_SIM_MODE === '1';

/**
 * v5.13.4: 从 HTML 中提取 __ANNOTATION_DATA__ = { ... } 赋值块的内容
 * 通过花括号配对找到完整赋值块，避免匹配内联 JS 注释中的 "P01: {...}" 文本
 * @param {string} html
 * @returns {string|null} 花括号之间的内容（不含外层 {}），未找到返回 null
 */
function extractAnnotationDataBlock(html) {
  const startMatch = html.match(/__ANNOTATION_DATA__\s*=\s*\{/);
  if (!startMatch) return null;
  // 定位到赋值块的起始 {
  const openBraceIdx = startMatch.index + startMatch[0].length - 1;
  let depth = 0;
  for (let i = openBraceIdx; i < html.length; i++) {
    const ch = html[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        return html.slice(openBraceIdx + 1, i);
      }
    }
  }
  return null;
}

// v5.15 P1-5：基于大括号配对的页面对象块提取（修复非贪婪截断）
//   根因：非贪婪 *? 遇到嵌套对象的 } 缩进为 2 空格时提前截断，丢失后续字段
//   修复：从 pk: { 开始，用大括号计数器提取完整块
function extractPageBlock(dataBlock, pageKey) {
  const startPattern = pageKey + '\\s*:\\s*\\{';
  const startMatch = dataBlock.match(new RegExp(startPattern));
  if (!startMatch) return null;
  const startIdx = startMatch.index + startMatch[0].length;
  let depth = 1;
  let i = startIdx;
  while (i < dataBlock.length && depth > 0) {
    if (dataBlock[i] === '{') depth++;
    else if (dataBlock[i] === '}') depth--;
    i++;
  }
  if (depth !== 0) return null;
  return dataBlock.substring(startIdx, i - 1);
}

// v5.19 P2-1: 从 startIdx 起扫描，跳过字符串字面量内的括号，返回与首个 open 配对的 close 位置
//   注意：description 等中文文本可能含 } ] 等字符，不跳过字符串会导致条目提前截断误判
function scanMatchingBracket(text, startIdx, open, close) {
  let depth = 1, i = startIdx, inStr = false, strCh = '';
  while (i < text.length && depth > 0) {
    const ch = text[i];
    if (inStr) {
      if (ch === '\\') i++;            // 转义字符，跳过下一字符
      else if (ch === strCh) inStr = false;
    } else if (ch === '"' || ch === "'" || ch === '`') {
      inStr = true; strCh = ch;
    } else if (ch === open) depth++;
    else if (ch === close) depth--;
    i++;
  }
  return depth === 0 ? i - 1 : -1;     // 未配对返回 -1（结构异常）
}

// v5.19 P2-1: 提取块内 <arrayKey>: [ ... ] 数组字面量内容（方括号配对，风格同 extractPageBlock）
function extractArrayBlock(block, arrayKey) {
  // 前缀边界 (?:^|[^\w$]) 防止 XL2: 之类 key 的后缀误匹配
  const startMatch = block.match(new RegExp('(?:^|[^\\w$])' + arrayKey + '\\s*:\\s*\\['));
  if (!startMatch) return null;
  const openIdx = startMatch.index + startMatch[0].length - 1;
  const closeIdx = scanMatchingBracket(block, openIdx + 1, '[', ']');
  if (closeIdx === -1) return null;
  return block.substring(openIdx + 1, closeIdx);
}

// v5.19 P2-1: 遍历数组块内的顶层对象条目 {...}，返回每个条目的内容（不含外层 {}）
//   括号不配对（结构异常）时停止遍历，调用方按已提取条目继续检查
function extractObjectEntries(arrayBlock) {
  const entries = [];
  let i = 0;
  while (i < arrayBlock.length) {
    const openIdx = arrayBlock.indexOf('{', i);
    if (openIdx === -1) break;
    const closeIdx = scanMatchingBracket(arrayBlock, openIdx + 1, '{', '}');
    if (closeIdx === -1) break;
    entries.push(arrayBlock.substring(openIdx + 1, closeIdx));
    i = closeIdx + 1;
  }
  return entries;
}

// v5.19 P2-1: 字段非空字符串检查 — 匹配 <field>: "非空值"（'...' 同理，字段值剥离空白后非空）
function hasNonEmptyStringField(entry, field) {
  const m = entry.match(new RegExp('(?:^|[^\\w$])' + field + '\\s*:\\s*([\'"])([^\'"]*)\\1'));
  return !!m && m[2].trim() !== '';
}

// v5.19 P2-1: 提取字段字符串值（未找到/非字符串返回 null）
function getStringFieldValue(entry, field) {
  const m = entry.match(new RegExp('(?:^|[^\\w$])' + field + '\\s*:\\s*([\'"])([^\'"]*)\\1'));
  return m ? m[2] : null;
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('check-business-fill.mjs — 业务填充校验 (v5.13.3)');
  log('======================================================================');

  let pass = 0, fail = 0, critical = 0;

  // BF-1: 通用占位标记检测
  const jsFiles = ['app.js', 'style.css'].map(f => path.join(demoDir, 'assets', f));
  const htmlFile = path.join(demoDir, 'index.html');
  const allFiles = [...jsFiles, htmlFile].filter(f => fs.existsSync(f));

  let placeholderFound = false;
  for (const f of allFiles) {
    const content = fs.readFileSync(f, 'utf-8');
    if (content.includes('__FILL_BUSINESS__')) {
      log(`  [FAIL] BF-1: ${path.relative(projectRoot, f)} 包含 __FILL_BUSINESS__ 占位标记`);
      placeholderFound = true;
      critical++;
    }
  }
  if (!placeholderFound) {
    log('  [OK] BF-1: 无 __FILL_BUSINESS__ 占位标记');
    pass++;
  }

  // BF-2: 空标注数据检测
  if (fs.existsSync(htmlFile)) {
    const html = fs.readFileSync(htmlFile, 'utf-8');
    const hasAnnotationData = html.includes('__ANNOTATION_DATA__');
    if (hasAnnotationData) {
      // 检查是否为空对象
      const emptyMatch = /__ANNOTATION_DATA__\s*=\s*\{\s*\}/.test(html);
      if (emptyMatch) {
        // v5.13.4: SIM 模式下降级为 WARN（sim-runner 不模拟 AI 业务填充）
        if (SIM_MODE) {
          log('  [WARN] BF-2: __ANNOTATION_DATA__ 为空对象（SIM 模式，AI 未填充属预期）');
        } else {
          log('  [FAIL] BF-2: __ANNOTATION_DATA__ 为空对象，AI 未填充标注数据');
          critical++;
        }
      } else {
        log('  [OK] BF-2: 标注数据已定义');
        pass++;
      }
    } else {
      log('  [WARN] BF-2: 未检测到 __ANNOTATION_DATA__（标注数据可能未定义）');
    }

    // v5.13.4: 提取实际 __ANNOTATION_DATA__ = { ... } 赋值块
    // BF-3/BF-4 仅在此块内搜索页面 key，避免匹配内联 annotation-engine.js 注释
    const dataBlock = extractAnnotationDataBlock(html);
    const hasNonEmptyData = hasAnnotationData && dataBlock !== null && dataBlock.trim() !== '';

    // BF-3 (v5.13.3): page.name 字段存在性
    // 标注面板头部显示 "P01 - 页面名称"，若 page 对象无 name/title 字段则仅显示编号
    if (hasNonEmptyData) {
      // v5.13.4: 仅在 dataBlock 内搜索页面 key
      const pageKeys = [];
      const pageKeyRegex = /^\s*(P\d+)\s*:\s*\{/gm;
      let m;
      while ((m = pageKeyRegex.exec(dataBlock)) !== null) {
        pageKeys.push(m[1]);
      }
      // 兼容 pages 包装结构：pages: { P01: { ... } }
      if (pageKeys.length === 0) {
        const pagesBlockRegex = /pages\s*:\s*\{([\s\S]*?)\n\s*\}/;
        const pagesMatch = dataBlock.match(pagesBlockRegex);
        if (pagesMatch) {
          const innerKeyRegex = /(P\d+)\s*:\s*\{/g;
          let m2;
          while ((m2 = innerKeyRegex.exec(pagesMatch[1])) !== null) {
            pageKeys.push(m2[1]);
          }
        }
      }

      if (pageKeys.length === 0) {
        log('  [WARN] BF-3: 未检测到页面标注数据（无 P01/P02 等 key）');
      } else {
        // 检查每个页面是否有 name 或 title 字段
        const missingName = [];
        for (const pk of pageKeys) {
          // 提取该页面的对象块（简单匹配，不执行 JS）
          const blockContent = extractPageBlock(dataBlock, pk);
          if (blockContent) {
            const block = blockContent;
            if (!/name\s*:/.test(block) && !/title\s*:/.test(block)) {
              missingName.push(pk);
            }
          }
        }
        if (missingName.length === 0) {
          log('  [OK] BF-3: 所有页面（' + pageKeys.length + ' 个）均含 name/title 字段');
          pass++;
        } else {
          log('  [WARN] BF-3: ' + missingName.length + ' 个页面缺少 name/title 字段: ' + missingName.join(', '));
          log('         详情: 标注面板头部将仅显示页面编号（如 "P01"）而非 "P01 - 页面名称"');
          log('         修复: 在 __ANNOTATION_DATA__ 的页面对象中添加 name: "页面中文名称"');
        }
      }
    }

    // BF-4 (v5.13.3): L2/L3 数据完整性
    // 每个页面应有 L2 数组且非空、L3 数组且非空
    if (hasNonEmptyData) {
      // v5.13.4: 仅在 dataBlock 内搜索页面 key
      const pageKeys = [];
      const pageKeyRegex = /^\s*(P\d+)\s*:\s*\{/gm;
      let m3;
      while ((m3 = pageKeyRegex.exec(dataBlock)) !== null) {
        pageKeys.push(m3[1]);
      }
      if (pageKeys.length === 0) {
        const pagesBlockRegex = /pages\s*:\s*\{([\s\S]*?)\n\s*\}/;
        const pagesMatch = dataBlock.match(pagesBlockRegex);
        if (pagesMatch) {
          const innerKeyRegex = /(P\d+)\s*:\s*\{/g;
          let m4;
          while ((m4 = innerKeyRegex.exec(pagesMatch[1])) !== null) {
            pageKeys.push(m4[1]);
          }
        }
      }

      if (pageKeys.length === 0) {
        log('  [WARN] BF-4: 未检测到页面标注数据，跳过 L2/L3 完整性校验');
      } else {
        const incomplete = [];

        // v5.19 P2-1: BF-4 扩展 — L3 字段完整性（FAIL）+ L2 description 详尽度（WARN）
        //   背景：十案例调研——L2 description 平均 19.2 字全为标签句；p6 案例 L3 仅 3 字段缩水无人拦截
        //   解析：沿用本文件既有括号配对提取风格（extractArrayBlock/extractObjectEntries），
        //   不引入 eval/JSON.parse；数组块缺失或括号不配对（结构异常）时新检查自动跳过，
        //   不阻塞流水线，也不影响下方原有空数组检查
        const L3_REQUIRED_FIELDS = ['id', 'element', 'function', 'trigger', 'response'];
        const l3FieldIssues = [];  // 'btn02 缺少必需字段 trigger'
        const l2DescIssues = [];   // { ref, len }
        let l3Checked = 0, l2Checked = 0;
        for (const pk of pageKeys) {
          const pageBlock = extractPageBlock(dataBlock, pk);
          if (!pageBlock) continue;

          // L3 字段完整性（契约：五字段齐全且为非空字符串）
          const l3Arr = extractArrayBlock(pageBlock, 'L3');
          if (l3Arr) {
            const l3Entries = extractObjectEntries(l3Arr);
            l3Checked += l3Entries.length;
            l3Entries.forEach((entry, idx) => {
              const missingFields = L3_REQUIRED_FIELDS.filter(f => !hasNonEmptyStringField(entry, f));
              if (missingFields.length > 0) {
                const idVal = getStringFieldValue(entry, 'id');
                l3FieldIssues.push((idVal && idVal.trim() ? idVal : pk + ' 条目#' + (idx + 1)) + ' 缺少必需字段 ' + missingFields.join('/'));
              }
            });
          }

          // L2 description 详尽度（软契约：剥空白后 ≥30 字，含"功能 + 数据来源/业务规则"两要素）
          const l2Arr = extractArrayBlock(pageBlock, 'L2');
          if (l2Arr) {
            extractObjectEntries(l2Arr).forEach((entry, idx) => {
              const descVal = getStringFieldValue(entry, 'description');
              if (descVal === null) return; // 无 description 字段不在本检查范围（存在性由 L2 结构约束）
              l2Checked++;
              const descLen = descVal.replace(/\s/g, '').length;
              if (descLen < 30) {
                const idVal = getStringFieldValue(entry, 'id');
                l2DescIssues.push({ ref: (idVal && idVal.trim() ? idVal : pk + ' 条目#' + (idx + 1)), len: descLen });
              }
            });
          }
        }
        if (l3Checked > 0 && l3FieldIssues.length === 0) {
          log('  [OK] BF-4: L3 条目（' + l3Checked + ' 个）五字段齐全（id/element/function/trigger/response）');
          pass++;
        } else if (l3FieldIssues.length > 0) {
          // v5.19 P2-1: SIM 模式沿用 v5.13.4 先例降级为 WARN（sim-runner 不模拟 AI 业务填充）
          if (SIM_MODE) {
            log('  [WARN] BF-4: ' + l3FieldIssues.length + ' 个 L3 条目缺少必需字段（SIM 模式降级，AI 未填充属预期）');
          } else {
            for (const issue of l3FieldIssues) {
              log('  [FAIL] BF-4: L3 条目 ' + issue + '（契约：五字段齐全）');
            }
            log('         修复: 补全 id/element/function/trigger/response 五字段，值均为非空字符串');
            critical++;
          }
        }
        if (l2DescIssues.length > 0) {
          for (const issue of l2DescIssues) {
            log('  [WARN] BF-4: L2 ' + issue.ref + ' 的 description 过简（' + issue.len + ' 字）——须含"功能 + 数据来源/业务规则"两要素（参考 ≥30 字）');
          }
          log('         修复: 按"展示<功能>；数据来源于<系统/接口>；规则为<业务规则>"句式扩写 description');
        } else if (l2Checked > 0) {
          log('  [OK] BF-4: L2 description 详尽度达标（' + l2Checked + ' 条均 ≥30 字）');
        }

        for (const pk of pageKeys) {
          const blockContent = extractPageBlock(dataBlock, pk);
          if (blockContent) {
            const block = blockContent;
            const hasL2 = /L2\s*:\s*\[/.test(block) && !/L2\s*:\s*\[\s*\]/.test(block);
            const hasL3 = /L3\s*:\s*\[/.test(block) && !/L3\s*:\s*\[\s*\]/.test(block);
            if (!hasL2 || !hasL3) {
              const missing = [];
              if (!hasL2) missing.push('L2');
              if (!hasL3) missing.push('L3');
              incomplete.push(pk + ' (缺 ' + missing.join('/') + ')');
            }
          }
        }
        if (incomplete.length === 0) {
          log('  [OK] BF-4: 所有页面（' + pageKeys.length + ' 个）L2/L3 数据完整');
          pass++;
        } else {
          // v5.13.4: SIM 模式下降级为 WARN（sim-runner 不模拟 AI 业务填充）
          if (SIM_MODE) {
            log('  [WARN] BF-4: ' + incomplete.length + ' 个页面 L2/L3 数据不完整（SIM 模式，AI 未填充属预期）: ' + incomplete.join(', '));
          } else {
            log('  [FAIL] BF-4: ' + incomplete.length + ' 个页面 L2/L3 数据不完整: ' + incomplete.join(', '));
            log('         详情: L2/L3 必须覆盖可视范围内所有区域/元件');
            log('         修复: 补充缺失的 L2 区域标注 / L3 元件标注');
            critical++;
          }
        }
      }
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 严重: ${critical}`);
  log('======================================================================');

  if (critical > 0) {
    log('>>> 业务填充校验失败，AI 需完成填充后重新运行');
    return { ok: false, pass, critical };
  }
  log('>>> 业务填充校验通过');
  return { ok: true, pass, critical };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('check-business-fill.mjs') || process.argv[1].endsWith('check-business-fill'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
