// check-business-fill.mjs
// 业务填充完整性校验（v5.13.5 — 4 项）
//
// 校验项：
//   BF-1: 通用占位 Mock 数据检测（__FILL_BUSINESS__ 标记残留）
//   BF-2: 空标注数据检测（annotationData 未定义或为空）
//   BF-3 (v5.13.3): page.name 字段存在性 — 每个页面对象应有 name 或 title 字段
//   BF-4 (v5.13.3): L2/L3 数据完整性 — 每个页面应有 L2 数组且非空、L3 数组且非空
//
// v5.13.4 修复：
//   - BF-3/BF-4 仅在实际 __ANNOTATION_DATA__ = { ... } 赋值块内搜索页面 key
//     （之前在整个 HTML 搜索，会匹配内联 annotation-engine.js 注释中的 "P01: {...}" 导致误报）
//   - DEMORA_SIM_MODE=1 时 BF-2/BF-4 的 critical 降级为 WARN（sim-runner 不模拟 AI 业务填充）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

// v5.13.4: sim-runner 设置 DEMORA_SIM_MODE=1，表示 sim-project 未由真实 AI 填充业务数据
// 此时 BF-2/BF-4 的 critical 失败降级为 WARN（不阻塞流水线）
const SIM_MODE = process.env.DEMORA_SIM_MODE === '1';

/**
 * v5.13.4: 从 HTML 中提取 __ANNOTATION_DATA__ = { ... } 赋值块的内容
 * 通过花括号配对找到完整赋值块，避免匹配内联 JS 注释中的 "P01: {...}" 文本
 * @param {string} html
 * @returns {string|null} 花括号之间的内容（不含外层 {}），未找到返回 null
 */
function extractAnnotationDataBlock(html) {
  const startMatch = html.match(/__ANNOTATION_DATA__\s*=\s*\{/);
  if (!startMatch) return null;
  // 定位到赋值块的起始 {
  const openBraceIdx = startMatch.index + startMatch[0].length - 1;
  let depth = 0;
  for (let i = openBraceIdx; i < html.length; i++) {
    const ch = html[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) {
        return html.slice(openBraceIdx + 1, i);
      }
    }
  }
  return null;
}

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('check-business-fill.mjs — 业务填充校验 (v5.13.3)');
  log('======================================================================');

  let pass = 0, fail = 0, critical = 0;

  // BF-1: 通用占位标记检测
  const jsFiles = ['app.js', 'style.css'].map(f => path.join(demoDir, 'assets', f));
  const htmlFile = path.join(demoDir, 'index.html');
  const allFiles = [...jsFiles, htmlFile].filter(f => fs.existsSync(f));

  let placeholderFound = false;
  for (const f of allFiles) {
    const content = fs.readFileSync(f, 'utf-8');
    if (content.includes('__FILL_BUSINESS__')) {
      log(`  [FAIL] BF-1: ${path.relative(projectRoot, f)} 包含 __FILL_BUSINESS__ 占位标记`);
      placeholderFound = true;
      critical++;
    }
  }
  if (!placeholderFound) {
    log('  [OK] BF-1: 无 __FILL_BUSINESS__ 占位标记');
    pass++;
  }

  // BF-2: 空标注数据检测
  if (fs.existsSync(htmlFile)) {
    const html = fs.readFileSync(htmlFile, 'utf-8');
    const hasAnnotationData = html.includes('__ANNOTATION_DATA__');
    if (hasAnnotationData) {
      // 检查是否为空对象
      const emptyMatch = /__ANNOTATION_DATA__\s*=\s*\{\s*\}/.test(html);
      if (emptyMatch) {
        // v5.13.4: SIM 模式下降级为 WARN（sim-runner 不模拟 AI 业务填充）
        if (SIM_MODE) {
          log('  [WARN] BF-2: __ANNOTATION_DATA__ 为空对象（SIM 模式，AI 未填充属预期）');
        } else {
          log('  [FAIL] BF-2: __ANNOTATION_DATA__ 为空对象，AI 未填充标注数据');
          critical++;
        }
      } else {
        log('  [OK] BF-2: 标注数据已定义');
        pass++;
      }
    } else {
      log('  [WARN] BF-2: 未检测到 __ANNOTATION_DATA__（标注数据可能未定义）');
    }

    // v5.13.4: 提取实际 __ANNOTATION_DATA__ = { ... } 赋值块
    // BF-3/BF-4 仅在此块内搜索页面 key，避免匹配内联 annotation-engine.js 注释
    const dataBlock = extractAnnotationDataBlock(html);
    const hasNonEmptyData = hasAnnotationData && dataBlock !== null && dataBlock.trim() !== '';

    // BF-3 (v5.13.3): page.name 字段存在性
    // 标注面板头部显示 "P01 - 页面名称"，若 page 对象无 name/title 字段则仅显示编号
    if (hasNonEmptyData) {
      // v5.13.4: 仅在 dataBlock 内搜索页面 key
      const pageKeys = [];
      const pageKeyRegex = /^\s*(P\d+)\s*:\s*\{/gm;
      let m;
      while ((m = pageKeyRegex.exec(dataBlock)) !== null) {
        pageKeys.push(m[1]);
      }
      // 兼容 pages 包装结构：pages: { P01: { ... } }
      if (pageKeys.length === 0) {
        const pagesBlockRegex = /pages\s*:\s*\{([\s\S]*?)\n\s*\}/;
        const pagesMatch = dataBlock.match(pagesBlockRegex);
        if (pagesMatch) {
          const innerKeyRegex = /(P\d+)\s*:\s*\{/g;
          let m2;
          while ((m2 = innerKeyRegex.exec(pagesMatch[1])) !== null) {
            pageKeys.push(m2[1]);
          }
        }
      }

      if (pageKeys.length === 0) {
        log('  [WARN] BF-3: 未检测到页面标注数据（无 P01/P02 等 key）');
      } else {
        // 检查每个页面是否有 name 或 title 字段
        const missingName = [];
        for (const pk of pageKeys) {
          // 提取该页面的对象块（简单匹配，不执行 JS）
          const pageBlockRegex = new RegExp(pk + '\\s*:\\s*\\{([\\s\\S]*?)\\n\\s{2,}\\}', 'm');
          const blockMatch = dataBlock.match(pageBlockRegex);
          if (blockMatch) {
            const block = blockMatch[1];
            if (!/name\s*:/.test(block) && !/title\s*:/.test(block)) {
              missingName.push(pk);
            }
          }
        }
        if (missingName.length === 0) {
          log('  [OK] BF-3: 所有页面（' + pageKeys.length + ' 个）均含 name/title 字段');
          pass++;
        } else {
          log('  [WARN] BF-3: ' + missingName.length + ' 个页面缺少 name/title 字段: ' + missingName.join(', '));
          log('         详情: 标注面板头部将仅显示页面编号（如 "P01"）而非 "P01 - 页面名称"');
          log('         修复: 在 __ANNOTATION_DATA__ 的页面对象中添加 name: "页面中文名称"');
        }
      }
    }

    // BF-4 (v5.13.3): L2/L3 数据完整性
    // 每个页面应有 L2 数组且非空、L3 数组且非空
    if (hasNonEmptyData) {
      // v5.13.4: 仅在 dataBlock 内搜索页面 key
      const pageKeys = [];
      const pageKeyRegex = /^\s*(P\d+)\s*:\s*\{/gm;
      let m3;
      while ((m3 = pageKeyRegex.exec(dataBlock)) !== null) {
        pageKeys.push(m3[1]);
      }
      if (pageKeys.length === 0) {
        const pagesBlockRegex = /pages\s*:\s*\{([\s\S]*?)\n\s*\}/;
        const pagesMatch = dataBlock.match(pagesBlockRegex);
        if (pagesMatch) {
          const innerKeyRegex = /(P\d+)\s*:\s*\{/g;
          let m4;
          while ((m4 = innerKeyRegex.exec(pagesMatch[1])) !== null) {
            pageKeys.push(m4[1]);
          }
        }
      }

      if (pageKeys.length === 0) {
        log('  [WARN] BF-4: 未检测到页面标注数据，跳过 L2/L3 完整性校验');
      } else {
        const incomplete = [];
        for (const pk of pageKeys) {
          const pageBlockRegex = new RegExp(pk + '\\s*:\\s*\\{([\\s\\S]*?)\\n\\s{2,}\\}', 'm');
          const blockMatch = dataBlock.match(pageBlockRegex);
          if (blockMatch) {
            const block = blockMatch[1];
            const hasL2 = /L2\s*:\s*\[/.test(block) && !/L2\s*:\s*\[\s*\]/.test(block);
            const hasL3 = /L3\s*:\s*\[/.test(block) && !/L3\s*:\s*\[\s*\]/.test(block);
            if (!hasL2 || !hasL3) {
              const missing = [];
              if (!hasL2) missing.push('L2');
              if (!hasL3) missing.push('L3');
              incomplete.push(pk + ' (缺 ' + missing.join('/') + ')');
            }
          }
        }
        if (incomplete.length === 0) {
          log('  [OK] BF-4: 所有页面（' + pageKeys.length + ' 个）L2/L3 数据完整');
          pass++;
        } else {
          // v5.13.4: SIM 模式下降级为 WARN（sim-runner 不模拟 AI 业务填充）
          if (SIM_MODE) {
            log('  [WARN] BF-4: ' + incomplete.length + ' 个页面 L2/L3 数据不完整（SIM 模式，AI 未填充属预期）: ' + incomplete.join(', '));
          } else {
            log('  [FAIL] BF-4: ' + incomplete.length + ' 个页面 L2/L3 数据不完整: ' + incomplete.join(', '));
            log('         详情: L2/L3 必须覆盖可视范围内所有区域/元件');
            log('         修复: 补充缺失的 L2 区域标注 / L3 元件标注');
            critical++;
          }
        }
      }
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 严重: ${critical}`);
  log('======================================================================');

  if (critical > 0) {
    log('>>> 业务填充校验失败，AI 需完成填充后重新运行');
    return { ok: false, pass, critical };
  }
  log('>>> 业务填充校验通过');
  return { ok: true, pass, critical };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('check-business-fill.mjs') || process.argv[1].endsWith('check-business-fill'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
