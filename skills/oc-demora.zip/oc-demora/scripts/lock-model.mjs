// lock-model.mjs
// 需求模型锁定/解锁管理：渲染确认卡片 + 执行锁定/解锁操作
//
// 调用：
//   node lock-model.mjs --lock             渲染锁定确认卡片（待 PM 确认）
//   node lock-model.mjs --lock --confirm   PM 确认后写入 state.yaml（model_locked: true）
//   node lock-model.mjs --unlock           渲染解锁确认卡片（待 PM 确认）
//   node lock-model.mjs --unlock --confirm PM 确认后解锁
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { renderCardBody } from './render-card.mjs';

/**
 * 读取并解析需求模型（轻量 YAML）
 */
function readModel(root) {
  const modelFile = path.join(root, '.demora', 'requirement-model.yaml');
  if (!fs.existsSync(modelFile)) return null;
  const text = fs.readFileSync(modelFile, { encoding: 'utf-8' });
  // 轻量解析：仅提取顶层 project/entities/pages/roles 的基础信息
  const model = { project: {}, entities: [], pages: [], roles: [] };
  const lines = text.split('\n');
  let section = null;
  for (const line of lines) {
    if (/^project:/.test(line)) section = 'project';
    else if (/^entities:/.test(line)) section = 'entities';
    else if (/^pages:/.test(line)) section = 'pages';
    else if (/^roles:/.test(line)) section = 'roles';
    else if (section === 'project') {
      const m = line.match(/^\s+name:\s*(.+)$/);
      if (m) model.project.name = m[1].trim().replace(/^["']|["']$/g, '');
    } else if (section === 'entities' && /^\s+-\s+name:\s*(.+)$/.test(line)) {
      const m = line.match(/^\s+-\s+name:\s*(.+)$/);
      model.entities.push({ name: m[1].trim(), displayName: m[1].trim() });
    } else if (section === 'pages' && /^\s+-\s+id:\s*(.+)$/.test(line)) {
      const m = line.match(/^\s+-\s+id:\s*(.+)$/);
      model.pages.push({ id: m[1].trim(), name: m[1].trim() });
    } else if (section === 'roles' && /^\s+-\s+name:\s*(.+)$/.test(line)) {
      const m = line.match(/^\s+-\s+name:\s*(.+)$/);
      model.roles.push({ name: m[1].trim(), displayName: m[1].trim() });
    }
  }
  return model;
}

/**
 * 更新 state.yaml 中的布尔字段
 */
function updateStateYaml(root, updates) {
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) return false;
  let text = fs.readFileSync(stateFile, { encoding: 'utf-8' });
  for (const [key, value] of Object.entries(updates)) {
    const regex = new RegExp('^(\\s*' + key + ':\\s*).*$', 'm');
    if (regex.test(text)) {
      text = text.replace(regex, '$1' + value);
    }
  }
  fs.writeFileSync(stateFile, text, { encoding: 'utf-8' });
  return true;
}

/**
 * 更新 model-lock.yaml：设置 locked 状态并追加 change_log
 */
function updateModelLock(root, locked, reason) {
  const lockFile = path.join(root, '.demora', 'model-lock.yaml');
  if (!fs.existsSync(lockFile)) return false;
  let text = fs.readFileSync(lockFile, { encoding: 'utf-8' });
  // 更新 locked 字段
  text = text.replace(/^(locked:\s*).*$/m, '$1' + locked);
  // 追加 change_log 条目
  const now = new Date().toISOString();
  const action = locked ? 'lock' : 'unlock';
  const logEntry = `  - action: ${action}\n    timestamp: ${now}\n    reason: ${reason || (locked ? 'PM 确认锁定，进入 Phase 2' : 'PM 确认解锁，回到 Phase 1')}`;
  // 替换 change_log: [] 为 change_log:\n  - ...
  if (/change_log:\s*\[\s*\]/.test(text)) {
    text = text.replace(/change_log:\s*\[\s*\]/, 'change_log:\n' + logEntry);
  } else if (/change_log:\s*\n/.test(text)) {
    // 已有条目，追加
    text = text.replace(/(change_log:\s*\n(?:\s+-\s.*\n?)*)/, '$1' + logEntry + '\n');
  } else {
    text += '\n' + logEntry + '\n';
  }
  fs.writeFileSync(lockFile, text, { encoding: 'utf-8' });
  return true;
}

/**
 * 追加 conversation-log 条目
 */
function appendConversationLog(root, message) {
  const logFile = path.join(root, '.demora', 'conversation-log.yaml');
  if (!fs.existsSync(logFile)) return;
  let text = fs.readFileSync(logFile, { encoding: 'utf-8' });
  const now = new Date().toISOString();
  const entry = `  - timestamp: ${now}\n    message: ${message}`;
  // 替换 entries: [] 为 entries:\n  - ...
  if (/entries:\s*\[\s*\]/.test(text)) {
    text = text.replace(/entries:\s*\[\s*\]/, 'entries:\n' + entry);
  } else {
    text = text.replace(/(entries:\s*\n(?:\s+-\s.*\n?)*)/, '$1' + entry + '\n');
  }
  fs.writeFileSync(logFile, text, { encoding: 'utf-8' });
}

/**
 * 主入口
 * @param {object} args - { root?, lock?, unlock?, confirm? }
 */
export function main(args = {}) {
  const root = args.root || process.cwd();
  const wantLock = args.lock !== undefined ? args.lock : false;
  const wantUnlock = args.unlock !== undefined ? args.unlock : false;
  const confirm = args.confirm || false;

  if (!wantLock && !wantUnlock) {
    process.stderr.write('[FAIL] 请指定 --lock 或 --unlock\n');
    process.exit(1);
  }

  const model = readModel(root);
  if (!model) {
    process.stderr.write('[FAIL] 需求模型不存在，请先执行 scaffold-project.mjs\n');
    process.exit(1);
  }

  const cardName = wantLock ? 'lock-confirm' : 'unlock-confirm';
  const projectName = (model.project && model.project.name) || '项目';
  const entityCount = model.entities.length;
  const entityList = model.entities.map(e => e.displayName || e.name).join(', ');
  const pageCount = model.pages.length;
  const pageList = model.pages.map(p => p.name || p.id).join(', ');
  const roleCount = model.roles.length;
  const roleList = model.roles.map(r => r.displayName || r.name).join(', ');

  const cardData = {
    project_name: projectName,
    pending_count: 0,
    entity_count: entityCount,
    entity_list: entityList,
    page_count: pageCount,
    page_list: pageList,
    role_count: roleCount,
    role_list: roleList,
    unlock_reason: args.reason || '需求变更，需要回到 Phase 1 重新确认',
  };

  // 仅渲染卡片（无 --confirm）
  if (!confirm) {
    const body = renderCardBody(cardName, cardData);
    process.stdout.write(body + '\n');
    return { ok: true, card: cardName };
  }

  // 执行锁定/解锁操作
  if (wantLock) {
    updateStateYaml(root, {
      model_locked: 'true',
      demo_protected: 'true',
      current_phase: '2',
    });
    updateModelLock(root, true, 'PM 确认锁定，进入 Phase 2');
    appendConversationLog(root, 'PM 确认锁定需求模型，进入 Phase 2');
    process.stdout.write('[OK] 需求模型已锁定（model_locked: true, demo_protected: true, current_phase: 2）\n');
  } else {
    updateStateYaml(root, {
      model_locked: 'false',
      demo_protected: 'false',
      current_phase: '1',
    });
    updateModelLock(root, false, args.reason || 'PM 确认解锁，回到 Phase 1');
    appendConversationLog(root, 'PM 确认解锁需求模型，回到 Phase 1');
    process.stdout.write('[OK] 需求模型已解锁（model_locked: false, current_phase: 1）\n');
  }

  return { ok: true, action: wantLock ? 'lock' : 'unlock' };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const argv = process.argv.slice(2);
  const args = {};
  if (argv.includes('--lock')) args.lock = true;
  if (argv.includes('--unlock')) args.unlock = true;
  if (argv.includes('--confirm')) args.confirm = true;
  const reasonIdx = argv.indexOf('--reason');
  if (reasonIdx >= 0 && argv[reasonIdx + 1]) args.reason = argv[reasonIdx + 1];
  main(args);
}
