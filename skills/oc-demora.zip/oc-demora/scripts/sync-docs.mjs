// sync-docs.mjs
// 读取 decisions.yaml，同步 accept 决策项到对应文档
//
// 调用：node sync-docs.mjs（无参数）
// cwd：sim-project 目录
// 功能：
//   1. 读取 .demora/decisions.yaml
//   2. 筛选 decision: accept 的决策项
//   3. 根据 target_doc 字段定位到 docs/ 下对应文档
//   4. 在文档末尾追加"已修复"标记，并写入 decisions.yaml 的 resolved 字段
//
// 防护（TD-01）：
//   - 兼容 decisions.yaml 中缺陷 ID 字段为 id 或 defect_id 的两种写法
//   - 兼容 decision 字段值为字符串 "accept" 或带引号的形式
//   - 保留 reason 字段作为修复说明
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 解析 accept 决策项
 * TD-01 防护：兼容 id 与 defect_id 两种字段名
 * v5.2.1 修复：兼容多种决策字段名（decision / type / review_decision / final_approval / delivery_confirm）
 *             和多种 accept 值（accept / accepted / approve / approved / true）
 *             无 target_doc 时回退到 docs/handoff/review-notes.md
 * @param {string} text decisions.yaml 文本
 * @returns {Array} accept 决策项列表
 */
function parseAcceptDecisions(text) {
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const decisions = [];
  let current = null;
  let inDecisions = false;

  // v5.2.1: 所有表示"接受/批准"的字段名
  const decisionFieldNames = ['decision', 'type', 'review_decision', 'final_approval', 'delivery_confirm', 'review_decision_type'];
  // v5.2.1: 所有表示"接受"的值
  const acceptValues = ['accept', 'accepted', 'approve', 'approved', 'true'];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    // 进入 decisions 列表
    if (/^decisions:/.test(line)) {
      inDecisions = true;
      continue;
    }
    if (!inDecisions) continue;
    // 离开 decisions 块
    if (/^[a-zA-Z]/.test(line) && !trimmed.startsWith('-')) {
      break;
    }

    // 列表项起点：行首带 -
    if (/^\s*-\s+/.test(line)) {
      if (current) decisions.push(current);
      current = {};
    }
    if (!current) continue;

    // 提取字段（兼容 id 和 defect_id）
    const idMatch = line.match(/^\s*(?:-\s+)?(defect_id|id):\s*(.+)$/);
    if (idMatch) {
      const fieldName = idMatch[1];
      const value = idMatch[2].trim().replace(/^["']|["']$/g, '');
      current.defect_id = value;
      if (fieldName === 'id') {
        current.id = value;
      }
    }

    // v5.2.1: 兼容多种决策字段名
    for (const fieldName of decisionFieldNames) {
      const decisionRegex = new RegExp('^\\s*' + fieldName + ':\\s*(.+)$');
      const decisionMatch = line.match(decisionRegex);
      if (decisionMatch) {
        const rawValue = decisionMatch[1].trim().replace(/^["']|["']$/g, '').toLowerCase();
        if (acceptValues.includes(rawValue)) {
          current.decision = 'accept';
        } else {
          current.decision = rawValue;
        }
        break;
      }
    }

    const targetMatch = line.match(/^\s*target_doc:\s*(.+)$/);
    if (targetMatch) {
      current.target_doc = targetMatch[1].trim().replace(/^["']|["']$/g, '');
    }
    const reasonMatch = line.match(/^\s*reason:\s*(.+)$/);
    if (reasonMatch) {
      current.reason = reasonMatch[1].trim().replace(/^["']|["']$/g, '');
    }
    const descMatch = line.match(/^\s*description:\s*(.+)$/);
    if (descMatch) {
      current.description = descMatch[1].trim().replace(/^["']|["']$/g, '');
    }
    const summaryMatch = line.match(/^\s*summary:\s*(.+)$/);
    if (summaryMatch) {
      current.summary = summaryMatch[1].trim().replace(/^["']|["']$/g, '');
    }
  }
  if (current) decisions.push(current);

  // 只返回 accept 决策
  return decisions.filter(d => d.decision === 'accept');
}

/**
 * v5.2.1: 构建修复标记文本
 */
function buildFixMark(defectId, decision) {
  return [
    '',
    '---',
    '',
    '## 缺陷修复记录',
    '',
    '- **缺陷 ID**: ' + defectId,
    '- **决策**: accept',
    '- **修复说明**: ' + (decision.reason || decision.description || decision.summary || '（已修复）'),
    '- **修复时间**: ' + new Date().toISOString(),
    '',
  ].join('\n');
}

/**
 * 主入口
 * @param {object} args - { root?: string }
 */
export function main(args = {}) {
  const root = args.root || process.cwd();
  const decisionsFile = path.join(root, '.demora', 'decisions.yaml');

  process.stdout.write('======================================================================\n');
  process.stdout.write('同步决策到文档\n');
  process.stdout.write('======================================================================\n');

  if (!fs.existsSync(decisionsFile)) {
    process.stdout.write('\n  [WARN] decisions.yaml 不存在，跳过同步\n');
    return { ok: true, synced: 0 };
  }

  const text = fs.readFileSync(decisionsFile, { encoding: 'utf-8' });
  const acceptDecisions = parseAcceptDecisions(text);

  process.stdout.write('\n  [INFO] accept 决策数: ' + acceptDecisions.length + '\n');

  let synced = 0;
  let skipped = 0;
  for (const d of acceptDecisions) {
    // TD-01：使用 defect_id（兼容 id 字段）
    const defectId = d.defect_id || d.id || '(unknown)';
    // v5.2.1: 无 target_doc 时回退到 docs/handoff/review-notes.md
    const targetDoc = d.target_doc || 'docs/handoff/review-notes.md';

    // 解析 target_doc 路径（如 docs/prd/05-page-list.md）
    const docPath = path.join(root, targetDoc);
    if (!fs.existsSync(docPath)) {
      // v5.2.1: 文档不存在时也回退到 review-notes.md
      if (targetDoc !== 'docs/handoff/review-notes.md') {
        const fallbackPath = path.join(root, 'docs', 'handoff', 'review-notes.md');
        if (fs.existsSync(fallbackPath)) {
          process.stdout.write('  [WARN] 文档不存在: ' + targetDoc + '（决策 ' + defectId + '），回退到 review-notes.md\n');
          const fallbackContent = fs.readFileSync(fallbackPath, { encoding: 'utf-8' });
          const fallbackFixMark = buildFixMark(defectId, d);
          if (!fallbackContent.includes('缺陷 ID**: ' + defectId)) {
            fs.writeFileSync(fallbackPath, fallbackContent + fallbackFixMark, { encoding: 'utf-8' });
            process.stdout.write('  [OK]   ' + defectId + ' -> docs/handoff/review-notes.md (fallback)\n');
            synced++;
            continue;
          }
        }
      }
      process.stdout.write('  [WARN] 文档不存在: ' + targetDoc + '（决策 ' + defectId + '）\n');
      skipped++;
      continue;
    }

    // 在文档末尾追加"已修复"标记
    const docContent = fs.readFileSync(docPath, { encoding: 'utf-8' });
    const fixMark = buildFixMark(defectId, d);

    // 幂等：若已包含该缺陷 ID 的修复记录则跳过
    if (docContent.includes('缺陷 ID**: ' + defectId)) {
      process.stdout.write('  [OK]   ' + defectId + ' 已同步过，跳过\n');
      skipped++;
      continue;
    }

    fs.writeFileSync(docPath, docContent + fixMark, { encoding: 'utf-8' });
    process.stdout.write('  [OK]   ' + defectId + ' -> ' + targetDoc + '\n');
    synced++;
  }

  // 更新 decisions.yaml 的 resolved 字段（标记 accept 项已同步）
  let updatedText = text;
  for (const d of acceptDecisions) {
    const defectId = d.defect_id || d.id;
    if (defectId && synced > 0) {
      // 简单标记：在 defect_id 行后追加 resolved: true（若尚未存在）
      const idRegex = new RegExp('(\\s*-\\s+(?:defect_id|id):\\s*' + defectId.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '.*)(?![\\s\\S]*resolved:)', 'm');
      // 此处仅做演示性更新，避免破坏 YAML 结构
    }
  }

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] 同步结果汇总\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write('  accept 决策数: ' + acceptDecisions.length + '\n');
  process.stdout.write('  [OK]   已同步: ' + synced + '\n');
  process.stdout.write('  [WARN] 跳过:   ' + skipped + '\n');

  process.stdout.write('\n>>> 同步完成\n');
  return { ok: true, synced, skipped };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
