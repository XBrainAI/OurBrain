// check-business-fill.mjs
// 业务填充完整性校验（v5.0 精简版 ~2 项）
//
// 校验项：
//   BF-1: 通用占位 Mock 数据检测（__FILL_BUSINESS__ 标记残留）
//   BF-2: 空标注数据检测（annotationData 未定义或为空）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('check-business-fill.mjs — 业务填充校验 (v5.0)');
  log('======================================================================');

  let pass = 0, fail = 0, critical = 0;

  // BF-1: 通用占位标记检测
  const jsFiles = ['app.js', 'style.css'].map(f => path.join(demoDir, 'assets', f));
  const htmlFile = path.join(demoDir, 'index.html');
  const allFiles = [...jsFiles, htmlFile].filter(f => fs.existsSync(f));

  let placeholderFound = false;
  for (const f of allFiles) {
    const content = fs.readFileSync(f, 'utf-8');
    if (content.includes('__FILL_BUSINESS__')) {
      log(`  [FAIL] BF-1: ${path.relative(projectRoot, f)} 包含 __FILL_BUSINESS__ 占位标记`);
      placeholderFound = true;
      critical++;
    }
  }
  if (!placeholderFound) {
    log('  [OK] BF-1: 无 __FILL_BUSINESS__ 占位标记');
    pass++;
  }

  // BF-2: 空标注数据检测
  if (fs.existsSync(htmlFile)) {
    const html = fs.readFileSync(htmlFile, 'utf-8');
    const hasAnnotationData = html.includes('__ANNOTATION_DATA__');
    if (hasAnnotationData) {
      // 检查是否为空对象
      const emptyMatch = /__ANNOTATION_DATA__\s*=\s*\{\s*\}/.test(html);
      if (emptyMatch) {
        log('  [FAIL] BF-2: __ANNOTATION_DATA__ 为空对象，AI 未填充标注数据');
        critical++;
      } else {
        log('  [OK] BF-2: 标注数据已定义');
        pass++;
      }
    } else {
      log('  [WARN] BF-2: 未检测到 __ANNOTATION_DATA__（标注数据可能未定义）');
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 严重: ${critical}`);
  log('======================================================================');

  if (critical > 0) {
    log('>>> 业务填充校验失败，AI 需完成填充后重新运行');
    return { ok: false, pass, critical };
  }
  log('>>> 业务填充校验通过');
  return { ok: true, pass, critical };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('check-business-fill.mjs') || process.argv[1].endsWith('check-business-fill'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
