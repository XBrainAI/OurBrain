// generate-product-docs.mjs
// Phase 2 HTML 产品文档生成器：基于需求模型生成 HTML 格式产品文档
//
// 功能：
//   1. 读取 .demora/requirement-model.yaml 需求模型
//   2. 生成 docs/index.html（产品文档总引导页面，链接到各 HTML 子文档）
//   3. 生成 docs/product-overview.html（产品概览：项目信息、实体、页面、角色）
//   4. 生成 docs/page-spec.html（页面规格：每页的 L1/L2/L3 标注）
//   5. 生成 docs/data-model.html（数据模型：实体、字段、关系）
//   6. 生成 docs/role-permission.html（角色权限：权限矩阵）
//
// 设计原则：
//   - HTML 文档基于 Demora IP 规范（暗色主题、Teal 主色）
//   - 不含 emoji（遵循 FP-013）
//   - 自包含（无外部 CSS/JS 依赖，内联样式）
//   - 响应式布局，适配桌面与移动端
//   - 主引导页面（index.html）链接到各子文档
//
// 调用：node generate-product-docs.mjs
// cwd：sim-project 目录
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * 轻量 YAML 解析（仅处理需求模型涉及的子集）
 */
function parseYAML(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let pos = 0;

  function isBlankOrComment(line) {
    const t = line.trim();
    return t === '' || t.startsWith('#');
  }
  function indentOf(line) { return line.search(/\S/); }
  function peek() {
    while (pos < lines.length && isBlankOrComment(lines[pos])) pos++;
    return pos < lines.length ? lines[pos] : null;
  }
  function parseValue(parentIndent) {
    const line = peek();
    if (line === null) return null;
    const ind = indentOf(line);
    if (ind <= parentIndent) return null;
    return parseBlock(ind);
  }
  function parseBlock(blockIndent) {
    const first = peek();
    if (first === null) return null;
    if (first.trim().startsWith('-')) return parseSequence(blockIndent);
    return parseMapping(blockIndent);
  }
  function parseMapping(blockIndent) {
    const obj = {};
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      const m = trimmed.match(/^([\w-]+):\s*(.*)$/);
      if (!m) break;
      const key = m[1];
      const rest = m[2].trim();
      pos++;
      if (rest === '') {
        obj[key] = parseValue(blockIndent);
      } else if (rest === '|' || rest === '|-') {
        obj[key] = parseLiteralBlock(blockIndent, rest === '|-');
      } else if (rest.startsWith('[') && rest.endsWith(']')) {
        const inner = rest.slice(1, -1).trim();
        obj[key] = inner === '' ? [] : inner.split(',').map(x => parseScalar(x.trim()));
      } else {
        obj[key] = parseScalar(rest);
      }
    }
    return obj;
  }
  function parseSequence(blockIndent) {
    const arr = [];
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      if (!trimmed.startsWith('-')) break;
      const dashEnd = line.indexOf('-') + 1;
      let contentStart = dashEnd;
      while (contentStart < line.length && line[contentStart] === ' ') contentStart++;
      const after = line.slice(contentStart);
      if (after === '') {
        pos++;
        arr.push(parseValue(blockIndent));
      } else {
        const m = after.match(/^([\w-]+):\s*(.*)$/);
        if (m) {
          const itemIndent = contentStart;
          lines[pos] = ' '.repeat(itemIndent) + after;
          arr.push(parseMapping(itemIndent));
        } else {
          pos++;
          arr.push(parseScalar(after));
        }
      }
    }
    return arr;
  }
  function parseLiteralBlock(parentIndent, strip) {
    const blockLines = [];
    let blockIndent = -1;
    while (true) {
      if (pos >= lines.length) break;
      const line = lines[pos];
      if (line.trim() === '') { blockLines.push(''); pos++; continue; }
      const ind = indentOf(line);
      if (ind <= parentIndent) break;
      if (blockIndent === -1) blockIndent = ind;
      if (ind < blockIndent) break;
      blockLines.push(line.slice(blockIndent));
      pos++;
    }
    while (blockLines.length > 0 && blockLines[blockLines.length - 1] === '') blockLines.pop();
    let content = blockLines.join('\n');
    if (!strip) content += '\n';
    return content;
  }
  function parseScalar(s) {
    if (s === 'true') return true;
    if (s === 'false') return false;
    if (s === 'null' || s === '~') return null;
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1);
    return s;
  }
  return parseBlock(0);
}

/**
 * HTML 转义
 */
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * 生成 CSS 样式（基于 Demora IP 规范：暗色主题、Teal 主色）
 */
function genCss() {
  return `
  :root {
    --color-bg: #070708;
    --color-surface: #0A0A0A;
    --color-surface-hover: #111114;
    --color-text: #F5F5F7;
    --color-text-muted: #A1A1AA;
    --color-text-dim: #71717A;
    --color-border: #1A1A1F;
    --color-border-light: #27272A;
    --color-accent: #14B8A6;
    --color-accent-dim: rgba(20, 184, 166, 0.15);
    --font-body: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Noto Sans SC", sans-serif;
    --font-mono: "JetBrains Mono", "SF Mono", Consolas, monospace;
    --radius-sm: 8px;
    --radius-md: 12px;
    --radius-lg: 20px;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html { font-size: 16px; -webkit-font-smoothing: antialiased; }
  body {
    font-family: var(--font-body);
    background: var(--color-bg);
    color: var(--color-text);
    line-height: 1.7;
    min-height: 100vh;
    padding: 40px 20px;
  }
  .container { max-width: 1100px; margin: 0 auto; }
  .header { text-align: center; margin-bottom: 48px; padding-bottom: 24px; border-bottom: 1px solid var(--color-border); }
  .header h1 { font-size: 32px; font-weight: 700; color: var(--color-text); margin-bottom: 8px; }
  .header .subtitle { font-size: 16px; color: var(--color-text-muted); }
  .header .badge { display: inline-block; padding: 4px 12px; background: var(--color-accent-dim); color: var(--color-accent); border-radius: 99px; font-size: 13px; font-weight: 500; margin-top: 12px; }
  section { margin-bottom: 48px; }
  section h2 { font-size: 22px; font-weight: 700; color: var(--color-accent); margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid var(--color-border); }
  section h3 { font-size: 18px; font-weight: 600; color: var(--color-text); margin: 24px 0 12px; }
  .card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 24px; margin-bottom: 16px; }
  .card:hover { background: var(--color-surface-hover); }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
  table { width: 100%; border-collapse: collapse; margin: 12px 0; }
  th, td { padding: 10px 14px; text-align: left; border-bottom: 1px solid var(--color-border); font-size: 14px; }
  th { color: var(--color-accent); font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }
  td { color: var(--color-text-muted); }
  tr:hover td { color: var(--color-text); }
  code { background: var(--color-surface); padding: 2px 6px; border-radius: 4px; font-family: var(--font-mono); font-size: 13px; color: var(--color-accent); }
  .tag { display: inline-block; padding: 2px 8px; background: var(--color-accent-dim); color: var(--color-accent); border-radius: 99px; font-size: 12px; font-weight: 500; margin-right: 4px; }
  .field-list { list-style: none; padding: 0; }
  .field-list li { padding: 8px 0; border-bottom: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center; }
  .field-list li:last-child { border-bottom: none; }
  .field-name { font-family: var(--font-mono); color: var(--color-accent); font-size: 14px; }
  .field-type { color: var(--color-text-dim); font-size: 13px; }
  .field-desc { color: var(--color-text-muted); font-size: 14px; }
  .nav-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; margin-top: 24px; }
  .nav-card { display: block; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 20px; text-decoration: none; color: var(--color-text); transition: all 0.2s; }
  .nav-card:hover { background: var(--color-surface-hover); border-color: var(--color-accent); transform: translateY(-2px); }
  .nav-card-title { font-size: 16px; font-weight: 600; color: var(--color-accent); margin-bottom: 6px; }
  .nav-card-desc { font-size: 13px; color: var(--color-text-muted); }
  .back-link { display: inline-block; margin-bottom: 24px; color: var(--color-accent); text-decoration: none; font-size: 14px; }
  .back-link:hover { text-decoration: underline; }
  .annotation-block { background: var(--color-surface); border-left: 3px solid var(--color-accent); padding: 16px; margin: 12px 0; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
  .annotation-block h4 { color: var(--color-accent); font-size: 14px; margin-bottom: 8px; }
  .annotation-block p { color: var(--color-text-muted); font-size: 14px; }
  @media (max-width: 768px) {
    body { padding: 20px 12px; }
    .header h1 { font-size: 24px; }
    .grid { grid-template-columns: 1fr; }
    .nav-grid { grid-template-columns: 1fr; }
  }
  `;
}

/**
 * 生成 HTML 文档头部
 */
function genHtmlHead(title, projectName) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(title)} - ${esc(projectName)} 产品文档</title>
<style>${genCss()}</style>
</head>
<body>
<div class="container">
`;
}

/**
 * 生成 HTML 文档尾部
 */
function genHtmlFooter() {
  return `
</div>
</body>
</html>
`;
}

/**
 * 生成主引导页面 index.html
 */
function genIndexHtml(model) {
  const project = model.project || { name: 'Demo', description: '', domain: 'APP' };
  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];

  let body = genHtmlHead('产品文档总览', project.name);
  body += `
<header class="header">
  <h1>${esc(project.name)} 产品文档</h1>
  <p class="subtitle">${esc(project.description || '基于 Demora Skill 生成的结构化产品文档')}</p>
  <span class="badge">Demora 自动生成</span>
</header>

<section>
  <h2>文档导航</h2>
  <p style="color: var(--color-text-muted); margin-bottom: 16px;">以下是该项目的产品文档清单，点击查看详细内容：</p>
  <div class="nav-grid">
    <a class="nav-card" href="product-overview.html">
      <div class="nav-card-title">产品概览</div>
      <div class="nav-card-desc">项目信息、实体清单、页面清单、角色清单</div>
    </a>
    <a class="nav-card" href="page-spec.html">
      <div class="nav-card-title">页面规格</div>
      <div class="nav-card-desc">每个页面的 L1/L2/L3 三层标注（摘要、区域、元件）</div>
    </a>
    <a class="nav-card" href="data-model.html">
      <div class="nav-card-title">数据模型</div>
      <div class="nav-card-desc">实体定义、字段清单、实体关系图</div>
    </a>
    <a class="nav-card" href="role-permission.html">
      <div class="nav-card-title">角色权限</div>
      <div class="nav-card-desc">角色清单、权限矩阵、数据范围</div>
    </a>
  </div>
</section>

<section>
  <h2>项目摘要</h2>
  <div class="card">
    <table>
      <tr><th>项目名称</th><td>${esc(project.name)}</td></tr>
      <tr><th>项目描述</th><td>${esc(project.description || '-')}</td></tr>
      <tr><th>业务领域</th><td>${esc(project.domain || '-')}</td></tr>
      <tr><th>实体数量</th><td>${entities.length}</td></tr>
      <tr><th>页面数量</th><td>${pages.length}</td></tr>
      <tr><th>角色数量</th><td>${roles.length}</td></tr>
    </table>
  </div>
</section>
`;
  body += genHtmlFooter();
  return body;
}

/**
 * 生成产品概览页面 product-overview.html
 */
function genProductOverviewHtml(model) {
  const project = model.project || { name: 'Demo', description: '', domain: 'APP' };
  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];

  let body = genHtmlHead('产品概览', project.name);
  body += `
<a class="back-link" href="index.html">← 返回文档总览</a>
<header class="header">
  <h1>产品概览</h1>
  <p class="subtitle">${esc(project.name)}</p>
</header>

<section>
  <h2>项目信息</h2>
  <div class="card">
    <table>
      <tr><th>项目名称</th><td>${esc(project.name)}</td></tr>
      <tr><th>项目描述</th><td>${esc(project.description || '-')}</td></tr>
      <tr><th>业务领域</th><td>${esc(project.domain || '-')}</td></tr>
    </table>
  </div>
</section>

<section>
  <h2>实体清单（${entities.length}）</h2>
  <div class="grid">
`;
  for (const e of entities) {
    body += `
    <div class="card">
      <h3>${esc(e.displayName || e.name)}</h3>
      <p style="color: var(--color-text-muted); font-size: 14px; margin-bottom: 8px;">${esc(e.description || '-')}</p>
      <p style="font-size: 13px;"><code>${esc(e.name)}</code> · ${e.fields ? e.fields.length : 0} 字段</p>
    </div>`;
  }
  body += `
  </div>
</section>

<section>
  <h2>页面清单（${pages.length}）</h2>
  <table>
    <thead><tr><th>ID</th><th>页面名称</th><th>类型</th><th>路由</th><th>实体</th><th>优先级</th></tr></thead>
    <tbody>
`;
  for (const p of pages) {
    body += `      <tr><td>${esc(p.id)}</td><td>${esc(p.name)}</td><td><span class="tag">${esc(p.type)}</span></td><td><code>${esc(p.route)}</code></td><td>${esc(p.entity || '-')}</td><td>${esc(p.priority || '-')}</td></tr>\n`;
  }
  body += `    </tbody>
  </table>
</section>

<section>
  <h2>角色清单（${roles.length}）</h2>
  <div class="grid">
`;
  for (const r of roles) {
    body += `
    <div class="card">
      <h3>${esc(r.displayName || r.name)}</h3>
      <p style="font-size: 13px;"><code>${esc(r.name)}</code></p>
      <p style="color: var(--color-text-muted); font-size: 14px; margin-top: 8px;">${esc(r.description || '-')}</p>
    </div>`;
  }
  body += `
  </div>
</section>
`;
  body += genHtmlFooter();
  return body;
}

/**
 * 生成页面规格页面 page-spec.html
 */
function genPageSpecHtml(model) {
  const project = model.project || { name: 'Demo' };
  const pages = model.pages || [];

  let body = genHtmlHead('页面规格', project.name);
  body += `
<a class="back-link" href="index.html">← 返回文档总览</a>
<header class="header">
  <h1>页面规格</h1>
  <p class="subtitle">三层标注体系（L1 摘要 / L2 区域 / L3 元件）</p>
</header>
`;
  for (const p of pages) {
    const ann = p.annotations || {};
    const L1 = ann.L1 || {};
    const L2 = ann.L2 || [];
    const L3 = ann.L3 || [];
    body += `
<section>
  <h2>${esc(p.id)} · ${esc(p.name)}</h2>
  <div class="card">
    <table>
      <tr><th>页面 ID</th><td>${esc(p.id)}</td></tr>
      <tr><th>页面名称</th><td>${esc(p.name)}</td></tr>
      <tr><th>页面类型</th><td><span class="tag">${esc(p.type)}</span></td></tr>
      <tr><th>路由</th><td><code>${esc(p.route)}</code></td></tr>
      <tr><th>关联实体</th><td>${esc(p.entity || '-')}</td></tr>
    </table>
  </div>

  <h3>L1 页面说明</h3>
  <div class="annotation-block">
`;
    if (Object.keys(L1).length > 0) {
      body += `    <h4>摘要</h4><p>${esc(L1.summary || '-')}</p>\n`;
      if (L1.entry) body += `    <h4>入口</h4><p>${esc(L1.entry)}</p>\n`;
      if (L1.precondition) body += `    <h4>前置条件</h4><p>${esc(L1.precondition)}</p>\n`;
      if (L1.data_entity) body += `    <h4>数据实体</h4><p>${esc(L1.data_entity)}</p>\n`;
      if (L1.test_data) body += `    <h4>测试数据</h4><p>${esc(L1.test_data)}</p>\n`;
      if (L1.business_rules) {
        body += `    <h4>业务规则</h4><ul style="padding-left: 20px; color: var(--color-text-muted);">\n`;
        for (const r of L1.business_rules) body += `      <li>${esc(r)}</li>\n`;
        body += `    </ul>\n`;
      }
    } else {
      body += `    <p>（无 L1 标注）</p>\n`;
    }
    body += `  </div>

  <h3>L2 区域标注（${L2.length}）</h3>
`;
    if (L2.length > 0) {
      body += `  <table><thead><tr><th>区域 ID</th><th>区域名称</th><th>说明</th></tr></thead><tbody>\n`;
      for (const z of L2) {
        body += `    <tr><td>${esc(z.id || '-')}</td><td>${esc(z.zone || z.name || '-')}</td><td>${esc(z.description || '-')}</td></tr>\n`;
      }
      body += `  </tbody></table>\n`;
    } else {
      body += `  <p style="color: var(--color-text-muted);">（无 L2 标注）</p>\n`;
    }

    body += `  <h3>L3 元件标注（${L3.length}）</h3>
`;
    if (L3.length > 0) {
      body += `  <table><thead><tr><th>元件 ID</th><th>元件名称</th><th>功能</th><th>触发</th><th>响应</th></tr></thead><tbody>\n`;
      for (const e of L3) {
        body += `    <tr><td>${esc(e.id || '-')}</td><td>${esc(e.element || '-')}</td><td>${esc(e.function || '-')}</td><td>${esc(e.trigger || '-')}</td><td>${esc(e.response || '-')}</td></tr>\n`;
      }
      body += `  </tbody></table>\n`;
    } else {
      body += `  <p style="color: var(--color-text-muted);">（无 L3 标注）</p>\n`;
    }

    body += `</section>
`;
  }

  body += genHtmlFooter();
  return body;
}

/**
 * 生成数据模型页面 data-model.html
 */
function genDataModelHtml(model) {
  const project = model.project || { name: 'Demo' };
  const entities = model.entities || [];

  let body = genHtmlHead('数据模型', project.name);
  body += `
<a class="back-link" href="index.html">← 返回文档总览</a>
<header class="header">
  <h1>数据模型</h1>
  <p class="subtitle">实体定义与字段清单</p>
</header>
`;
  for (const e of entities) {
    body += `
<section>
  <h2>${esc(e.displayName || e.name)}</h2>
  <div class="card">
    <table>
      <tr><th>实体名称</th><td><code>${esc(e.name)}</code></td></tr>
      <tr><th>显示名称</th><td>${esc(e.displayName || '-')}</td></tr>
      <tr><th>描述</th><td>${esc(e.description || '-')}</td></tr>
    </table>
  </div>

  <h3>字段清单</h3>
`;
    const fields = e.fields || [];
    if (fields.length > 0) {
      body += `  <table><thead><tr><th>字段名</th><th>类型</th><th>显示名称</th><th>必填</th><th>说明</th></tr></thead><tbody>\n`;
      for (const f of fields) {
        body += `    <tr><td><code>${esc(f.name)}</code></td><td>${esc(f.type || '-')}</td><td>${esc(f.displayName || '-')}</td><td>${f.required ? '是' : '否'}</td><td>${esc(f.description || '-')}</td></tr>\n`;
      }
      body += `  </tbody></table>\n`;
    } else {
      body += `  <p style="color: var(--color-text-muted);">（无字段定义）</p>\n`;
    }

    const statuses = e.statuses || [];
    if (statuses.length > 0) {
      body += `  <h3>状态字典</h3>
  <table><thead><tr><th>状态值</th><th>显示名称</th><th>标签颜色</th></tr></thead><tbody>\n`;
      for (const s of statuses) {
        body += `    <tr><td><code>${esc(s.value)}</code></td><td>${esc(s.label || '-')}</td><td><span class="tag">${esc(s.color || 'info')}</span></td></tr>\n`;
      }
      body += `  </tbody></table>\n`;
    }

    const relations = e.relations || [];
    if (relations.length > 0) {
      body += `  <h3>关联关系</h3>
  <table><thead><tr><th>关系类型</th><th>目标实体</th></tr></thead><tbody>\n`;
      for (const r of relations) {
        body += `    <tr><td><span class="tag">${esc(r.type)}</span></td><td><code>${esc(r.target)}</code></td></tr>\n`;
      }
      body += `  </tbody></table>\n`;
    }

    body += `</section>
`;
  }

  body += genHtmlFooter();
  return body;
}

/**
 * 生成角色权限页面 role-permission.html
 */
function genRolePermissionHtml(model) {
  const project = model.project || { name: 'Demo' };
  const roles = model.roles || [];
  const entities = model.entities || [];

  let body = genHtmlHead('角色权限', project.name);
  body += `
<a class="back-link" href="index.html">← 返回文档总览</a>
<header class="header">
  <h1>角色权限</h1>
  <p class="subtitle">角色清单与权限矩阵</p>
</header>

<section>
  <h2>角色清单</h2>
  <div class="grid">
`;
  for (const r of roles) {
    body += `
    <div class="card">
      <h3>${esc(r.displayName || r.name)}</h3>
      <p style="font-size: 13px;"><code>${esc(r.name)}</code></p>
      <p style="color: var(--color-text-muted); font-size: 14px; margin-top: 8px;">${esc(r.description || '-')}</p>
    </div>`;
  }
  body += `
  </div>
</section>

<section>
  <h2>权限矩阵</h2>
`;
  if (roles.length > 0 && entities.length > 0) {
    const headerCells = entities.map(e => `<th>${esc(e.displayName || e.name)}</th>`).join('');
    body += `  <table><thead><tr><th>角色</th>${headerCells}</tr></thead><tbody>\n`;
    for (const r of roles) {
      const perms = r.permissions || [];
      const cells = entities.map(e => {
        const perm = perms.find(p => p.entity === e.name);
        if (!perm) return '<td>-</td>';
        const actions = (perm.actions || []).join(', ');
        return `<td><span class="tag">${esc(perm.scope || 'all')}</span> ${esc(actions)}</td>`;
      }).join('');
      body += `    <tr><td>${esc(r.displayName || r.name)}</td>${cells}</tr>\n`;
    }
    body += `  </tbody></table>\n`;
  } else {
    body += `  <p style="color: var(--color-text-muted);">（无角色或实体数据）</p>\n`;
  }

  body += `</section>
`;

  // 页面可见性
  const hasVisibility = roles.some(r => r.page_visibility && r.page_visibility.length > 0);
  if (hasVisibility) {
    body += `
<section>
  <h2>页面可见性</h2>
  <table><thead><tr><th>角色</th><th>可见页面</th></tr></thead><tbody>\n`;
    for (const r of roles) {
      const pv = r.page_visibility || [];
      const pages = pv.map(p => `<span class="tag">${esc(typeof p === 'string' ? p : (p.pageId || p.id || JSON.stringify(p)))}</span>`).join(' ');
      body += `    <tr><td>${esc(r.displayName || r.name)}</td><td>${pages || '-'}</td></tr>\n`;
    }
    body += `  </tbody></table>
</section>
`;
  }

  body += genHtmlFooter();
  return body;
}

/**
 * 主入口
 */
export function main(args = {}) {
  const root = args.root || process.cwd();

  process.stdout.write('======================================================================\n');
  process.stdout.write('HTML 产品文档生成\n');
  process.stdout.write('======================================================================\n');

  // 1. 读取需求模型
  const modelFile = path.join(root, '.demora', 'requirement-model.yaml');
  if (!fs.existsSync(modelFile)) {
    process.stderr.write('[FAIL] 需求模型不存在: ' + modelFile + '\n');
    process.exit(1);
  }

  const text = fs.readFileSync(modelFile, { encoding: 'utf-8' });
  let model;
  try {
    model = parseYAML(text);
  } catch (e) {
    process.stderr.write('[FAIL] 需求模型解析失败: ' + e.message + '\n');
    process.exit(1);
  }

  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];
  const project = model.project || { name: 'Demo', description: '', domain: 'APP' };

  process.stdout.write('  [INFO] 项目: ' + project.name + '\n');
  process.stdout.write('  [INFO] 实体: ' + entities.length + ' 个\n');
  process.stdout.write('  [INFO] 页面: ' + pages.length + ' 个\n');
  process.stdout.write('  [INFO] 角色: ' + roles.length + ' 个\n');

  // 2. 生成 HTML 文档到 docs/ 目录
  const docsDir = path.join(root, 'docs');
  if (!fs.existsSync(docsDir)) {
    fs.mkdirSync(docsDir, { recursive: true });
  }

  const docs = [
    { name: 'index.html', content: genIndexHtml(model), title: '产品文档总览' },
    { name: 'product-overview.html', content: genProductOverviewHtml(model), title: '产品概览' },
    { name: 'page-spec.html', content: genPageSpecHtml(model), title: '页面规格' },
    { name: 'data-model.html', content: genDataModelHtml(model), title: '数据模型' },
    { name: 'role-permission.html', content: genRolePermissionHtml(model), title: '角色权限' },
  ];

  for (const d of docs) {
    const filePath = path.join(docsDir, d.name);
    fs.writeFileSync(filePath, d.content, { encoding: 'utf-8' });
    process.stdout.write('  [OK] 生成 ' + d.name + ' (' + d.title + ')\n');
  }

  // v5.0：设计判断产出物为 .demora/design-decisions.md，提示 PM 查看
  const designDecisionsFile = path.join(root, '.demora', 'design-decisions.md');
  if (fs.existsSync(designDecisionsFile)) {
    const overviewPath = path.join(docsDir, 'product-overview.html');
    if (fs.existsSync(overviewPath)) {
      let overview = fs.readFileSync(overviewPath, { encoding: 'utf-8' });
      // 仅在尚未追加设计意图章节时追加（幂等）
      if (!/设计意图（design-decisions）/.test(overview)) {
        const briefSection = `
<section>
  <h2>设计意图（design-decisions）</h2>
  <p style="color: var(--color-text-muted); margin-bottom: 16px;">由 frontend-design skill 完整方法论生成，详见 <code>.demora/design-decisions.md</code>（自由形式 markdown）。设计质量的可观测性由 PM 人工评审与 A/B/C 对比验证承担。业界标准方案引入计划详见根目录 AGENTS.md §一.1 原则 4。</p>
</section>
`;
        // 在最后一个 </section> 后插入（确保在 </div></body> 之前）
        overview = overview.replace(/<\/div>\s*<\/body>/, briefSection + '</div>\n</body>');
        fs.writeFileSync(overviewPath, overview, { encoding: 'utf-8' });
        process.stdout.write('  [OK] 追加 design-decisions 章节到 product-overview.html\n');
      }
    }
  }

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] HTML 产品文档生成汇总\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write('  输出目录: docs/\n');
  process.stdout.write('  文档数量: ' + docs.length + '\n');
  process.stdout.write('  主引导页: docs/index.html\n');
  process.stdout.write('\n>>> HTML 产品文档生成完成\n');

  return { ok: true, docCount: docs.length, docsDir };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
