// quality-check.mjs
// 基本质量门禁（v5.0 精简版 + v5.1 Q-6 AI 产出侧自检）
//
// 六维度检查：
//   Q-1: 目录结构完整性（demo/index.html 存在且非空）
//   Q-2: 业务填充完整性（无 __FILL_BUSINESS__ 占位标记）
//   Q-3: 文档生成完整性（docs/ 目录非空）
//   Q-4: 状态机推进（final_approved = true）
//   Q-5: 业界方案闭环校验（htmlhint 静态分析，无 htmlhint 时降级为基本 HTML 检查）
//   Q-6: AI 产出侧自检清单（v5.1 新增，规则化检查，不增加 LLM 调用）
//
// v5.1 Sprint 1 P0-5（来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion）：
//   - 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
//   - PM 决策：不增加 LLM 调用，仅规则化检查
//   - 检查项：DOCTYPE / viewport / lang / signature element / typography / 反 AI 默认审美 / 占位文本
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { spawnSync } from 'child_process';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/**
 * Q-5 业界方案闭环校验：调用 htmlhint 静态分析 HTML
 *
 * 策略（保持 Skill 包零外部依赖原则）：
 *   1. 优先用项目根目录的 htmlhint（用户在自己的项目内 npm install htmlhint 后可用）
 *   2. 找不到 htmlhint 时降级为基本 HTML 检查（doctype、未闭合标签、img alt）
 *
 * @param {string} projectRoot 项目根目录（含 .demora）
 * @param {string} demoDir Demo 目录
 * @param {string} htmlFile index.html 完整路径
 * @returns {{skipped?:boolean, message?:string, errors:number, warnings:number, details:string[]}}
 */
function runHtmlhintCheck(projectRoot, demoDir, htmlFile) {
  // 候选 htmlhint CLI 路径：项目根 / 当前工作目录 / Skill 包内 / demora 开发态根
  // projectRoot 是用户运行 quality-check 时所在的项目根（含 .demora 目录）
  // process.cwd() 兼容在 demora 开发态项目根直接运行测试的场景
  // SOURCE 结构：scripts/ → skill-template/ → templates/ → src/ → demora/（4 级）
  // BUILD 结构：scripts/ → <pkg>/ → build/ → demora/（3 级）
  // 注意：htmlhint 1.9.x 的 CLI 入口是 dist/cli/htmlhint.js（不是 dist/cli.js）
  const candidates = [
    path.join(projectRoot, 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(process.cwd(), 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(__dirname, '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(__dirname, '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    // BUILD 包：scripts/ → <pkg>/ → build/ → demora/（3 级向上到 demora 根）
    path.join(__dirname, '..', '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    // SOURCE 包：scripts/ → skill-template/ → templates/ → src/ → demora/（4 级向上到 demora 根）
    path.join(__dirname, '..', '..', '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
  ];
  let htmlhintCli = null;
  for (const p of candidates) {
    if (fs.existsSync(p)) { htmlhintCli = p; break; }
  }

  // 有 htmlhint：subprocess 调用（--format json 便于解析）
  // 关键：demoDir 必须转为绝对路径，否则当 cwd=projectRoot 时 htmlhint 会将相对路径
  // 解析为 cwd/demoDir（即 projectRoot/projectRoot/demo），导致找不到文件返回空结果
  // cwd 设为 projectRoot 以便 htmlhint 从该目录向上查找 .htmlhintrc 配置文件
  if (htmlhintCli) {
    const absDemoDir = path.resolve(demoDir);
    const result = spawnSync(process.execPath, [htmlhintCli, absDemoDir, '--format', 'json'], {
      encoding: 'utf-8',
      cwd: path.resolve(projectRoot),
      maxBuffer: 5 * 1024 * 1024,
      timeout: 30000,
      windowsHide: true,
    });
    let errors = 0, warnings = 0, details = [];
    // v5.2.4 修复：Demora 标注系统约定的布尔属性白名单
    // 原因：annotation-guide.md §3/§4 约定 data-annotation-root/toggle/close 为布尔属性
    //   但 htmlhint 的 attr-value-not-empty 规则要求所有属性必须有值 → 误报
    //   audit-warehouse-v5.2 发现 3 个误报告警
    const BOOLEAN_ATTR_WHITELIST = [
      'data-annotation-root',
      'data-annotation-toggle',
      'data-annotation-close',
    ];
    try {
      const parsed = JSON.parse(result.stdout || '[]');
      if (Array.isArray(parsed)) {
        for (const file of parsed) {
          if (file.messages && Array.isArray(file.messages)) {
            for (const msg of file.messages) {
              // 过滤白名单布尔属性的 attr-value-not-empty 误报
              if (msg.rule && msg.rule.id === 'attr-value-not-empty') {
                const isWhitelisted = BOOLEAN_ATTR_WHITELIST.some(attr =>
                  msg.message && msg.message.includes(attr));
                if (isWhitelisted) continue;
              }
              if (msg.type === 'error') errors++;
              else if (msg.type === 'warning') warnings++;
              details.push(`${msg.rule.id}: ${msg.message} (line ${msg.line})`);
            }
          }
        }
      }
    } catch (e) {
      // htmlhint 输出无法解析，视为 skip
      return { skipped: true, message: `htmlhint 输出解析失败: ${e.message}`, errors: 0, warnings: 0, details: [] };
    }
    return { errors, warnings, details };
  }

  // 无 htmlhint：降级为基本 HTML 检查
  // 检查项：doctype、html 闭合标签、head/body 配对、未闭合的 div/section、img alt
  const rawHtml = fs.readFileSync(htmlFile, 'utf-8');
  // 关键：剥离 <style>...</style> 和 <script>...</script> 内容后再计数 HTML 标签
  // 原因：CSS/JS 注释中可能包含 "<head>" / "<body>" 等文本（如标注系统注释
  //   "注入 Demo 的 <head>"），会被正则误判为标签未配对
  const html = rawHtml.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '').replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
  const errors = [];
  const warnings = [];

  // doctype 检查
  if (!/<!doctype\s+html>/i.test(rawHtml.slice(0, 200))) {
    errors.push('缺少 <!DOCTYPE html> 声明');
  }

  // html/head/body 配对检查
  // 注意：HTML 中 <html lang="zh-CN"> 的 lang 属性会被 \b 边界匹配，需正确处理
  for (const tag of ['html', 'head', 'body']) {
    const openCount = (html.match(new RegExp(`<${tag}\\b[^>]*>`, 'gi')) || []).length;
    const closeCount = (html.match(new RegExp(`</${tag}\\s*>`, 'gi')) || []).length;
    if (openCount !== closeCount) {
      errors.push(`<${tag}> 标签未配对: open=${openCount}, close=${closeCount}`);
    }
  }

  // 简单的块级元素闭合检查（基于计数）
  for (const tag of ['div', 'section', 'main', 'header', 'footer', 'nav', 'aside', 'article']) {
    const openCount = (html.match(new RegExp(`<${tag}\\b[^>]*>`, 'gi')) || []).length;
    const closeCount = (html.match(new RegExp(`</${tag}\\s*>`, 'gi')) || []).length;
    if (openCount !== closeCount) {
      errors.push(`<${tag}> 标签未配对: open=${openCount}, close=${closeCount}`);
    }
  }

  // img 标签 alt 属性检查（warning）
  const imgTags = html.match(/<img\b[^>]*>/gi) || [];
  for (const img of imgTags) {
    if (!/\balt\s*=/.test(img)) {
      warnings.push(`img 标签缺少 alt 属性: ${img.slice(0, 50)}`);
    }
  }

  return {
    errors: errors.length,
    warnings: warnings.length,
    details: [...errors, ...warnings],
  };
}

/**
 * Q-6 AI 产出侧自检清单（v5.1 新增）
 *
 * 来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion
 * 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
 * PM 决策：不增加 LLM 调用，仅规则化检查
 *
 * 检查项（基于 v0-hardrules-supplement.md 与 frontend-design/SKILL.md 契约）：
 *   - DOCTYPE 声明（错误）
 *   - viewport meta（错误）
 *   - html lang 属性（错误）
 *   - 标注契约 data-zone-id（错误）
 *   - 标注契约 data-element-id（错误）
 *   - 标注契约 data-annotation-toggle（错误）
 *   - 占位文本 TODO/FIXME/Loading（错误）
 *   - 反 AI 默认审美：warm cream #F4F1EA 背景（警告，非错误）
 *   - 反 AI 默认审美：terracotta #B8864A 强调色（警告）
 *   - 反 AI 默认审美：indigo/blue 主色（警告）
 *   - signature element 缺失提示（警告：无 SVG / 无独特视觉元素）
 *
 * @param {string} htmlFile index.html 完整路径
 * @returns {{errors:number, warnings:number, details:string[]}}
 */
function runAiOutputSelfCheck(htmlFile) {
  const html = fs.readFileSync(htmlFile, 'utf-8');
  const errors = [];
  const warnings = [];

  // 错误级检查（FAIL）

  // 1. DOCTYPE 声明
  if (!/<!doctype\s+html>/i.test(html.slice(0, 200))) {
    errors.push('缺少 <!DOCTYPE html> 声明（v0-hardrules-supplement.md §三 强制 COMPLETE 代码）');
  }

  // 2. viewport meta
  if (!/<meta\s+name=["']viewport["']/i.test(html)) {
    errors.push('缺少 <meta name="viewport"> 响应式视口（frontend-design/SKILL.md "responsive down to mobile"）');
  }

  // 3. html lang 属性
  if (!/<html\s+[^>]*lang=/i.test(html)) {
    errors.push('缺少 <html lang="..."> 语言属性（a11y 基线）');
  }

  // 4-6. 标注契约（Demora 核心差异化能力）
  // v5.2.1 修复：支持布尔属性（data-annotation-toggle 无 = 也算合法）
  if (!/data-zone-id\s*=/.test(html)) {
    errors.push('缺少 data-zone-id 属性（标注契约 L2 区域标识，详见 annotation-guide.md）');
  }
  if (!/data-element-id\s*=/.test(html)) {
    errors.push('缺少 data-element-id 属性（标注契约 L3 元件标识）');
  }
  // 支持 data-annotation-toggle="" 和 data-annotation-toggle（布尔）
  if (!/data-annotation-toggle(\s*=|\s|>)/.test(html)) {
    errors.push('缺少 data-annotation-toggle 属性（标注契约 标注开关）');
  }

  // 7. 占位文本
  // v5.2.1 修复：移除 'placeholder'（合法 HTML 属性名，不是占位文本）
  const placeholders = ['TODO', 'FIXME', 'Loading...', 'Demo - 待 AI 设计', '__FILL_BUSINESS__', '待填充'];
  for (const p of placeholders) {
    if (html.includes(p)) {
      errors.push(`检测到占位文本 "${p}"（v0-hardrules-supplement.md §三 强制 COMPLETE 代码）`);
    }
  }

  // 警告级检查（WARN，不阻塞 pass，但提示 AI 可能落入默认审美）

  // v5.2.1 修复：剥离 enhance-prototype.mjs 注入的标注系统内容后再检查颜色
  // 原因：注入的 annotation-styles.css 含 var(--primary, #3b82f6) 等 fallback 值，
  //   这些不是 AI 产出的主色，而是标注引擎的默认 fallback
  // v5.2.4 修复：原正则期望 >>> [demora-...:begin] <<< 格式，但 enhance-prototype.mjs
  //   实际注入格式为 <!-- [demora-annotation-xxx] start --> ... <!-- [demora-annotation-xxx] end -->
  //   导致 Q-6 误报 #3b82f6（audit-warehouse-v5.2 发现）
  const demoraInjectedPatterns = [
    // 旧格式（向后兼容）
    /\/\*\s*>>>\s*\[demora-[^\]]*\s*:begin\]\s*<<<\s*\*\/[\s\S]*?\/\*\s*>>>\s*\[demora-[^\]]*\s*:end\]\s*<<<\s*\*\//g,
    /<!--\s*>>>\s*\[demora-[^\]]*\s*:begin\]\s*<<<\s*-->[\s\S]*?<!--\s*>>>\s*\[demora-[^\]]*\s*:end\]\s*<<<\s*-->/g,
    // 新格式（v5.2.4）：匹配 enhance-prototype.mjs 实际注入的 <!-- [demora-annotation-xxx] start -->...end -->
    /<!--\s*\[demora-annotation-[^\]]*\]\s*start\s*-->[\s\S]*?<!--\s*\[demora-annotation-[^\]]*\]\s*end\s*-->/g,
  ];
  let aiAuthoredHtml = html;
  for (const pat of demoraInjectedPatterns) {
    aiAuthoredHtml = aiAuthoredHtml.replace(pat, '');
  }

  // 8. 反 AI 默认审美：warm cream 背景
  // frontend-design/SKILL.md 明确禁止的 3 种默认风之一
  const warmCreamPatterns = ['#F4F1EA', '#f4f1ea', '#F4F1E8', '#f4f1e8', 'rgba(244, 241, 234'];
  for (const p of warmCreamPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 warm cream 背景 ${p}（frontend-design/SKILL.md 默认风 1，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 9. 反 AI 默认审美：terracotta 强调色
  const terracottaPatterns = ['#B8864A', '#b8864a', '#C66B3D', '#c66b3d', '#B8860B', '#b8860b'];
  for (const p of terracottaPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 terracotta 强调色 ${p}（frontend-design/SKILL.md 默认风 1，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 10. 反 AI 默认审美：indigo/blue 主色
  // v0 硬规则禁止，与 frontend-design 同源
  const indigoPatterns = ['#6366F1', '#6366f1', '#4F46E5', '#4f46e5', '#3B82F6', '#3b82f6', '#2563EB', '#2563eb'];
  for (const p of indigoPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 indigo/blue 主色 ${p}（v0-hardrules-supplement.md §五 禁默认色清单，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 11. signature element 提示（不强制，仅提示）
  // frontend-design/SKILL.md "Spend boldness in one place. Let the signature element be the one memorable thing"
  // 启发式检测：是否包含 SVG / canvas / 独特视觉元素
  const hasSvg = /<svg[\s>]/i.test(html);
  const hasCanvas = /<canvas[\s>]/i.test(html);
  const hasDataViz = /class=["'][^"']*\b(chart|viz|signature|hero|signature-element)\b/i.test(html);
  if (!hasSvg && !hasCanvas && !hasDataViz) {
    warnings.push('未检测到明显的 signature element（SVG/canvas/独特视觉类），建议参考 frontend-design/SKILL.md "Signature element" 章节');
  }

  return {
    errors: errors.length,
    warnings: warnings.length,
    details: [...errors, ...warnings],
  };
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();

  log('======================================================================');
  log('quality-check.mjs — 质量门禁 (v5.0)');
  log('======================================================================');

  let pass = 0, fail = 0;

  // Q-1: 目录结构（内联检查，避免循环 import）
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');
  if (fs.existsSync(indexPath) && fs.statSync(indexPath).size > 50) {
    log('  [OK] Q-1: Demo 结构完整');
    pass++;
  } else {
    log('  [FAIL] Q-1: Demo 结构不完整');
    fail++;
  }

  // Q-2: 业务填充（检测占位标记）
  if (fs.existsSync(indexPath)) {
    const html = fs.readFileSync(indexPath, 'utf-8');
    if (!html.includes('__FILL_BUSINESS__')) {
      log('  [OK] Q-2: 无占位标记残留');
      pass++;
    } else {
      log('  [FAIL] Q-2: 仍有 __FILL_BUSINESS__ 占位标记');
      fail++;
    }
  }

  // Q-3: 文档目录
  const docsDir = path.join(projectRoot, 'docs');
  if (fs.existsSync(docsDir)) {
    const files = fs.readdirSync(docsDir, { withFileTypes: true });
    const hasContent = files.some(f => f.isFile() || (f.isDirectory() && fs.readdirSync(path.join(docsDir, f.name)).length > 0));
    if (hasContent) {
      log('  [OK] Q-3: 文档目录非空');
      pass++;
    } else {
      log('  [WARN] Q-3: 文档目录为空（可能未运行 generate-prd.mjs）');
    }
  } else {
    log('  [WARN] Q-3: docs/ 目录不存在');
  }

  // 检查 state.yaml
  const statePath = path.join(projectRoot, '.demora', 'state.yaml');
  if (fs.existsSync(statePath)) {
    const state = fs.readFileSync(statePath, 'utf-8');
    if (/final_approved:\s*true/.test(state)) {
      log('  [OK] Q-4: final_approved = true');
      pass++;
    } else {
      log('  [WARN] Q-4: final_approved 未设为 true');
    }
  }

  // Q-5: 业界方案闭环校验（htmlhint 静态分析）
  // P3-2 交付物：通过 htmlhint 验证 HTML 规范性（标签闭合、属性完整、doctype 等）
  // Skill 包零外部依赖原则：htmlhint 不是 Skill 包 dependencies，优先用项目根的（用户 npm install 后），
  // 无则降级为基于正则的基本 HTML 检查
  if (fs.existsSync(indexPath)) {
    const q5Result = runHtmlhintCheck(projectRoot, demoDir, indexPath);
    if (q5Result.skipped) {
      log(`  [WARN] Q-5: ${q5Result.message}`);
    } else if (q5Result.errors > 0) {
      log(`  [FAIL] Q-5: htmlhint 检出 ${q5Result.errors} 个错误, ${q5Result.warnings} 个警告`);
      q5Result.details.slice(0, 5).forEach(d => log(`         - ${d}`));
      fail++;
    } else if (q5Result.warnings > 0) {
      log(`  [OK] Q-5: htmlhint 通过（${q5Result.warnings} 个警告，0 个错误）`);
      pass++;
    } else {
      log(`  [OK] Q-5: htmlhint 通过（0 errors, 0 warnings）`);
      pass++;
    }
  }

  // Q-6: AI 产出侧自检清单（v5.1 新增）
  // 来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion
  // 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
  // PM 决策：不增加 LLM 调用，仅规则化检查
  //
  // sim-project 空壳降级（与 v5.0.1 R1 修复逻辑一致）：
  //   sim-project 的 demo/index.html 是空壳（仅标注系统注入，无真实业务内容），
  //   Q-6 错误级检查（标注契约/占位文本）会失败，属预期。
  //   检测空壳特征：包含 "Demo - 待 AI 设计" 或 "AI: 基于 frontend-design skill 方法论从零设计"
  //   空壳场景下 Q-6 错误降级为 WARN，不阻塞 pass。
  if (fs.existsSync(indexPath)) {
    const q6Result = runAiOutputSelfCheck(indexPath);
    const htmlContent = fs.readFileSync(indexPath, 'utf-8');
    const isSimShell = htmlContent.includes('Demo - 待 AI 设计') ||
                       htmlContent.includes('AI: 基于 frontend-design skill 方法论从零设计') ||
                       htmlContent.includes('AI 基于 frontend-design skill 方法论从零设计');
    if (isSimShell && q6Result.errors > 0) {
      // sim-project 空壳场景：错误降级为 WARN
      log(`  [WARN] Q-6: AI 产出侧自检跳过（sim-project 空壳，${q6Result.errors} 项降级为提示）`);
      q6Result.details.forEach(d => log(`         - ${d}`));
      log('  [INFO] Q-6: 真实 AI 产出场景将严格执行所有检查项');
      pass++;
    } else if (q6Result.errors > 0) {
      log(`  [FAIL] Q-6: AI 产出侧自检未通过（${q6Result.errors} 个错误）`);
      q6Result.details.forEach(d => log(`         - ${d}`));
      fail++;
    } else if (q6Result.warnings > 0) {
      log(`  [OK] Q-6: AI 产出侧自检通过（${q6Result.warnings} 个提示）`);
      pass++;
    } else {
      log(`  [OK] Q-6: AI 产出侧自检通过（0 errors, 0 warnings）`);
      pass++;
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}`);
  log('======================================================================');

  // 生成 quality-report.yaml
  const demoraDir = path.join(projectRoot, '.demora');
  if (fs.existsSync(demoraDir)) {
    const reportLines = [
      '# quality-report.yaml — 自动生成',
      `passed: ${fail === 0}`,
      `defects: ${fail}`,
      `critical: 0`,
      `major: ${fail}`,
      `checks_passed: ${pass}`,
      `checks_failed: ${fail}`,
    ];
    fs.writeFileSync(path.join(demoraDir, 'quality-report.yaml'), reportLines.join('\n') + '\n', 'utf-8');
    log('  [OK] 已生成 quality-report.yaml');
  }

  if (fail > 0) {
    log('>>> 质量门禁未通过');
    return { ok: false, pass, fail };
  }
  log('>>> 质量门禁通过');
  return { ok: true, pass, fail };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('quality-check.mjs') || process.argv[1].endsWith('quality-check'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
