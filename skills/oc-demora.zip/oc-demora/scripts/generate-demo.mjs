// generate-demo.mjs
// Phase 1 Demo 目录结构生成器（v5.0）
//
// 设计理念：
//   仅创建空目录结构和空文件，不生成任何 HTML/JS/CSS 内容。
//   Demo 的完整内容由 AI 基于 frontend-design skill 方法论从零设计。
//
// 流程：
//   1. 读取 .demora/requirement-model.yaml（验证存在）
//   2. 创建 demo/ 目录结构（空文件 + start.bat + README）
//   3. 更新 state.yaml 的 demo_protected 字段
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoraDir = path.join(projectRoot, '.demora');
  const demoDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('generate-demo.mjs — 创建 Demo 目录结构 (v5.0)');
  log('======================================================================');

  // 1. 验证需求模型存在
  const modelPath = path.join(demoraDir, 'requirement-model.yaml');
  if (!fs.existsSync(modelPath)) {
    log('[FAIL] .demora/requirement-model.yaml 不存在，请先完成 Phase 1 需求澄清');
    return { ok: false, error: 'requirement-model.yaml not found' };
  }

  // 2. 检查 demo_protected
  const statePath = path.join(demoraDir, 'state.yaml');
  if (fs.existsSync(statePath)) {
    const stateContent = fs.readFileSync(statePath, 'utf-8');
    if (/demo_protected:\s*true/.test(stateContent)) {
      log('[WARN] demo_protected: true，Demo 已受保护。如需重新生成，请先解锁');
      return { ok: false, error: 'demo is protected' };
    }
  }

  // 3. 创建 demo/ 目录结构
  const dirs = [
    demoDir,
    path.join(demoDir, 'assets'),
  ];
  for (const d of dirs) {
    if (!fs.existsSync(d)) {
      fs.mkdirSync(d, { recursive: true });
      log(`  [OK] 创建目录: ${path.relative(projectRoot, d)}/`);
    }
  }

  // 4. 创建空文件（AI 填充）
  const emptyFiles = [
    { path: path.join(demoDir, 'index.html'), content: '<!DOCTYPE html>\n<html lang="zh-CN">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>Demo</title>\n</head>\n<body>\n  <!-- AI: 基于 frontend-design skill 方法论从零设计完整 HTML -->\n</body>\n</html>\n' },
    { path: path.join(demoDir, 'assets', 'app.js'), content: '// AI: 基于 frontend-design skill 方法论编写应用逻辑\n' },
    { path: path.join(demoDir, 'assets', 'style.css'), content: '/* AI: 基于 frontend-design skill 方法论编写样式 */\n' },
  ];

  for (const f of emptyFiles) {
    if (!fs.existsSync(f.path)) {
      fs.writeFileSync(f.path, f.content, 'utf-8');
      log(`  [OK] 创建文件: ${path.relative(projectRoot, f.path)}`);
    } else {
      log(`  [INFO] 文件已存在，跳过: ${path.relative(projectRoot, f.path)}`);
    }
  }

  // 5. 创建 start.bat（默认内容，不再引用已 DROP 的 demo-framework 模板）
  const startBatPath = path.join(demoDir, 'start.bat');
  if (!fs.existsSync(startBatPath)) {
    fs.writeFileSync(startBatPath, '@echo off\nstart "" "index.html"\n', 'utf-8');
    log('  [OK] 创建默认 start.bat');
  }

  // 6. 创建 README.txt
  const readmePath = path.join(demoDir, 'README.txt');
  if (!fs.existsSync(readmePath)) {
    fs.writeFileSync(readmePath, 'Demora Demo\n============\n\n由 AI 基于 frontend-design skill 方法论设计。\n双击 start.bat 或直接在浏览器中打开 index.html 查看。\n', 'utf-8');
    log('  [OK] 创建 README.txt');
  }

  // 7. 更新 state.yaml
  if (fs.existsSync(statePath)) {
    let stateContent = fs.readFileSync(statePath, 'utf-8');
    stateContent = stateContent.replace(/demo_protected:\s*false/, 'demo_protected: true');
    if (!stateContent.includes('demo_protected')) {
      stateContent += '\ndemo_protected: true\n';
    }
    fs.writeFileSync(statePath, stateContent, 'utf-8');
    log('  [OK] 更新 state.yaml: demo_protected = true');
  }

  log('\n======================================================================');
  log('[SUMMARY] Demo 目录结构已创建');
  log('======================================================================');
  log('  demo/index.html          — AI 填充完整 HTML');
  log('  demo/assets/app.js       — AI 填充应用逻辑');
  log('  demo/assets/style.css    — AI 填充样式');
  log('  demo/start.bat           — 启动脚本');
  log('\n>>> AI 下一步：读取 skills/frontend-design/SKILL.md，从零设计 Demo');

  return { ok: true };
}

// 直接运行守卫
const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('generate-demo.mjs') || process.argv[1].endsWith('generate-demo'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
