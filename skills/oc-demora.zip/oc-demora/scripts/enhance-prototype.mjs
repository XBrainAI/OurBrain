// enhance-prototype.mjs
// Phase 2 Demo 增强：注入标注三件套（v5.1 Shadow DOM 隔离版）
//
// 设计理念：
//   标注系统作为"独立叠加层"，通过 data-* 属性约定与 AI 生成的 HTML 对接。
//   面板用 Shadow DOM 封装，避免 .anno-card / .l2-tag 等通用类名污染主页面。
//
// 注入方式（v5.1 Shadow DOM 隔离）：
//   1. annotation-styles.css 主页面部分 → demo/index.html <head> 末尾
//   2. Shadow DOM 宿主 <div id="demora-annotation-host"> → <body> 末尾
//   3. annotation-styles.css 面板部分 + annotation-panel.html → Shadow DOM 内
//   4. annotation-engine.js → <body> 末尾（通过 host.shadowRoot 访问面板）
//
// 幂等：使用标记注释包裹注入内容，重复运行不会重复注入。
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

function findReferencesDir() {
  const candidates = [
    path.join(__dirname, '..', 'references'),
    path.join(__dirname, '..', '..', '..', 'src', 'reference'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/**
 * 从 CSS 内容中按标记提取区段
 * 标记格式：/* >>> [section-name:begin] <<< *​/ ... /* >>> [section-name:end] <<< *​/
 * @param {string} css 完整 CSS 内容
 * @param {string} sectionName 区段名（如 'demora-main-page-styles'）
 * @returns {string} 区段内容（不含标记行），未找到则返回空字符串
 */
function extractCssSection(css, sectionName) {
  const beginMarker = `>>> [${sectionName}:begin]`;
  const endMarker = `>>> [${sectionName}:end]`;
  const beginIdx = css.indexOf(beginMarker);
  const endIdx = css.indexOf(endMarker);
  if (beginIdx === -1 || endIdx === -1 || endIdx < beginIdx) {
    return '';
  }
  // 截取 begin 行结束位置到 end 标记开始位置之间的内容
  const beginLineEnd = css.indexOf('\n', beginIdx);
  const content = css.slice(beginLineEnd + 1, endIdx).trim();
  return content;
}

const INJECT_CSS_START = '<!-- [demora-annotation-css] start -->';
const INJECT_CSS_END = '<!-- [demora-annotation-css] end -->';
const INJECT_PANEL_START = '<!-- [demora-annotation-panel] start -->';
const INJECT_PANEL_END = '<!-- [demora-annotation-panel] end -->';
const INJECT_JS_START = '<!-- [demora-annotation-js] start -->';
const INJECT_JS_END = '<!-- [demora-annotation-js] end -->';

// v5.2.7：CSS 内部标记（用于 check-structure.mjs S-6 排除正则匹配）
// 原因：HTML 注释标记位于 <style> 标签外，readAllCss() 仅提取 <style> 内的 CSS 文本，
//       导致 injectedBlockRegex 无法匹配，注入的保留类名规则被误判为 AI 重复定义。
// 修复：在 <style> 标签内额外添加 CSS 注释包裹标记，使 S-6 能正确识别注入块。
const INJECT_CSS_INNER_START = '/* [demora-injected-css] start */';
const INJECT_CSS_INNER_END = '/* [demora-injected-css] end */';
const INJECT_PANEL_CSS_INNER_START = '/* [demora-injected-panel-css] start */';
const INJECT_PANEL_CSS_INNER_END = '/* [demora-injected-panel-css] end */';

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');
  const refsDir = findReferencesDir();

  log('======================================================================');
  log('enhance-prototype.mjs — 注入标注三件套 (v5.1 Shadow DOM 隔离)');
  log('======================================================================');

  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在，请先运行 generate-demo.mjs 并让 AI 填充内容');
    return { ok: false, error: 'demo/index.html not found' };
  }

  if (!refsDir) {
    log('[FAIL] 未找到 references 目录');
    return { ok: false, error: 'references dir not found' };
  }

  const annotationDir = path.join(refsDir, 'annotation');
  const cssPath = path.join(annotationDir, 'annotation-styles.css');
  const panelPath = path.join(annotationDir, 'annotation-panel.html');
  const jsPath = path.join(annotationDir, 'annotation-engine.js');

  for (const [label, fp] of [['CSS', cssPath], ['Panel', panelPath], ['JS', jsPath]]) {
    if (!fs.existsSync(fp)) {
      log(`[FAIL] 标注 ${label} 文件不存在: ${fp}`);
      return { ok: false, error: `annotation ${label} not found` };
    }
  }

  // 读取并分割 CSS（v5.1：主页面样式 + 面板样式）
  const fullCss = fs.readFileSync(cssPath, 'utf-8');
  const mainPageCss = extractCssSection(fullCss, 'demora-main-page-styles');
  const panelCss = extractCssSection(fullCss, 'demora-panel-styles');

  if (!mainPageCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-main-page-styles] 区段');
    return { ok: false, error: 'CSS section demora-main-page-styles not found' };
  }
  if (!panelCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-panel-styles] 区段');
    return { ok: false, error: 'CSS section demora-panel-styles not found' };
  }
  log('  [OK] CSS 分割完成: 主页面 ' + mainPageCss.length + ' 字符, 面板 ' + panelCss.length + ' 字符');

  const panelHtml = fs.readFileSync(panelPath, 'utf-8').trim();

  let html = fs.readFileSync(indexPath, 'utf-8');
  let injectCount = 0;

  // 1. 注入主页面 CSS 到 <head> 末尾（标记样式 + 激活态 padding）
  // v5.2.7：在 <style> 内额外添加 CSS 注释包裹标记，配合 check-structure.mjs S-6 排除正则
  if (!html.includes(INJECT_CSS_START)) {
    const cssBlock = `\n${INJECT_CSS_START}\n<style>\n${INJECT_CSS_INNER_START}\n${mainPageCss}\n${INJECT_CSS_INNER_END}\n</style>\n${INJECT_CSS_END}\n`;
    if (html.includes('</head>')) {
      html = html.replace('</head>', cssBlock + '</head>');
      injectCount++;
      log('  [OK] 注入主页面标记样式 -> <head>（含 S-6 内部标记）');
    } else {
      log('  [WARN] 未找到 </head>，跳过主页面 CSS 注入');
    }
  } else {
    log('  [INFO] 主页面 CSS 已注入（幂等跳过）');
  }

  // 2. 注入 Shadow DOM 宿主 + 面板内容到 </body> 前
  //    使用 <template> 元素承载面板 CSS+HTML，避免 </script> 字符串转义问题
  // v5.2.7：在面板 <style> 内额外添加 CSS 注释包裹标记
  if (!html.includes(INJECT_PANEL_START)) {
    const panelBlock = `\n${INJECT_PANEL_START}\n<template id="demora-annotation-panel-tpl"><style>\n${INJECT_PANEL_CSS_INNER_START}\n${panelCss}\n${INJECT_PANEL_CSS_INNER_END}\n</style>\n${panelHtml}\n</template>\n<div id="demora-annotation-host"></div>\n<script>(function(){var h=document.getElementById('demora-annotation-host');var t=document.getElementById('demora-annotation-panel-tpl');if(!h||!t){return;}var s=h.attachShadow({mode:'open'});s.appendChild(t.content.cloneNode(true));})();</script>\n${INJECT_PANEL_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', panelBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板（template + 宿主 + bootstrap，含 S-6 内部标记）');
    } else {
      html += panelBlock;
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板 -> 末尾（含 S-6 内部标记）');
    }
  } else {
    log('  [INFO] Shadow DOM 面板已注入（幂等跳过）');
  }

  // 3. 注入标注引擎 JS 到 </body> 前
  if (!html.includes(INJECT_JS_START)) {
    const jsContent = fs.readFileSync(jsPath, 'utf-8');
    const jsBlock = `\n${INJECT_JS_START}\n<script>\n${jsContent}\n</script>\n${INJECT_JS_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', jsBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> <body>');
    } else {
      html += jsBlock;
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> 末尾');
    }
  } else {
    log('  [INFO] JS 已注入（幂等跳过）');
  }

  if (injectCount > 0) {
    fs.writeFileSync(indexPath, html, 'utf-8');
    log(`\n  [OK] demo/index.html 已更新（${injectCount} 项注入）`);
  }

  log('\n======================================================================');
  log('[SUMMARY] 标注三件套注入完成（v5.1 Shadow DOM 隔离）');
  log('======================================================================');
  log('  主页面样式（标记 + 激活态 padding）-> <head>');
  log('  面板样式 + 面板 HTML -> Shadow DOM');
  log('  标注引擎 JS -> <body>（通过 host.shadowRoot 访问面板）');
  log('  AI 代码零侵入 — 标注系统通过 data-* 属性约定工作');

  return { ok: true, injected: injectCount };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('enhance-prototype.mjs') || process.argv[1].endsWith('enhance-prototype'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
