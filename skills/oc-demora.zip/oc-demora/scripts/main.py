#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""main.py - Demora Skill CLI 入口

提供 5 个子命令路由到对应的 .mjs 脚本：
  - scaffold:          初始化项目结构
  - validate:          校验需求模型
  - lock:              锁定/解锁需求模型
  - unlock:            解锁需求模型
  - render:            渲染交互卡片

使用方式：
  python main.py scaffold
  python main.py validate
  python main.py lock --confirm
  python main.py unlock
  python main.py render lock-confirm-card

注意：
  - 不强制 stdout/stderr 编码，使用系统默认（GBK）
  - 禁止在 print 输出中使用 emoji，使用 [OK]/[FAIL] 等 ASCII 标记
  - 路径处理使用 pathlib
  - 子命令通过 subprocess 调用 node + .mjs 脚本
"""

import sys
import argparse
import subprocess
from pathlib import Path

# 脚本所在目录（scripts/）
SCRIPTS_DIR = Path(__file__).parent

# 子命令到 .mjs 脚本的映射
COMMAND_MAP = {
    "scaffold": "scaffold-project.mjs",
    "validate": "validate-model.mjs",
    "lock": "lock-model.mjs",
    "unlock": "lock-model.mjs",
    "render": "render-card.mjs",
}


def run_mjs(script_name, extra_args=None):
    """通过 subprocess 调用 node + .mjs 脚本

    Args:
        script_name: .mjs 文件名（如 scaffold-project.mjs）
        extra_args: 额外参数列表

    Returns:
        int: 退出码（0 成功，1 失败）
    """
    script_path = SCRIPTS_DIR / script_name
    if not script_path.exists():
        print("[FAIL] 脚本不存在: " + str(script_path))
        return 1

    cmd = ["node", str(script_path)]
    if extra_args:
        cmd.extend(extra_args)

    print("[INFO] 执行: " + " ".join(cmd))
    try:
        result = subprocess.run(
            cmd,
            cwd=str(Path.cwd()),
            shell=False,
        )
        return result.returncode
    except FileNotFoundError:
        print("[FAIL] 未找到 node 命令，请确保 Node.js 已安装")
        return 1
    except Exception as e:
        print("[FAIL] 执行失败: " + str(e))
        return 1


def cmd_scaffold(args):
    """scaffold 子命令：初始化项目结构"""
    return run_mjs("scaffold-project.mjs")


def cmd_validate(args):
    """validate 子命令：校验需求模型"""
    extra = []
    if args.file:
        extra.append(args.file)
    return run_mjs("validate-model.mjs", extra)


def cmd_lock(args):
    """lock 子命令：锁定需求模型"""
    extra = ["--lock"]
    if args.confirm:
        extra.append("--confirm")
    return run_mjs("lock-model.mjs", extra)


def cmd_unlock(args):
    """unlock 子命令：解锁需求模型"""
    extra = ["--unlock"]
    return run_mjs("lock-model.mjs", extra)


def cmd_render(args):
    """render 子命令：渲染交互卡片"""
    extra = []
    if args.card:
        extra.append(args.card)
    if args.file:
        extra.extend(["--file", args.file])
    if args.stdin:
        extra.append("--stdin")
    return run_mjs("render-card.mjs", extra)


def main():
    """主入口：解析参数并路由到子命令"""
    parser = argparse.ArgumentParser(
        prog="demora",
        description="Demora Skill CLI - 需求澄清与原型生成工具",
    )
    subparsers = parser.add_subparsers(dest="command", help="子命令")

    # scaffold 子命令
    sub_scaffold = subparsers.add_parser("scaffold", help="初始化项目结构")
    sub_scaffold.set_defaults(func=cmd_scaffold)

    # validate 子命令
    sub_validate = subparsers.add_parser("validate", help="校验需求模型")
    sub_validate.add_argument("--file", help="指定 requirement-model.yaml 路径")
    sub_validate.set_defaults(func=cmd_validate)

    # lock 子命令
    sub_lock = subparsers.add_parser("lock", help="锁定需求模型")
    sub_lock.add_argument("--confirm", action="store_true", help="确认锁定")
    sub_lock.set_defaults(func=cmd_lock)

    # unlock 子命令
    sub_unlock = subparsers.add_parser("unlock", help="解锁需求模型")
    sub_unlock.set_defaults(func=cmd_unlock)

    # render 子命令
    sub_render = subparsers.add_parser("render", help="渲染交互卡片")
    sub_render.add_argument("card", nargs="?", help="卡片名称")
    sub_render.add_argument("--file", help="从文件读取输入")
    sub_render.add_argument("--stdin", action="store_true", help="从 stdin 读取输入")
    sub_render.set_defaults(func=cmd_render)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
