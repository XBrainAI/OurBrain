// package-delivery.mjs
// 打包 demo/ + docs/ 为 delivery/delivery-package.zip
//
// 调用：node package-delivery.mjs（无参数）
// cwd：sim-project 目录
// 功能：
//   1. 校验 final_approved: true 状态
//   2. 将 demo/ 与 docs/ 目录压缩到 delivery/delivery-package.zip（标准 ZIP 格式）
//   3. 更新 state.yaml 的 delivery_packaged: true
//
// 注意：使用 PowerShell Compress-Archive 创建标准 ZIP，确保跨平台可解压
//       旧版使用 gzip+pack 自定义格式，无法被标准工具识别，已废弃
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 遍历目录，返回相对路径文件列表
 */
function walkRelative(dir, base) {
  const result = [];
  if (!fs.existsSync(dir)) return result;
  function walk(d) {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else {
        const rel = path.relative(base, full).replace(/\\/g, '/');
        result.push({ full, rel });
      }
    }
  }
  walk(dir);
  return result;
}

/**
 * 将源目录打包为标准 ZIP（使用 PowerShell Compress-Archive）
 * 跨平台兼容：Windows 使用 PowerShell，其它平台使用 zip 命令
 * @param {string} srcDir - 源目录
 * @param {string} outputPath - 输出 ZIP 路径
 * @returns {number} ZIP 文件大小（字节）
 */
function packToZipStandard(srcDir, outputPath) {
  // 删除已存在的 zip
  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
  }
  if (process.platform === 'win32') {
    // Windows: 使用 PowerShell Compress-Archive
    const srcPath = path.resolve(srcDir).replace(/\\/g, '\\');
    const dstPath = path.resolve(outputPath).replace(/\\/g, '\\');
    const cmd = `powershell.exe -NoProfile -Command "Compress-Archive -Path '${srcPath}\\*' -DestinationPath '${dstPath}' -Force"`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('Compress-Archive 失败: ' + e.message);
    }
  } else {
    // Unix: 使用 zip 命令
    const cmd = `cd "${srcDir}" && zip -r "${outputPath}" .`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('zip 命令失败: ' + e.message);
    }
  }
  return fs.statSync(outputPath).size;
}

/**
 * 主入口
 * @param {object} args - { root?: string }
 */
export function main(args = {}) {
  const root = args.root || process.cwd();

  process.stdout.write('======================================================================\n');
  process.stdout.write('打包交付\n');
  process.stdout.write('======================================================================\n');

  // 1. 校验 demo_protected 状态（Phase 2 已完成）+ 质量门禁通过
  // 注意：final_approved 在 Phase 3 末尾才设置（package-delivery 之后），此处不能检查 final_approved
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) {
    process.stderr.write('[FAIL] state.yaml 不存在\n');
    process.exit(1);
  }
  const stateText = fs.readFileSync(stateFile, { encoding: 'utf-8' });
  if (!/demo_protected:\s*true/.test(stateText)) {
    process.stderr.write('[FAIL] Demo 未受保护（Phase 2 未完成），禁止打包\n');
    process.exit(1);
  }
  // 质量门禁检查：quality-report.yaml 中 passed: true
  const qReportFile = path.join(root, '.demora', 'quality-report.yaml');
  if (fs.existsSync(qReportFile)) {
    const qText = fs.readFileSync(qReportFile, { encoding: 'utf-8' });
    if (!/^passed:\s*true\s*$/m.test(qText)) {
      process.stderr.write('[FAIL] 质量门禁未通过，禁止打包\n');
      process.exit(1);
    }
    process.stdout.write('  [OK]   质量门禁通过\n');
  }
  process.stdout.write('  [OK]   demo_protected: true\n');

  // 2. 收集 demo/ 与 docs/ 文件清单（用于统计与校验）
  const demoDir = path.join(root, 'demo');
  const docsDir = path.join(root, 'docs');
  let totalFiles = 0;

  if (fs.existsSync(demoDir)) {
    const demoFiles = walkRelative(demoDir, demoDir);
    totalFiles += demoFiles.length;
    process.stdout.write('  [INFO] demo/ 文件数: ' + demoFiles.length + '\n');
  } else {
    process.stdout.write('  [WARN] demo/ 目录不存在\n');
  }

  if (fs.existsSync(docsDir)) {
    const docsFiles = walkRelative(docsDir, docsDir);
    totalFiles += docsFiles.length;
    process.stdout.write('  [INFO] docs/ 文件数: ' + docsFiles.length + '\n');
  } else {
    process.stdout.write('  [WARN] docs/ 目录不存在\n');
  }

  if (totalFiles === 0) {
    process.stderr.write('[FAIL] 无可打包文件\n');
    process.exit(1);
  }

  // 3. 打包到 delivery/delivery-package.zip（标准 ZIP 格式）
  // 由于 Compress-Archive 只能打包单个目录，需先将 demo/ 与 docs/ 复制到临时合并目录
  const deliveryDir = path.join(root, 'delivery');
  if (!fs.existsSync(deliveryDir)) {
    fs.mkdirSync(deliveryDir, { recursive: true });
  }
  const zipPath = path.join(deliveryDir, 'delivery-package.zip');

  // 创建临时合并目录
  const tmpMergeDir = path.join(deliveryDir, '.tmp-merge');
  if (fs.existsSync(tmpMergeDir)) {
    fs.rmSync(tmpMergeDir, { recursive: true, force: true });
  }
  fs.mkdirSync(tmpMergeDir, { recursive: true });

  // 复制 demo/ 与 docs/ 到临时合并目录
  function copyDir(src, dst) {
    if (!fs.existsSync(src)) return 0;
    fs.mkdirSync(dst, { recursive: true });
    let count = 0;
    function walk(s, d) {
      for (const entry of fs.readdirSync(s, { withFileTypes: true })) {
        const sFull = path.join(s, entry.name);
        const dFull = path.join(d, entry.name);
        if (entry.isDirectory()) {
          fs.mkdirSync(dFull, { recursive: true });
          walk(sFull, dFull);
        } else {
          fs.copyFileSync(sFull, dFull);
          count++;
        }
      }
    }
    walk(src, dst);
    return count;
  }
  copyDir(demoDir, path.join(tmpMergeDir, 'demo'));
  copyDir(docsDir, path.join(tmpMergeDir, 'docs'));

  const zipSize = packToZipStandard(tmpMergeDir, zipPath);

  // 清理临时合并目录
  fs.rmSync(tmpMergeDir, { recursive: true, force: true });

  process.stdout.write('  [OK]   交付包: ' + path.relative(root, zipPath) + '\n');
  process.stdout.write('  [INFO] 大小: ' + (zipSize / 1024).toFixed(2) + ' KB\n');
  process.stdout.write('  [INFO] 文件数: ' + totalFiles + '\n');

  // 4. 更新 state.yaml
  let updatedState = stateText;
  if (/delivery_packaged:\s*false/.test(updatedState)) {
    updatedState = updatedState.replace(/delivery_packaged:\s*false/, 'delivery_packaged: true');
  } else if (!/delivery_packaged:/.test(updatedState)) {
    updatedState = updatedState.trimEnd() + '\ndelivery_packaged: true\n';
  }
  fs.writeFileSync(stateFile, updatedState, { encoding: 'utf-8' });
  process.stdout.write('  [OK]   state.yaml 已更新（delivery_packaged: true）\n');

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] 打包汇总\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write('  交付包路径: ' + zipPath + '\n');
  process.stdout.write('  打包文件数: ' + totalFiles + '\n');
  process.stdout.write('  交付包大小: ' + (zipSize / 1024).toFixed(2) + ' KB\n');

  process.stdout.write('\n>>> 打包完成\n');
  return { ok: true, zipPath, fileCount: totalFiles, size: zipSize };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
