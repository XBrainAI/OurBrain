// scaffold-project.mjs
// 初始化 Demora 项目结构：在用户当前工作目录下创建标准目录与初始文件
//
// 创建内容：
//   - .demora/ 7 个初始 YAML 文件（state/context/conversation-log/requirement-model/model-lock/decisions/traceability）
//   - inbox/ 三个子目录（text/documents/screenshots），各放 .gitkeep
//   - demo/、delivery/ 目录骨架
//   - docs/prd/ 14 个文档（00-13）+ docs/prd/06-page-details/_page-template.md
//   - docs/spec/ 7 个文档（00-06）
//   - docs/test/ 3 个文档（00-02）
//   - docs/handoff/review-notes.md
//   - IDE rules 自动注入（v5.1）：.cursor/rules/demora.mdc + .windsurf/rules/demora.md + AGENTS.md
//
// 调用约定：node scaffold-project.mjs，cwd 为用户项目根目录
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * 查找 IDE rules 模板目录
 * 构建包：scripts/ → ../ide-rules/
 * 源码：scripts/ → ../ide-rules/（skill-template 内）
 */
function findIdeRulesDir() {
  const candidate = path.join(__dirname, '..', 'ide-rules');
  if (fs.existsSync(candidate)) return candidate;
  return null;
}

/**
 * 备份已存在的目标文件（复制为 .bak，不覆盖原文件）
 * @returns {boolean} 是否执行了备份
 */
function backupIfExists(targetPath) {
  if (fs.existsSync(targetPath)) {
    const bakPath = targetPath + '.bak';
    fs.copyFileSync(targetPath, bakPath);
    return true;
  }
  return false;
}

/**
 * 注入 IDE rules（v5.1）：backup 后注入 Cursor / Windsurf / AGENTS.md
 * - .cursor/rules/demora.mdc（从 cursor-demora.mdc 复制）
 * - .windsurf/rules/demora.md（从 windsurf-demora.md 复制）
 * - AGENTS.md（从 agents-demora.md 复制）
 */
function injectIdeRules(root, ideRulesDir, created) {
  const targets = [
    { src: 'cursor-demora.mdc', dstDir: path.join(root, '.cursor', 'rules'), dstFile: 'demora.mdc' },
    { src: 'windsurf-demora.md', dstDir: path.join(root, '.windsurf', 'rules'), dstFile: 'demora.md' },
    { src: 'agents-demora.md', dstDir: root, dstFile: 'AGENTS.md' },
  ];
  let injected = 0;
  for (const t of targets) {
    const srcPath = path.join(ideRulesDir, t.src);
    if (!fs.existsSync(srcPath)) continue;
    fs.mkdirSync(t.dstDir, { recursive: true });
    const dstPath = path.join(t.dstDir, t.dstFile);
    // backup 已有文件
    if (backupIfExists(dstPath)) {
      process.stdout.write(`  [INFO] 已备份: ${t.dstFile} -> ${t.dstFile}.bak\n`);
    }
    fs.copyFileSync(srcPath, dstPath);
    created.push(dstPath);
    injected++;
  }
  return injected;
}

// 占位内容（所有 docs 文档初始内容）
const DOC_PLACEHOLDER = '> 本文档将在 Phase 2 中由系统自动生成。当前为占位状态。';

// docs/prd 14 个文档清单（00-13，06 为目录）
const PRD_DOCS = [
  '00-overview.md',
  '01-background.md',
  '02-target-audience.md',
  '03-user-roles.md',
  '04-business-flow.md',
  '05-page-list.md',
  // 06-page-details/ 是目录，单独处理
  '07-fields.md',
  '08-permissions.md',
  '09-user-stories.md',
  '10-success-metrics.md',
  '11-timeline.md',
  '12-risk-assumptions.md',
  '13-open-questions.md',
];

const SPEC_DOCS = [
  '00-project-overview.md',
  '01-page-architecture.md',
  '02-interaction-flow.md',
  '03-state-matrix.md',
  '04-route-table.md',
  '05-api-contract-draft.md',
  '06-error-and-empty-states.md',
];

const TEST_DOCS = [
  '00-acceptance-criteria.md',
  '01-test-suggestions.md',
  '02-permission-matrix.md',
];

/**
 * 初始化项目结构
 * @param {object} args - { root?: string } 项目根目录，默认 process.cwd()
 * @returns {{ ok: boolean, created: string[] }}
 */
export function main(args = {}) {
  const root = args.root || process.cwd();
  const created = [];

  // 创建目录辅助函数
  function mkdirp(p) {
    fs.mkdirSync(p, { recursive: true });
  }

  // 写入文件辅助函数（UTF-8 编码）
  function writeFile(p, content) {
    fs.writeFileSync(p, content, { encoding: 'utf-8' });
    created.push(p);
  }

  try {
    // ===== 1. .demora/ 目录及 7 个 YAML 文件 =====
    const reqDir = path.join(root, '.demora');
    mkdirp(reqDir);

    // state.yaml：阶段与保护状态
    const now = new Date().toISOString();
    const stateYaml = [
      '# Demora 项目状态文件（scaffold-project.mjs 自动生成）',
      'current_phase: 1',
      'model_locked: false',
      'demo_protected: false',
      'final_approved: false',
      'delivery_packaged: false',
      `pages_generated: []`,
      `docs_generated: []`,
      `created_at: ${now}`,
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'state.yaml'), stateYaml);

    // context.yaml：跨会话上下文
    const contextYaml = [
      '# 跨会话上下文（领域术语、组件清单、样式约束快照）',
      'domain_terms: {}',
      'component_inventory: []',
      'style_constraints: {}',
      '# v5.0 新增：标记 AI 是否已读取 frontend-design 方法论',
      'design_methodology_read: false',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'context.yaml'), contextYaml);

    // conversation-log.yaml：对话历史（append-only）
    const conversationLogYaml = [
      '# 对话历史（append-only，禁止覆盖已有条目）',
      'entries: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'conversation-log.yaml'), conversationLogYaml);

    // requirement-model.yaml：需求模型（Phase 1 填充）
    const modelYaml = [
      '# 需求模型（Phase 1 由 AI 与 PM 对话填充，Phase 2 锁定后只读）',
      'project:',
      '  name: "[待填充]"',
      '  description: "[待填充]"',
      '  domain: "[待填充]"',
      'entities: []',
      'pages: []',
      'roles: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'requirement-model.yaml'), modelYaml);

    // model-lock.yaml：锁定状态与变更日志
    const modelLockYaml = [
      '# 需求模型锁定状态（lock-model.mjs 维护）',
      'locked: false',
      'change_log: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'model-lock.yaml'), modelLockYaml);

    // decisions.yaml：决策记录
    const decisionsYaml = [
      '# 评审决策记录（Phase 3 由 PM 转述评审意见后生成）',
      'decisions: []',
      '# v2.7 新增：设计决策记录（AI 应用 frontend-design 方法论后的设计选择，含 signature_element/typography 等）',
      'design_decisions: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'decisions.yaml'), decisionsYaml);

    // traceability.yaml：追溯链
    const traceabilityYaml = [
      '# 追溯链（generate-traceability.mjs 生成）',
      'traces: []',
      '',
    ].join('\n');
    writeFile(path.join(reqDir, 'traceability.yaml'), traceabilityYaml);

    // ===== 2. inbox/ 三个子目录，各放 .gitkeep =====
    const inboxSubDirs = ['text', 'documents', 'screenshots'];
    for (const sub of inboxSubDirs) {
      const subDir = path.join(root, 'inbox', sub);
      mkdirp(subDir);
      writeFile(path.join(subDir, '.gitkeep'), '');
    }

    // ===== 3. demo/、delivery/ 目录骨架 =====
    mkdirp(path.join(root, 'demo'));
    mkdirp(path.join(root, 'delivery'));

    // ===== 4. docs/prd/ 文档（14 个 + _page-template.md）=====
    const prdDir = path.join(root, 'docs', 'prd');
    mkdirp(prdDir);
    for (const doc of PRD_DOCS) {
      writeFile(path.join(prdDir, doc), DOC_PLACEHOLDER + '\n');
    }
    // 06-page-details 目录与模板
    const pageDetailsDir = path.join(prdDir, '06-page-details');
    mkdirp(pageDetailsDir);
    writeFile(path.join(pageDetailsDir, '_page-template.md'), DOC_PLACEHOLDER + '\n');

    // ===== 5. docs/spec/ 文档（7 个）=====
    const specDir = path.join(root, 'docs', 'spec');
    mkdirp(specDir);
    for (const doc of SPEC_DOCS) {
      writeFile(path.join(specDir, doc), DOC_PLACEHOLDER + '\n');
    }

    // ===== 6. docs/test/ 文档（3 个）=====
    const testDir = path.join(root, 'docs', 'test');
    mkdirp(testDir);
    for (const doc of TEST_DOCS) {
      writeFile(path.join(testDir, doc), DOC_PLACEHOLDER + '\n');
    }

    // ===== 7. docs/handoff/review-notes.md =====
    const handoffDir = path.join(root, 'docs', 'handoff');
    mkdirp(handoffDir);
    writeFile(path.join(handoffDir, 'review-notes.md'), DOC_PLACEHOLDER + '\n');

    // ===== 8. IDE rules 自动注入（v5.1）=====
    const ideRulesDir = findIdeRulesDir();
    if (ideRulesDir) {
      const injected = injectIdeRules(root, ideRulesDir, created);
      process.stdout.write(`  [OK] IDE rules 注入: ${injected} 项（.cursor/rules + .windsurf/rules + AGENTS.md）\n`);
    } else {
      process.stdout.write('  [WARN] ide-rules 目录未找到，跳过 IDE rules 注入\n');
    }

    process.stdout.write('[OK] scaffold 完成（创建 ' + created.length + ' 个文件）\n');
    return { ok: true, created };
  } catch (e) {
    process.stderr.write('[FAIL] scaffold 失败: ' + e.message + '\n');
    process.exit(1);
  }
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
