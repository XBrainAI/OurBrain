// verify-demo-runtime.mjs
// Demo 运行时验证（v5.1 step 分组 + 失败截图）
//
// 使用 Playwright 验证 Demo 运行时可用性：
//   R-1: 页面可加载（HTTP 200 或 file:// 可访问）
//   R-2: 无 JS 控制台错误与请求失败
//   R-3: 标注面板可显示（web-first assertion: toBeAttached）
//   R-4: 标注开关可切换（web-first assertion: toBeVisible + click）
//   R-5: 页面无空白（body 有内容，排除占位文本）
//
// v5.1 Sprint 1 P1-4 增强：
//   - step 分组：每项检查包裹在 runStep() 中，输出清晰的步骤边界
//   - 失败截图：检查失败时自动 page.screenshot() 保存到 demo/verify-fail-*.png
//   - 保留 v5.0 P0-4 反模式修复（networkidle / locator / web-first assertions）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/**
 * step 分组包装器（v5.1）
 * - 输出步骤边界（--- name ---）
 * - 失败时自动保存 page.screenshot() 到 demo/verify-fail-<safeName>-<ts>.png
 * - 不依赖 @playwright/test，使用轻量级自定义实现
 *
 * @param {string} name 步骤名（如 "R-1: 页面可加载"）
 * @param {Function} fn 异步检查函数（抛出 Error 表示失败）
 * @param {object|null} page Playwright page 对象（用于失败截图）
 * @param {string} screenshotDir 截图保存目录
 * @param {object} results 累计 { pass, fail }
 */
async function runStep(name, fn, page, screenshotDir, results) {
  log('\n  --- ' + name + ' ---');
  try {
    await fn();
    results.pass++;
    log('  [OK] ' + name);
  } catch (e) {
    results.fail++;
    log('  [FAIL] ' + name + ' - ' + e.message);
    // 失败截图：保存到 demo/ 目录便于诊断
    if (page) {
      try {
        const ts = Date.now();
        const safeName = name.replace(/[^a-zA-Z0-9-]/g, '_');
        const screenshotPath = path.join(screenshotDir, `verify-fail-${safeName}-${ts}.png`);
        await page.screenshot({ path: screenshotPath, fullPage: true });
        log('  [INFO] 失败截图已保存: ' + screenshotPath);
      } catch (se) {
        log('  [WARN] 截图保存失败: ' + se.message);
      }
    }
  }
}

export async function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const indexPath = path.join(projectRoot, 'demo', 'index.html');
  const screenshotDir = path.join(projectRoot, 'demo');

  log('======================================================================');
  log('verify-demo-runtime.mjs — 运行时验证 (v5.1 step 分组 + 失败截图)');
  log('======================================================================');

  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在');
    return { ok: false, pass: 0, fail: 1 };
  }

  const results = { pass: 0, fail: 0 };

  try {
    const { chromium, expect } = await import('playwright');
    const browser = await chromium.launch({ headless: true });
    const context = await browser.newContext();
    const page = await context.newPage();

    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') errors.push(msg.text());
    });
    page.on('pageerror', err => errors.push(err.message));
    page.on('requestfailed', req => {
      const url = req.url();
      if (!url.endsWith('/favicon.ico') && !url.endsWith('/favicon.png')) {
        errors.push(`requestfailed: ${url} - ${req.failure()?.errorText || 'unknown'}`);
      }
    });

    // R-1: 页面可加载
    await runStep('R-1: 页面可加载', async () => {
      const fileUrl = 'file:///' + indexPath.replace(/\\/g, '/');
      await page.goto(fileUrl, { timeout: 10000 });
      await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {
        // networkidle 在无网络请求的 file:// 场景可能超时，忽略
      });
    }, page, screenshotDir, results);

    // R-2: 无 JS 控制台错误与请求失败
    await runStep('R-2: 无 JS 控制台错误与请求失败', async () => {
      if (errors.length > 0) {
        const detail = errors.slice(0, 5).map(e => '    - ' + e).join('\n');
        throw new Error(`${errors.length} 个错误（含 console.error / pageerror / requestfailed）\n${detail}`);
      }
    }, page, screenshotDir, results);

    // R-3: 标注面板可显示（契约要求：enhance-prototype.mjs 必须注入）
    await runStep('R-3: 标注面板存在（toBeAttached）', async () => {
      const panelLocator = page.locator('.annotation-panel').first();
      await expect(panelLocator).toBeAttached({ timeout: 3000 });
    }, page, screenshotDir, results);

    // R-4: 标注开关可切换（契约要求：data-annotation-toggle 必须存在）
    await runStep('R-4: 标注开关可点击（toBeVisible + click）', async () => {
      const toggleLocator = page.locator('[data-annotation-toggle]').first();
      await expect(toggleLocator).toBeVisible({ timeout: 3000 });
      await toggleLocator.click();
      await page.waitForLoadState('networkidle', { timeout: 1000 }).catch(() => {});
    }, page, screenshotDir, results);

    // R-5: 页面有充实内容（不能是占位文本）
    await runStep('R-5: 页面有充实内容', async () => {
      const bodyText = await page.evaluate(() => document.body.innerText.trim());
      const bodyLen = bodyText.length;
      const isPlaceholder = bodyText === 'Loading...' || bodyText.startsWith('Demo - 待 AI 设计');
      if (bodyLen <= 200 || isPlaceholder) {
        throw new Error(`内容过少或为占位文本 (${bodyLen} 字符: "${bodyText.slice(0, 40)}...")`);
      }
    }, page, screenshotDir, results);

    await browser.close();
  } catch (e) {
    log('[WARN] Playwright 不可用，跳过运行时验证: ' + e.message);
    log('  [INFO] 请手动在浏览器中打开 demo/index.html 验证');
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${results.pass}, 失败: ${results.fail}`);
  log('======================================================================');

  if (results.fail > 0) {
    log('>>> 运行时验证失败');
    return { ok: false, pass: results.pass, fail: results.fail };
  }
  log('>>> 运行时验证通过');
  return { ok: true, pass: results.pass, fail: results.fail };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('verify-demo-runtime.mjs') || process.argv[1].endsWith('verify-demo-runtime'));
if (isDirectRun) {
  main().then(result => process.exit(result.ok ? 0 : 1));
}
