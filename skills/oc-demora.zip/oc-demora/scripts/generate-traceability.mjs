// generate-traceability.mjs
// 追溯矩阵生成器（v5.0 精简版）
//
// 生成 inbox -> model -> demo -> docs 四层追溯链
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

function findReferencesDir() {
  const candidates = [
    path.join(__dirname, '..', 'references'),
    path.join(__dirname, '..', '..', '..', 'src', 'reference'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// TD-03 防护：仅解析缩进为 2 的顶层列表项
const TOP_LEVEL_INDENT = 2;
function parseModelElements(model, key) {
  const re = new RegExp(`^\\s{${TOP_LEVEL_INDENT}}-\\s*${key}:\\s*(.+)$`, 'gm');
  const results = [];
  for (const m of model.matchAll(re)) results.push(m[1].trim());
  return results;
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoraDir = path.join(projectRoot, '.demora');
  const modelPath = path.join(demoraDir, 'requirement-model.yaml');
  const tracePath = path.join(demoraDir, 'traceability.yaml');
  const inboxDir = path.join(projectRoot, 'inbox');

  log('======================================================================');
  log('generate-traceability.mjs — 追溯矩阵生成 (v5.0)');
  log('======================================================================');

  if (!fs.existsSync(modelPath)) {
    log('[FAIL] requirement-model.yaml 不存在');
    return { ok: false };
  }

  const model = fs.readFileSync(modelPath, 'utf-8');

  // 解析实体列表（TD-03 防护）
  const entities = parseModelElements(model, 'name');

  // 解析页面列表
  const pages = parseModelElements(model, 'id');

  // 检查 inbox 资料
  const inboxFiles = [];
  if (fs.existsSync(inboxDir)) {
    function walkDir(dir, prefix) {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.isDirectory()) walkDir(path.join(dir, e.name), prefix + e.name + '/');
        else inboxFiles.push(prefix + e.name);
      }
    }
    walkDir(inboxDir, '');
  }

  // 检查 docs 生成
  const docsDir = path.join(projectRoot, 'docs');
  const docFiles = [];
  if (fs.existsSync(docsDir)) {
    function walkDocs(dir, prefix) {
      const entries = fs.readdirSync(dir, { withFileTypes: true });
      for (const e of entries) {
        if (e.isDirectory()) walkDocs(path.join(dir, e.name), prefix + e.name + '/');
        else docFiles.push(prefix + e.name);
      }
    }
    walkDocs(docsDir, '');
  }

  // 检查 demo
  const demoExists = fs.existsSync(path.join(projectRoot, 'demo', 'index.html'));

  // 生成追溯矩阵
  let yaml = '# traceability.yaml — 追溯矩阵 (v5.0)\n';
  yaml += `# 生成时间: ${new Date().toISOString()}\n\n`;
  yaml += 'inbox:\n';
  inboxFiles.forEach(f => { yaml += `  - ${f}\n`; });
  yaml += '\nmodel:\n';
  yaml += `  entities: ${entities.length}\n`;
  entities.forEach(e => { yaml += `    - ${e}\n`; });
  yaml += `  pages: ${pages.length}\n`;
  pages.forEach(p => { yaml += `    - ${p}\n`; });
  yaml += '\ndemo:\n';
  yaml += `  exists: ${demoExists}\n`;
  yaml += '\ndocs:\n';
  yaml += `  files: ${docFiles.length}\n`;
  docFiles.forEach(f => { yaml += `    - ${f}\n`; });

  fs.writeFileSync(tracePath, yaml, 'utf-8');
  log(`  [OK] 追溯矩阵已生成: .demora/traceability.yaml`);
  log(`  [INFO] inbox: ${inboxFiles.length} 文件, model: ${entities.length} 实体 / ${pages.length} 页面, docs: ${docFiles.length} 文件`);

  log('\n>>> 追溯矩阵生成完成');
  return { ok: true };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('generate-traceability.mjs') || process.argv[1].endsWith('generate-traceability'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
