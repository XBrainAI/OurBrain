# Demora Skill

> AI 驱动产品研发加速工具 — 方法论驱动、代码无关、业界标准

## 简介

Demora 通过"想清楚 → 做精致 → 改到位"三阶段流程，帮助 AI 与 PM 协作产出可运行的高保真原型 + 完整 PRD 文档 + 测试验收清单。

- **Phase 1（想清楚）**：AI 与 PM 对话澄清需求，填充结构化需求模型，创建 demo 空目录
- **Phase 2（做精致）**：AI 基于 frontend-design skill 从零设计 Demo，注入标注系统，生成文档
- **Phase 3（改到位）**：处理评审决策，同步文档，打包交付

## 安装依赖

### 必需环境

- Node.js >= 18（支持原生 ES Modules）
- Python >= 3.8（可选，用于 main.py CLI 入口）

### 无需安装额外依赖

本 Skill 包采用**自包含原则**，所有运行时依赖已打包到 `references/` 目录，无需 `npm install`。

## 快速开始

### 1. 初始化项目

```bash
cd your-project-dir
node /path/to/skill/scripts/scaffold-project.mjs
```

将在当前目录创建标准结构：

```
your-project-dir/
├── .demora/      # 状态与需求模型（7 个 YAML 文件）
├── inbox/        # PM 投喂的资料
├── demo/         # 可交互原型（Phase 2 由 AI 设计）
├── docs/         # PRD + Spec + Test 文档（24 个）
└── delivery/     # 最终交付包
```

### 2. Phase 1 - 填充需求模型

将需求资料放入 `inbox/text/`、`inbox/documents/`、`inbox/screenshots/`，AI 读取后与 PM 对话，填充 `.demora/requirement-model.yaml`。

```bash
node scripts/generate-demo.mjs          # 创建 demo 空目录结构
node scripts/validate-model.mjs         # 校验完成度
node scripts/lock-model.mjs --lock      # 渲染锁定确认卡
node scripts/lock-model.mjs --lock --confirm  # 确认锁定
```

### 3. Phase 2 - AI 设计 Demo + 生成文档

AI 基于 frontend-design skill 方法论从零设计 Demo（代码无关，技术选型由 AI 自主决定）。

```bash
node scripts/enhance-prototype.mjs      # 注入标注三件套（CSS + 面板 + 引擎）
node scripts/generate-prd.mjs           # 生成 24 个文档
node scripts/generate-traceability.mjs  # 生成追溯矩阵
node scripts/check-structure.mjs        # 结构校验（~3 项）
node scripts/check-business-fill.mjs    # 业务填充校验（~2 项）
```

### 4. Phase 3 - 处理评审与交付

```bash
node scripts/sync-docs.mjs              # 同步 accept 决策到文档
node scripts/quality-check.mjs          # 基本质量门禁
node scripts/package-delivery.mjs       # 打包交付
```

## 标注系统

v5.0 标注系统为独立叠加层，AI 在 HTML 中使用 `data-*` 属性约定：

| 属性 | 用途 | 示例 |
|------|------|------|
| `data-annotation-root` | 标注根容器 | `<body data-annotation-root>` |
| `data-zone-id` | L2 区域标识 | `<section data-zone-id="R-001">` |
| `data-element-id` | L3 元件标识 | `<button data-element-id="C-001">` |
| `data-page-id` | 页面标识 | `<div data-page-id="P01">` |
| `data-annotation-toggle` | 标注开关按钮 | `<input data-annotation-toggle>` |

标注引擎在页面加载后自动扫描 `data-*` 属性并绑定交互，AI 无需引入任何标注相关 JS 代码。

## references/ 目录说明

| 子目录 | 内容 | 用于 |
|--------|------|------|
| `annotation/` | 标注系统三件套 + guide | enhance-prototype |
| `methodology/doc-templates/` | PRD/Spec/Test 文档模板 | generate-prd |
| `methodology/interaction-templates/` | 6 个交互卡片模板 | render-card |
| `methodology/schemas/` | requirement-model Schema + validator | validate-model |
| `methodology/guides/` | 标注系统与设计系统最佳实践 | AI 参考 |

## 配置说明

| 文件 | 用途 | 维护脚本 |
|------|------|----------|
| `.demora/state.yaml` | 阶段与保护状态 | scaffold / lock-model / package-delivery |
| `.demora/requirement-model.yaml` | 需求模型（单一数据源） | Phase 1 AI 填充，lock 后只读 |
| `.demora/model-lock.yaml` | 锁定状态与变更日志 | lock-model |
| `.demora/decisions.yaml` | 评审决策记录 | Phase 3 PM 转述 |
| `.demora/traceability.yaml` | 追溯链 | generate-traceability |
| `.demora/quality-report.yaml` | 质量报告 | quality-check |
