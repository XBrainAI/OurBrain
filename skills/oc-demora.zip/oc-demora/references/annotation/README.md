# 标注系统（Annotation System）

demora 的核心差异化能力——三层标注体系（L1/L2/L3），作为独立叠加层注入 AI 生成的 Demo。

## 文件清单

| 文件 | 说明 |
|------|------|
| `annotation-engine.js` | 自包含标注引擎，DOMContentLoaded 后自动扫描 data-* 属性并构建标注 UI |
| `annotation-styles.css` | 标注系统样式，L2/L3 标记 + 面板 + 卡片 |
| `annotation-panel.html` | 标注面板 HTML 模板（纯 HTML，无框架依赖） |
| `annotation-guide.md` | AI 使用指南：data-* 属性约定 + API 参考 |

## 设计理念

- **代码无关**：不依赖 Vue/React 等框架，纯 vanilla JS
- **零侵入**：AI 不需要在代码中引入标注相关逻辑，只需在 HTML 元素上加 data-* 属性
- **叠加层**：标注三件套（CSS + HTML + JS）由 `enhance-prototype.mjs` 注入，不破坏 AI 的设计

## 注入流程

`enhance-prototype.mjs` 执行三件事：

1. 注入 `annotation-styles.css` 到 Demo 的 `<head>`
2. 注入 `annotation-panel.html` 到 Demo 的 `<body>` 末尾
3. 注入 `annotation-engine.js` 到 Demo 的 `<body>` 末尾

AI 只需：
1. 在 HTML 元素上添加 `data-zone-id` / `data-element-id` 属性
2. 定义 `window.__ANNOTATION_DATA__` 对象

详见 `annotation-guide.md`。
