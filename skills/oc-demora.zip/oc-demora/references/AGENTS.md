# src/reference/ — 共享资产

> 本目录是 Demora 项目的**共享资产**存放处。构建 Skill 包时，`annotation/` 和 `methodology/` 会被复制到 `build/<skill-name>/references/`，确保 Skill 包**自包含**。

## 目录结构

```
reference/
├── REFERENCE.md                    # 运行时参考文档索引（Skill 包内 AI 必读）
├── README.md                       # 源目录说明
├── request.schema.yaml             # 请求 Schema
│
├── annotation/                     # 标注系统（独立叠加层）
│   ├── annotation-engine.js        #   自包含标注引擎（vanilla JS，DOMContentLoaded 自动初始化）
│   ├── annotation-styles.css       #   标注 CSS（注入 <head> 末尾）
│   ├── annotation-panel.html       #   标注面板 HTML（注入 <body> 末尾）
│   ├── annotation-guide.md         #   data-* 属性使用说明（AI 必读）
│   └── README.md                   #   标注系统说明
│
├── methodology/                    # 产品需求方法论（纯方法论，不绑定代码）
│   ├── annotation-spec.md          #   L1/L2/L3 三层标注规范
│   ├── doc-templates/              #   24 个文档模板
│   │   ├── prd/                    #     PRD 14 个（00-overview 到 13-open-questions）
│   │   ├── spec/                   #     Spec 7 个（00-project-overview 到 06-error-and-empty-states）
│   │   ├── test/                   #     Test 3 个（00-acceptance-criteria 到 02-permission-matrix）
│   │   └── handoff/                #     评审记录模板
│   ├── interaction-templates/      #   6 个交互卡片模板
│   ├── schemas/                    #   需求模型 Schema + 校验器
│   │   ├── requirement-model-schema.yaml
│   │   └── validator.mjs
│   └── guides/                     #   方法论指南
│       ├── annotation-interaction-troubleshooting.md
│       └── design-system-loading-best-practices.md
│
└── scripts/
    └── render-card.mjs             # 卡片渲染器（共享脚本）
```

## 资产分类

### 实现性资产（AI 不可改）

- `annotation/` 三件套 — 标注核心代码，必须原样注入 Demo
- `methodology/schemas/requirement-model-schema.yaml` — 需求模型权威定义

### 参考性资产（AI 读取遵循）

- `methodology/annotation-spec.md` — L1/L2/L3 三层标注规范
- `methodology/guides/*.md` — 最佳实践指南
- `annotation/annotation-guide.md` — data-* 属性使用说明

### 模板资产（AI 填充业务）

- `methodology/doc-templates/` — 文档模板（占位符）
- `methodology/interaction-templates/` — 卡片模板（由 render-card.mjs 渲染）

## 构建时资产流转

| 源路径 | 目标路径 | 说明 |
|--------|---------|------|
| `reference/annotation/*` | `build/<skill-name>/references/annotation/*` | 标注系统 |
| `reference/methodology/*` | `build/<skill-name>/references/methodology/*` | 方法论资产 |
| `reference/scripts/render-card.mjs` | `build/<skill-name>/scripts/render-card.mjs` | 同时复制到 scripts/ |

## 修改原则

- **修改资产**：直接修改本目录文件，重新运行 `node scripts/build-test-dist.mjs` 即可生效
- **新增资产**：新建文件后需同步更新 `REFERENCE.md` 索引
- **删除资产**：删除文件后需检查 `REFERENCE.md`、`AGENTS.md`（根）和 `build-skill.mjs` 中的引用
- **禁止**：在 `build/` 或 `dist/` 中直接修改资产（会被下次构建覆盖）

## 关键约束

- **标注三件套代码不得修改**：`annotation-styles.css` / `annotation-panel.html` / `annotation-engine.js` 必须原样注入 Demo
- **Schema 单一权威源**：`methodology/schemas/requirement-model-schema.yaml` 是需求模型的唯一权威定义
- **render-card.mjs 共享**：本目录的 `scripts/render-card.mjs` 与 Skill 包内 `scripts/render-card.mjs` 应保持一致
- **data-* 属性约定**：AI 在 HTML 中使用 `data-zone-id` / `data-element-id` / `data-annotation-root` 属性，标注引擎自动扫描绑定
