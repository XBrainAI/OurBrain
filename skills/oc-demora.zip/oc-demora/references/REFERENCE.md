# Demora Skill 参考资料索引

> 本文档说明 `references/` 目录下各子目录的设计目标与内容。Skill 包运行时，AI 读取此索引了解可用资产。

## 设计目标

`references/` 目录是 Skill 包的**运行时依赖集合**：

1. **自包含**：所有运行时所需文件必须打包到本目录，禁止引用开发环境路径
2. **代码无关**：资产不绑定任何前端框架，Demo 技术选型由 AI 自主决定
3. **方法论驱动**：所有约束以通用方法论形式存在，不绑定特定需求类型

## 目录说明

### 1. annotation/ — 标注系统（独立叠加层）

标注系统是 demora 的核心差异化能力（L1/L2/L3 三层标注），v5.0 重写为独立叠加层。

| 文件 | 说明 |
|------|------|
| `annotation-engine.js` | 自包含标注引擎（vanilla JS），DOMContentLoaded 后自动扫描 `data-*` 属性并绑定交互 |
| `annotation-styles.css` | 标注系统 CSS（面板/L1/L2/L3 样式），注入到 `<head>` 末尾 |
| `annotation-panel.html` | 标注面板 HTML（右侧抽屉），注入到 `<body>` 末尾 |
| `annotation-guide.md` | `data-*` 属性使用说明，AI 必读 |
| `README.md` | 标注系统技术说明 |

**data-* 属性约定：**

| 属性 | 用途 | 示例 |
|------|------|------|
| `data-annotation-root` | 标注根容器 | `<body data-annotation-root>` |
| `data-zone-id` | L2 区域标识 | `<section data-zone-id="R-001">` |
| `data-element-id` | L3 元件标识 | `<button data-element-id="C-001">` |
| `data-page-id` | 页面标识 | `<div data-page-id="P01">` |
| `data-annotation-toggle` | 标注开关按钮 | `<input data-annotation-toggle>` |

### 2. methodology/ — 产品需求方法论

纯方法论资产，不绑定任何代码实现。

| 子目录/文件 | 说明 |
|------------|------|
| `annotation-spec.md` | L1/L2/L3 三层标注方法论规范 |
| `doc-templates/prd/` | PRD 文档模板（14 个，00-overview 到 13-open-questions） |
| `doc-templates/spec/` | 技术规格文档模板（7 个，00-project-overview 到 06-error-and-empty-states） |
| `doc-templates/test/` | 测试文档模板（3 个，00-acceptance-criteria 到 02-permission-matrix） |
| `doc-templates/handoff/` | 交付评审记录模板（review-notes.md） |
| `interaction-templates/` | 6 个交互卡片模板（由 render-card.mjs 渲染） |
| `schemas/requirement-model-schema.yaml` | 需求模型 Schema（唯一权威定义） |
| `schemas/validator.mjs` | Schema 校验器（validateModel / calculateCompletion） |
| `guides/annotation-interaction-troubleshooting.md` | 标注交互常见问题排查 |
| `guides/design-system-loading-best-practices.md` | CSS 字体加载最佳实践 |

### 3. scripts/ — 共享脚本

| 文件 | 说明 |
|------|------|
| `render-card.mjs` | 卡片渲染器（读取 interaction-templates/*.template.md 渲染为 markdown） |

## 扩展指南

### 新增交互卡片

1. 在 `methodology/interaction-templates/` 创建 `<card-name>.template.md`
2. 在 `scripts/render-card.mjs` 的 `CARD_TEMPLATE_MAP` 注册映射

### 新增文档模板

1. 在 `methodology/doc-templates/` 对应子目录添加 `.md` 模板
2. 在 `scripts/scaffold-project.mjs` 和 `scripts/generate-prd.mjs` 的文档清单添加文件名

### 修改标注系统

标注三件套（engine/styles/panel）为**实现性资产**，修改前需确认：
- CSS 类名和 `data-*` 属性约定保持一致
- `annotation-guide.md` 同步更新
- 运行 `test-suite/regression/verify-annotation-v2.mjs` 验证

## 故障排查

### 脚本找不到 references 目录

**解决**：确认 `references/` 在 Skill 包根目录下存在，或开发环境中 `src/reference/` 存在。

### 模板渲染后仍含 [待填充]

**原因**：`requirement-model.yaml` 中对应字段未填充。
**解决**：检查 requirement-model.yaml 的 project/entities/pages/roles 是否已填充，重新运行 `generate-prd.mjs`。
