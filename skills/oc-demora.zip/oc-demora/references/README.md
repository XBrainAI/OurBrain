# src/reference/ — 共享资产说明

> 本目录存放 Demora 项目的**共享资产**。构建 Skill 包时，`annotation/` 和 `methodology/` 会被复制到 Skill 包的 `references/` 子目录，确保 Skill 包自包含（可脱离项目根目录独立运行）。

## 资产组织结构

### annotation/ — 标注系统（v5.0 独立叠加层）

| 文件 | 说明 |
|------|------|
| `annotation-engine.js` | 自包含标注引擎（vanilla JS），扫描 `data-*` 属性并绑定交互 |
| `annotation-styles.css` | 标注系统 CSS |
| `annotation-panel.html` | 右侧标注面板 HTML |
| `annotation-guide.md` | `data-*` 属性使用说明 |
| `README.md` | 标注系统技术说明 |

### methodology/ — 产品需求方法论（纯方法论）

- `annotation-spec.md` — L1/L2/L3 三层标注规范
- `doc-templates/` — PRD(14) + Spec(7) + Test(3) + Handoff(1) 文档模板
- `interaction-templates/` — 6 个交互卡片模板
- `schemas/requirement-model-schema.yaml` — 需求模型 Schema
- `schemas/validator.mjs` — Schema 校验器
- `guides/` — 标注交互排查与设计系统加载指南

### scripts/ — 共享脚本

| 文件 | 用途 |
|------|------|
| `render-card.mjs` | 卡片渲染器（复制到 Skill 包 `scripts/` 使用） |

## v5.0 已废弃资产

以下资产类型在 v5.0 中已被移除，**不再存在于本目录**：

- Demo 框架模板（绑定特定前端框架），v5.0 改为 AI 从零设计
- 旧标注系统（绑定框架 mixin），v5.0 改为独立叠加层
- 设计系统约束文件（绑定特定 UI 组件库），v5.0 用业界标准替代
- 多套 UI 规范，会限制 AI 设计自由度
- 方法论翻译层，v5.0 AI 直接读取 SKILL.md 原文
- Demo 设计稿中转机制，v5.0 AI 直接产出 HTML

**禁止**将上述资产复制回本目录。

## 修改原则

- 修改资产后运行 `node scripts/build-test-dist.mjs` 重新构建
- 新增资产需同步更新 `REFERENCE.md` 索引
- 禁止在 `build/` 或 `dist/` 中直接修改（会被覆盖）
