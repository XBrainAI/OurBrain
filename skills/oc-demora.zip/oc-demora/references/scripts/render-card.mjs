// render-card.mjs
// 共享卡片渲染脚本：渲染 interaction-templates/ 下的人机交互卡片模板。
//
// 设计意图：
//   - 消除不同 LLM 生成卡片内容的格式差异
//   - 作为 Skill 包 render-card.mjs 的参考实现，可直接复制到 build/<skill>/scripts/ 使用
//   - 支持从任意工作目录调用（自动定位项目根目录）
//
// 用法：
//   import { renderCard, renderCardBody, main } from '<path>/render-card.mjs';
//   const md = renderCard('lock-confirm', { project_name: '客户管理' });
//
// CLI 支持三种 JSON 传参方式（规避 PowerShell 剥离双引号问题）：
//   node render-card.mjs lock-confirm '{"project_name":"客户管理"}'
//   '{"project_name":"客户管理"}' | node render-card.mjs lock-confirm --stdin
//   node render-card.mjs lock-confirm --file ./card-data.json

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// card-name → 模板文件名映射
const CARD_MAP = {
  'scope-selection': 'scope-selection-card.template.md',
  'lock-confirm': 'lock-confirm-card.template.md',
  'unlock-confirm': 'unlock-confirm-card.template.md',
  'delivery': 'delivery-card.template.md',
  'review-decision': 'review-decision-card.template.md',
  'final-approval': 'final-approval-card.template.md',
};

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 查找 references 目录：优先 Skill 包内 references/methodology/，其次开发环境 src/reference/methodology/
 * @param {string} [startDir] - 起始目录，默认本脚本所在目录
 * @returns {string|null}
 */
export function findProjectRoot(startDir = __dirname) {
  let dir = startDir;
  for (let i = 0; i < 6; i++) {
    // Skill 包内：scripts/render-card.mjs -> references/methodology/interaction-templates/
    const skillCandidate = path.join(dir, 'references', 'methodology', 'interaction-templates');
    if (fs.existsSync(skillCandidate)) return dir;
    // 开发环境：src/reference/scripts/render-card.mjs -> src/reference/methodology/interaction-templates/
    const devCandidate = path.join(dir, 'src', 'reference', 'methodology', 'interaction-templates');
    if (fs.existsSync(devCandidate)) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/**
 * 获取模板目录
 * @param {object} [options]
 * @param {string} [options.projectRoot] - 项目根目录
 * @param {string} [options.templateDir] - 直接指定模板目录
 * @returns {string}
 */
function getTemplateDir(options = {}) {
  if (options.templateDir) return options.templateDir;
  const root = options.projectRoot || findProjectRoot() || path.resolve(__dirname, '..', '..');
  // 优先 Skill 包路径，其次开发环境路径
  const skillPath = path.join(root, 'references', 'methodology', 'interaction-templates');
  if (fs.existsSync(skillPath)) return skillPath;
  return path.join(root, 'src', 'reference', 'methodology', 'interaction-templates');
}

/**
 * 渲染卡片：读取模板并替换 {{占位符}}
 * @param {string} cardName - 卡片名
 * @param {object} data - 占位符键值对
 * @param {object} [options] - { projectRoot?, templateDir? }
 * @returns {string} 渲染后的卡片文本
 */
export function renderCard(cardName, data = {}, options = {}) {
  if (!CARD_MAP[cardName]) {
    throw new Error(`[FAIL] 未知卡片名: ${cardName}，可选值: ${Object.keys(CARD_MAP).join(', ')}`);
  }
  const templateDir = getTemplateDir(options);
  const templateFile = path.join(templateDir, CARD_MAP[cardName]);
  if (!fs.existsSync(templateFile)) {
    throw new Error(`[FAIL] 卡片模板不存在: ${templateFile}`);
  }
  const template = fs.readFileSync(templateFile, { encoding: 'utf-8' });
  return template.replace(/\{\{\s*([\w.]+)\s*\}\}/g, (match, key) => {
    if (Object.prototype.hasOwnProperty.call(data, key)) {
      const val = data[key];
      return val === null || val === undefined ? '' : String(val);
    }
    return match;
  });
}

/**
 * 仅提取模板中第一个 ``` 代码块作为卡片正文渲染
 * @param {string} cardName - 卡片名
 * @param {object} data - 占位符键值对
 * @param {object} [options]
 * @returns {string} 渲染后的卡片正文
 */
export function renderCardBody(cardName, data = {}, options = {}) {
  const rendered = renderCard(cardName, data, options);
  const match = rendered.match(/```[\s\S]*?```/);
  return match ? match[0] : rendered;
}

/**
 * 读取 stdin 内容（PowerShell 友好）
 * @returns {string}
 */
function readStdin() {
  const chunks = [];
  const buf = Buffer.alloc(4096);
  let bytesRead;
  try {
    while ((bytesRead = fs.readSync(0, buf, 0, buf.length, null)) > 0) {
      chunks.push(Buffer.from(buf.slice(0, bytesRead)));
    }
  } catch (e) {
    // stdin 不可读时忽略
  }
  return Buffer.concat(chunks).toString('utf-8').trim().replace(/^\uFEFF/, '');
}

/**
 * CLI / import 兼容入口
 * @param {object} args - { cardName?: string, data?: object, file?: string, stdin?: boolean }
 * @returns {string} 渲染结果
 */
export function main(args = {}) {
  const argv = process.argv.slice(2);
  const cardName = args.cardName || argv[0];
  if (!cardName) {
    throw new Error('用法: node render-card.mjs <card-name> [data-json|--stdin|--file <path>]');
  }

  let data = args.data || {};
  if (!args.data) {
    const hasStdin = args.stdin || argv.includes('--stdin');
    const fileIdx = argv.indexOf('--file');
    const hasFile = fileIdx >= 0 && argv[fileIdx + 1];

    if (hasStdin) {
      const stdinText = readStdin();
      if (stdinText) data = JSON.parse(stdinText);
    } else if (hasFile) {
      const fileText = fs.readFileSync(argv[fileIdx + 1], { encoding: 'utf-8' }).replace(/^\uFEFF/, '').trim();
      data = JSON.parse(fileText);
    } else if (argv[1]) {
      data = JSON.parse(argv[1]);
    }
  }

  return renderCard(cardName, data, { projectRoot: args.projectRoot, templateDir: args.templateDir });
}

// 直接执行时运行 CLI
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  try {
    const output = main();
    process.stdout.write(output);
    process.stderr.write(`[OK] 卡片已渲染\n`);
  } catch (e) {
    process.stderr.write(`[FAIL] ${e.message}\n`);
    process.exit(1);
  }
}
