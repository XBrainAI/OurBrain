# v0 式硬规则辅助指引（Demora 工程视角补充）

> 版本：v5.1 Sprint 1 P0-3
> 来源：P3-1B 调研（Vercel v0 + shadcn 设计系统方法论）
> 与 frontend-design skill 的关系：本指引是**工程视角的补充**，不修改 frontend-design/SKILL.md 原文。frontend-design skill 是**设计方法论**（视觉个性/反 AI 默认审美/Hero as thesis/Signature element），本指引补充 v0 harness 模式下 AI 应遵守的**工程硬规则**。
> 适用场景：AI 在执行 Phase 2 "做精致" 时，除读取 frontend-design/SKILL.md 外，应同时读取本指引，确保产出符合工程标准。

---

## 一、Role 双重定位

AI 在 Demora Phase 2 设计 Demo 时，同时承担两个角色：

| 角色 | 职责 | 与 frontend-design skill 的关系 |
|------|------|-------------------------------|
| UI/UX 设计师 | 视觉个性、字体配对、签名元素、反默认审美 | **frontend-design/SKILL.md 主导** |
| 前端工程师 | 完整代码、可运行、零 console error、Tech Stack 选择 | **本指引主导** |

两个角色必须同时满足，不允许偏废。

---

## 二、Tech Stack 硬约束

Demora 产出单文件 HTML Demo，Tech Stack 必须满足：

| 约束 | 说明 |
|------|------|
| 单文件 HTML | 整个 Demo 必须在 `demo/index.html` 一个文件内（含 inline CSS + JS） |
| 零外部依赖 | 不允许引入 CDN（除字体 CDN）、不允许 npm install |
| 浏览器原生 API | 优先使用 vanilla JS（ES2020+），不强制框架 |
| 标注系统契约 | 必须包含 `data-zone-id` / `data-element-id` / `data-annotation-toggle` 属性（详见 `references/annotation/annotation-guide.md`） |
| 可访问性基线 | 必须满足：键盘可达、focus 可见、reduced-motion 尊重 |

Tech Stack 选择由 AI 自主决定（与 frontend-design skill "代码无关"原则一致），但必须在上述约束内。

---

## 三、强制 COMPLETE 代码

v0 harness 模式要求 AI 输出 COMPLETE 代码，不允许 placeholder。Demora 沿用此规则：

| 检查项 | 要求 |
|--------|------|
| HTML 结构 | `<!DOCTYPE html>` + `<html>` + `<head>` + `<body>` 完整闭合 |
| CSS 样式 | 所有引用的 class 必须有对应 CSS 定义 |
| JS 逻辑 | 所有绑定的事件必须有对应函数实现 |
| Mock 数据 | 所有 UI 元素引用的数据必须实际存在 |
| 占位文本 | 不允许 `TODO` / `FIXME` / `Loading...` / `Demo - 待 AI 设计` |

**反例**：
```html
<!-- 禁止 -->
<div class="hero">TODO: 待 AI 填充 hero 内容</div>
<button onclick="handleClick()">按钮</button>
<!-- 缺少 handleClick 函数定义 -->
```

**正例**：
```html
<div class="hero">
  <h1>聚酰亚胺薄膜专利全景分析</h1>
  <p>覆盖 24 件核心专利，6 大工艺类别</p>
</div>
<button onclick="handleClick()">查看详情</button>
<script>
  function handleClick() {
    document.querySelector('.detail-panel').classList.toggle('visible');
  }
</script>
```

---

## 四、Chain of Thought（CoT）

AI 在设计 Demo 前必须先在 `.demora/design-decisions.md` 中完成 CoT 思考：

```markdown
## 设计决策

### 1. Subject grounding
- 产品主题：[具体产品名]
- 目标用户：[具体角色]
- 页面单一职责：[一句话描述]

### 2. Visual identity 选择
- 调色板：[4-6 个命名 hex 值，含理由]
- 字体配对：[display + body + utility，含理由]
- 签名元素：[1 个独特元素，含理由]

### 3. 反 AI 默认审美自检
- 我的设计是否落入了 3 种默认风格之一？
  - [ ] warm cream + 高对比 serif + terracotta accent
  - [ ] near-black + acid-green/vermilion accent
  - [ ] broadsheet + hairline rules + zero border-radius
- 如果是，说明理由（brief 明确要求 / 真的是最佳选择）
- 如果不是，说明如何避免的

### 4. Tech Stack 选择
- HTML/CSS/JS 风格：[vanilla / Tailwind-like utility / BEM / 其他]
- 选择理由：[为什么这个 stack 最适合本 brief]

### 5. 标注契约落实
- L1 页面说明：[1 句]
- L2 区域规划：[R-001 主导航 / R-002 主内容 / ...]
- L3 元件规划：[C-001 标注开关 / C-002 数据筛选 / ...]

### 6. Signature element 自检
- 我的 signature element 是什么？
- 它如何体现 brief 的核心？
- 它是否避免了通用默认（如大数字+小标签+渐变）？
```

CoT 完成后，AI 才能开始写 `demo/index.html`。

---

## 五、禁默认色清单

frontend-design/SKILL.md 已明确禁止 3 种 AI 默认审美。本指引补充具体颜色清单，便于 AI 自检：

### 5.1 禁止作为主色的默认色

| 颜色 | hex | 出现频率 | 说明 |
|------|-----|---------|------|
| Warm cream | #F4F1EA | 极高 | 默认风 1 的背景 |
| Terracotta | #C66B3D / #B8864A | 极高 | 默认风 1 的强调色 |
| Near-black | #0A0A0A / #111111 | 极高 | 默认风 2 的背景 |
| Acid green | #A3E635 / #84CC16 | 高 | 默认风 2 的强调色 |
| Vermilion | #DC2626 / #EF4444 | 高 | 默认风 2 的备选强调色 |
| Indigo | #6366F1 / #4F46E5 | 极高 | v0 禁止（与 frontend-design 同源） |
| Blue | #3B82F6 / #2563EB | 极高 | v0 禁止 |

### 5.2 例外

- brief 明确要求这些颜色时，可以使用（如客户品牌色就是 indigo）
- 作为辅助色（不作为主色）时，可以少量使用
- 文字色（#000 / #fff）不受此限

### 5.3 推荐替代色（启发，非强制）

| 用途 | 默认色 | 替代思路 |
|------|--------|---------|
| 中性背景 | Warm cream #F4F1EA | 根据产品世界选择（如医疗用 pale teal、法律用 parchment、工业用 graphite） |
| 强调色 | Terracotta #B8864A | 从产品本身的视觉语言提取（如聚酰亚胺薄膜的金色纤维 → 琥珀金 #C8973D） |
| 暗色背景 | Near-black #0A0A0A | 用深色而非纯黑（如 #0F1419 深墨绿、#1A0F0A 深咖） |
| 高亮色 | Acid green #A3E635 | 从产品工艺提取（如化学反应的 catalyst 紫色、机械加工的火花橙） |

---

## 六、与 frontend-design skill 的协作

### 6.1 读取顺序

```
1. frontend-design/SKILL.md      → 设计方法论（视觉个性、字体、签名元素）
2. v0-hardrules-supplement.md    → 工程硬规则（Tech Stack、COMPLETE 代码、CoT）
3. annotation/annotation-guide.md → 标注契约（data-* 属性约定）
```

### 6.2 冲突解决

如果 frontend-design/SKILL.md 与本指引冲突：

| 冲突类型 | 优先级 |
|---------|--------|
| 视觉个性 vs 工程约束 | **frontend-design 主导**（视觉个性是差异化核心） |
| 字体选择 vs 加载性能 | **frontend-design 主导**（个性 > 性能） |
| 标注契约 vs 任何视觉决策 | **标注契约主导**（标注是 Demora 核心差异化能力） |
| Tech Stack 选择 | **本指引主导**（frontend-design 不涉及） |

---

## 七、自检清单（AI 产出后必跑）

AI 完成 `demo/index.html` 后，必须按本清单自检（不增加 LLM 调用，仅规则化检查）：

| # | 检查项 | 命令 | 通过条件 |
|---|--------|------|---------|
| 1 | HTML 完整闭合 | `node scripts/quality-check.mjs` Q-1 + Q-5 | pass |
| 2 | 无占位标记 | `node scripts/quality-check.mjs` Q-2 | pass |
| 3 | 文档生成 | `node scripts/quality-check.mjs` Q-3 | pass |
| 4 | 状态机推进 | `node scripts/quality-check.mjs` Q-4 | final_approved=true |
| 5 | 业界标准（htmlhint） | `node scripts/quality-check.mjs` Q-5 | 0 errors |
| 6 | AI 产出侧自检（v5.1 新增） | `node scripts/quality-check.mjs` Q-6 | pass（详见 quality-check.mjs Q-6） |
| 7 | 运行时验证 | `node scripts/verify-demo-runtime.mjs` | R-1~R-5 全 pass |

**指令化措辞**（借鉴 Superpowers verification-before-completion）：

> Run the command, read the output, then claim the result. Do not claim pass until the command output confirms pass.

---

## 八、参考资料

- [frontend-design/SKILL.md](../../../../skills/frontend-design/SKILL.md) — 设计方法论原文（56 行，不修改）
- [P3-1B-vercel-v0-shadcn.md](../../../../../docs/v5.1-research/P3-1B-vercel-v0-shadcn.md) — v0 + shadcn 调研报告
- [P3-1E-openspec-superpowers.md](../../../../../docs/v5.1-research/P3-1E-openspec-superpowers.md) — Superpowers verification-before-completion 借鉴来源
- [annotation-guide.md](../../annotation/annotation-guide.md) — 标注契约
