# 设计系统加载最佳实践

本文档针对 Demo 开发过程中因 CSS 加载顺序和方式不当导致的设计系统失效问题，提供可复用的最佳实践方案。

---

## 1. Google Fonts @import 阻塞问题

### 问题现象

`style.css` 顶部通过 `@import` 加载 Google Fonts：

```css
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

:root {
  --primary: #024ad8;
  --font-sans: Inter, sans-serif;
  /* ... 大量 CSS 变量 */
}
```

结果：Demo 打开后只有纯文字，无任何样式，所有 CSS 变量失效，浏览器 DevTools 中 `:root` 变量显示为空。

### 根因分析

CSS `@import` 规则的特性：
- 浏览器必须**先下载并解析** `@import` 引用的外部样式表，才能继续解析后续 CSS 规则
- 当网络延迟或外部资源不可用时，后续所有 CSS 规则被阻塞
- 在某些浏览器中，被阻塞的 `:root` 变量可能导致整段规则被跳过

### 禁止做法

```css
/* 禁止：在 CSS 文件顶部使用 @import */
@import url('https://fonts.googleapis.com/css2?family=Inter...');

:root {
  /* 这些变量可能被阻塞 */
}
```

### 推荐方案 A：使用 `<link>` 标签在 HTML 中加载

```html
<!-- index.html -->
<!DOCTYPE html>
<html>
<head>
  <!-- 字体通过 link 加载，不阻塞 CSS 解析 -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
  
  <!-- 本地样式文件 -->
  <link rel="stylesheet" href="assets/style.css">
</head>
</html>
```

**优点**：
- `<link>` 是并行加载，不阻塞 CSS 文件解析
- `rel="preconnect"` 提前建立连接，减少延迟

### 推荐方案 B：本地托管字体文件

将需要的字体文件下载到本地，通过 `@font-face` 引入：

```css
/* style.css */
@font-face {
  font-family: 'Inter';
  src: url('fonts/Inter-Regular.woff2') format('woff2');
  font-weight: 400;
  font-style: normal;
  font-display: swap;
}

@font-face {
  font-family: 'Inter';
  src: url('fonts/Inter-Medium.woff2') format('woff2');
  font-weight: 500;
  font-style: normal;
  font-display: swap;
}

:root {
  --primary: #024ad8;
  --font-sans: Inter, sans-serif;
  /* ... */
}
```

**优点**：
- 完全消除外部网络依赖
- 字体文件可随 Demo 一起打包
- 最快的加载速度

### 推荐方案 C：使用 font-display: swap

如果必须使用 `@import`（不推荐），确保字体加载不阻塞首次渲染：

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter...&display=swap">
```

`display=swap` 参数确保浏览器先使用系统字体渲染文本，待字体下载完成后再替换。

---

## 2. CSS 变量内联最佳实践

### 原则：设计系统变量必须可靠加载

设计系统 CSS 变量是整个 Demo 的视觉基础，必须确保：
- 变量定义在样式表的最前面
- 不受外部资源加载影响
- 浏览器能 100% 解析成功

### 正确结构

```css
/* style.css */

/* ============================================ */
/* 第1段：@font-face 声明（如使用本地字体）      */
/* ============================================ */
@font-face {
  font-family: 'Inter';
  src: url('fonts/Inter-Regular.woff2') format('woff2');
  font-weight: 400;
  font-display: swap;
}

/* ============================================ */
/* 第2段：CSS 变量定义（:root）                  */
/* ============================================ */
:root {
  /* 品牌色 */
  --primary: #024ad8;
  --primary-foreground: #ffffff;
  
  /* 功能色 */
  --destructive: #b3262b;
  --success: #67C23A;
  --warning: #E6A23C;
  
  /* 中性色 */
  --background: #ffffff;
  --foreground: #1a1a1a;
  --muted: #f7f7f7;
  --muted-foreground: #636363;
  --border: #e8e8e8;
  
  /* 字体 */
  --font-sans: Inter, Manrope, Roboto, Arial, sans-serif;
  --font-mono: JetBrains Mono, monospace;
  
  /* 尺寸 */
  --radius-sm: 3px;
  --radius-md: 4px;
  --radius-lg: 16px;
  
  /* ... */
}

/* ============================================ */
/* 第3段：Reset 和 Base 样式                     */
/* ============================================ */
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { height: 100%; overflow: hidden; }

/* ============================================ */
/* 第4段：组件和布局样式                         */
/* ============================================ */
/* ... */
```

### 禁止结构

```css
/* 禁止：@import 在 :root 之前 */
@import url('https://...');  /* 阻塞后续解析 */

:root {
  /* 可能被阻塞 */
}
```

### 颜色空间指导（v5.1+ 推荐 oklch）

现代浏览器支持 oklch 颜色空间，相比 hex/hsl 有以下优势：
- **感知均匀性**：相同 lightness 值在人眼感知上亮度一致
- **可预测性**：调整 lightness/chroma 时颜色变化更可预测
- **与 shadcn 对齐**：shadcn/ui registry 默认使用 oklch

```css
:root {
  /* hex 形式（兼容性好，v5.0 默认） */
  --primary: #024ad8;
  --primary-foreground: #ffffff;

  /* oklch 形式（v5.1+ 推荐，感知均匀） */
  --primary: oklch(0.55 0.2 264);          /* 对应 #024ad8 */
  --primary-foreground: oklch(1 0 0);       /* 对应 #ffffff */
  --destructive: oklch(0.55 0.22 25);       /* 对应 #b3262b */
  --success: oklch(0.7 0.15 145);            /* 对应 #67C23A */
  --warning: oklch(0.75 0.15 75);            /* 对应 #E6A23C */
}
```

**变量对齐计划（v5.2 Sprint 2）**：annotation-styles.css 当前使用 `--accent`/`--color-warning`/`--fg` 等旧变量名，将在 v5.2 对齐为 shadcn 风格 `--primary`/`--warning`/`--foreground`。需解决语义冲突：标注系统的 `--muted` 用作次要文本色（shadcn 中 `--muted` 是背景色，对应应为 `--muted-foreground`）。

---

## 3. 多文件 CSS 合并加载顺序

当 Demo 使用多个 CSS 文件时，加载顺序至关重要：

### 推荐顺序

```html
<head>
  <!-- 1. 外部字体（可选） -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter...">
  
  <!-- 2. 设计系统变量（必须最先加载） -->
  <link rel="stylesheet" href="assets/design/tokens.css">
  
  <!-- 3. 基础样式 -->
  <link rel="stylesheet" href="assets/style.css">
  
  <!-- 4. 组件样式 -->
  <link rel="stylesheet" href="assets/design/components.css">
  
  <!-- 5. 标注样式（最后加载，覆盖前面） -->
  <link rel="stylesheet" href="assets/design/annotations.css">
</head>
```

### 关键原则

- **变量文件最先**：确保后续样式能使用 CSS 变量
- **标注样式最后**：标注样式需要覆盖普通样式，z-index、position 等属性优先生效
- **避免 @import 链**：不要在 CSS 文件中再用 @import 引入其他 CSS 文件

---

## 4. 内联 vs 外链的权衡

| 方案 | 适用场景 | 优点 | 缺点 |
|------|---------|------|------|
| 全部内联到单个 style.css | 简单 Demo、快速原型 | 无网络依赖、无加载顺序问题 | 文件较大、缓存效率低 |
| 变量内联 + 组件外链 | 中等复杂度 Demo | 变量可靠、组件可缓存 | 需要管理加载顺序 |
| 全部外链 + 预加载 | 生产级应用 | 缓存友好、按需加载 | 配置复杂 |

**Skill 推荐**：对于 Phase 1 Demo，采用"变量内联到 style.css + 字体本地托管"方案，确保最可靠的加载。

---

## 5. 验证检查清单

在 Demo 生成后，按以下步骤验证设计系统加载：

- [ ] `style.css` 顶部不存在 `@import`
- [ ] `:root` 中的 CSS 变量在浏览器 DevTools 中可正常查看
- [ ] 所有设计系统颜色变量在页面上正确生效
- [ ] 字体族正确应用（非系统默认字体）
- [ ] 无控制台 CSS 相关报错
- [ ] 断网情况下 Demo 样式正常（使用本地字体时）

---

## 6. 快速修复指南

### 场景 A：Demo 纯文字无 UI

**诊断**：
1. 打开浏览器 DevTools -> Elements -> 选中 `<html>`
2. 查看 Computed -> 检查 font-family 是否为系统默认字体
3. 查看 `:root` 变量是否为空

**修复**：
1. 移除 `style.css` 顶部的 `@import`
2. 将字体加载移到 `index.html` 的 `<link>` 标签
3. 或将字体文件本地化

### 场景 B：部分样式生效、部分不生效

**诊断**：
1. 检查 `style.css` 中 `@import` 之后是否有语法错误
2. 语法错误可能导致后续规则全部被跳过

**修复**：
1. 运行 `node --check` 检查 JS 文件
2. 使用 CSS 验证器检查样式文件
3. 将 `@import` 移出 CSS 文件
