# 标注交互常见问题排查指南

本文档汇总了 Demo 标注交互开发中最常见的问题现象、根因定位与修复方法，供 Skill 使用者和 AI 在调试时快速参考。

---

## 问题1：右侧卡片不滚动

**现象**：点击左侧或右侧标注后，右侧标注面板中的卡片没有自动滚动到可视区域。

**排查步骤**：
1. 打开浏览器 DevTools，检查右侧面板的 HTML 结构
2. 确认面板内容区域的 class 名称（通常为 `.panel-body`）
3. 在 `app.js` 中搜索 `scrollRightPanelToCard` 函数
4. 检查其内部的选择器是否为 `.annotation-panel .panel-body`

**错误示例**：
```javascript
// 错误：选择器与模板中的 class 不匹配
var panelBody = document.querySelector('.annotation-panel-body');
```

**正确修复**：
```javascript
var panelBody = document.querySelector('.annotation-panel .panel-body');
```

---

## 问题2：点击右侧卡片后标签页不切换

**现象**：在 L1 或 L3 标签页点击右侧 L2 卡片后，面板仍停留在当前标签页，看不到被高亮的 L2 卡片。

**排查步骤**：
1. 在 `app.js` 中搜索 `highlightZone` 函数
2. 检查激活时是否设置了 `activeTab = 'L2'`
3. 同样检查 `highlightElement` 是否设置了 `activeTab = 'L3'`

**错误示例**：
```javascript
// 错误：未切换 activeTab
highlightZone: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  // 缺少 activeTab 切换
}
```

**正确修复**：
```javascript
highlightZone: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  if (annotationState.highlightedZone) {
    annotationState.activeTab = 'L2';
  }
}
```

---

## 问题3：左右高亮状态交叉污染

**现象**：左侧同时出现橙色区域高亮（`zone-active`）和蓝色圆点高亮（`dot-active`），视觉混乱。

**排查步骤**：
1. 检查 `highlightZone` / `focusZoneCard` 是否清除了 `highlightedElement`
2. 检查 `highlightElement` / `focusElementCard` 是否清除了 `highlightedZone`

**错误示例**：
```javascript
// 错误：点击 L2 时未清除 L3 高亮
highlightZone: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  annotationState.activeTab = 'L2';
}
```

**正确修复**：
```javascript
highlightZone: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  if (annotationState.highlightedZone) {
    annotationState.activeTab = 'L2';
  }
  annotationState.highlightedElement = null; // 清除 L3 高亮
}
```

---

## 问题4：scrollIntoView 不生效

**现象**：点击标注后，左侧页面没有滚动到对应区域或元素。

**排查步骤**：
1. 检查目标元素是否在可滚动容器内
2. 确认容器是否设置了 `overflow-y: auto` 或 `overflow: auto`
3. 检查 `scrollIntoView` 是否被异步渲染等待包裹（框架无关：`requestAnimationFrame` + `setTimeout`，或 Vue 的 `nextTick`、React 的 `flushSync` 等）

**常见缺失场景**：
- `.welcome-state` 缺少 `overflow-y: auto`
- `.sidebar` 不可滚动（但 `.sidebar-body` 可滚动）

**正确修复**：
```css
.welcome-state {
  overflow-y: auto;
}
```

---

## 问题5：标注标记显示不全

**现象**：L2 水滴图标或 L3 圆点被裁剪，只显示一部分或完全消失。

**排查步骤**：
1. 检查标注标记的 CSS 偏移值是否为负数
2. 检查父容器是否有 `overflow: hidden` 或 `overflow: auto`

**错误示例**：
```css
.l2-marker {
  position: absolute;
  top: -8px;   /* 负数偏移会被裁剪 */
  left: -8px;
}
```

**正确修复**：
```css
.l2-marker {
  position: absolute;
  top: 4px;    /* 正数偏移，在 padding 区域内 */
  left: 4px;
  width: 16px;
  height: 16px;
}
```

---

## 问题6：标注穿透抽屉

**现象**：标注标记显示在专利详情抽屉之上，遮挡抽屉内容。

**排查步骤**：
1. 检查 `.l2-marker` / `.l3-dot-wrap` 的 z-index
2. 检查抽屉的 z-index
3. 确认层级关系：标记 < 抽屉 < 标注面板

**错误示例**：
```css
.l2-marker { z-index: 9999; }     /* 过高 */
.patent-detail-drawer { z-index: 1500; }  /* 过低 */
```

**正确修复**：
```css
.l2-marker, .l3-dot-wrap { z-index: 2000; }
.patent-detail-drawer { z-index: 2500 !important; }
.annotation-panel { z-index: 3000; }
```

---

## 问题7：Demo 纯文字无 UI

**现象**：Demo 打开后只有纯文字，没有任何样式，设计系统变量全部失效。

**排查步骤**：
1. 检查 `style.css` 顶部是否有 `@import url('https://fonts.googleapis.com/...')`
2. 检查浏览器 DevTools 中 CSS 变量是否被解析

**根因**：`@import` 会阻塞后续 CSS 规则解析，导致 `:root` 中定义的变量失效。

**错误示例**：
```css
@import url('https://fonts.googleapis.com/css2?family=Inter...');
:root {
  --primary: #024ad8;  /* 可能不被解析 */
}
```

**正确修复**：
```html
<!-- 在 index.html 中用 link 加载字体 -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter...">
```

或：
```css
/* 直接将变量内联到 style.css，移除 @import */
:root {
  --primary: #024ad8;
}
```

---

## 问题8：跨页面标注点击无响应

**现象**：在对话页点击欢迎页区域的标注，或在欢迎页点击对话页区域的标注，没有任何反应。

**排查步骤**：
1. 检查 `focusZoneCard` 和 `focusElementCard` 中是否有页面状态切换逻辑
2. 检查 `highlightZone` 和 `highlightElement` 中是否有页面状态切换逻辑
3. 确认四个函数中都存在状态切换逻辑，缺一不可

**错误示例**：
```javascript
// 错误：只在 highlightZone 中切换，focusZoneCard 中缺失
focusZoneCard: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  annotationState.activeTab = 'L2';
  // 缺少页面状态切换
}
```

**正确修复**（伪代码，AI 按所用框架实现）：
```javascript
focusZoneCard: function (zoneId) {
  annotationState.highlightedZone = zoneId;
  annotationState.activeTab = 'L2';
  annotationState.highlightedElement = null;
  // 跨页面切换：根据当前业务状态决定是否切换页面
  if (zoneId === 'R-005' && getMessages().length > 0) {
    startNewConversation();
  }
  // ... 其他状态切换 + 滚动逻辑
}
```

---

## 问题9：右侧标注面板内容未同步

**现象**：左侧从对话页切换到欢迎页后，右侧仍然显示对话页的标注。

**排查步骤**：
1. 检查是否有 `currentVisibleZones` 计算属性
2. 检查 `visibleL2Zones` 和 `visibleAnnotations` 是否正确过滤
3. 检查 `newConversation` / `switchConversation` 中是否清除了无效高亮

**正确实现**（伪代码，AI 按所用框架实现响应式计算）：
```javascript
// 响应式计算示例：根据当前业务状态动态返回可见区域列表
function getCurrentVisibleZones() {
  var zones = ['R-001'];
  if (isDrawerVisible('patent')) zones.push('R-004');
  if (getMessages().length === 0) zones.push('R-005');
  else zones.push('R-002', 'R-003');
  return zones;
}
```

---

## 问题10：SyntaxError 导致 Demo 无法运行

**现象**：浏览器控制台报 `SyntaxError`，页面空白。

**排查步骤**：
1. 运行 `node --check app.js` 和 `node --check components.js`
2. 检查模板字符串拼接处是否有尾随反斜杠
3. 检查 IIFE 包裹是否完整

**常见错误**：
```javascript
// 错误：尾随反斜杠导致语法错误
'<div class="foo">\' +
'  <span>bar</span>\' +
```

**修复**：确保每行末尾的反斜杠后紧跟换行符，无多余空格。
