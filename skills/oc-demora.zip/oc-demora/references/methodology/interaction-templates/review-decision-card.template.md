# 评审决策卡

用于 Phase 3 评审阶段，PM/开发/测试对 Demo 与文档提出修改意见后，AI 输出结构化决策清单，PM 对每个缺陷做 accept/defer/reject 决策。

## 触发场景

- 阶段：Phase 3（评审修订）
- 触发条件：评审会议结束后，PM 将意见反馈给 AI
- 前置条件：Phase 2 已完成，demo/ 与 docs/ 已生成

## 卡片内容

```
━━━ 🔍 评审决策 ━━━
项目名称：{{project_name}}
评审日期：{{review_date}}
缺陷总数：{{defect_count}}

缺陷清单与决策：

{{defect_list}}

决策说明：
  accept  —— 采纳，需要修复（Phase 3 路径 A 将自动修复）
  defer   —— 暂缓，后续处理（本轮不修复，记录到产品债务）
  reject  —— 驳退，不修复（需注明理由）

请按以下格式回复决策结果（可复制上方缺陷清单修改）：

  DEF-001: accept  # 采纳，需修复
  DEF-002: defer   # 本轮暂不处理
  DEF-003: reject  # 不属于本轮范围

或直接说"全部 accept"批量采纳所有缺陷。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{project_name}}` | 项目名称 | `.demora/requirement-model.yaml` 的 `project.name` |
| `{{review_date}}` | 评审日期 | 系统当前日期 |
| `{{defect_count}}` | 缺陷总数 | AI 评审后生成的缺陷清单长度 |
| `{{defect_list}}` | 缺陷清单（多行） | AI 评审后生成，每行格式：`DEF-XXX | severity | category | description | evidence` |

## 缺陷清单格式

`{{defect_list}}` 占位符渲染后的格式示例：

```
DEF-001 | critical | missing_feature | 用户列表页缺少批量删除按钮 | PRD §05 页面清单 P03
DEF-002 | major    | wrong_behavior  | 订单状态流转缺少"已发货"分支 | PRD §04 业务流程
DEF-003 | minor    | ui_issue        | 表单标签对齐不一致 | Spec §01 页面架构
DEF-004 | suggestion | consistency   | 字段命名风格不统一 | PRD §07 字段说明
```

## 渲染后行为

1. AI 接收 PM 转述的评审意见，分析后生成本卡片
2. PM 按格式回复决策结果
3. AI 解析决策，写入 `.demora/decisions.yaml`：
   ```yaml
   decisions:
     - defect_id: DEF-001
       severity: critical
       category: missing_feature
       description: 用户列表页缺少批量删除按钮
       evidence: PRD §05 页面清单 P03
       decision: accept
       comment: 采纳，需修复
     - defect_id: DEF-002
       ...
   ```
4. AI 根据决策类型判断修改路径：
   - 全部为 accept 且不违反 §4.3.3 6 项条件 → Phase 3 路径 A（实现级微调）
   - 任一缺陷修复涉及需求模型变更 → Phase 3 路径 B（需求级变更，需解锁回到 Phase 1）
5. 在 `.demora/conversation-log.yaml` 追加评审决策记录

## 关联状态文件

- 读：`.demora/requirement-model.yaml`、`demo/`、`docs/`
- 写：`.demora/decisions.yaml`、`.demora/conversation-log.yaml`、`.demora/state.yaml`
