# 迭代范围选择卡

用于 Phase 1 初期，当 PM 的需求涉及多个可选范围时，AI 输出结构化的范围选择清单，PM 选择后写入需求模型。

## 触发场景

- 阶段：Phase 1（需求对话与功能验证）初期
- 触发条件：AI 分析 inbox/ 输入资料后，识别出多个可选迭代范围
- 前置条件：inbox/ 已收集到 PM 输入的需求资料

## 卡片内容

```
━━━ 📋 迭代范围选择 ━━━
根据 inbox/ 中资料分析，建议以下迭代范围：

方案 A（推荐）：{{option_a_description}}
  包含页面：{{option_a_pages}}
  预估对话轮次：{{option_a_rounds}}
  预估 Phase 1 完成时间：{{option_a_eta}}

方案 B：{{option_b_description}}
  包含页面：{{option_b_pages}}
  预估对话轮次：{{option_b_rounds}}
  预估 Phase 1 完成时间：{{option_b_eta}}

{{additional_options}}

请选择方案（A/B{{option_letters}}），或说明您的调整意见。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{option_a_description}}` | 方案 A 描述 | AI 基于 inbox/ 资料分析生成 |
| `{{option_a_pages}}` | 方案 A 包含的页面列表 | AI 拆解候选页面 |
| `{{option_a_rounds}}` | 方案 A 预估对话轮次 | AI 评估需求复杂度 |
| `{{option_a_eta}}` | 方案 A 预估完成时间 | AI 估算 |
| `{{option_b_description}}` | 方案 B 描述 | 同上 |
| `{{option_b_pages}}` | 方案 B 包含的页面列表 | 同上 |
| `{{option_b_rounds}}` | 方案 B 预估对话轮次 | 同上 |
| `{{option_b_eta}}` | 方案 B 预估完成时间 | 同上 |
| `{{additional_options}}` | 方案 C/D 等可选附加项（无则为空） | AI 按需生成 |
| `{{option_letters}}` | 附加方案的字母（如 /C/D），无则为空 | 同上 |

## 渲染后行为

1. AI 读取 inbox/ 中 PM 输入的资料（text/、documents/、screenshots/）
2. AI 分析后生成候选范围方案，渲染本卡片输出到 AI 对话界面
3. PM 回复选择（如"A"）或提出调整意见
4. PM 确认后，AI 将所选范围写入 `.demora/requirement-model.yaml` 的 `pages[]`（仅含选中页面的初始占位）
5. 在 `.demora/conversation-log.yaml` 追加范围选择记录
6. 进入 Phase 1 正式对话澄清

## 关联状态文件

- 读：`inbox/` 下所有资料
- 写：`.demora/requirement-model.yaml`（初始化 `pages[]`）、`.demora/conversation-log.yaml`
