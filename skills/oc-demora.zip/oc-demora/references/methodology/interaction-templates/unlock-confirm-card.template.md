# 需求解锁确认卡

用于 Phase 2/3 回退到 Phase 1 时的显式解锁确认。PM 说"解锁"后，AI 要求 PM 输入解锁原因，输出此卡片，PM 回复"确认解锁"后才执行解锁操作。

## 触发场景

- 阶段：Phase 2 或 Phase 3（已锁定状态）
- 触发词："解锁"
- 前置条件：`model_locked: true`
- 安全检查：无（解锁本身是受控操作，但需 PM 明确原因）

## 卡片内容

```
━━━ 🔓 需求解锁确认 ━━━
解锁原因：{{unlock_reason}}

将影响的文件：
  - .demora/requirement-model.yaml（恢复可写）
  - demo/（解除保护，demo_protected = false）
  - docs/（可能需要同步更新）

解锁后需要：
  1. 修改需求模型（entities/pages/roles/fields/statuses 等）
  2. 重新说"锁定需求"以再次锁定
  3. 重新执行 Phase 2 完善与文档生成

请回复"确认解锁"执行，或回复"取消"放弃解锁。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{unlock_reason}}` | PM 输入的解锁原因 | AI 在渲染卡片前向 PM 询问获取 |

## 渲染后行为

1. PM 说"解锁"后，AI 先询问"请输入解锁原因"
2. PM 输入原因后，`lock-model.mjs` 读取本模板并渲染，输出到 AI 对话界面
3. PM 回复"确认解锁"后，`lock-model.mjs` 执行以下操作：
   - 写入 `.demora/model-lock.yaml`（`locked: false`，追加解锁原因与时间到变更日志）
   - 更新 `.demora/state.yaml`（`model_locked: false`，`demo_protected: false`，`current_phase: 1`）
   - 在 `.demora/conversation-log.yaml` 追加解锁记录与原因
4. PM 回复"取消"时，不执行解锁，保持锁定状态

## 关联状态文件

- 读：`.demora/state.yaml`、`.demora/model-lock.yaml`
- 写：`.demora/model-lock.yaml`、`.demora/state.yaml`、`.demora/conversation-log.yaml`
