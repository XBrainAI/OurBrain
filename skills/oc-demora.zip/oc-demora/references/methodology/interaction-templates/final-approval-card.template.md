# 定稿确认卡

用于 Phase 3 评审决策处理完成后，PM 确认是否生成最终交付。确认后系统进入终态，demo/ 与 docs/ 锁定不可再改。

## 触发场景

- 阶段：Phase 3（评审修订）末尾
- 触发条件：所有 accept 缺陷已修复，质量校验通过
- 前置条件：`.demora/decisions.yaml` 中所有 accept 项已处理

## 卡片内容

```
━━━ ✅ 定稿确认 ━━━
项目名称：{{project_name}}
当前版本：{{delivery_version}}

确认前检查：
  [{{qa_status}}] QA 评审缺陷已全部处理（accept 项已修复，defer/reject 项已记录）
  [{{regression_status}}] 回归测试无新增 Critical/Major 缺陷
  [{{pending_items_status}}] 所有 [待确认] 问题已确认或标注为已知限制
  [{{traceability_status}}] 追溯矩阵完整（需求 → Demo → 文档 全链路覆盖）

缺陷处理汇总：
  总数：{{defect_total}}
  accept（已修复）：{{accept_count}}
  defer（暂缓）：{{defer_count}}
  reject（驳退）：{{reject_count}}

确认后效果：
  - demo/ 与 docs/ 进入终态，不可再改
  - .demora/state.yaml 标记 final_approved: true
  - 可执行"打包交付"生成最终交付包

请回复"确认定稿"执行，或回复"继续修改"返回 Phase 3 处理剩余缺陷。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{project_name}}` | 项目名称 | `.demora/requirement-model.yaml` 的 `project.name` |
| `{{delivery_version}}` | 当前版本号 | `.demora/state.yaml` |
| `{{qa_status}}` | QA 检查状态（✓ 或 ✗） | `quality-check.mjs` 输出 |
| `{{regression_status}}` | 回归测试状态（✓ 或 ✗） | `quality-check.mjs` 输出 |
| `{{pending_items_status}}` | 待确认项状态（✓ 或 ✗） | `.demora/requirement-model.yaml` 中 `[待确认]` 计数 |
| `{{traceability_status}}` | 追溯矩阵状态（✓ 或 ✗） | `generate-traceability.mjs` 输出 |
| `{{defect_total}}` | 缺陷总数 | `.demora/decisions.yaml` |
| `{{accept_count}}` | accept 项数 | `.demora/decisions.yaml` |
| `{{defer_count}}` | defer 项数 | `.demora/decisions.yaml` |
| `{{reject_count}}` | reject 项数 | `.demora/decisions.yaml` |

## 渲染后行为

1. AI 在所有 accept 缺陷修复完成后，渲染本卡片输出到 AI 对话界面
2. PM 回复"确认定稿"后，AI 执行以下操作：
   - 更新 `.demora/state.yaml`（`final_approved: true`，`current_phase: 3`，`demo_protected: true`）
   - 在 `.demora/conversation-log.yaml` 追加定稿记录
   - 提示 PM 可执行"打包交付"
3. PM 回复"继续修改"时，返回 Phase 3 处理剩余缺陷
4. 任一检查项为 ✗ 时，AI 不允许定稿，提示 PM 先处理未通过项

## 关联状态文件

- 读：`.demora/decisions.yaml`、`.demora/state.yaml`、`.demora/requirement-model.yaml`、`.demora/traceability.yaml`
- 写：`.demora/state.yaml`、`.demora/conversation-log.yaml`
