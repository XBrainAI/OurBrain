# 需求锁定确认卡

用于 Phase 1 → Phase 2 转换时的显式锁定确认。PM 说"锁定需求"后，AI 必须输出此卡片，PM 回复"确认锁定"后才执行锁定操作。

## 触发场景

- 阶段：Phase 1（需求对话与功能验证）
- 触发词："锁定需求"
- 前置条件：需求模型完成度 = 100%，无 `[待确认]` 项
- 安全检查：`safety.require_source_traceability`

## 卡片内容

```
━━━ 🔒 需求锁定确认 ━━━
项目名称：{{project_name}}
需求完成度：100%
[待确认] 项：{{pending_count}}

即将锁定的内容：
  实体：{{entity_count}} 个（{{entity_list}}）
  页面：{{page_count}} 个（{{page_list}}）
  角色：{{role_count}} 个（{{role_list}}）

锁定后效果：
  - .demora/requirement-model.yaml 变为只读
  - demo/ 进入受保护状态（demo_protected = true）
  - 后续修改必须通过"解锁"操作

请回复"确认锁定"执行，或提出修改意见。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{project_name}}` | 项目名称 | `.demora/requirement-model.yaml` 的 `project.name` |
| `{{pending_count}}` | 待确认项数量 | `.demora/requirement-model.yaml` 中 `[待确认]` 标记计数 |
| `{{entity_count}}` | 实体数量 | `.demora/requirement-model.yaml` 的 `entities[]` 长度 |
| `{{entity_list}}` | 实体名称列表 | `entities[].displayName` 拼接 |
| `{{page_count}}` | 页面数量 | `pages[]` 长度 |
| `{{page_list}}` | 页面名称列表 | `pages[].name` 拼接 |
| `{{role_count}}` | 角色数量 | `roles[]` 长度 |
| `{{role_list}}` | 角色名称列表 | `roles[].displayName` 拼接 |

## 渲染后行为

1. 卡片由 `lock-model.mjs` 读取本模板并渲染，输出到 AI 对话界面
2. PM 回复"确认锁定"后，`lock-model.mjs` 执行以下操作：
   - 写入 `.demora/model-lock.yaml`（`locked: true`，记录锁定时间与变更日志）
   - 更新 `.demora/state.yaml`（`model_locked: true`，`demo_protected: true`，`current_phase: 2`）
   - 在 `.demora/conversation-log.yaml` 追加锁定记录
3. PM 提出修改意见时，不执行锁定，回到 Phase 1 对话继续澄清

## 关联状态文件

- 读：`.demora/requirement-model.yaml`、`.demora/state.yaml`
- 写：`.demora/model-lock.yaml`、`.demora/state.yaml`、`.demora/conversation-log.yaml`
