// validator.mjs
// Demora 需求模型 Schema 校验器
// 读取 src/reference/schemas/requirement-model-schema.yaml，对解析后的需求模型做结构化校验。
//
// 本模块同时服务于：
//   - sim-runner 的 model-builder（校验 expected_model 语义完整性）
//   - 未来生成的 Skill 包 validate-model.mjs（替代内联 Schema 理解）
//   - test-suite 的 Schema 一致性测试
//
// 设计原则：
//   - 优先使用 js-yaml，降级到轻量正则解析（避免跨包依赖）
//   - 轻量：仅覆盖 guide §4.4.1 定义的子集，不实现完整 JSON Schema
//   - 可独立运行：export function main(args = {}) 模式，便于 import 和 CLI 调用

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// 优先使用 js-yaml（如可用）
let yamlLib = null;
try {
  yamlLib = (await import('js-yaml')).default;
} catch {
  // js-yaml 未安装时降级到轻量解析
  yamlLib = null;
}

// 内联 parseYAML：优先 js-yaml，降级到轻量解析
function parseYAML(text) {
  if (yamlLib) {
    return yamlLib.load(text);
  }
  return parseYamlLite(text);
}

// 轻量 YAML 解析（降级方案，仅处理简单结构）
function parseYamlLite(text) {
  const result = {};
  const lines = text.split('\n');
  const stack = [{ indent: -1, obj: result }];
  for (const line of lines) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const indent = line.length - line.trimStart().length;
    while (stack.length > 1 && stack[stack.length - 1].indent >= indent) stack.pop();
    const current = stack[stack.length - 1].obj;
    const trimmed = line.trim();
    const colonIdx = trimmed.indexOf(':');
    if (colonIdx === -1) continue;
    const key = trimmed.substring(0, colonIdx).trim();
    const value = trimmed.substring(colonIdx + 1).trim();
    if (value === '') {
      const child = {};
      current[key] = child;
      stack.push({ indent, obj: child });
    } else {
      current[key] = value.replace(/^["']|["']$/g, '');
    }
  }
  return result;
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SCHEMA_PATH = path.join(__dirname, 'requirement-model-schema.yaml');

/**
 * 加载 Schema 文件
 * @returns {object} 解析后的 Schema 对象
 */
export function loadSchema() {
  const text = fs.readFileSync(SCHEMA_PATH, { encoding: 'utf-8' });
  const schema = parseYAML(text);
  if (!schema || !schema.schemas) {
    throw new Error('Schema 文件解析失败或缺少 schemas 根节点: ' + SCHEMA_PATH);
  }
  return schema;
}

/**
 * 获取指定 schema 定义
 * @param {object} schema - 顶层 Schema 对象
 * @param {string} name - schema 名称（如 entity、page）
 * @returns {object|null}
 */
function getSchemaDef(schema, name) {
  return schema.schemas && schema.schemas[name] ? schema.schemas[name] : null;
}

/**
 * 解析 $ref 引用（仅支持 #/schemas/xxx 和 #/types/xxx）
 * @param {object} schema - 顶层 Schema 对象
 * @param {string} ref
 * @returns {object|null}
 */
function resolveRef(schema, ref) {
  if (!ref || typeof ref !== 'string') return null;
  const m = ref.match(/^#\/(schemas|types)\/(.+)$/);
  if (!m) return null;
  const [, kind, key] = m;
  if (kind === 'types') {
    const typeDef = schema.types && schema.types[key];
    return typeDef ? { type: 'enum', enum: typeDef.enum } : null;
  }
  return getSchemaDef(schema, key);
}

/**
 * 校验一个值是否符合 schema 定义（轻量递归）
 * @param {object} schema - 顶层 Schema 对象
 * @param {object} def - 当前字段的 schema 定义
 * @param {*} value - 实际值
 * @param {string} pathStr - 当前字段路径（用于错误信息）
 * @returns {string[]} 错误列表
 */
function validateValue(schema, def, value, pathStr) {
  const errors = [];
  if (!def) return errors;

  // 处理 $ref
  if (def.$ref) {
    const refDef = resolveRef(schema, def.$ref);
    if (!refDef) {
      errors.push(`${pathStr}: 无法解析引用 ${def.$ref}`);
      return errors;
    }
    return validateValue(schema, refDef, value, pathStr);
  }

  // 数组类型
  if (def.type === 'array') {
    if (!Array.isArray(value)) {
      errors.push(`${pathStr}: 应为数组`);
      return errors;
    }
    if (def.min_items !== undefined && value.length < def.min_items) {
      errors.push(`${pathStr}: 数组长度至少 ${def.min_items}，实际 ${value.length}`);
    }
    if (def.item_schema) {
      const itemDef = getSchemaDef(schema, def.item_schema);
      value.forEach((item, idx) => {
        errors.push(...validateValue(schema, itemDef, item, `${pathStr}[${idx}]`));
      });
    }
    return errors;
  }

  // 对象类型
  if (def.type === 'object') {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
      errors.push(`${pathStr}: 应为对象`);
      return errors;
    }
    if (def.required_fields) {
      for (const f of def.required_fields) {
        if (!(f in value) || value[f] === undefined || value[f] === null) {
          errors.push(`${pathStr}: 缺少必填字段 ${f}`);
        }
      }
    }
    if (def.properties) {
      for (const [key, propDef] of Object.entries(def.properties)) {
        if (key in value) {
          errors.push(...validateValue(schema, propDef, value[key], `${pathStr}.${key}`));
        }
      }
    }
    return errors;
  }

  // 枚举类型
  if (def.enum) {
    if (!def.enum.includes(value)) {
      errors.push(`${pathStr}: 值 "${value}" 不在允许列表 [${def.enum.join(', ')}] 中`);
    }
    return errors;
  }

  // 标量类型
  if (def.type && value !== undefined && value !== null) {
    const jsType = typeof value;
    const typeMap = {
      string: jsType === 'string',
      number: jsType === 'number',
      boolean: jsType === 'boolean',
    };
    if (typeMap[def.type] === false) {
      errors.push(`${pathStr}: 类型应为 ${def.type}，实际为 ${jsType}`);
    }
  }

  return errors;
}

/**
 * 校验需求模型整体结构
 * @param {object} model - 解析后的需求模型
 * @param {object} [schema] - 可选，外部传入的 Schema 对象（默认加载内置 Schema）
 * @returns {{valid: boolean, errors: string[], completion: number, total: number, filled: number}}
 */
export function validateModel(model, schema = null) {
  if (!schema) schema = loadSchema();
  const errors = [];

  // 根节点必填字段
  for (const key of schema.root_required_keys || []) {
    if (!(key in model) || model[key] === undefined || model[key] === null) {
      errors.push(`根节点缺少必填字段: ${key}`);
    }
  }

  // 按 Schema 校验四个根节点
  const rootSchemas = ['project', 'entities', 'pages', 'roles'];
  for (const key of rootSchemas) {
    const def = getSchemaDef(schema, key);
    if (def && (key in model)) {
      errors.push(...validateValue(schema, def, model[key], key));
    }
  }

  // 计算完成度（与旧 validate-model.mjs 保持一致，便于过渡）
  const completionResult = calculateCompletion(model, schema);

  return {
    valid: errors.length === 0,
    errors,
    completion: completionResult.completion,
    total: completionResult.total,
    filled: completionResult.filled,
  };
}

/**
 * 计算需求模型完成度
 * @param {object} model
 * @param {object} schema
 * @returns {{completion: number, total: number, filled: number}}
 */
export function calculateCompletion(model, schema) {
  const weights = schema.completion_weights || {};
  let total = 0;
  let filled = 0;

  // project
  const project = model.project || {};
  const projectFields = weights.project ? Object.keys(weights.project) : ['name', 'description', 'domain'];
  for (const f of projectFields) {
    total++;
    if (project[f] && project[f] !== '[待填充]') filled++;
  }

  // entities
  const entities = model.entities || [];
  if (entities.length === 0) {
    total += 2;
  } else {
    const perEntity = weights.per_entity || { name: 1, displayName: 1, fields: 1 };
    for (const e of entities) {
      for (const f of Object.keys(perEntity)) {
        total++;
        if (f === 'fields') {
          if (Array.isArray(e.fields) && e.fields.length > 0) filled++;
        } else if (e[f] && e[f] !== '[待填充]') {
          filled++;
        }
      }
    }
  }

  // pages
  const pages = model.pages || [];
  if (pages.length === 0) {
    total += 2;
  } else {
    const perPage = weights.per_page || { id: 1, name: 1, type: 1, entity: 1 };
    for (const p of pages) {
      for (const f of Object.keys(perPage)) {
        total++;
        if (f === 'annotations') {
          // annotations 需深度校验：L1.summary 非空 + L2 >=1 + L3 >=1
          const ann = p.annotations || {};
          const L1 = ann.L1 || {};
          const L2 = ann.L2 || [];
          const L3 = ann.L3 || [];
          if (L1.summary && L2.length > 0 && L3.length > 0) filled++;
        } else if (p[f] && p[f] !== '[待填充]') {
          filled++;
        }
      }
    }
  }

  // roles
  const roles = model.roles || [];
  if (roles.length === 0) {
    total += 1;
  } else {
    const perRole = weights.per_role || { name: 1, permissions: 1 };
    for (const r of roles) {
      for (const f of Object.keys(perRole)) {
        total++;
        if (f === 'permissions') {
          if (Array.isArray(r.permissions) && r.permissions.length > 0) filled++;
        } else if (r[f] && r[f] !== '[待填充]') {
          filled++;
        }
      }
    }
  }

  const completion = total > 0 ? Math.round((filled / total) * 100) : 0;
  return { completion, total, filled };
}

/**
 * 校验 requirement-model.yaml 文件
 * @param {string} filePath
 * @returns {{valid: boolean, errors: string[], completion: number, total: number, filled: number}}
 */
export function validateModelFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return { valid: false, errors: [`文件不存在: ${filePath}`], completion: 0, total: 0, filled: 0 };
  }
  const text = fs.readFileSync(filePath, { encoding: 'utf-8' });
  let model;
  try {
    model = parseYAML(text);
  } catch (e) {
    return { valid: false, errors: [`YAML 解析失败: ${e.message}`], completion: 0, total: 0, filled: 0 };
  }
  if (!model || typeof model !== 'object') {
    return { valid: false, errors: ['YAML 解析结果为空或不是对象'], completion: 0, total: 0, filled: 0 };
  }
  return validateModel(model);
}

/**
 * CLI / import 兼容入口
 * @param {object} args - { file?: string, model?: object }
 * @returns {object} 校验结果
 */
export function main(args = {}) {
  const filePath = args.file;
  if (filePath) {
    return validateModelFile(filePath);
  }
  if (args.model) {
    return validateModel(args.model);
  }
  // 默认读取当前工作目录下的 requirement-model.yaml
  return validateModelFile(path.join(process.cwd(), '.demora', 'requirement-model.yaml'));
}

// 直接运行时作为 CLI 工具
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const fileArg = process.argv[2];
  const result = main({ file: fileArg });
  console.log('======================================================================');
  console.log('需求模型 Schema 校验（reference/schemas/validator.mjs）');
  console.log('======================================================================');
  console.log(`  有效: ${result.valid ? '[OK]' : '[FAIL]'}`);
  console.log(`  完成度: ${result.completion}% (${result.filled}/${result.total})`);
  if (result.errors.length > 0) {
    console.log(`  错误数: ${result.errors.length}`);
    for (const e of result.errors) {
      console.log(`    - ${e}`);
    }
    process.exit(1);
  } else {
    console.log('  >>> Schema 校验通过');
    process.exit(0);
  }
}
