// generate-prd.mjs (v5.2.2)
// 生成 24 个文档（13 PRD + 06-page-details/ 子目录 + 7 Spec + 3 Test + 1 Handoff）
//
// v5.20 变更（UAT 二轮收口，docs/audit-reports/v5.20-uat-analysis-and-fix-plan.md）：
//   - P0-1（U19 回归根因）：loadRequirementInput 候选首位补 inbox/text/requirement-input.md
//     （scaffold 标准目录形态），保留旧两路径兼容历史平铺形态
//   - P0-1 语义修正：TMPL_MARK 由「（模板生成，待基于需求输入修订）」改为事实陈述
//     「（模板生成：需求输入未包含该部分内容）」——消除 delivery 后仍"待用户确认"的自相矛盾
//   - P0-2（U13 残留）：spec/00 模板 5 处圆柱节点转义（DB/CACHE/DBM/DBS/REDIS → [("…")]），
//     生成器输出对齐自家 V-9f 检查器口径，消灭每案必现的 agent 手工善后
//   - P2-1（U15 裁决）：BPMN/DFD/UI Flow 三处「元素说明（图例）」区块彻底删除
//     （v5.19 P2-5 的 ```text 围栏收纳方案按用户裁决升级为移除）
//
// v5.2.2 变更：
//   - 完全重写文档生成逻辑：不再依赖模板 [待填充] 占位符替换
//   - 直接从 requirement-model.yaml 生成完整、实质性的文档内容
//   - 新增 24 个文档专属生成器，每个均从模型数据推导内容
//   - 新增 extractTransitions / extractPagesRich / extractRolesRich 增强提取器
//   - 新增领域感知助手：从实体推导痛点/指标/风险，确保内容与具体场景相关
//   - 消除所有"待补充"占位符（仅 13-open-questions.md 保留真正的开放问题）
//
// v5.2.1 保留：
//   - YAML 解析逻辑（parseYamlLite, extractSection, parseArrayItems, parseItemFields,
//     parseSubArray, parseSubObjectArray, extractEntities, extractRoles, extractPages, loadModelRich）
//   - findReferencesDir / loadTemplate / generatePageDetails 机制
//   - 幂等性检测、state.yaml 更新、design-decisions 集成
//
// 调用：node generate-prd.mjs（无参数）
// cwd：sim-project 目录
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function findReferencesDir() {
  const candidates = [
    path.join(__dirname, '..', 'references'),
    path.join(__dirname, '..', '..', '..', 'src', 'reference'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// ==========================================
// YAML 解析（基础版，向后兼容，v5.2.1 已验证正确，不修改）
// ==========================================

function parseYamlLite(text) {
  const result = {};
  const lines = text.replace(/\r\n/g, '\n').split('\n');
  const stack = [{ indent: -1, obj: result }];
  for (const line of lines) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const indent = line.length - line.trimStart().length;
    while (stack.length > 1 && stack[stack.length - 1].indent >= indent) stack.pop();
    const current = stack[stack.length - 1].obj;
    const trimmed = line.trim();
    const colonIdx = trimmed.indexOf(':');
    if (colonIdx === -1) continue;
    const key = trimmed.substring(0, colonIdx).trim();
    const value = trimmed.substring(colonIdx + 1).trim().replace(/^["']|["']$/g, '');
    if (value === '') {
      const child = {};
      current[key] = child;
      stack.push({ indent, obj: child });
    } else {
      current[key] = value;
    }
  }
  return result;
}

// ==========================================
// 结构化数据提取（regex-based，v5.2.1 已验证正确，不修改）
// ==========================================

function extractSection(text, section) {
  // v5.2.1 修复：JavaScript 不支持 \Z，用 $ 替代（无 m flag，$ 匹配字符串末尾）
  const regex = new RegExp('(^|\\n)' + section + ':\\s*\\n([\\s\\S]*?)(?=\\n[a-zA-Z][\\w]*:|\\n---|$)');
  const match = text.match(regex);
  return match ? match[2] : null;
}

function parseArrayItems(sectionText) {
  if (!sectionText) return [];
  const lines = sectionText.split('\n');
  let itemIndent = -1;
  for (const line of lines) {
    if (/^\s*-\s+/.test(line)) {
      itemIndent = line.length - line.trimStart().length;
      break;
    }
  }
  if (itemIndent === -1) return [];

  const items = [];
  let current = [];
  for (const line of lines) {
    if (line.length - line.trimStart().length === itemIndent && /^\s*-\s+/.test(line)) {
      if (current.length > 0) items.push(current.join('\n'));
      current = [line];
    } else if (current.length > 0) {
      current.push(line);
    }
  }
  if (current.length > 0) items.push(current.join('\n'));
  return items.map(raw => ({ raw, indent: itemIndent }));
}

function parseItemFields(itemText) {
  const result = {};
  const lines = itemText.split('\n');
  let fieldIndent = -1;
  for (const line of lines) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    if (/^\s*-\s+/.test(line)) continue;
    fieldIndent = line.length - line.trimStart().length;
    break;
  }
  if (fieldIndent === -1) {
    for (const line of lines) {
      if (/^\s*-\s+/.test(line)) {
        fieldIndent = line.indexOf('-') + 2;
        break;
      }
    }
  }
  for (const line of lines) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const indent = line.length - line.trimStart().length;
    const trimmed = line.trim();
    if (/^\s*-\s+/.test(line)) {
      if (fieldIndent !== -1 && indent > fieldIndent) continue;
      const match = line.match(/^\s*-\s+(.+)$/);
      if (match) {
        const rest = match[1];
        const colonIdx = rest.indexOf(':');
        if (colonIdx > 0) {
          const key = rest.substring(0, colonIdx).trim();
          const value = rest.substring(colonIdx + 1).trim().replace(/^["']|["']$/g, '');
          if (value) result[key] = value;
        }
      }
      continue;
    }
    if (indent > fieldIndent) continue;
    const colonIdx = trimmed.indexOf(':');
    if (colonIdx > 0) {
      const key = trimmed.substring(0, colonIdx).trim();
      const value = trimmed.substring(colonIdx + 1).trim().replace(/^["']|["']$/g, '');
      if (value) result[key] = value;
    }
  }
  return result;
}

function parseSubArray(itemText, subField) {
  const regex = new RegExp('^\\s*' + subField + ':\\s*\\n([\\s\\S]*?)(?=\\n\\s{2,}\\w|\\n\\s*-\\s+\\w+:|\\Z)', 'm');
  const match = itemText.match(regex);
  if (!match) return [];

  const blockLines = match[1].split('\n');
  const items = [];
  for (const line of blockLines) {
    const trimmed = line.trim();
    if (trimmed.startsWith('- ')) {
      items.push(trimmed.substring(2).trim().replace(/^["']|["']$/g, ''));
    } else if (trimmed.startsWith('-') && trimmed.length > 1) {
      items.push(trimmed.substring(1).trim().replace(/^["']|["']$/g, ''));
    }
  }
  return items;
}

function parseSubObjectArray(itemText, subField) {
  const lines = itemText.split('\n');
  let startIdx = -1;
  let subIndent = -1;
  for (let i = 0; i < lines.length; i++) {
    const trimmed = lines[i].trim();
    if (new RegExp('^' + subField + ':\\s*$').test(trimmed)) {
      startIdx = i + 1;
      for (let j = startIdx; j < lines.length; j++) {
        if (lines[j].trim() && /^\s*-\s+/.test(lines[j])) {
          subIndent = lines[j].length - lines[j].trimStart().length;
          break;
        }
      }
      break;
    }
  }
  if (startIdx === -1 || subIndent === -1) return [];

  const items = [];
  let current = null;
  for (let i = startIdx; i < lines.length; i++) {
    const line = lines[i];
    const indent = line.length - line.trimStart().length;
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    if (indent === subIndent && /^\s*-\s+/.test(line)) {
      if (current) items.push(current);
      current = {};
      const rest = trimmed.substring(2);
      const colonIdx = rest.indexOf(':');
      if (colonIdx > 0) {
        const key = rest.substring(0, colonIdx).trim();
        const value = rest.substring(colonIdx + 1).trim().replace(/^["']|["']$/g, '');
        if (value) current[key] = value;
      }
    } else if (indent > subIndent && current) {
      const colonIdx = trimmed.indexOf(':');
      if (colonIdx > 0) {
        const key = trimmed.substring(0, colonIdx).trim();
        const value = trimmed.substring(colonIdx + 1).trim().replace(/^["']|["']$/g, '');
        if (value) current[key] = value;
      }
    } else if (indent < subIndent) {
      if (current) items.push(current);
      current = null;
      break;
    }
  }
  if (current) items.push(current);
  return items;
}

// ==========================================
// 顶层提取器（v5.2.1 已验证正确，不修改）
// ==========================================

function loadModelRich(root) {
  const modelFile = path.join(root, '.demora', 'requirement-model.yaml');
  if (!fs.existsSync(modelFile)) {
    process.stderr.write('[FAIL] 需求模型不存在: ' + modelFile + '\n');
    process.exit(1);
  }
  const text = fs.readFileSync(modelFile, { encoding: 'utf-8' });
  return {
    raw: text,
    basic: parseYamlLite(text),
    project: extractProjectInfo(text),
    entities: extractEntities(text),
    roles: extractRoles(text),
    pages: extractPages(text),
  };
}

function extractProjectInfo(text) {
  const section = extractSection(text, 'project');
  if (!section) return { name: '', description: '', domain: '' };
  return parseItemFields(section);
}

function extractEntities(text) {
  const section = extractSection(text, 'entities');
  if (!section) return [];
  const items = parseArrayItems(section);
  return items.map(({ raw }) => {
    const fields = parseItemFields(raw);
    const fieldList = parseSubObjectArray(raw, 'fields');
    let stateList = [];
    const statesObjs = parseSubObjectArray(raw, 'states');
    if (statesObjs.length > 0) {
      stateList = statesObjs.map(s => s.value || s.label || s.name || '').filter(s => s);
    }
    if (stateList.length === 0) {
      const statusObjs = parseSubObjectArray(raw, 'statuses');
      if (statusObjs.length > 0) {
        stateList = statusObjs.map(s => s.value || s.label || s.name || '').filter(s => s);
      }
    }
    if (stateList.length === 0) stateList = parseSubArray(raw, 'states');
    if (stateList.length === 0) stateList = parseSubArray(raw, 'statuses');
    return {
      id: fields.id || fields.name || '',
      name: fields.displayName || fields.name || fields.id || '',
      fields: fieldList,
      states: stateList,
    };
  });
}

function extractRoles(text) {
  const section = extractSection(text, 'roles');
  if (!section) return [];
  const items = parseArrayItems(section);
  return items.map(({ raw }) => {
    const fields = parseItemFields(raw);
    let permList = [];
    const permObjs = parseSubObjectArray(raw, 'permissions');
    if (permObjs.length > 0) {
      permList = permObjs.map(p => {
        if (p.entity && p.actions) {
          const actionsStr = String(p.actions).replace(/[\[\]"'\s]/g, '');
          return p.entity + ':' + actionsStr;
        }
        return p.entity || p.action || p.name || '';
      }).filter(p => p);
    }
    if (permList.length === 0) permList = parseSubArray(raw, 'permissions');
    return {
      id: fields.id || fields.name || '',
      name: fields.displayName || fields.name || fields.id || '',
      description: fields.description || '',
      permissions: permList,
    };
  });
}

function extractPages(text) {
  const section = extractSection(text, 'pages');
  if (!section) return [];
  const items = parseArrayItems(section);
  return items.map(({ raw }) => {
    const fields = parseItemFields(raw);
    return {
      id: fields.id || '',
      name: fields.name || fields.id || '',
      // v5.19 P0-1：提取页面中文标题 displayName（yaml pages[].displayName，如"数据总览"）
      // 此前未提取导致任务节点 label 泄漏英文页面 id（如 layoutplan）
      displayName: fields.displayName || '',
      type: fields.type || 'crud_list',
      entity: fields.entity || '',
      route: fields.route || '/' + (fields.name || fields.id || ''),
      description: fields.description || '',
    };
  });
}

// ==========================================
// v5.2.2 新增：增强提取器（使用已有解析原语，不修改上述函数）
// ==========================================

// 提取实体状态转换（transitions）
// v5.9：同时提取 action 字段（YAML 中常见 action 而非 trigger），作为 trigger 兜底
// v5.9：同时构建 stateValue → stateLabel 映射，供 mermaid 与 bullet 渲染中文状态
function extractTransitions(text) {
  const section = extractSection(text, 'entities');
  if (!section) return [];
  const items = parseArrayItems(section);
  const transitions = [];
  for (const { raw } of items) {
    const fields = parseItemFields(raw);
    const entityName = fields.displayName || fields.name || '';
    const transList = parseSubObjectArray(raw, 'transitions');
    for (const t of transList) {
      transitions.push({
        entity: entityName,
        from: t.from || '',
        to: t.to || '',
        // v5.9：优先用 trigger，其次 action（YAML 中常见），最后空串
        trigger: t.trigger || t.action || '',
        condition: t.condition || '',
        action: t.action || '',
      });
    }
  }
  return transitions;
}

/**
 * v5.9 新增：构建实体状态值 → 状态标签映射
 * 数据源：entities[].statuses（{ value, label }）
 * @param {string} text - requirement-model.yaml 原文
 * @returns {Map} key = entityDisplayName, value = Map(stateValue → stateLabel)
 */
function buildEntityStateMap(text) {
  const section = extractSection(text, 'entities');
  if (!section) return new Map();
  const items = parseArrayItems(section);
  const entityStateMap = new Map();
  for (const { raw } of items) {
    const fields = parseItemFields(raw);
    const entityName = fields.displayName || fields.name || '';
    const stateMap = new Map();
    // 优先解析 statuses（含 value/label 结构）
    const statusObjs = parseSubObjectArray(raw, 'statuses');
    if (statusObjs.length > 0) {
      for (const s of statusObjs) {
        if (s.value && s.label) stateMap.set(s.value, s.label);
      }
    }
    // 兼容旧格式 states
    if (stateMap.size === 0) {
      const statesObjs = parseSubObjectArray(raw, 'states');
      for (const s of statesObjs) {
        if (s.value && s.label) stateMap.set(s.value, s.label);
      }
    }
    if (stateMap.size > 0) entityStateMap.set(entityName, stateMap);
  }
  return entityStateMap;
}

/**
 * v5.9 新增：将状态值转换为中文标签
 * @param {string} entityName - 实体 displayName
 * @param {string} stateValue - 状态值（如 pending）
 * @param {Map} entityStateMap - buildEntityStateMap 返回的映射
 * @returns {string} 中文标签（如 待付款）；无映射时返回原值
 */
function stateLabelOf(entityName, stateValue, entityStateMap) {
  if (!entityName || !stateValue) return stateValue || '';
  const stateMap = entityStateMap.get(entityName);
  if (!stateMap) return stateValue;
  return stateMap.get(stateValue) || stateValue;
}

/**
 * v5.9 新增：生成页面业务标签（中文名 + 页面代码）
 * PM 反馈："order-list页面" 对用户不可读，应改为 "订单列表页(order-list)" 格式
 * @param {object} pg - page 对象（含 type / name / entity）
 * @param {Map} entityMap - entity.id → entity.displayName 映射
 * @returns {string} 如 "订单列表页(order-list)"
 */
function pageDisplayLabel(pg, entityMap) {
  if (!pg) return '系统页面';
  const entName = pg.entity ? (entityMap.get(pg.entity) || pg.entity) : '';
  const type = pg.type || '';
  let cnName = '';
  switch (type) {
    case 'crud_list':
    case 'list':
      cnName = entName ? `${entName}列表页` : '列表页';
      break;
    case 'detail_view':
    case 'detail':
      cnName = entName ? `${entName}详情页` : '详情页';
      break;
    case 'form_page':
    case 'form':
      cnName = entName ? `${entName}表单页` : '表单页';
      break;
    case 'dashboard':
      cnName = '仪表盘页';
      break;
    case 'kanban':
      cnName = '看板页';
      break;
    case 'login':
      cnName = '登录页';
      break;
    case 'profile':
      cnName = '个人信息页';
      break;
    case 'chat':
      cnName = '对话页';
      break;
    case 'landing':
      cnName = '首页';
      break;
    default:
      cnName = pg.name || '业务页面';
  }
  return `${cnName}(${pg.name || pg.id})`;
}

// 提取页面增强信息（含 priority / operations）
function extractPagesRich(text) {
  const section = extractSection(text, 'pages');
  if (!section) return [];
  const items = parseArrayItems(section);
  return items.map(({ raw }) => {
    const fields = parseItemFields(raw);
    const operations = parseSubObjectArray(raw, 'operations');
    return {
      id: fields.id || '',
      name: fields.name || fields.id || '',
      type: fields.type || 'crud_list',
      entity: fields.entity || '',
      route: fields.route || '/' + (fields.name || fields.id || ''),
      description: fields.description || '',
      priority: fields.priority || 'P1',
      operations: operations,
    };
  });
}

// 提取角色增强信息（含 page_visibility 与 scope）
function extractRolesRich(text) {
  const section = extractSection(text, 'roles');
  if (!section) return [];
  const items = parseArrayItems(section);
  return items.map(({ raw }) => {
    const fields = parseItemFields(raw);
    const permObjs = parseSubObjectArray(raw, 'permissions');
    const structuredPerms = permObjs.map(p => {
      const actionsStr = String(p.actions || '').replace(/[\[\]"'\s]/g, '');
      return {
        entity: p.entity || '',
        actions: actionsStr ? actionsStr.split(',') : [],
        scope: p.scope || 'all',
      };
    });
    const visRaw = parseSubArray(raw, 'page_visibility');
    return {
      id: fields.id || fields.name || '',
      name: fields.displayName || fields.name || fields.id || '',
      description: fields.description || '',
      permissions: structuredPerms,
      pageVisibility: visRaw,
    };
  });
}

// ==========================================
// 模板加载（保留，用于页面详情模板）
// ==========================================

function loadTemplate(referencesDir, category, fileName) {
  const tmplPath = path.join(referencesDir, 'methodology', 'doc-templates', category, fileName);
  if (!fs.existsSync(tmplPath)) return null;
  return fs.readFileSync(tmplPath, { encoding: 'utf-8' });
}

// ==========================================
// v5.2.2：领域感知助手与内容生成工具
// ==========================================

function getDomainContext(model) {
  const domain = (model.project.domain || '').toUpperCase();
  const entities = model.entities || [];
  let domainLabel = '通用业务系统';
  let domainIntro = '';
  if (domain === 'HRM' || domain.includes('HR') || domain.includes('人力资源')) {
    domainLabel = '人力资源管理 (HRM)';
    domainIntro = '人力资源管理是企业运营的核心支撑职能，涉及员工全生命周期管理、考勤薪酬核算、招聘流程跟踪等多个业务域。';
  } else if (domain === 'CRM' || domain.includes('客户')) {
    domainLabel = '客户关系管理 (CRM)';
    domainIntro = '客户关系管理是企业销售与服务的核心系统，覆盖客户档案、商机跟踪、订单管理、售后服务等业务域。';
  } else if (domain === 'ERP' || domain.includes('进销存') || domain.includes('供应链')) {
    domainLabel = '企业资源计划 (ERP)';
    domainIntro = '企业资源计划系统覆盖采购、库存、销售、财务等核心业务流，是企业运营的中枢系统。';
  } else if (domain === 'OA' || domain.includes('办公')) {
    domainLabel = '办公自动化 (OA)';
    domainIntro = '办公自动化系统支撑企业内部审批、协作、文档管理等日常办公流程。';
  } else if (domain) {
    domainLabel = domain;
    domainIntro = '本系统面向 ' + domain + ' 领域的核心业务场景。';
  } else {
    domainIntro = '本系统面向企业核心业务管理场景。';
  }
  return { domainLabel, domainIntro, entityCount: entities.length };
}

function entityPainPoint(entity) {
  const name = entity.id || entity.name;
  const display = entity.name;
  const map = {
    'Employee': display + '档案分散在 Excel/纸质文件中，查询耗时长，信息更新不及时且易出现数据不一致',
    'Attendance': display + '依赖手工统计，迟到/早退/缺勤难以准确追踪，异常处理滞后且易引发劳动纠纷',
    'Salary': display + '计算繁琐易错，社保/公积金/个税规则复杂，手动核算耗时且合规风险高',
    'SalaryAdjustment': display + '缺乏统一流程跟踪，审批进度不透明，历史调薪记录难以追溯',
    'Candidate': display + '信息散落在各面试官手中，招聘阶段流转不清晰，协同效率低导致人才流失',
    'Department': display + '组织架构变更缺乏记录，跨部门协作时汇报关系不明确，权限难以精准控制',
    'Customer': display + '信息分散，销售跟进记录不完整，客户流失风险难以及时发现',
    'Order': display + '处理依赖人工流转，订单状态不透明，容易漏单错单',
    'Product': display + '信息维护分散，库存与销售数据脱节，难以实时掌握商品状态',
    'Contract': display + '管理依赖纸质归档，到期提醒缺失，续约/归档流程不规范',
  };
  return map[name] || display + '管理缺乏统一系统支撑，数据分散、流程不规范、跨角色协作效率低';
}

function entityMetric(entity) {
  const name = entity.id || entity.name;
  const map = {
    'Employee': { name: '员工档案完整率', current: '60%', target: '95%', method: '档案字段填写率统计', source: '员工档案表' },
    'Attendance': { name: '考勤数据准确率', current: '85%', target: '99%', method: '打卡记录与实际比对', source: '考勤记录表' },
    'Salary': { name: '薪酬计算准确率', current: '90%', target: '99.5%', method: '薪酬复核差错率', source: '工资条记录' },
    'SalaryAdjustment': { name: '调薪审批时效', current: '7天', target: '3天', method: '审批流耗时统计', source: '调薪审批记录' },
    'Candidate': { name: '招聘周期缩短', current: '45天', target: '30天', method: '岗位发布到 offer 平均天数', source: '候选人记录' },
    'Department': { name: '组织架构同步及时率', current: '70%', target: '95%', method: '架构变更录入滞后天数', source: '部门表' },
    'Customer': { name: '客户信息完整度', current: '65%', target: '90%', method: '客户字段填写率', source: '客户档案表' },
    'Order': { name: '订单处理准确率', current: '88%', target: '99%', method: '订单差错率统计', source: '订单表' },
    'Product': { name: '商品信息准确率', current: '80%', target: '98%', method: '商品信息校验', source: '商品表' },
  };
  return map[name] || { name: entity.name + '数据准确率', current: '80%', target: '98%', method: '数据校验通过率', source: entity.name + '表' };
}

function entityRisk(entity) {
  const name = entity.id || entity.name;
  const hasStates = entity.states && entity.states.length > 0;
  const map = {
    'Employee': entity.name + '状态流转异常（如试用期未及时转正、离职未归档）导致人事数据失真',
    'Attendance': entity.name + '数据篡改或补卡滥用导致考勤统计失真',
    'Salary': entity.name + '信息泄露或计算错误引发薪酬纠纷与合规风险',
    'SalaryAdjustment': entity.name + '审批越权或金额超标未触发二审，导致薪酬失控',
    'Candidate': entity.name + '信息泄露或阶段回退违规导致招聘流程混乱',
    'Customer': entity.name + '信息泄露或跟进记录丢失导致客户流失',
    'Order': entity.name + '状态异常跳转或重复创建导致业务数据混乱',
  };
  if (map[name]) return map[name];
  if (hasStates) return entity.name + '状态流转异常（非法状态跳转、状态停滞）导致业务数据不一致';
  return entity.name + '数据录入不规范或缺少校验导致数据质量下降';
}

function roleFrequency(roleName) {
  const map = {
    'HR 管理员': '每日高频（8-15 次/天）',
    '部门经理': '每日中频（3-5 次/天）',
    '普通员工': '每周低频（2-3 次/周）',
    '系统管理员': '每周低频（按需）',
    '财务人员': '每月集中（月初/月末高峰）',
  };
  return map[roleName] || '每日中频（3-5 次/天）';
}

// 角色ID生成器：优先使用模型中的 id 字段（如 PARKING_ADMIN），其次 name 字段，最后才回退到 R01 占位
// 修复 v5.2.2 之前硬编码 R01~R03 导致与 requirement-model.yaml 角色标识脱节的问题
function roleId(r, idx) {
  if (!r) return 'R' + String((idx || 0) + 1).padStart(2, '0');
  if (r.id) return r.id;
  if (r.name) return r.name;
  return 'R' + String((idx || 0) + 1).padStart(2, '0');
}

function genFooterMark() {
  return '\n\n---\n\n> 本文档由 generate-prd.mjs (v5.2.2) 基于 requirement-model.yaml 自动生成（' + new Date().toISOString() + '）\n';
}

function pageTypeLabel(type) {
  // v5.4：补全 chat / kanban，与 validate-model.mjs VALID_PAGE_TYPES 8 种对齐
  const map = {
    'crud_list': 'CRUD 列表页',
    'detail_view': '详情页',
    'form_page': '表单页',
    'dashboard': '仪表盘页',
    'tree_list': '树形列表页',
    'step_form': '分步表单页',
    'chat': '聊天对话页',
    'kanban': '看板页',
  };
  return map[type] || type || '列表页';
}

function entityToModule(entityName) {
  const map = {
    'Employee': '员工管理',
    'Attendance': '考勤管理',
    'Salary': '薪酬管理',
    'SalaryAdjustment': '薪酬管理',
    'Candidate': '招聘管理',
    'Department': '组织管理',
    'Customer': '客户管理',
    'Order': '订单管理',
    'Product': '商品管理',
  };
  return map[entityName] || (entityName || '通用') + '管理';
}

// ==========================================
// v5.2.2：PRD 文档生成器（从模型数据生成完整内容）
// ==========================================

function genOverview(model) {
  const p = model.project || {};
  const entities = model.entities || [];
  const roles = model.roles || [];
  const pages = model.pages || [];
  const ctx = getDomainContext(model);
  // v5.8：构建 entityMap 供 TL;DR 关键功能使用业务任务名
  const entityMap = new Map(entities.map(e => [e.name, e.displayName || e.name]));
  const L = [];
  L.push('# 00 - PRD 总览与索引', '', '> 本文档是产品需求文档 (PRD) 的主索引，汇总项目基本信息与文档结构。', '', '---', '');

  // v5.8 新增：TL;DR 段落 — 5 字段固定结构，确保 generate-product-docs.mjs 总能提取到
  // 修复 PM 反馈"项目摘要部分内容渲染异常"根因：旧版 00-overview.md 无 TL;DR 段落，
  // 触发 generate-product-docs.mjs 的 fallback 拼装，拼装时表格语法被压平导致渲染问题
  L.push('## TL;DR（一页纸摘要）', '',
    '> 3-5 行项目摘要，让 PM/研发/测试在 30 秒内理解项目本质。', '');
  L.push('- **项目定位**：' + (p.description || (p.name || '本系统') + '是面向' + ctx.domainLabel + '领域的业务管理系统'));
  const entNames = entities.slice(0, 4).map(e => e.displayName || e.name);
  L.push('- **核心差异点**：整合 ' + entities.length + ' 大业务实体' +
    (entNames.length > 0 ? '（' + entNames.join('、') + '）' : '') +
    '，提供全流程数字化管理');
  // 关键功能：取前 3 个 page，转业务任务名
  const topTasks = pages.slice(0, 3).map(pg => pageToTaskName(pg, entityMap));
  L.push('- **关键功能**：' + (topTasks.length > 0 ? topTasks.join('、') : '核心业务录入、查询、审批'));
  L.push('- **一句话状态**：' + (p.status || '规划中') + '，计划 ' + (p.releaseDate || '2026-Q4') + ' 上线');
  L.push('- **关键数字**：' + entities.length + ' 实体 / ' + roles.length + ' 角色 / ' + pages.length + ' 页面', '');

  L.push('---', '', '## 项目信息', '', '| 字段 | 内容 |', '|------|------|');
  L.push('| 项目名称 | ' + (p.name || '未命名项目') + ' |');
  L.push('| 产品愿景 | ' + (p.description || '构建高效的业务管理系统') + ' |');
  L.push('| 所属领域 | ' + ctx.domainLabel + ' |');
  L.push('| 目标平台 | Web 后台管理系统（响应式适配桌面端） |');
  L.push('| 技术栈 | 前端 React + 后端 RESTful API + 关系型数据库 |');
  L.push('| 文档版本 | v5.2.2 |');
  L.push('| 项目状态 | 规划中 |');
  L.push('| 产品经理 | 由 Demora 生成 |');
  L.push('| 计划发布日期 | 2026-Q4 |');
  L.push('', '---', '', '## PRD 文档结构', '', '| 编号 | 文档名称 | 说明 | 链接 |', '|------|----------|------|------|');
  const docStruct = [
    ['00', 'PRD 总览与索引', '项目信息、文档结构、关联文档', '00-overview.md'],
    ['01', '背景与目标', '业务背景、核心痛点、解决方案、目标', '01-background.md'],
    ['02', '目标用户', '用户分群、用户画像、使用场景、客户洞察', '02-target-audience.md'],
    ['03', '用户角色', '角色定义、权限概要、角色详细说明', '03-user-roles.md'],
    ['04', '业务流程', '主流程、分支流程、异常流程、状态流转', '04-business-flow.md'],
    ['05', '页面清单', '模块划分、页面列表、页面类型说明', '05-page-list.md'],
    ['06', '页面详情', '各页面详细设计（子目录）', '06-page-details/'],
    ['07', '字段定义', '全局共享字段、实体字段详情', '07-fields.md'],
    ['08', '权限设计', 'RBAC 角色、功能权限、数据权限', '08-permissions.md'],
    ['09', '用户故事', '用户故事列表、故事地图', '09-user-stories.md'],
    ['10', '成功指标', '指标定义、测量计划、A/B 测试、成功标准', '10-success-metrics.md'],
    ['11', '时间线', '关键里程碑、路线图、发布计划', '11-timeline.md'],
    ['12', '风险与假设', '假设清单、风险矩阵、待验证项', '12-risk-assumptions.md'],
    ['13', '待确认问题', '开放问题追踪、确认记录', '13-open-questions.md'],
  ];
  for (const d of docStruct) L.push('| ' + d[0] + ' | ' + d[1] + ' | ' + d[2] + ' | [' + d[3] + '](./' + d[3] + ') |');
  L.push('', '---', '', '## 关联文档', '', '| 文档类型 | 名称 | 链接 |', '|----------|------|------|');
  L.push('| 技术规格文档 | spec/ 目录 | [../spec/](../spec/) |');
  L.push('| 测试验收文档 | test/ 目录 | [../test/](../test/) |');
  L.push('| 交付评审文档 | handoff/ 目录 | [../handoff/](../handoff/) |');
  L.push('| 需求模型 | requirement-model.yaml | [.demora/requirement-model.yaml](../../.demora/requirement-model.yaml) |');
  L.push('', '---', '', '## 项目结构概要', '', '| 维度 | 内容 |', '|------|------|');
  L.push('| 产品名称 | ' + (p.name || '-') + ' |');
  L.push('| 产品描述 | ' + (p.description || '-') + ' |');
  L.push('| 所属领域 | ' + ctx.domainLabel + ' |');
  L.push('| 实体数量 | ' + entities.length + ' 个 |');
  L.push('| 角色数量 | ' + roles.length + ' 个 |');
  L.push('| 页面数量 | ' + pages.length + ' 个 |');
  L.push('', '### 实体清单', '', '| ID | 名称 | 字段数 | 状态数 |', '|------|------|--------|--------|');
  if (entities.length > 0) { for (const e of entities) L.push('| ' + e.id + ' | ' + e.name + ' | ' + e.fields.length + ' | ' + e.states.length + ' |'); }
  else { L.push('| - | （无实体定义） | 0 | 0 |'); }
  L.push('', '### 角色清单', '', '| ID | 名称 | 权限数 |', '|------|------|--------|');
  if (roles.length > 0) { for (let i = 0; i < roles.length; i++) { const r = roles[i]; L.push('| ' + roleId(r, i) + ' | ' + r.name + ' | ' + r.permissions.length + ' |'); } }
  else { L.push('| - | （无角色定义） | 0 |'); }
  L.push('', '### 页面清单', '', '| ID | 页面名称 | 类型 | 关联实体 | 路由 |', '|------|---------|------|---------|------|');
  if (pages.length > 0) { for (const pg of pages) L.push('| ' + pg.id + ' | ' + pg.name + ' | ' + pageTypeLabel(pg.type) + ' | ' + (pg.entity || '-') + ' | ' + pg.route + ' |'); }
  else { L.push('| - | （无页面定义） | - | - | - |'); }
  L.push(genFooterMark());
  return L.join('\n');
}

// ==========================================
// v5.19 P1-3 / P1-4：需求输入消费辅助（requirement-input.md 定位 + 痛点/方案原文提取 + non-goals 提取）
// ==========================================

// v5.19 P1-4：定位并读取需求输入文件（读不到返回 null，调用方走模板兜底）
// v5.20 P0-1 修复：候选首位补 inbox/text/requirement-input.md（scaffold 标准目录形态）——
//   v5.19 候选清单缺 text/ 子目录，标准产物路径下输入永远读不到，痛点/方案全部走模板兜底（U19 回归根因）
// 优先级：./inbox/text/requirement-input.md → ./inbox/requirement-input.md → ./requirement-input.md（相对 sim-project 根目录）
function loadRequirementInput(root) {
  const candidates = [
    path.join(root, 'inbox', 'text', 'requirement-input.md'),
    path.join(root, 'inbox', 'requirement-input.md'),
    path.join(root, 'requirement-input.md'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      try { return fs.readFileSync(p, { encoding: 'utf-8' }); } catch { return null; }
    }
  }
  return null;
}

// v5.19 P1-4：修复句尾双句号拼接 bug——去掉句尾全角句号，由调用方统一补单一句号
function stripTrailingPeriod(s) {
  return String(s || '').replace(/。+$/, '');
}

// v5.19 P1-4：从 requirement-input.md 提取痛点/方案原文段落
// 提取规则：
//   1. 标题关键词分节：标题含 痛点|问题|挑战 → 痛点节；含 方案|解决|目标 → 方案节；同时命中归双桶
//   2. 节内列表项（- / * / 1.）与实质段落行按所属节归桶
//   3. 无节上下文的列表项按行内关键词（痛点类/方案类）归桶
function extractInputNarrative(inputText) {
  const result = { pains: [], solutions: [] };
  if (!inputText) return result;
  const lines = String(inputText).replace(/\r\n/g, '\n').split('\n');
  let section = ''; // 'pain' | 'solution' | 'both' | 'nongoal' | ''
  for (const line of lines) {
    const heading = line.match(/^#{1,6}\s+(.*)$/);
    if (heading) {
      const t = heading[1];
      // v5.19 P1-3 补充：非目标/范围外节须先排除——"非目标"含"目标"字样，
      // 不排除会被误判为方案节导致 non-goals 内容泄入解决方案桶（该节由 extractNonGoals 消费）
      if (/非目标|范围外|不做|out\s*of\s*scope/i.test(t)) { section = 'nongoal'; continue; }
      const isPain = /痛点|问题|挑战|pain/i.test(t);
      const isSolution = /方案|解决|目标|solution/i.test(t);
      section = isPain && isSolution ? 'both' : (isPain ? 'pain' : (isSolution ? 'solution' : ''));
      continue;
    }
    // v5.20 P0-1 补充：加粗小节标签（如 **行业痛点**：/**价值主张**：）也切换节上下文——
    //   v5.19 仅识别 # 标题，痛点/方案叙事挂在加粗标签下时漏提（p10 复跑实证：4 条痛点仅命中 2 条）
    //   纯标签行仅切换节；标签 + 行内叙事（如 **价值主张**：以 AI …）余文按新节归桶
    let overrideText = null;
    const bold = line.match(/^\*\*([^*]{1,20})\*\*\s*[:：]?\s*(.*)$/);
    if (bold) {
      const t = bold[1];
      if (/非目标|范围外|不做|out\s*of\s*scope/i.test(t)) { section = 'nongoal'; continue; }
      const isPain = /痛点|问题|挑战/i.test(t);
      const isSolution = /方案|价值主张|解决|目标/i.test(t);
      if (isPain && !isSolution) section = 'pain';
      else if (isSolution && !isPain) section = 'solution';
      // 中性标签（如 **项目背景**）：不改变节上下文（外层 # 标题语境延续）
      if (!bold[2].trim()) continue; // 纯标签行：仅切换节上下文
      overrideText = bold[2].trim();  // 行内叙事走下方归桶
    }
    // 跳过代码围栏与表格行（非叙事内容）
    if (line.trim().startsWith('```') || line.trim().startsWith('|')) continue;
    // 非目标节内容不参与痛点/方案归桶
    if (section === 'nongoal') continue;
    const listItem = overrideText === null ? line.match(/^\s*(?:[-*]|\d+\.)\s+(.+)$/) : null;
    const text = (listItem ? listItem[1] : (overrideText !== null ? overrideText : line)).trim();
    if (!text || text.length < 4) continue;
    const kwPain = /痛点|分散|低效|耗时|滞后|手工|excel|孤岛|难以及时|效率低|易错/i.test(text);
    const kwSolution = /解决|方案|实现|提供|构建|搭建|打通|支持|线上化|数字化/i.test(text);
    if (listItem) {
      if (section === 'pain' || section === 'both') result.pains.push(text);
      else if (section === 'solution') result.solutions.push(text);
      else if (kwPain && !kwSolution) result.pains.push(text);
      else if (kwSolution) result.solutions.push(text);
    } else if (text.length >= 10) {
      if (section === 'pain' || section === 'both') result.pains.push(text);
      else if (section === 'solution') result.solutions.push(text);
    }
  }
  result.pains = [...new Set(result.pains)].slice(0, 6);
  result.solutions = [...new Set(result.solutions)].slice(0, 6);
  return result;
}

// v5.19 P1-3：提取 non-goals（范围外/明确不做）
// 来源优先级：requirement-model.yaml 的 non_goals 节 → requirement-input.md 的"非目标/范围外"章节
// 完全无输入时返回 null（调用方输出显式缺省行，绝不编造）
function extractNonGoals(model) {
  // 1) requirement-model.yaml 的 non_goals / nonGoals 列表
  for (const key of ['non_goals', 'nonGoals']) {
    const section = extractSection(model.raw || '', key);
    if (section) {
      const items = parseArrayItems(section)
        .map(({ raw }) => raw.split('\n')[0].replace(/^\s*-\s*/, '').trim().replace(/^["']|["']$/g, ''))
        .filter(s => s);
      if (items.length > 0) return items;
    }
  }
  // 2) requirement-input.md 的 非目标/范围外/不做 章节
  if (model.inputText) {
    const lines = String(model.inputText).replace(/\r\n/g, '\n').split('\n');
    let inSection = false;
    const items = [];
    for (const line of lines) {
      const heading = line.match(/^#{1,6}\s+(.*)$/);
      if (heading) {
        inSection = /非目标|范围外|不做|out\s*of\s*scope/i.test(heading[1]);
        continue;
      }
      if (!inSection) continue;
      const listItem = line.match(/^\s*(?:[-*]|\d+\.)\s+(.+)$/);
      const text = (listItem ? listItem[1] : line).trim();
      if (text && text.length >= 2 && !text.startsWith('```')) items.push(text);
    }
    if (items.length > 0) return items.slice(0, 8);
  }
  return null;
}

function genBackground(model) {
  const p = model.project || {};
  const entities = model.entities || [];
  const pages = model.pages || [];
  const ctx = getDomainContext(model);
  const topEntities = entities.slice(0, 3);
  // v5.19 P1-4：优先消费 requirement-input.md 原文叙事；提取不到时模板句式兜底并显式标注
  const narrative = extractInputNarrative(model.inputText);
  // v5.19 P1-3：non-goals 提取（无输入时输出显式缺省行，绝不编造）
  const nonGoals = extractNonGoals(model);
  // v5.19 P1-4：兜底模板行的统一标注后缀
  // v5.20 P0-1 语义修正：「待基于需求输入修订」与 demora 流程矛盾——能走到文档输出即代表需求已获用户确认，
  //   兜底行改为事实陈述（说明该部分内容为模板生成且输入未覆盖），不再向用户悬置"待确认/待修订"动作
  const TMPL_MARK = '（模板生成：需求输入未包含该部分内容）';
  const L = [];
  L.push('# 01 - 背景与目标', '', '> 本文档描述项目的业务背景、核心痛点、解决方案及各类目标定义。', '', '---', '', '## 业务背景', '');
  // v5.19 P1-4：修复句尾双句号拼接 bug（定位句与能力句拼接处去重句号）
  L.push(ctx.domainIntro + '当前' + (p.name || '本系统') + '旨在通过数字化手段整合' + (entities.length > 0 ? entities.map(e => e.name).slice(0, 4).join('、') : '核心业务') + '等业务模块，实现数据集中管理、流程标准化与跨角色协作提效。' + (p.description ? '项目定位为：' + stripTrailingPeriod(p.description) + '。' : ''));
  L.push('', '---', '', '## 核心痛点', '');
  // v5.19 P1-4：痛点优先忠实输出需求输入原文；仅当输入完全提取不到时降级模板句式并标注
  if (narrative.pains.length > 0) {
    narrative.pains.forEach((t, idx) => L.push((idx + 1) + '. ' + t));
  } else {
    topEntities.forEach((e, idx) => { L.push((idx + 1) + '. **痛点' + ['一', '二', '三'][idx] + '**：' + stripTrailingPeriod(entityPainPoint(e)) + TMPL_MARK); });
    if (entities.length > 3) { L.push('4. **痛点四**：跨模块数据孤岛严重，' + entities.map(e => e.name).slice(0, 3).join('、') + '等业务数据无法联动，报表统计依赖人工汇总，决策缺乏实时数据支撑' + TMPL_MARK); }
    else if (entities.length === 0) { L.push('1. **痛点一**：核心业务数据缺乏统一管理系统，依赖 Excel/纸质流程，效率低且易出错' + TMPL_MARK); }
  }
  L.push('', '---', '', '## 解决方案', '', stripTrailingPeriod(p.description || '构建统一的管理后台系统') + '。通过构建' + ctx.domainLabel + '一体化管理平台，实现以下能力：', '');
  // v5.19 P1-4：解决方案优先忠实输出需求输入原文；仅当输入完全提取不到时降级固定 bullet 并标注
  if (narrative.solutions.length > 0) {
    narrative.solutions.forEach(t => L.push('- ' + t));
  } else {
    L.push('- **数据集中化**：将' + (entities.length > 0 ? entities.map(e => e.name).join('、') : '核心业务') + '数据统一存储与管理，消除数据孤岛' + TMPL_MARK);
    L.push('- **流程标准化**：将核心业务流程（录入、审批、状态流转）固化到系统，减少人为差错' + TMPL_MARK);
    L.push('- **权限精细化**：基于 RBAC 模型实现角色-实体-操作三级权限控制，保障数据安全' + TMPL_MARK);
    L.push('- **协作在线化**：多角色在线协同，审批流自动流转，提升跨部门协作效率' + TMPL_MARK);
    L.push('- **决策数据化**：提供实时数据看板与报表，支撑管理决策' + TMPL_MARK);
  }
  L.push('', '---', '', '## 业务目标', '', '| 业务指标 | 当前值 | 目标值 | 关联战略 |', '|----------|--------|--------|----------|');
  entities.slice(0, 4).forEach(e => { const m = entityMetric(e); L.push('| ' + m.name + ' | ' + m.current + ' | ' + m.target + ' | 数字化转型提效 |'); });
  if (entities.length === 0) { L.push('| 核心业务数字化率 | 30% | 90% | 数字化转型 |'); }
  L.push('', '---', '', '## 产品目标 (OKR 格式)', '', '**Objective**: 构建' + ctx.domainLabel + '一体化平台，实现' + (entities.length > 0 ? entities.map(e => e.name).slice(0, 3).join('、') : '核心业务') + '全流程数字化管理', '', '| Key Result | 当前基准 | 目标值 | 衡量方式 |', '|------------|----------|--------|----------|');
  entities.slice(0, 3).forEach((e, idx) => { const m = entityMetric(e); L.push('| KR' + (idx + 1) + ': ' + m.name + '提升至 ' + m.target + ' | ' + m.current + ' | ' + m.target + ' | ' + m.method + ' |'); });
  if (entities.length > 0) { L.push('| KR' + (Math.min(entities.length, 3) + 1) + ': 系统覆盖 ' + entities.length + ' 个核心业务实体 | 0 | ' + entities.length + ' | 实体上线数 |'); }
  L.push('', '---', '', '## 技术目标', '', '- 前端首屏加载时间 < 2 秒（生产环境）', '- API 接口平均响应时间 < 500ms（P95）', '- 系统可用性 SLA >= 99.5%', '- 支持' + (entities.length > 0 ? entities[0].name : '核心') + '数据万级记录下流畅查询与分页', '- 权限控制覆盖所有页面与 API，无越权访问漏洞');
  L.push('', '---', '', '## 范围与约束', '', '### 范围内', '');
  pages.slice(0, 5).forEach(pg => { L.push('- ' + pg.name + '（' + pageTypeLabel(pg.type) + '）：' + (pg.description || entityToModule(pg.entity) + '功能页面')); });
  if (pages.length === 0) { L.push('- 核心业务实体的 CRUD 管理页面'); }
  L.push('', '### 范围外', '');
  // v5.19 P1-3：删除三条固定"范围外"硬编码文案（十案例逐字相同的编造内容），
  // 改为忠实输出 non_goals 提取结果；完全无输入时输出显式缺省行
  if (nonGoals && nonGoals.length > 0) {
    nonGoals.forEach(t => L.push('- ' + t));
  } else {
    L.push('- 本期范围外事项：需求输入未指定（如需明确请在需求输入中补充"非目标/范围外"章节）');
  }
  L.push('', '### 约束条件', '', '- 部署环境：内网/云服务器，需支持 Docker 容器化部署', '- 浏览器兼容：Chrome 90+ / Edge 90+ / Firefox 88+', '- 数据合规：' + ctx.domainLabel + '相关数据需符合隐私保护要求', '- 交付周期：2026-Q4 前完成核心功能上线', genFooterMark());
  return L.join('\n');
}

function genTargetAudience(model) {
  const roles = model.roles || [];
  const pages = model.pages || [];
  const entities = model.entities || [];
  const ctx = getDomainContext(model);
  // v5.9：构建 entity.id → entity.displayName 映射，供 pageDisplayLabel 使用
  const entityMap = new Map(entities.map(e => [e.id, e.name]));
  const L = [];
  L.push('# 02 - 目标用户', '', '> 本文档定义目标用户分群、用户画像、使用场景及客户洞察。', '', '---', '', '## 用户分群', '', '| 用户类型 | 定位 | 占比 | 核心诉求 |', '|----------|------|------|----------|');
  const ratioMap = ['40%', '35%', '20%', '5%'];
  const positionMap = ['核心管理用户', '协同管理用户', '终端使用用户', '辅助使用用户'];
  roles.forEach((r, idx) => { L.push('| ' + r.name + ' | ' + ctx.domainLabel + '系统' + (positionMap[idx] || '辅助使用用户') + ' | ' + (ratioMap[idx] || '5%') + ' | ' + (r.description || '高效完成' + r.name + '相关业务操作') + ' |'); });
  if (roles.length === 0) { L.push('| 系统用户 | 管理后台使用者 | 100% | 高效完成业务操作 |'); }
  L.push('', '---', '', '## 用户画像', '');
  roles.forEach((r, idx) => {
    const letter = String.fromCharCode(65 + idx);
    const freq = roleFrequency(r.name);
    L.push('### 画像 ' + letter + '：' + r.name, '', '| 维度 | 描述 |', '|------|------|');
    L.push('| 职业 | ' + r.name + ' |');
    L.push('| 核心职责 | ' + (r.description || '负责' + r.name + '相关业务的管理与执行') + ' |');
    L.push('| 痛点 | ' + (model.entities.length > idx ? entityPainPoint(model.entities[idx]) : '手工操作效率低，数据查询不便') + ' |');
    // v5.9：使用 pageDisplayLabel 替代裸 page.name（PM 反馈：order-list 不可读）
    L.push('| 使用场景 | 通过' + (pages.length > idx ? pageDisplayLabel(pages[idx], entityMap) : '系统后台') + '进行日常业务操作 |');
    L.push('| 期望体验 | 操作简洁高效，数据实时准确，权限清晰无越权风险 |');
    L.push('| 当前替代方案 | Excel 表格 + 纸质流程 + 邮件/即时通讯沟通 |', '');
  });
  if (roles.length === 0) { L.push('### 画像 A：系统用户', '', '| 维度 | 描述 |', '|------|------|', '| 职业 | 业务管理人员 |', '| 核心职责 | 日常业务管理 |', '| 痛点 | 缺乏统一系统支撑 |', '| 使用场景 | 通过后台进行业务操作 |', '| 期望体验 | 高效准确 |', '| 当前替代方案 | Excel |', ''); }
  L.push('---', '', '## 使用场景', '', '| 场景编号 | 用户类型 | 触发情境 | 任务 | 设备 |', '|----------|----------|----------|------|------|');
  let sIdx = 0;
  const devices = ['桌面端 PC', '桌面端 PC', '桌面端 PC'];
  // v5.9：触发情境中的 pg.entity 改用实体 displayName，任务中的 pg.name 改用 pageDisplayLabel
  roles.forEach(r => { pages.slice(0, 2).forEach(pg => {
    sIdx++;
    const entName = pg.entity ? (entityMap.get(pg.entity) || pg.entity) : '业务';
    L.push('| S' + String(sIdx).padStart(2, '0') + ' | ' + r.name + ' | ' + (pg.description || '需要查看/管理' + entName + '数据') + ' | 在' + pageDisplayLabel(pg, entityMap) + '进行操作 | ' + (devices[sIdx % 3] || '桌面端 PC') + ' |');
  }); });
  if (sIdx === 0) { L.push('| S01 | 系统用户 | 日常业务处理 | 登录系统进行操作 | 桌面端 PC |'); }
  L.push('', '---', '', '## 客户洞察', '', '| 来源 | 日期 | 关键发现 | 链接 |', '|------|------|----------|------|');
  L.push('| 需求模型分析 | 2026-07 | ' + ctx.domainLabel + '系统需覆盖 ' + (model.entities || []).length + ' 个核心实体、' + roles.length + ' 类角色 | requirement-model.yaml |');
  L.push('| 业务流程推导 | 2026-07 | 核心流程涉及 ' + pages.length + ' 个页面的协同操作 | 04-business-flow.md |');
  L.push('| 权限设计分析 | 2026-07 | 需实现基于 RBAC 的精细化权限控制 | 08-permissions.md |');
  L.push(genFooterMark());
  return L.join('\n');
}

function genUserRoles(model) {
  const roles = model.roles || [];
  const entities = model.entities || [];
  const L = [];
  L.push('# 03 - 用户角色', '', '> 本文档定义系统中的用户角色、权限概要与角色详细说明。', '', '---', '', '## 角色定义', '', '| ID | 名称 | 职责 | 场景 |', '|----|------|------|------|');
  roles.forEach((r, idx) => { const scenario = entities.length > idx ? entities[idx].name + '管理' : '日常业务操作'; L.push('| ' + roleId(r, idx) + ' | ' + r.name + ' | ' + (r.description || '负责' + r.name + '相关业务') + ' | ' + scenario + ' |'); });
  if (roles.length === 0) { L.push('| R01 | 系统用户 | 日常业务管理 | 业务操作 |'); }
  L.push('', '---', '', '## 角色权限概要', '', '| 角色 | 查看 | 新增 | 编辑 | 删除 | 审批 | 导出 |', '|------|------|------|------|------|------|------|');
  roles.forEach(r => { const a = r.permissions.join(','); const has = x => a.includes(x); L.push('| ' + r.name + ' | ' + (has('read') ? 'Y' : '-') + ' | ' + (has('create') ? 'Y' : '-') + ' | ' + (has('update') ? 'Y' : '-') + ' | ' + (has('delete') ? 'Y' : '-') + ' | ' + (has('update') && r.name.includes('经理') ? 'Y' : '-') + ' | ' + (has('export') ? 'Y' : '-') + ' |'); });
  if (roles.length === 0) { L.push('| 系统用户 | Y | Y | Y | - | - | - |'); }
  L.push('', '> 详细权限矩阵请参见 [08-permissions.md](./08-permissions.md)。', '', '---', '', '## 角色详细说明', '');
  roles.forEach((r, idx) => {
    const freq = roleFrequency(r.name);
    const rolePages = model.pages || [];
    const pathStr = rolePages.length > 0 ? rolePages.slice(0, 3).map(pg => pg.name).join(' -> ') : '后台首页';
    let dataScope = '全部数据';
    const ps = r.permissions.join(' ');
    if (ps.includes('own')) dataScope = '仅本人数据';
    else if (ps.includes('department')) dataScope = '本部门数据';
    else if (ps.includes('all')) dataScope = '全部数据';
    L.push('### 角色 ' + roleId(r, idx) + '：' + r.name, '', '| 维度 | 描述 |', '|------|------|');
    L.push('| 核心职责 | ' + (r.description || '负责' + r.name + '相关业务的管理与执行') + ' |');
    L.push('| 使用频率 | ' + freq + ' |');
    L.push('| 典型操作路径 | ' + pathStr + ' |');
    L.push('| 数据权限 | ' + dataScope + ' |');
    L.push('| 关联权限 | ' + (r.permissions.length > 0 ? r.permissions.join('、') : '基础查看权限') + ' |', '');
  });
  L.push('---', '', '> 完整的 RBAC 权限设计请参见 [08-permissions.md](./08-permissions.md)。', genFooterMark());
  return L.join('\n');
}

// ==========================================
// v5.7 新增：三大 Flow 生成器（Task / Data / Page）
// ==========================================

/**
 * v5.8：按 page.type + entity.displayName 推导业务任务名
 * 修复 PM 反馈："Task Flow 照搬后台开发文档，应该从读者视觉从产品需求进行黑盒呈现"
 * 旧逻辑直接用 pg.name（如 'itinerary-list'）作为节点标签，技术化且对 PM 不可读
 * 新逻辑按 7 种主流 page.type 映射为业务任务动词 + 实体名
 *
 * @param {object} pg - page 对象（含 type / name / entity / displayName）
 * @param {Map} entityMap - entity.name → entity.displayName 映射
 * @returns {string} 业务任务名（如"浏览行程"、"查看订单详情"）
 */
function pageToTaskName(pg, entityMap) {
  if (!pg) return '执行业务操作';
  // v5.19 P0-1：任务节点 label 一律优先使用页面中文标题（displayName），
  // 修复 BPMN 任务节点泄漏英文页面 id（如 Pool1_T5("layoutplan")）的问题；
  // displayName 缺失时回落到原有 type 推导链
  if (pg.displayName) return pg.displayName;
  // 优先使用 page.displayName（如有），其次用实体 displayName
  const entName = pg.entity ? (entityMap.get(pg.entity) || pg.entity) : '';
  const type = pg.type || '';
  switch (type) {
    case 'crud_list':
    case 'list':
      return entName ? `浏览${entName}` : '浏览列表';
    case 'detail_view':
    case 'detail':
      return entName ? `查看${entName}详情` : '查看详情';
    case 'form_page':
    case 'form':
      return entName ? `新增/编辑${entName}` : '填写表单';
    case 'dashboard':
      return '查看看板';
    case 'kanban':
      return '管理看板';
    case 'login':
      return '登录系统';
    case 'profile':
      return '管理个人信息';
    case 'chat':
      return '发起会话';
    case 'landing':
      return '访问首页';
    default:
      // 兜底：用 page.displayName 或 name（去掉 -list/-form 等技术后缀）
      if (pg.displayName) return pg.displayName;
      if (pg.name) {
        return pg.name.replace(/[-_](list|detail|form|page|view)$/, '').replace(/[-_]/g, '');
      }
      return '执行业务操作';
  }
}

// 生成 Task Flow（任务流，BPMN 2.0 风格）
// 数据源：pages + roles（按角色分泳道）+ transitions + structured permissions
// v5.8：节点标签改用 pageToTaskName 业务任务名（屏蔽技术页面 ID）
// v5.9：entityMap 改用 entity.id 作为 key（修复 entityMap.get(pg.entity) 失败的 Bug）
// v5.10：基于 BPMN 2.0 业界标杆重构（Events / Activities / Gateways / Pools / Lanes）
//   - Start/End 事件使用圆形节点 (( ))  —— BPMN Event
//   - 任务节点使用圆角矩形 ( )          —— BPMN Task
//   - 网关使用菱形 { }                  —— BPMN Gateway（排他网关 XOR）
//   - 角色作为 Pool（subgraph），每个 Pool 内按 Lane 分组（按 entity 维度）
//   - 跨 Pool 协作使用虚线箭头 -.->     —— BPMN Message Flow
//   - 同 Pool 内使用实线箭头 -->        —— BPMN Sequence Flow
//   - 页面归属判定：基于角色对该页面 entity 的 permissions（create/update 优先于 read）
// v5.19 P2-6：构建页面 → 角色索引映射（从 genTaskFlow 抽取为共享函数，供主流程泳道复用）
// 数据映射方式：页面主角色 = 对该页面 entity 拥有 create/update/write/approve/assign
// 类权限的角色（基于 roles[].permissions 结构化数据）；无匹配角色时回退 pIdx % roles.length
function buildPageRoleMap(model) {
  const pages = model.pages || [];
  const roles = model.roles || [];
  const rolesRich = extractRolesRich(model.raw);
  // 构建角色 → 拥有的实体集合（基于 create/update 权限）
  const roleOwnedEntities = new Map();
  rolesRich.forEach((r, idx) => {
    const owned = new Set();
    (r.permissions || []).forEach(p => {
      if (p.entity && (p.actions || []).some(a => ['create', 'update', 'write', 'approve', 'assign'].includes(a))) {
        owned.add(p.entity);
      }
    });
    roleOwnedEntities.set(idx, owned);
  });
  // 构建页面 → 关联角色索引（按 entity 归属判定，回退到 pIdx % roles.length）
  const pageRoleMap = new Map();
  pages.forEach((pg, pIdx) => {
    let roleIdx = -1;
    if (pg.entity) {
      for (const [idx, owned] of roleOwnedEntities) {
        if (owned.has(pg.entity)) { roleIdx = idx; break; }
      }
    }
    if (roleIdx === -1) roleIdx = roles.length > 0 ? (pIdx % roles.length) : 0;
    pageRoleMap.set(pIdx, roleIdx);
  });
  return { pageRoleMap, roleOwnedEntities };
}

function genTaskFlow(model) {
  const pages = model.pages || [];
  const roles = model.roles || [];
  const entities = model.entities || [];
  const transitions = extractTransitions(model.raw);
  // v5.9 修复：entityMap 用 e.id 作为 key
  const entityMap = new Map(entities.map(e => [e.id, e.name]));
  // v5.10：使用 rich extractors 获取 operations + 结构化 permissions
  const pagesRich = extractPagesRich(model.raw);
  // v5.19 P2-6：页面-角色归组逻辑抽取为共享函数 buildPageRoleMap（与主流程泳道保持一致）
  const { pageRoleMap, roleOwnedEntities } = buildPageRoleMap(model);

  const L = [];
  L.push('## Task Flow（任务流，BPMN 2.0）', '',
    '> **业界标准**：BPMN 2.0（Business Process Model and Notation）',
    '> **关注点**：用户完成业务任务的操作步骤序列，按角色分 Pool/Lane。',
    '> **图例**：`(( ))` 事件 / `( )` 任务 / `{ }` 网关 / 实线=Sequence Flow / 虚线=Message Flow', '',
    '### BPMN 任务流图', '',
    '```mermaid', 'flowchart TD');

  // 起始事件
  L.push('    Start((用户登录))');

  if (roles.length === 0) {
    // 兜底：无角色时仅展示任务序列（v5.8：业务任务名）
    L.push('    Start --> T1[浏览主页]');
    if (pages.length > 0) {
      pages.slice(0, 5).forEach((pg, i) => {
        const id = 'T' + (i + 2);
        const taskName = pageToTaskName(pg, entityMap);
        // v5.11：节点标签加双引号，避免 Mermaid 11.16.0 严格模式解析失败
        L.push('    T' + (i + 1) + ' --> ' + id + '("' + taskName + '")');
      });
    }
    L.push('    T' + Math.max(pages.length + 1, 2) + ' --> End((完成))');
  } else {
    // 按 Pool/Lane 划分：每个角色一个 Pool
    roles.forEach((role, rIdx) => {
      const rid = 'Pool' + (rIdx + 1);
      // v5.11：subgraph 标签加双引号
      L.push('    subgraph ' + rid + '["' + (role.displayName || role.name) + '"]');
      // 该角色负责的页面（基于 entity 归属判定，回退到索引取模）
      const rolePages = pages.map((pg, pIdx) => ({ pg, pIdx }))
        .filter(({ pIdx }) => pageRoleMap.get(pIdx) === rIdx);
      if (rolePages.length === 0) {
        L.push('        ' + rid + '_T1("执行业务操作")');
      } else {
        // 起始任务
        rolePages.slice(0, 5).forEach(({ pg, pIdx }, idx) => {
          const tid = rid + '_T' + (idx + 1);
          const taskName = pageToTaskName(pg, entityMap);
          // v5.11：节点标签加双引号
          L.push('        ' + tid + '("' + taskName + '")');
          if (idx > 0) {
            // 任务间用网关（决策点）连接 —— BPMN 排他网关
            const prevTid = rid + '_T' + idx;
            const gatewayId = rid + '_G' + idx;
            // v5.11：网关标签加双引号
            L.push('        ' + prevTid + ' --> ' + gatewayId + '{"通过?"}');
            L.push('        ' + gatewayId + ' -->|是| ' + tid);
            L.push('        ' + gatewayId + ' -->|否| ' + rid + '_End((结束))');
          }
        });
        // 结束事件
        const lastTaskIdx = Math.min(rolePages.length, 5);
        L.push('        ' + rid + '_T' + lastTaskIdx + ' --> ' + rid + '_Done((任务完成))');
      }
      L.push('    end');
    });
    // 起始事件 → 第一个 Pool 的第一个任务
    L.push('    Start --> Pool1_T1');
    // 跨 Pool 协作（Message Flow，虚线）—— 基于实体状态流转 transitions 推导
    if (roles.length >= 2) {
      // 默认链式协作：Pool1 → Pool2 → ... → PoolN
      for (let i = 0; i < roles.length - 1; i++) {
        // 查找两个角色之间共享的实体（协作点）
        const fromOwned = roleOwnedEntities.get(i) || new Set();
        const toOwned = roleOwnedEntities.get(i + 1) || new Set();
        const sharedEntities = [...fromOwned].filter(e => toOwned.has(e));
        const label = sharedEntities.length > 0
          ? '交付' + sharedEntities.map(e => entityMap.get(e) || e).join('/')
          : '交付';
        L.push('    Pool' + (i + 1) + '_Done -.->|' + label + '| Pool' + (i + 2) + '_T1');
      }
    }
    // 全局结束事件
    L.push('    Pool' + roles.length + '_Done --> End((业务完成))');
    // 状态流转触发分支（基于 transitions）—— BPMN 中间事件
    if (transitions.length > 0) {
      const validTrans = transitions.filter(t => t.from && t.to).slice(0, 3);
      validTrans.forEach((t, idx) => {
        const fromLabel = stateLabelOf(t.entity, t.from, buildEntityStateMap(model.raw));
        const toLabel = stateLabelOf(t.entity, t.to, buildEntityStateMap(model.raw));
        // v5.11：事件节点标签加双引号
        // v5.19 P0-1：修复 mermaid 非法形状——原 `EvtN>{{"…"}}`（旗帜符+六角形拼接）
        // 在 mermaid 11.16 报 Parse error (DIAMOND_START)，改为合法六角形语法 `EvtN{{"…"}}`
        L.push('    ' + 'Evt' + (idx + 1) + '{{"' + t.entity + ': ' + fromLabel + ' → ' + toLabel + '"}}');
      });
    }
  }

  L.push('```', '', '### 角色任务清单（BPMN Pool/Lane 视角）', '',
    '| 角色 (Pool) | 任务 (Task) | 触发条件 | 关联页面 | 关联实体 | 交付物 |',
    '|------|------|----------|----------|---------|--------|');

  if (roles.length === 0) {
    const fallbackTask = pages[0] ? pageToTaskName(pages[0], entityMap) : '浏览并操作页面';
    const fallbackPage = pages[0] ? pageDisplayLabel(pages[0], entityMap) : '主页';
    L.push('| 默认用户 | ' + fallbackTask + ' | 登录系统 | ' + fallbackPage + ' | - | 数据记录 |');
  } else {
    roles.forEach((role, rIdx) => {
      const rolePagesIdx = pages.map((pg, pIdx) => ({ pg, pIdx }))
        .filter(({ pIdx }) => pageRoleMap.get(pIdx) === rIdx);
      const firstPg = rolePagesIdx[0]?.pg;
      const taskName = firstPg ? pageToTaskName(firstPg, entityMap) : '执行业务操作';
      const pageLabel = firstPg ? pageDisplayLabel(firstPg, entityMap) : '-';
      const entName = firstPg?.entity ? (entityMap.get(firstPg.entity) || firstPg.entity) : '-';
      // 查找该角色拥有的所有实体
      const ownedEnts = [...(roleOwnedEntities.get(rIdx) || [])]
        .map(e => entityMap.get(e) || e).join('、') || '-';
      L.push('| ' + (role.displayName || role.name) + ' | ' + taskName + ' | 登录后进入工作台 | ' +
        pageLabel + ' | ' + ownedEnts + ' | 业务数据 |');
    });
  }

  // v5.20 P2-1：BPMN 元素说明图例彻底删除（UAT 二轮 U15 裁决："请直接删除，不需要了"）
  //   v5.19 P2-5 曾收纳为 ```text 围栏弱化区块；用户裁决收起仍占章节噪音，整体移除
  L.push('');
  return L.join('\n');
}

// 生成 Data Flow（数据流，DFD Yourdon-DeMarco 风格）
// 数据源：entities + roles + pages + structured permissions + page operations
// v5.10：基于 DFD（Yourdon-DeMarco）业界标杆重构
//   - 外部实体（External Entity）：角色，使用矩形 [ ]   —— DFD External Entity
//   - 处理过程（Process）：页面操作，使用圆角矩形 ( )  —— DFD Process
//   - 数据存储（Data Store）：实体，使用双线 [[ ]]      —— DFD Data Store
//   - 数据流（Data Flow）：带标签的箭头 -->|数据|       —— DFD Data Flow
//   - 层级：Context Diagram → Level 0 → Level 1
function genDataFlow(model) {
  const entities = model.entities || [];
  const roles = model.roles || [];
  const pages = model.pages || [];
  const pagesRich = extractPagesRich(model.raw);
  const rolesRich = extractRolesRich(model.raw);
  const entityMap = new Map(entities.map(e => [e.id, e.name]));
  const L = [];
  L.push('## Data Flow（数据流，DFD Yourdon-DeMarco）', '',
    '> **业界标准**：DFD（Data Flow Diagram，Yourdon-DeMarco notation）',
    '> **关注点**：数据在系统各模块/角色间的流动路径，含数据归属与操作权限。',
    '> **图例**：`[ ]` 外部实体 / `( )` 处理过程 / `[[ ]]` 数据存储 / 箭头标签=数据流内容', '',
    '### Level 0 - 上下文图（Context Diagram）', '',
    '```mermaid', 'flowchart LR');

  // Context Diagram：系统作为单一 Process，外部实体围绕
  L.push('    System((本系统<br/>' + (model.project?.name || '业务系统') + '))');
  roles.slice(0, 6).forEach((r, i) => {
    // v5.11：节点标签加双引号
    L.push('    Ext' + (i + 1) + '["' + r.name + '"]');
  });
  // 外部实体 → 系统的输入数据流
  roles.slice(0, 6).forEach((r, i) => {
    // 推导该角色向系统提交的主要数据
    const rolePerms = rolesRich[i]?.permissions || [];
    const writableEntities = rolePerms
      .filter(p => (p.actions || []).some(a => ['create', 'update', 'write', 'import'].includes(a)))
      .map(p => entityMap.get(p.entity) || p.entity)
      .filter(Boolean).slice(0, 2);
    const inputData = writableEntities.length > 0 ? writableEntities.join('、') + '数据' : '业务请求';
    L.push('    Ext' + (i + 1) + ' -->|' + inputData + '| System');
    // 系统返回的数据流
    L.push('    System -.->|查询结果/反馈| Ext' + (i + 1));
  });

  L.push('```', '', '### Level 1 - 数据流分解图', '',
    '```mermaid', 'flowchart LR');

  // 数据存储（Data Store）—— 使用 [[ ]] 表示 DFD 双线
  entities.slice(0, 10).forEach((e, i) => {
    const dsId = 'DS' + (i + 1);
    const fieldSummary = e.fields && e.fields.length > 0
      ? '<br/>字段: ' + e.fields.slice(0, 4).map(f => f.name || f).join(', ') +
        (e.fields.length > 4 ? '...' : '')
      : '';
    // v5.11：数据存储节点标签加双引号，避免 e.name 含特殊字符导致 Mermaid 解析失败
    L.push('    ' + dsId + '[["' + e.name + fieldSummary + '"]]');
  });

  // 处理过程（Process）—— 基于页面操作推导
  const processes = [];
  pages.slice(0, 8).forEach((pg, pIdx) => {
    const richPg = pagesRich[pIdx] || {};
    const ops = richPg.operations || [];
    if (ops.length > 0) {
      ops.slice(0, 2).forEach((op, opIdx) => {
        const procId = 'P' + (processes.length + 1);
        const opName = op.name || op.type || '操作';
        const entName = pg.entity ? (entityMap.get(pg.entity) || pg.entity) : '';
        const procLabel = entName ? opName + '<br/>(' + entName + ')' : opName;
        processes.push({ id: procId, label: procLabel, entity: pg.entity, op: op });
        // v5.11：Process 节点标签加双引号，避免内嵌 (()) 导致 Mermaid 11.16.0 解析失败
        L.push('    ' + procId + '("' + procLabel + '")');
      });
    } else {
      // 兜底：基于 page.type 推导 Process
      const procId = 'P' + (processes.length + 1);
      const taskName = pageToTaskName(pg, entityMap);
      processes.push({ id: procId, label: taskName, entity: pg.entity, op: null });
      // v5.11：节点标签加双引号
      L.push('    ' + procId + '("' + taskName + '")');
    }
  });

  // 外部实体（External Entity）—— 角色
  roles.slice(0, 6).forEach((r, i) => {
    // v5.11：节点标签加双引号
    L.push('    Ext' + (i + 1) + '["' + r.name + '"]');
  });

  // 数据流（Data Flow）—— 角色 → Process → DataStore
  processes.forEach((proc, idx) => {
    if (!proc.entity) return;
    const eIdx = entities.findIndex(e => e.id === proc.entity || e.name === proc.entity);
    if (eIdx < 0 || eIdx >= 10) return;
    const dsId = 'DS' + (eIdx + 1);

    // 推导哪些角色对此实体有写权限 → 向 Process 提交数据
    rolesRich.forEach((r, rIdx) => {
      if (rIdx >= 6) return;
      const hasWrite = (r.permissions || []).some(p =>
        p.entity === proc.entity &&
        (p.actions || []).some(a => ['create', 'update', 'write', 'import', 'approve'].includes(a))
      );
      if (hasWrite) {
        const actionLabel = proc.op?.type || '提交';
        L.push('    Ext' + (rIdx + 1) + ' -->|' + actionLabel + ' ' + (entityMap.get(proc.entity) || proc.entity) + '| ' + proc.id);
      }
    });

    // Process → DataStore（写入/读取）
    const opType = proc.op?.type || '';
    if (['create', 'add', 'insert', 'save', 'submit', 'import', 'update', 'edit', 'approve', 'delete'].includes(opType)) {
      L.push('    ' + proc.id + ' -->|写入| ' + dsId);
    } else if (['view', 'read', 'list', 'search', 'query', 'export'].includes(opType)) {
      L.push('    ' + dsId + ' -->|读取| ' + proc.id);
    } else {
      // v5.11：修复 <-.-> 非法箭头为 -.->（Mermaid 11.16.0 标准语法）
      L.push('    ' + proc.id + ' -.->|CRUD| ' + dsId);
    }

    // Process → 角色（反馈结果）
    rolesRich.forEach((r, rIdx) => {
      if (rIdx >= 6) return;
      const hasRead = (r.permissions || []).some(p =>
        p.entity === proc.entity &&
        (p.actions || []).some(a => ['read', 'view', 'list', 'export'].includes(a))
      );
      if (hasRead) {
        L.push('    ' + proc.id + ' -.->|查询结果| Ext' + (rIdx + 1));
      }
    });
  });

  // 兜底：若无任何边，添加示例边
  if (processes.length === 0 && entities.length === 0 && roles.length === 0) {
    L.push('    Ext1[默认角色] -->|请求数据| P1(处理请求)');
    L.push('    P1 -->|存储| DS1[[示例数据]]');
    L.push('    DS1 -->|返回| P1');
    L.push('    P1 -.->|响应| Ext1');
  }

  L.push('```', '', '### 实体数据归属矩阵', '',
    '| 实体 | 所有者角色 | 可读角色 | 可写角色 | 数据流向 | 主键字段 | 关键字段 |',
    '|------|------------|----------|----------|----------|---------|---------|');

  if (entities.length === 0) {
    L.push('| - | - | - | - | - | - | - |');
  } else {
    entities.slice(0, 8).forEach((e, idx) => {
      // 推导归属：第一个对该实体有 create 权限的角色
      let owner = '-';
      let readers = [];
      let writers = [];
      rolesRich.forEach((r, rIdx) => {
        (r.permissions || []).forEach(p => {
          if (p.entity === e.id || p.entity === e.name) {
            if ((p.actions || []).includes('create') && owner === '-') owner = r.name;
            if ((p.actions || []).some(a => ['read', 'view', 'list'].includes(a))) readers.push(r.name);
            if ((p.actions || []).some(a => ['write', 'update', 'edit', 'create', 'approve'].includes(a))) writers.push(r.name);
          }
        });
      });
      // 推导主键字段（id/code/name 结尾的字段）
      const fields = e.fields || [];
      const pkField = fields.find(f => (f.name || '').match(/^(id|code)$/i))?.name || 'id';
      const keyFields = fields.slice(0, 3).map(f => f.name || f).join(', ');
      L.push('| ' + e.name + ' | ' + owner + ' | ' +
        (readers.length ? readers.join('/') : '所有角色') + ' | ' +
        (writers.length ? writers.join('/') : owner === '-' ? '-' : owner) + ' | ' +
        (owner !== '-' ? owner + ' → [' + e.name + '] → ' + (readers[0] || '其他角色') : '内部流转') + ' | ' +
        pkField + ' | ' + keyFields + ' |');
    });
  }

  // v5.20 P2-1：DFD 元素说明图例彻底删除（UAT 二轮 U15 裁决，同 BPMN 处理）
  L.push('',
    '### 数据流层级说明', '',
    '- **Level 0 - Context Diagram**：将整个系统视为单一 Process，展示外部实体与系统的交互边界',
    '- **Level 1 - 数据流分解图**：将系统分解为多个 Process（页面操作），展示 Process 与 Data Store（实体）的数据交互',
    '- **建议进一步分解**：复杂 Process 可继续分解为 Level 2 / Level 3 DFD');
  L.push('');
  return L.join('\n');
}

// 生成 Page Flow（页面流，UI Flow Diagram 风格）
// 数据源：pages（按 route 顺序）+ pagesRich.operations + entities（关联实体）
// v5.9：页面跳转图与路由表的页面引用改用 pageDisplayLabel（中文名+页面代码）
// v5.10：基于 UI Flow 业界标杆重构
//   - Terminator（起始/终止）：使用圆形 (( ))          —— UI Flow Terminator
//   - Screen（页面）：使用矩形 [ ]                     —— UI Flow Screen
//   - Decision（决策点）：使用菱形 { }                  —— UI Flow Decision
//   - Action（动作）：带标签的箭头 -->|动作|             —— UI Flow Action
//   - Modal/Drawer：subgraph 子图                       —— UI Flow Overlay
//   - Back Navigation：虚线箭头 -.->|返回|               —— UI Flow Back
//   - 跳转条件推导：基于 page.operations 的 trigger/condition 字段
function genPageFlow(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const pagesRich = extractPagesRich(model.raw);
  // v5.9：构建 entity.id → entity.displayName 映射
  const entityMap = new Map(entities.map(e => [e.id, e.name]));
  const L = [];
  L.push('## Page Flow（页面流，UI Flow Diagram）', '',
    '> **业界标准**：UI Flow Diagram（用户界面流程图）',
    '> **关注点**：页面间的跳转关系，含路由、跳转条件与决策分支。',
    '> **图例**：`(( ))` 起止节点 / `[ ]` 页面 / `{ }` 决策点 / 实线=跳转 / 虚线=返回', '',
    '### UI Flow 页面跳转图', '',
    '```mermaid', 'flowchart TD');

  if (pages.length === 0) {
    L.push('    Start((用户登录))');
    L.push('    P01[主页<br/>/]');
    L.push('    Start --> P01');
    L.push('    P01 -->|退出| Exit((退出系统))');
  } else {
    // 起始 Terminator
    L.push('    Start((用户登录))');
    // 页面 Screen 节点
    pages.slice(0, 10).forEach(pg => {
      const label = pageDisplayLabel(pg, entityMap) + '<br/>' + pg.route;
      // v5.11：节点标签加双引号，避免含 () / : 等特殊字符导致 Mermaid 解析失败
      L.push('    ' + pg.id + '["' + label + '"]');
    });
    // 起始 → 第一个页面
    L.push('    Start --> ' + pages[0].id);

    // 页面间跳转：基于 page.operations 推导真实跳转关系
    for (let i = 0; i < pages.length && i < 10; i++) {
      const curPg = pages[i];
      const richPg = pagesRich[i] || {};
      const ops = richPg.operations || [];
      // 推导每个页面的跳转去向
      // 优先使用 operations 中的 trigger 推导跳转目标
      const navigationOps = ops.filter(op => {
        const t = String(op.trigger || op.type || '').toLowerCase();
        return ['view', 'detail', 'click', '跳转', '查看', '点击'].some(kw => t.includes(kw));
      });

      if (i < pages.length - 1 && i < 9) {
        // 默认跳转到下一个页面（线性主流程）
        const nextPg = pages[i + 1];
        // 决策点：列表页通常有"查看详情" vs "新建"两个分支
        const isListPage = ['crud_list', 'list', 'tree_list', 'kanban'].includes(curPg.type);
        if (isListPage) {
          // 决策菱形
          const decisionId = curPg.id + '_D';
          // v5.11：网关标签加双引号
          L.push('    ' + curPg.id + ' --> ' + decisionId + '{"用户操作?"}');
          // 分支1：查看详情 → 下一个详情页
          L.push('    ' + decisionId + ' -->|查看详情| ' + nextPg.id);
          // 分支2：新建 → 表单页（如果存在）
          const formPage = pages.find(p => p.entity === curPg.entity &&
            ['form_page', 'form', 'step_form'].includes(p.type));
          if (formPage && formPage.id !== nextPg.id) {
            L.push('    ' + decisionId + ' -->|新建| ' + formPage.id);
          } else {
            // 兜底：返回当前页（无表单页）
            L.push('    ' + decisionId + ' -->|新建| ' + curPg.id);
          }
        } else {
          // 非列表页：直接跳转到下一个页面
          const triggerLabel = navigationOps[0]?.trigger || '下一步';
          const shortLabel = String(triggerLabel).replace(/^(点击|按下)/, '').slice(0, 12) || '下一步';
          L.push('    ' + curPg.id + ' -->|' + shortLabel + '| ' + nextPg.id);
        }
      }
    }

    // 返回跳转（虚线）—— UI Flow Back Navigation
    if (pages.length > 1) {
      // 最后一个页面返回第一个页面（主页）
      L.push('    ' + pages[Math.min(pages.length, 10) - 1].id + ' -.->|返回主页| ' + pages[0].id);
      // 详情页返回列表页
      for (let i = 1; i < Math.min(pages.length, 10); i++) {
        if (['detail_view', 'detail'].includes(pages[i].type)) {
          // 查找前一个列表页
          for (let j = i - 1; j >= 0; j--) {
            if (['crud_list', 'list', 'tree_list', 'kanban'].includes(pages[j].type)) {
              L.push('    ' + pages[i].id + ' -.->|返回列表| ' + pages[j].id);
              break;
            }
          }
        }
      }
    }

    // 终止 Terminator
    L.push('    ' + pages[0].id + ' -->|退出登录| Exit((退出系统))');
  }

  L.push('```', '', '### 路由表与跳转条件', '',
    '| 源页面 | 目标页面 | 触发条件 | 传参 | 权限要求 | 跳转类型 |',
    '|--------|----------|----------|------|----------|---------|');

  if (pages.length === 0) {
    L.push('| - | - | - | - | - | - |');
  } else {
    // v5.9：页面引用改用 pageDisplayLabel
    L.push('| 登录页 | ' + pageDisplayLabel(pages[0], entityMap) + ' | 用户登录成功 | userId | 已认证 | 路由跳转 |');
    // 相邻页面跳转
    for (let i = 0; i < pages.length - 1 && i < 8; i++) {
      const curPg = pages[i];
      const nextPg = pages[i + 1];
      const richPg = pagesRich[i] || {};
      const ops = richPg.operations || [];
      // 从 operations 推导真实触发条件
      const triggerOp = ops.find(op => op.trigger) || ops[0];
      const trigger = triggerOp?.trigger || '点击下一步/查看详情';
      const shortTrigger = String(trigger).slice(0, 20);
      // 推导传参
      const param = curPg.entity || 'id';
      // 推导跳转类型
      const isModal = String(trigger).includes('弹窗') || String(trigger).includes('抽屉');
      const jumpType = isModal ? '模态/抽屉' : '路由跳转';
      L.push('| ' + pageDisplayLabel(curPg, entityMap) + ' | ' + pageDisplayLabel(nextPg, entityMap) +
        ' | ' + shortTrigger + ' | ' + param + ' | 已认证 | ' + jumpType + ' |');
    }
    // 返回
    if (pages.length > 1) {
      L.push('| ' + pageDisplayLabel(pages[pages.length - 1], entityMap) + ' | ' + pageDisplayLabel(pages[0], entityMap) +
        ' | 点击返回/面包屑 | - | 已认证 | 返回 |');
    }
  }

  // v5.20 P2-1：UI Flow 元素说明图例彻底删除（UAT 二轮 U15 裁决，同 BPMN/DFD 处理）
  L.push('',
    '### 跳转模式说明', '',
    '- **列表 → 详情**：用户在列表页点击行项目，跳转到详情页查看完整信息',
    '- **列表 → 表单**：用户在列表页点击"新建"按钮，跳转到表单页录入数据',
    '- **详情 → 列表**：用户在详情页点击"返回"，回到列表页',
    '- **任意页 → 主页**：用户点击面包屑或 Logo，返回主页',
    '- **退出登录**：用户点击退出按钮，终止会话');
  L.push('');
  return L.join('\n');
}

// ==========================================
// v5.7 重构：genBusinessFlow 调用三大 Flow 生成器 + 保留主流程/分支/异常/状态
// 修复点：
//   1. 新增 Task Flow / Data Flow / Page Flow 三章节（在主流程之前）
//   2. 修复 Mermaid 节点 ID 复用 Bug（原 A/B/C 复用导致渲染失败，改用 N1/N2/N3 + D1/D2/D3）
//   3. 主流程重命名为"业务流程"避免与 Page Flow 概念混淆
//   4. 加载 transitions 到 model（原 model.transitions 始终为空）
// v5.9 修复：
//   5. entityMap 改用 entity.id 作为 key（原 entityMap.get(pg.entity) 失败导致 "浏览order"）
//   6. 分支流程 mermaid 节点标签改用状态中文标签（如 "待付款" 替代 "pending"）
//   7. 分支流程 mermaid 边修复空 trigger 导致的 "-->||" 语法错误（改用 "-->|动作|" 或 "-->"）
//   8. 分支流程与状态流转表的 from/to/trigger 改用中文标签 + action 作为触发动作
//   9. 主流程步骤的"关联实体"改用实体 displayName（替代代码 order）
// ==========================================
function genBusinessFlow(model) {
  // v5.7 修复：原 model.transitions 始终为空（loadModelRich 未提取），此处即时提取
  const transitions = extractTransitions(model.raw);
  const pages = model.pages || [];
  const entities = model.entities || [];
  // v5.9 修复：entityMap 改用 entity.id 作为 key，使 pageToTaskName/pageDisplayLabel 能正确解析 pg.entity
  const entityMap = new Map(entities.map(e => [e.id, e.name]));
  // v5.9 新增：构建状态值→中文标签映射，供分支流程与状态流转使用
  const entityStateMap = buildEntityStateMap(model.raw);
  const L = [];
  L.push('# 04 - 业务流程', '',
    '> 本文档描述系统的任务流（Task Flow）、数据流（Data Flow）、页面流（Page Flow）、主流程、分支流程、异常流程及状态流转规则。', '',
    '> 模板版本：v5.7  |  章节契约：与 04-business-flow.md 模板严格对齐', '',
    '---', '');

  // v5.7 新增：三大 Flow 章节
  L.push(genTaskFlow(model), '', '---', '',
    genDataFlow(model), '', '---', '',
    genPageFlow(model), '', '---', '');

  // v5.19 P2-6：主流程改造——删除 ASCII 流程图双写（```ascii 块整体移除），
  // Mermaid 图改为按角色泳道；数据映射方式：复用 buildPageRoleMap（与 Task Flow 的
  // Pool 归组一致：步骤按所属页面归组到页面主角色），跨泳道连线保留原有流转顺序与决策点
  const pageRoleMap = buildPageRoleMap(model).pageRoleMap;
  const rolesBF = model.roles || [];
  L.push('## 主流程（业务流程）', '',
    '> 系统的核心业务流程，端到端的操作序列（按角色泳道划分）。', '',
    '### 业务流程图（按角色泳道）', '',
    '```mermaid', 'flowchart TD');
  // 与原实现一致：最多呈现 8 个页面步骤（N2..N9）
  const MAX_STEPS = 8;
  // 全局起止节点（泳道外；v5.11 精神：标签加双引号）
  L.push('    N1["用户登录"]');
  L.push('    END["完成"]');
  // 泳道：每个有步骤的角色一个 subgraph；节点在泳道内定义，边统一在泳道外连接（跨 subgraph 边合法）
  if (rolesBF.length > 0) {
    rolesBF.forEach((role, rIdx) => {
      const idxs = [];
      pages.forEach((pg, pIdx) => { if (pIdx < MAX_STEPS && pageRoleMap.get(pIdx) === rIdx) idxs.push(pIdx); });
      if (idxs.length === 0) return;
      L.push('    subgraph R' + (rIdx + 1) + '["' + (role.displayName || role.name) + '"]');
      idxs.forEach(pIdx => {
        L.push('        N' + (pIdx + 2) + '("' + pageToTaskName(pages[pIdx], entityMap) + '")');
      });
      L.push('    end');
    });
  } else {
    // 兜底：无角色时不生成泳道，节点平铺
    pages.slice(0, MAX_STEPS).forEach((pg, i) => L.push('    N' + (i + 2) + '("' + pageToTaskName(pg, entityMap) + '")'));
  }
  // v5.7 修复：使用 N1/N2/N3 作为页面节点 ID，D1/D2/D3 作为决策节点 ID
  // v5.8：节点 label 改用 pageToTaskName（业务任务名）替代 pg.name（技术 ID）
  if (pages.length > 0) {
    L.push('    N1 --> N2');
    for (let i = 1; i < pages.length && i < MAX_STEPS; i++) {
      const prevNode = 'N' + (i + 1);
      const currNode = 'N' + (i + 2);
      const decision = 'D' + i;
      const taskName = pageToTaskName(pages[i], entityMap);
      L.push('    ' + prevNode + ' --> ' + decision + '{"需要' + taskName + '?"}');
      L.push('    ' + decision + ' -->|是| ' + currNode);
      L.push('    ' + decision + ' -->|否| END');
    }
    if (pages.length > 1) {
      L.push('    N' + Math.min(pages.length + 1, 9) + ' --> END');
    }
  } else {
    L.push('    N2["核心业务操作"]');
    L.push('    N1 --> N2');
    L.push('    N2 --> END');
  }
  L.push('```', '', '### 主流程步骤说明', '');
  pages.forEach((pg, idx) => {
    // v5.8：步骤标题使用业务任务名，技术细节作为 bullet（dev/test 可见）
    // v5.9：关联实体改用 displayName（替代代码 order）
    const entDisplayName = pg.entity ? (entityMap.get(pg.entity) || pg.entity) : '无';
    L.push('**步骤 ' + (idx + 1) + '：' + pageToTaskName(pg, entityMap) + '**',
      '- 页面 ID：' + pg.id,
      '- 页面类型：' + pageTypeLabel(pg.type),
      '- 关联实体：' + entDisplayName,
      '- 路由：' + pg.route,
      pg.description ? '- 说明：' + pg.description : '', '');
  });

  // 分支流程（v5.9：状态值→中文标签 + 修复 mermaid 空标签语法）
  L.push('---', '', '## 分支流程', '');
  const ewt = {};
  transitions.forEach(t => { if (!ewt[t.entity]) ewt[t.entity] = []; ewt[t.entity].push(t); });
  let bIdx = 0;
  for (const [entity, trans] of Object.entries(ewt)) {
    bIdx++;
    // v5.19 P0-1：空壳状态图防御——状态列表为空或转移 from/to 全空时跳过 mermaid 块，
    // 改为输出一行说明文本（绝不输出 S0[] / S0 --> S0 等非法空标签图形）
    const validTrans = trans.filter(t => t.from && t.to);
    const ss = new Set(); validTrans.forEach(t => { ss.add(t.from); ss.add(t.to); });
    const states = Array.from(ss);
    if (states.length === 0 || validTrans.length === 0) {
      L.push('### 分支' + ['一', '二', '三', '四', '五'][bIdx - 1] + '：' + entity + '状态流转', '',
        '（本流程无状态流转数据）', '');
      continue;
    }
    L.push('### 分支' + ['一', '二', '三', '四', '五'][bIdx - 1] + '：' + entity + '状态流转', '',
      '```mermaid', 'graph TD');
    // v5.9：节点标签改用状态中文标签（如 "待付款" 替代 "pending"）
    // v5.19 P0-1：节点标签加双引号（防状态名含特殊字符破坏 mermaid 解析）
    states.forEach((s, i) => L.push('    S' + i + '["' + stateLabelOf(entity, s, entityStateMap) + '"]'));
    // v5.9：修复空 trigger 导致的 "-->||" 语法错误
    // - 若 trigger 非空：使用 -->|trigger|
    // - 若 trigger 为空：使用 --> （无标签）
    // v5.19 P0-1：仅渲染有效转移（from/to 均非空）
    validTrans.forEach(t => {
      const fromIdx = states.indexOf(t.from);
      const toIdx = states.indexOf(t.to);
      if (t.trigger) {
        L.push('    S' + fromIdx + ' -->|' + t.trigger + '| S' + toIdx);
      } else {
        L.push('    S' + fromIdx + ' --> S' + toIdx);
      }
    });
    L.push('```', '');
    // v5.9：bullet 列表改用中文状态标签 + action 作为触发动作（替代空 trigger/condition）
    // v5.19 P0-1：仅列出有效转移，跳过 from/to 为空的垃圾行（如 "- ** -> **"）
    validTrans.forEach(t => {
      const fromLabel = stateLabelOf(entity, t.from, entityStateMap);
      const toLabel = stateLabelOf(entity, t.to, entityStateMap);
      const triggerLabel = t.trigger || t.action || '-';
      const conditionLabel = t.condition || '-';
      L.push('- **' + fromLabel + ' -> ' + toLabel + '**：触发=' + triggerLabel + '，条件=' + conditionLabel);
    });
    L.push('');
  }
  if (bIdx === 0) {
    L.push('### 分支一：数据查询分支', '',
      '```mermaid', 'graph TD',
      '    N1[列表页] --> D1{是否找到数据?}',
      '    D1 -->|是| N2[展示详情]',
      '    D1 -->|否| N3[显示空状态]',
      '```', '');
  }

  // 异常流程（保留原有逻辑）
  L.push('---', '', '## 异常流程', '',
    '| 异常场景 | 触发条件 | 处理方式 | 提示信息 |',
    '|----------|----------|----------|----------|');
  [
    ['数据加载失败', '网络异常或接口超时', '显示错误状态页，提供重试按钮', '数据加载失败，请重试'],
    ['权限不足', '用户访问无权限页面或操作', '路由守卫拦截，跳转 403 页面', '您无权访问该页面'],
    ['数据校验失败', '表单提交字段不合规', '表单内联显示校验错误', '请检查输入内容'],
    ['数据不存在', '访问已删除/不存在的记录', '显示 404 空状态页', '该记录不存在或已删除'],
    ['并发冲突', '多人同时编辑同一记录', '提交时检测版本冲突，提示刷新', '数据已被他人修改，请刷新后重试'],
  ].forEach(e => L.push('| ' + e[0] + ' | ' + e[1] + ' | ' + e[2] + ' | ' + e[3] + ' |'));

  // 状态流转（v5.9：from/to 改用中文标签 + action 作为触发动作）
  L.push('', '---', '', '## 状态流转', '',
    '| 实体 | 当前状态 | 允许转换到 | 触发操作 | 触发条件 |',
    '|------|----------|------------|----------|----------|');
  if (transitions.length > 0) {
    transitions.forEach(t => {
      const fromLabel = stateLabelOf(t.entity, t.from, entityStateMap);
      const toLabel = stateLabelOf(t.entity, t.to, entityStateMap);
      const triggerLabel = t.trigger || t.action || '-';
      const conditionLabel = t.condition || '-';
      L.push('| ' + t.entity + ' | ' + fromLabel + ' | ' + toLabel + ' | ' + triggerLabel + ' | ' + conditionLabel + ' |');
    });
  } else {
    L.push('| - | - | - | - | - |');
  }
  const ews = entities.filter(e => e.states.length > 0);
  if (ews.length > 0) {
    L.push('', '### 各实体状态枚举', '');
    // v5.9：状态枚举改用中文标签（若可用）
    ews.forEach(e => {
      const stateMap = entityStateMap.get(e.name);
      const labels = e.states.map(s => (stateMap && stateMap.get(s)) || s);
      L.push('- **' + e.name + '**：' + labels.join(' / '));
    });
  }
  L.push('', '> 状态字典定义请参见 `status-dictionary.yaml`（由实体状态枚举自动推导）。', genFooterMark());
  return L.join('\n');
}

function genPageList(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const mm = {};
  pages.forEach(pg => { const mod = pg.entity ? entityToModule(pg.entity) : '通用功能'; if (!mm[mod]) mm[mod] = []; mm[mod].push(pg); });
  const modules = Object.keys(mm);
  const L = [];
  L.push('# 05 - 页面清单', '', '> 本文档定义系统的模块划分、页面列表、页面类型说明及功能依赖关系。', '', '---', '', '## 模块划分', '', '| 模块 ID | 名称 | 说明 | 页面数 |', '|---------|------|------|--------|');
  modules.forEach((mod, idx) => L.push('| M' + String(idx + 1).padStart(2, '0') + ' | ' + mod + ' | ' + mod + '相关功能页面 | ' + mm[mod].length + ' |'));
  if (modules.length === 0) { L.push('| M01 | 通用功能 | 核心业务管理 | 0 |'); }
  L.push('', '---', '', '## 页面列表', '', '| 页面 ID | 名称 | 模块 | 类型 | 路由 | 优先级 |', '|---------|------|------|------|------|--------|');
  pages.forEach(pg => { const mod = pg.entity ? entityToModule(pg.entity) : '通用功能'; L.push('| ' + pg.id + ' | ' + pg.name + ' | ' + mod + ' | ' + pageTypeLabel(pg.type) + ' | ' + pg.route + ' | P0 |'); });
  if (pages.length === 0) { L.push('| - | （无页面定义） | - | - | - | - |'); }
  L.push('', '---', '', '## 页面类型说明', '', '| 类型代码 | 类型名称 | 说明 |', '|----------|----------|------|');
  L.push('| crud_list | CRUD 列表页 | 包含搜索区、数据表格、分页器，支持增删改查操作 |');
  L.push('| detail_view | 详情页 | 展示单条记录的完整信息，支持查看与编辑 |');
  L.push('| form_page | 表单页 | 独立的新增/编辑表单页面，适用于复杂录入场景 |');
  L.push('| dashboard | 仪表盘页 | 数据概览与可视化统计页面 |');
  L.push('| tree_list | 树形列表页 | 左侧树形导航 + 右侧数据列表的布局 |');
  L.push('| step_form | 分步表单页 | 多步骤填写流程，适用于复杂业务创建场景 |');
  L.push('| chat | 聊天对话页 | 消息列表 + 输入框 + 会话切换的即时通讯布局 |');
  L.push('| kanban | 看板页 | 多列卡片拖拽布局，适用于工单/任务流转管理 |');
  L.push('', '---', '', '## 功能依赖关系', '', '| 功能 | 依赖 | 说明 |', '|------|------|------|');
  pages.forEach((pg, idx) => { if (idx > 0) L.push('| ' + pg.name + ' | ' + pages[idx - 1].name + ' | ' + pg.name + '通常在' + pages[idx - 1].name + '之后操作 |'); });
  entities.slice(0, 3).forEach(e => { const oe = entities.filter(en => en.id !== e.id).slice(0, 1); if (oe.length > 0) L.push('| ' + e.name + '管理 | ' + oe[0].name + '管理 | ' + e.name + '可能关联' + oe[0].name + '数据 |'); });
  if (pages.length === 0 && entities.length === 0) { L.push('| 核心功能 | 用户认证 | 业务操作依赖登录鉴权 |'); }
  L.push(genFooterMark());
  return L.join('\n');
}

function genFields(model) {
  const entities = model.entities || [];
  const L = [];
  L.push('# 07 - 字段定义', '', '> 本文档定义系统中的全局共享字段及各实体的字段详情。', '', '---', '', '## 全局共享字段', '', '以下字段在所有实体中统一使用，无需重复定义。', '', '| 字段名 | 字段标签 | 类型 | 必填 | 校验规则 | 组件映射 | 说明 |', '|--------|----------|------|------|----------|----------|------|');
  L.push('| id | 主键 | string | 是 | UUID 格式 | - | 系统自动生成，不可编辑 |');
  L.push('| created_at | 创建时间 | datetime | 是 | ISO 8601 | DatePicker | 系统自动生成，不可编辑 |');
  L.push('| updated_at | 更新时间 | datetime | 是 | ISO 8601 | DatePicker | 系统自动更新，不可编辑 |');
  L.push('| created_by | 创建人 | string | 是 | - | Select | 关联当前操作用户，不可编辑 |');
  L.push('| status | 状态 | enum | 是 | 见状态枚举 | Select | 状态值由实体状态枚举定义 |');
  L.push('', '---', '', '## 实体字段详情', '');
  if (entities.length === 0) { L.push('（暂无实体定义，请补充 requirement-model.yaml 中的 entities 部分）', ''); }
  entities.forEach(e => {
    L.push('### 实体：' + e.name + '（' + e.id + '）', '');
    if (e.fields.length > 0) {
      L.push('| 字段名 | 字段标签 | 类型 | 必填 | 校验规则 | 组件映射 | 说明 |', '|--------|----------|------|------|----------|----------|------|');
      e.fields.forEach(f => {
        const fname = f.name || f.id || '';
        const ftype = f.type || 'string';
        const fReq = f.required === 'true' || f.required === true ? '是' : '否';
        const fDisp = f.displayName || fname;
        let val = '-'; let comp = 'Input';
        if (ftype === 'enum') { comp = 'Select'; val = '枚举值校验'; }
        else if (ftype === 'date') { comp = 'DatePicker'; val = '日期格式 YYYY-MM-DD'; }
        else if (ftype === 'number') { comp = 'InputNumber'; val = '数值范围校验'; }
        else if (ftype === 'text') { comp = 'TextArea'; val = '最大长度 500'; }
        else if (fname === 'email') { val = '邮箱格式校验'; }
        else if (fname === 'phone') { val = '手机号格式校验'; }
        else if (fReq === '是') { val = '必填校验'; }
        L.push('| ' + fname + ' | ' + fDisp + ' | ' + ftype + ' | ' + fReq + ' | ' + val + ' | ' + comp + ' | ' + fDisp + '字段 |');
      });
    } else { L.push('（该实体暂无字段定义）'); }
    if (e.states.length > 0) { L.push('', '**状态枚举**：' + e.states.join(' / '), ''); }
    L.push('');
  });
  L.push('---', '', '> 完整的字段定义请参见 `field-definitions.yaml`（由实体字段自动推导）。', genFooterMark());
  return L.join('\n');
}

function genPermissions(model) {
  const roles = model.roles || [];
  const entities = model.entities || [];
  const pages = model.pages || [];
  const rolesRich = model.rolesRich || [];
  const L = [];
  L.push('# 08 - 权限设计', '', '> 本文档定义 RBAC 角色权限体系，包括功能权限、数据权限、页面可见性及页面操作权限。', '', '---', '', '## 角色列表', '', '| 角色 ID | 角色名称 | 描述 |', '|---------|----------|------|');
  roles.forEach((r, idx) => L.push('| ' + roleId(r, idx) + ' | ' + r.name + ' | ' + (r.description || '负责' + r.name + '相关业务') + ' |'));
  if (roles.length === 0) { L.push('| R01 | 系统用户 | 日常业务管理 |'); }
  L.push('', '---', '', '## 功能权限矩阵', '', '> 权限标识：R = 可读 (Read)，W = 可写 (Write)，N = 无权限 (None)', '', '| 功能模块 | ' + roles.map(r => r.name).join(' | ') + ' |', '|----------|' + roles.map(() => '------').join('|') + '|');
  entities.forEach(e => {
    const cells = roles.map(r => {
      const perms = r.permissions.filter(p => p.toLowerCase().includes(e.id.toLowerCase()) || p.toLowerCase().includes(e.name.toLowerCase()));
      if (perms.length === 0) return 'N';
      const hw = perms.some(p => p.includes('create') || p.includes('update') || p.includes('delete'));
      const hr = perms.some(p => p.includes('read') || p.includes('list') || p.includes('view'));
      if (hw && hr) return 'R/W'; if (hw) return 'W'; if (hr) return 'R'; return 'R';
    });
    L.push('| ' + e.name + '管理 | ' + cells.join(' | ') + ' |');
  });
  if (entities.length === 0) { L.push('| 核心功能 | ' + roles.map(() => 'R').join(' | ') + ' |'); }
  L.push('', '---', '', '## 数据权限矩阵', '', '| 角色 | 数据范围 | 说明 |', '|------|----------|------|');
  roles.forEach((r, idx) => {
    let scope = '全部数据 (all)'; let desc = '可查看/管理所有数据';
    const rr = rolesRich[idx];
    if (rr && rr.permissions) {
      const scopes = rr.permissions.map(p => p.scope).filter(s => s);
      if (scopes.includes('own')) { scope = '仅本人 (own)'; desc = '仅可查看/管理本人相关数据'; }
      else if (scopes.includes('department')) { scope = '本部门 (department)'; desc = '仅可查看/管理本部门数据'; }
      else if (scopes.includes('all')) { scope = '全部 (all)'; desc = '可查看/管理全部数据'; }
    }
    L.push('| ' + roleId(r, idx) + ' - ' + r.name + ' | ' + scope + ' | ' + desc + ' |');
  });
  L.push('', '---', '', '## 页面可见性矩阵', '', '| 页面 | ' + roles.map(r => r.name).join(' | ') + ' |', '|------|' + roles.map(() => '------').join('|') + '|');
  pages.forEach(pg => {
    const cells = roles.map((r, idx) => {
      const rr = rolesRich[idx];
      if (rr && rr.pageVisibility && rr.pageVisibility.length > 0) return rr.pageVisibility.includes(pg.id) ? 'Y' : '-';
      const hp = r.permissions.some(p => pg.entity && p.toLowerCase().includes(pg.entity.toLowerCase()));
      return hp ? 'Y' : '-';
    });
    L.push('| ' + pg.id + ' ' + pg.name + ' | ' + cells.join(' | ') + ' |');
  });
  if (pages.length === 0) { L.push('| 核心页面 | ' + roles.map(() => 'Y').join(' | ') + ' |'); }
  L.push('', '---', '', '## 页面操作权限详情', '', '| 页面 | 操作 | ' + roles.map(r => r.name).join(' | ') + ' |', '|------|------|' + roles.map(() => '------').join('|') + '|');
  const ops = [{ name: '新增', actions: ['create'] }, { name: '编辑', actions: ['update'] }, { name: '删除', actions: ['delete'] }, { name: '导出', actions: ['export'] }, { name: '审批', actions: ['update'] }];
  pages.slice(0, 5).forEach(pg => {
    if (!pg.entity) return;
    const ent = entities.find(e => e.id === pg.entity || e.name === pg.entity);
    if (!ent) return;
    ops.forEach(op => {
      const cells = roles.map(r => { const perms = r.permissions.filter(p => p.toLowerCase().includes(ent.id.toLowerCase()) || p.toLowerCase().includes(ent.name.toLowerCase())); const hp = perms.some(p => op.actions.some(a => p.includes(a))); return hp ? 'Y' : '-'; });
      if (op.name === '审批' && ent.states.length === 0) return;
      L.push('| ' + pg.name + ' | ' + op.name + ' | ' + cells.join(' | ') + ' |');
    });
  });
  L.push('', '---', '', '> 权限基线配置请参见 `permission-baseline.yaml`（由角色权限自动推导）。', genFooterMark());
  return L.join('\n');
}

function genUserStories(model) {
  const roles = model.roles || [];
  const pages = model.pages || [];
  const entities = model.entities || [];
  const L = [];
  L.push('# 09 - 用户故事', '', '> 本文档以用户故事格式描述功能需求及故事地图。', '', '---', '', '## 说明', '', '- 用户故事遵循格式：**作为 [角色]，我希望 [目标]，以便 [价值]**', '- 每个故事包含验收标准 (Acceptance Criteria, AC)', '- 优先级定义：P0 = 必须有 (Must Have)，P1 = 应该有 (Should Have)，P2 = 可以有 (Could Have)', '', '---', '', '## 用户故事列表', '');
  let sIdx = 0; const stories = [];
  roles.forEach(r => {
    pages.forEach(pg => {
      const hp = r.permissions.some(p => pg.entity && p.toLowerCase().includes(pg.entity.toLowerCase()));
      if (hp || stories.length === 0) {
        sIdx++;
        const ent = entities.find(e => e.id === pg.entity || e.name === pg.entity);
        const story = { id: 'US-' + String(sIdx).padStart(2, '0'), role: r.name, page: pg, entity: ent, priority: pg.id === 'P01' || pg.id === 'P02' ? 'P0' : (pg.id === 'P03' || pg.id === 'P04' ? 'P1' : 'P2') };
        stories.push(story);
        const goal = pg.type === 'crud_list' ? '查看和管理' + (ent ? ent.name : pg.name) + '列表' : pg.type === 'detail_view' ? '查看' + (ent ? ent.name : pg.name) + '详情' : pg.type === 'dashboard' ? '查看' + (ent ? ent.name : pg.name) + '概览' : '在' + pg.name + '页面进行操作';
        const val = '提高' + (ent ? ent.name : '业务') + '管理效率，减少手工操作';
        L.push('### ' + story.id + '：' + r.name + ' - ' + pg.name, '', '| 字段 | 内容 |', '|------|------|', '| 角色 | ' + r.name + ' |', '| 目标 | ' + goal + ' |', '| 价值 | ' + val + ' |', '| 优先级 | ' + story.priority + ' |', '| 关联页面 | ' + pg.id + ' ' + pg.name + ' |', '', '**验收标准：**', '', '| AC 编号 | 条件 | 预期结果 |', '|---------|------|----------|');
        const acs = [];
        acs.push('登录' + r.name + '账号访问' + pg.route);
        acs.push('页面正确加载' + (ent ? ent.name : '') + '数据');
        if (pg.type === 'crud_list') { acs.push('支持搜索/筛选' + (ent ? ent.name : '记录')); acs.push('列表分页正常（默认每页 20 条）'); }
        if (pg.type === 'detail_view') { acs.push('完整展示' + (ent ? ent.name : '记录') + '所有字段'); }
        if (pg.type === 'dashboard') { acs.push('数据概览统计准确'); }
        const hw = r.permissions.some(p => pg.entity && p.toLowerCase().includes(pg.entity.toLowerCase()) && (p.includes('create') || p.includes('update') || p.includes('delete')));
        if (hw) { acs.push('可执行新增/编辑/删除操作且有二次确认'); }
        acs.forEach((ac, ai) => L.push('| AC-' + String(sIdx).padStart(2, '0') + '-' + (ai + 1) + ' | ' + ac + ' | 操作成功，数据正确更新/展示 |'));
        L.push('', '---', '');
      }
    });
  });
  if (stories.length === 0) {
    L.push('### US-01：系统用户 - 核心功能', '', '| 字段 | 内容 |', '|------|------|', '| 角色 | 系统用户 |', '| 目标 | 完成核心业务操作 |', '| 价值 | 提高工作效率 |', '| 优先级 | P0 |', '| 关联页面 | 核心页面 |', '', '**验收标准：**', '', '| AC 编号 | 条件 | 预期结果 |', '|---------|------|----------|', '| AC-01-1 | 登录系统 | 进入主页面 |', '| AC-01-2 | 执行业务操作 | 操作成功 |', '', '---', '');
  }
  L.push('## 故事地图', '', '| 用户活动 | 用户任务 | P0 故事 | P1 故事 | P2 故事 |', '|----------|----------|---------|---------|---------|');
  const ms = {};
  stories.forEach(s => { const mod = s.entity ? entityToModule(s.entity.id) : '通用功能'; if (!ms[mod]) ms[mod] = []; ms[mod].push(s); });
  Object.entries(ms).forEach(([mod, mss]) => {
    const p0 = mss.filter(s => s.priority === 'P0').map(s => s.id).join(', ') || '-';
    const p1 = mss.filter(s => s.priority === 'P1').map(s => s.id).join(', ') || '-';
    const p2 = mss.filter(s => s.priority === 'P2').map(s => s.id).join(', ') || '-';
    L.push('| ' + mod + ' | ' + mss.map(s => s.page.name).join(', ') + ' | ' + p0 + ' | ' + p1 + ' | ' + p2 + ' |');
  });
  if (Object.keys(ms).length === 0) { L.push('| 核心业务 | 日常操作 | US-01 | - | - |'); }
  L.push(genFooterMark());
  return L.join('\n');
}

function genSuccessMetrics(model) {
  const entities = model.entities || [];
  const ctx = getDomainContext(model);
  const L = [];
  L.push('# 10 - 成功指标', '', '> 本文档定义产品成功指标、测量计划、A/B 测试设计及成功标准门槛。', '', '---', '', '## 指标定义表', '', '| 指标名称 | 类型 | 当前基准 | 目标值 | 测量方法 | 数据源 | 负责人 |', '|----------|------|----------|--------|----------|--------|--------|');
  entities.slice(0, 5).forEach(e => { const m = entityMetric(e); L.push('| ' + m.name + ' | 质量指标 | ' + m.current + ' | ' + m.target + ' | ' + m.method + ' | ' + m.source + ' | 产品经理 |'); });
  L.push('| 系统使用率 | 采纳指标 | 0% | 80% | 月活用户/目标用户数 | 系统日志 | 产品经理 |');
  L.push('| 用户满意度 | 满意度指标 | - | >=4.0/5 | 季度满意度问卷 | 问卷系统 | 产品经理 |');
  L.push('| 操作效率提升 | 效率指标 | 基准值 | 提升 50% | 单次操作耗时对比 | 时间戳日志 | 产品经理 |');
  if (entities.length === 0) { L.push('| 核心业务数字化率 | 采纳指标 | 30% | 90% | 业务上线统计 | 系统日志 | 产品经理 |'); }
  L.push('', '---', '', '## 测量计划', '', '| 指标名称 | 测量频率 | 测量工具 | 数据采集方式 | 报告周期 | 负责人 |', '|----------|----------|----------|--------------|----------|--------|');
  entities.slice(0, 3).forEach(e => { const m = entityMetric(e); L.push('| ' + m.name + ' | 每周 | 数据库统计脚本 | 自动采集 | 月报 | 产品经理 |'); });
  L.push('| 系统使用率 | 每日 | 系统日志分析 | 自动采集 | 周报 | 产品经理 |');
  L.push('| 用户满意度 | 每季度 | 问卷系统 | 人工发放 | 季报 | 产品经理 |');
  L.push('', '---', '', '## A/B 测试设计', '', '| 测试名称 | 测试假设 | 对照组 (A) | 实验组 (B) | 关键指标 | 样本量要求 | 测试周期 |', '|----------|----------|------------|------------|----------|------------|----------|');
  L.push('| 列表页分页 vs 无限滚动 | 无限滚动可提升浏览效率 | 传统分页器 | 无限滚动 | 单次浏览记录数 | 200 用户 | 2 周 |');
  L.push('| 搜索区展开 vs 折叠 | 折叠搜索区提升首屏数据密度 | 默认展开搜索区 | 默认折叠搜索区 | 首屏加载时间 | 200 用户 | 2 周 |');
  if (entities.length > 0) { L.push('| ' + entities[0].name + '列表默认排序 | 按时间降序更符合使用习惯 | 默认按创建时间升序 | 默认按创建时间降序 | 查找目标记录耗时 | 100 用户 | 1 周 |'); }
  L.push('', '---', '', '## 成功标准门槛', '', '| 指标 | 最低门槛 | 理想目标 | 评估时间窗 |', '|------|----------|----------|------------|');
  entities.slice(0, 3).forEach(e => { const m = entityMetric(e); L.push('| ' + m.name + ' | ' + m.current + ' | ' + m.target + ' | 上线后 3 个月 |'); });
  L.push('| 系统使用率 | 50% | 80% | 上线后 3 个月 |');
  L.push('| 用户满意度 | 3.5/5 | 4.5/5 | 上线后 6 个月 |');
  L.push('| 系统可用性 | 99% | 99.9% | 持续 |');
  L.push(genFooterMark());
  return L.join('\n');
}

function genTimeline(model) {
  const entities = model.entities || [];
  const pages = model.pages || [];
  const L = [];
  L.push('# 11 - 时间线', '', '> 本文档定义项目关键里程碑、路线图、发布计划及依赖项。', '', '---', '', '## 关键里程碑', '', '| 阶段 | 名称 | 开始 | 结束 | 负责人 | 交付物 |', '|------|------|------|------|--------|--------|');
  L.push('| 阶段一 | 需求确认与设计 | 2026-07 | 2026-08 | 产品经理 | PRD 文档、原型设计、需求模型锁定 |');
  L.push('| 阶段二 | 核心功能开发 | 2026-08 | 2026-10 | 研发团队 | ' + (entities.length > 0 ? entities.slice(0, 3).map(e => e.name).join('、') : '核心实体') + '管理功能、权限系统 |');
  L.push('| 阶段三 | 测试与上线 | 2026-10 | 2026-12 | QA + 研发 | 测试报告、上线部署、验收交付 |');
  L.push('', '---', '', '## 路线图', '', '```', '2026 Q3                      2026 Q4', '|--7月--|--8月--|--9月--|  |--10月-|--11月-|--12月-|', '                                                   ', '需求设计 ████████░░░░░░░░  ░░░░░░░░░░░░░░░░  ░░░░░░░░░░░░░░░░', '核心开发 ░░░░░░░░████████  ████████░░░░░░░░  ░░░░░░░░░░░░░░░░', '测试上线 ░░░░░░░░░░░░░░░░  ░░░░░░░░████████  ████████░░░░░░░░', '```', '', '---', '', '## 发布计划', '', '| 版本 | 发布日期 | 包含功能 | 目标环境 | 发布方式 | 负责人 |', '|------|----------|----------|----------|----------|--------|');
  L.push('| v0.1 (Alpha) | 2026-09 | ' + (pages.slice(0, 2).map(p => p.name).join('、') || '核心页面') + ' 基础功能 | 测试环境 | 手动部署 | 研发负责人 |');
  L.push('| v0.5 (Beta) | 2026-10 | ' + (pages.slice(0, 4).map(p => p.name).join('、') || '核心功能') + ' + 权限系统 | 预发布环境 | CI/CD | 研发负责人 |');
  L.push('| v1.0 (GA) | 2026-12 | 全部功能 + 验收通过 | 生产环境 | CI/CD | 研发负责人 |');
  L.push('', '---', '', '## 依赖项提醒', '', '| 依赖项 | 依赖方 | 影响范围 | 预计就绪时间 | 风险等级 | 备注 |', '|--------|--------|----------|--------------|----------|------|');
  L.push('| 需求模型锁定 | 设计/开发 | 全部页面 | 2026-08 | 中 | 需 PM 确认后冻结 |');
  L.push('| UI 设计稿 | 前端开发 | 全部页面 | 2026-08 | 中 | 需与需求同步推进 |');
  L.push('| 后端 API 契约 | 前后端联调 | 全部数据交互 | 2026-09 | 高 | 前后端并行开发需提前约定 |');
  L.push('| 测试环境搭建 | QA 测试 | 测试阶段 | 2026-09 | 低 | 需 DevOps 支持 |');
  L.push(genFooterMark());
  return L.join('\n');
}

function genRiskAssumptions(model) {
  const entities = model.entities || [];
  const roles = model.roles || [];
  const ctx = getDomainContext(model);
  const L = [];
  L.push('# 12 - 风险与假设', '', '> 本文档记录项目假设、风险矩阵及待验证项。', '', '---', '', '## 假设清单', '', '| 编号 | 假设内容 | 类型 | 验证状态 | 验证方式 |', '|------|----------|------|----------|----------|');
  L.push('| A01 | 用户具备基本的电脑操作能力，能熟练使用 Web 浏览器 | 用户行为假设 | 未验证 | 用户调研 |');
  L.push('| A02 | ' + ctx.domainLabel + '相关业务规则在项目周期内保持稳定 | 业务假设 | 未验证 | 与业务方确认 |');
  L.push('| A03 | 后端 API 能在 2026-09 前完成契约定义并进入联调 | 技术假设 | 未验证 | 项目进度跟踪 |');
  L.push('| A04 | ' + (entities.length > 0 ? entities.map(e => e.name).slice(0, 3).join('、') : '核心业务') + '数据可从现有系统迁移或人工录入 | 业务假设 | 未验证 | 数据迁移评估 |');
  L.push('| A05 | 目标用户规模在万级以内，单体架构可满足性能需求 | 技术假设 | 未验证 | 性能压测 |');
  L.push('', '---', '', '## 风险矩阵', '', '| 编号 | 描述 | 概率 | 影响 | 等级 | 缓解策略 | 负责人 |', '|------|------|------|------|------|----------|--------|');
  entities.slice(0, 4).forEach((e, idx) => { const risk = entityRisk(e); const level = e.states.length > 0 ? '中风险' : '低风险'; const prob = e.states.length > 0 ? '中' : '低'; L.push('| RISK-' + String(idx + 1).padStart(2, '0') + ' | ' + risk + ' | ' + prob + ' | 高 | ' + level + ' | 增加数据校验与状态机控制 | 产品经理 |'); });
  L.push('| RISK-' + String(entities.length + 1).padStart(2, '0') + ' | 权限设计不完整导致越权访问 | 低 | 高 | 高风险 | 完善权限矩阵评审，上线前安全测试 | 研发负责人 |');
  L.push('| RISK-' + String(entities.length + 2).padStart(2, '0') + ' | 需求变更频繁导致开发延期 | 中 | 中 | 中风险 | 需求模型锁定机制，变更需走流程 | 产品经理 |');
  L.push('| RISK-' + String(entities.length + 3).padStart(2, '0') + ' | 前后端联调效率低 | 中 | 中 | 中风险 | 提前约定 API 契约，Mock 数据先行 | 研发负责人 |');
  L.push('', '> 概率参考：高 / 中 / 低', '> 影响参考：高 / 中 / 低', '> 等级参考：高风险 / 中风险 / 低风险', '', '---', '', '## 待验证项', '', '| 编号 | 待验证内容 | 关联假设 | 验证方法 | 验证负责人 | 计划完成时间 | 验证结果 |', '|------|------------|----------|----------|------------|--------------|----------|');
  L.push('| V01 | ' + ctx.domainLabel + '目标用户是否接受 Web 后台操作方式 | A01 | 用户访谈 | 产品经理 | 2026-08 | 待验证 |');
  L.push('| V02 | ' + (entities.length > 0 ? entities[0].name : '核心业务') + '数据迁移可行性 | A04 | 数据迁移评估 | 研发负责人 | 2026-08 | 待验证 |');
  L.push('| V03 | 系统在万级数据下的性能表现 | A05 | 性能压测 | 研发负责人 | 2026-10 | 待验证 |');
  L.push('| V04 | ' + (roles.length > 0 ? roles.map(r => r.name).join('/') : '各角色') + '权限矩阵是否覆盖所有业务场景 | - | 权限评审 | 产品经理 | 2026-08 | 待验证 |');
  L.push(genFooterMark());
  return L.join('\n');
}

function genOpenQuestions(model) {
  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];
  const L = [];
  L.push('# 13 - 待确认问题', '', '> 本文档追踪项目中所有需要确认的开放问题。所有文档中标注 `[待确认]` 的内容必须在此注册。', '', '---', '', '## 问题列表', '', '| ID | 描述 | 来源文档 | 影响范围 | 状态 | 确认结果 |', '|----|------|----------|----------|------|----------|');
  let q = 0;
  entities.forEach(e => { if (e.fields.length === 0) { q++; L.push('| Q' + String(q).padStart(2, '0') + ' | ' + e.name + '实体的字段定义尚未明确 | 07-fields.md | ' + e.name + '管理 | 待确认 | - |'); } });
  q++; L.push('| Q' + String(q).padStart(2, '0') + ' | 各实体的数据迁移方案是否需要支持从现有系统导入 | 12-risk-assumptions.md | 数据初始化 | 待确认 | - |');
  q++; L.push('| Q' + String(q).padStart(2, '0') + ' | 是否需要支持多语言/国际化 | 00-overview.md | 全局 | 待确认 | - |');
  q++; L.push('| Q' + String(q).padStart(2, '0') + ' | 是否需要移动端适配或独立的移动端应用 | 01-background.md | 前端架构 | 待确认 | - |');
  if (roles.length > 0) { q++; L.push('| Q' + String(q).padStart(2, '0') + ' | ' + roles.map(r => r.name).join('/') + '的数据权限范围是否需要更细粒度控制 | 08-permissions.md | 权限系统 | 待确认 | - |'); }
  if (pages.length > 0) { q++; L.push('| Q' + String(q).padStart(2, '0') + ' | 页面优先级（P0/P1/P2）是否需要调整 | 05-page-list.md | 开发排期 | 待确认 | - |'); }
  q++; L.push('| Q' + String(q).padStart(2, '0') + ' | 是否需要操作日志/审计日志功能 | 08-permissions.md | 合规与安全 | 待确认 | - |');
  L.push('', '> 状态参考：待确认 / 讨论中 / 已确认 / 已取消', '', '---', '', '## 确认记录', '', '| 问题 ID | 确认日期 | 确认人 | 确认结论 | 后续动作 |', '|---------|----------|--------|----------|----------|', '| - | - | - | （待问题确认后记录） | - |', '', '---', '', '> **规则**：所有 PRD 文档中标注 `[待确认]` 的条目，必须在上方问题列表中注册对应记录，确保每个待确认项都有唯一 ID 可追踪。', genFooterMark());
  return L.join('\n');
}

// ==========================================
// v5.2.2：Spec 文档生成器（从模型数据生成完整技术规格内容）
// ==========================================

function genSpecProjectOverview(model) {
  const p = model.project || {};
  const entities = model.entities || [];
  const roles = model.roles || [];
  const pages = model.pages || [];
  const ctx = getDomainContext(model);
  const L = [];
  L.push('# 00 - 项目总览 (技术规格)', '', '> 本文档为技术规格层面的项目总览，从工程实现视角描述系统架构、技术选型、部署方案等信息。', '', '---', '', '## 1. 文档说明', '', '本文档与 PRD `00-overview.md` 互补：PRD 侧重业务视角，本文档侧重技术实现视角，覆盖架构、技术栈、部署、性能等非功能性需求。', '', '---', '', '## 2. 系统架构', '', '### 2.1 架构概览', '', '本项目采用前后端分离的 B/S 架构，前端单页应用 (SPA) 通过 RESTful API 与后端服务通信，后端按业务模块划分服务边界。', '', '### 2.2 架构图', '', '```mermaid', 'flowchart LR', '    subgraph 客户端', '        UI[Web 浏览器]', '    end', '    subgraph 前端', '        SPA[单页应用<br/>React + Router]', '        HTTP[HTTP 客户端<br/>Axios]', '    end', '    subgraph 后端', '        API[API 网关]', '        BIZ[业务服务层]', '        AUTH[认证授权]', '    end', '    subgraph 数据层', '        DB[("关系型数据库")]',
        '        CACHE[("缓存")]', '    end', '    UI --> SPA', '    SPA --> HTTP', '    HTTP --> API', '    API --> AUTH', '    API --> BIZ', '    BIZ --> DB', '    BIZ --> CACHE', '```', '', '### 2.3 模块划分', '', '基于需求模型中的 ' + entities.length + ' 个业务实体，系统划分为以下模块：', '', '| 模块 | 核心实体 | 职责 |', '|------|---------|------|');
  for (const e of entities) L.push('| ' + entityToModule(e.id) + ' | ' + e.name + ' | ' + e.name + '数据的增删改查、状态流转、权限控制 |');
  if (entities.length === 0) L.push('| 通用模块 | - | 业务管理 |');
  L.push('', '---', '', '## 3. 技术栈', '', '### 3.1 前端技术栈', '', '| 类别 | 选型 | 说明 |', '|------|------|------|', '| 框架 | React 18 | 函数组件 + Hooks 模式 |', '| 路由 | React Router v6 | 声明式路由 + 嵌套路由 |', '| UI 库 | Ant Design 5 | 企业级中后台组件库 |', '| 状态管理 | Zustand / Context | 轻量级状态管理 |', '| HTTP 客户端 | Axios | 请求/响应拦截、统一错误处理 |', '| 构建工具 | Vite | 快速冷启动 + HMR |', '| 语言 | TypeScript | 类型安全 |', '', '### 3.2 后端技术栈', '', '| 类别 | 选型 | 说明 |', '|------|------|------|', '| 语言 | Node.js / Java / Go | 按团队技术栈选择 |', '| API 风格 | RESTful | 资源化 URL + JSON |', '| 认证 | JWT + Refresh Token | 无状态认证 |', '| 权限模型 | RBAC | 基于角色的访问控制 |', '| 数据库 | MySQL / PostgreSQL | 关系型数据库 |', '| 缓存 | Redis | 会话/热点数据缓存 |', '', '---', '', '## 4. 部署架构', '', '### 4.1 环境清单', '', '| 环境 | 用途 | 部署方式 |', '|------|------|---------|', '| 开发环境 (dev) | 开发联调 | 本地 / Docker Compose |', '| 测试环境 (test) | QA 测试 | 容器化部署 |', '| 预发布环境 (staging) | 上线前验证 | 与生产同构 |', '| 生产环境 (prod) | 对外服务 | 容器编排 + 负载均衡 |', '', '### 4.2 部署拓扑', '', '```mermaid', 'flowchart TB', '    LB[负载均衡<br/>Nginx/ALB] --> FE1[前端实例 1]', '    LB --> FE2[前端实例 2]', '    LB --> API1[API 实例 1]', '    LB --> API2[API 实例 2]', '    API1 --> DBM[("数据库主")]', '    API2 --> DBM', '    DBM -.同步.-> DBS[("数据库从")]', '    API1 --> REDIS[("Redis 集群")]', '    API2 --> REDIS', '```', '', '---', '', '## 5. 第三方服务集成', '', '| 服务 | 用途 | 集成方式 |', '|------|------|---------|', '| 短信服务 | 验证码、通知 | API 调用 |', '| 邮件服务 | 系统通知、报表 | SMTP / API |', '| 对象存储 | 文件附件 | SDK 上传 |', '| 日志服务 | 操作审计、错误追踪 | 日志采集 + ELK |', '', '---', '', '## 6. 性能指标与非功能性需求', '', '| 指标 | 目标值 | 说明 |', '|------|--------|------|', '| 首屏加载时间 | ≤ 2s | 桌面端 4G 网络 |', '| API 平均响应 | ≤ 200ms | P95 ≤ 500ms |', '| 并发用户数 | ≥ 500 | 同时在线 |', '| 系统可用性 | ≥ 99.5% | 月度 SLA |', '| 数据备份 | 每日全量 + 实时增量 | RPO ≤ 1h |', '', '---', '', '## 7. 项目规模', '', '| 维度 | 数量 |', '|------|------|', '| 业务实体 | ' + entities.length + ' |', '| 用户角色 | ' + roles.length + ' |', '| 页面数 | ' + pages.length + ' |', '| API 接口数（预估） | ' + (entities.length * 5 + pages.length) + ' |', '', genFooterMark());
  return L.join('\n');
}

function genPageArchitecture(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const L = [];
  L.push('# 01 - 页面架构 (技术规格)', '', '> 本文档定义前端页面的技术架构，包括组件树结构、布局方案、组件清单、通信方式与响应式策略。', '', '---', '', '## 1. 文档说明', '', '本文档基于需求模型中的 ' + pages.length + ' 个页面，推导前端组件架构与布局方案。', '', '---', '', '## 2. 全局布局', '', '### 2.1 布局结构', '', '系统采用经典的中后台布局：顶部导航 + 左侧菜单 + 主内容区。', '', '```mermaid', 'flowchart TB', '    Layout[AppLayout]', '    Layout --> Header[AppHeader<br/>Logo + 用户信息 + 通知]', '    Layout --> Sider[AppSider<br/>主导航菜单]', '    Layout --> Content[AppContent<br/>路由出口]', '    Content --> Breadcrumb[PageBreadcrumb<br/>面包屑]', '    Content --> RouterView[RouterOutlet<br/>页面组件]', '    Content --> Footer[PageFooter<br/>版权信息]', '```', '', '### 2.2 路由出口', '', '主内容区通过 React Router 的 `<Outlet />` 渲染当前路由对应的页面组件。', '', '---', '', '## 3. 页面组件树', '');
  for (const pg of pages) {
    const ent = entities.find(e => e.id === pg.entity || e.name === pg.entity);
    L.push('', '### 3.' + (pages.indexOf(pg) + 1) + ' ' + pg.name + ' (' + pg.id + ')', '', '```mermaid', 'flowchart TB', '    P[' + pg.id + ' ' + pg.name + ']', '    P --> Search[SearchBar 搜索区]', '    P --> Toolbar[Toolbar 操作栏]');
    if (pg.type === 'crud_list' || pg.type === 'tree_list') {
      L.push('    P --> Table[DataTable 数据表格]', '    P --> Pagination[Pagination 分页]');
      if (ent && ent.fields.length > 0) {
        L.push('    P --> Form[' + ent.name + 'Form 新增/编辑表单]', '    P --> Detail[' + ent.name + 'Detail 详情弹窗]');
      }
    } else if (pg.type === 'detail_view') {
      L.push('    P --> Desc[Descriptions 详情展示]');
      if (ent && ent.fields.length > 0) L.push('    P --> Tabs[Tabs 关联信息标签页]');
    } else if (pg.type === 'form_page' || pg.type === 'step_form') {
      L.push('    P --> Form[StepForm 分步表单]');
    } else if (pg.type === 'dashboard') {
      L.push('    P --> Cards[StatisticCards 指标卡片]', '    P --> Charts[Charts 图表区]');
    }
    L.push('```');
  }
  L.push('', '---', '', '## 4. 公共组件清单', '', '| 组件 | 路径 | 用途 |', '|------|------|------|', '| AppLayout | components/layout/AppLayout | 全局布局 |', '| AppHeader | components/layout/AppHeader | 顶部导航 |', '| AppSider | components/layout/AppSider | 侧边菜单 |', '| PageBreadcrumb | components/layout/PageBreadcrumb | 面包屑 |', '| SearchBar | components/common/SearchBar | 通用搜索区 |', '| DataTable | components/common/DataTable | 通用数据表格 |', '| Pagination | components/common/Pagination | 分页器 |', '| FormDialog | components/common/FormDialog | 表单弹窗 |', '| ConfirmDialog | components/common/ConfirmDialog | 确认弹窗 |', '| EmptyState | components/common/EmptyState | 空状态 |', '| ErrorBoundary | components/common/ErrorBoundary | 错误边界 |', '', '---', '', '## 5. 业务组件清单', '', '| 组件 | 所属页面 | 用途 |', '|------|---------|------|');
  for (const pg of pages) L.push('| ' + pg.id + 'Page | ' + pg.route + ' | ' + pg.name + '页面主组件 |');
  L.push('', '---', '', '## 6. 组件间通信方式', '', '| 通信方式 | 场景 | 说明 |', '|----------|------|------|', '| Props | 父子组件 | 单向数据流 |', '| Context | 全局状态 | 用户信息、主题、权限 |', '| State Store | 跨页面共享 | Zustand 全局 store |', '| Event Bus | 兄弟组件 | 低频场景，避免滥用 |', '| URL Params | 路由跳转 | 详情页参数传递 |', '', '---', '', '## 7. 响应式策略', '', '| 断点 | 宽度 | 布局调整 |', '|------|------|---------|', '| lg | ≥ 1200px | 默认布局（侧边栏展开） |', '| md | 992-1199px | 侧边栏可折叠 |', '| sm | 768-991px | 侧边栏抽屉式 |', '| xs | < 768px | 不支持，提示使用桌面端 |', '', '> 主要面向桌面端后台管理场景，移动端不做强制适配。', '', genFooterMark());
  return L.join('\n');
}

function genInteractionFlow(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const transitions = extractTransitions(model.raw);
  const L = [];
  L.push('# 02 - 交互流程 (技术规格)', '', '> 本文档定义系统的主要交互流程，覆盖核心业务场景的前后端协作时序。', '', '---', '', '## 1. 文档说明', '', '本文档基于需求模型推导主要交互流程，使用 Mermaid 时序图描述前后端协作。', '', '---', '', '## 2. 通用列表页交互流程', '', '以 ' + (pages[0] ? pages[0].name : '主列表') + '为例，描述 CRUD 列表页的标准交互：', '', '```mermaid', 'sequenceDiagram', '    actor U as 用户', '    participant V as 前端页面', '    participant API as 后端 API', '    participant DB as 数据库', '    U->>V: 访问列表页', '    V->>API: GET /api/xxx?page=1&size=20', '    API->>DB: SELECT ... LIMIT', '    DB-->>API: 数据集', '    API-->>V: { list, total }', '    V-->>U: 渲染表格 + 分页器', '    U->>V: 输入搜索条件', '    V->>API: GET /api/xxx?keyword=...', '    API->>DB: WHERE ... LIKE', '    DB-->>API: 过滤数据', '    API-->>V: { list, total }', '    V-->>U: 重新渲染表格', '    U->>V: 点击新增', '    V-->>U: 弹出表单弹窗', '    U->>V: 填写表单并提交', '    V->>API: POST /api/xxx', '    API->>DB: INSERT', '    DB-->>API: 新增 ID', '    API-->>V: { success, id }', '    V-->>U: 提示成功 + 刷新列表', '```', '', '---', '', '## 3. 状态流转交互流程', '');
  if (transitions.length > 0) {
    const byEntity = {};
    for (const t of transitions) {
      if (!byEntity[t.entity]) byEntity[t.entity] = [];
      byEntity[t.entity].push(t);
    }
    let idx = 1;
    for (const ent of Object.keys(byEntity)) {
      L.push('', '### 3.' + idx + ' ' + ent + ' 状态流转', '', '```mermaid', 'sequenceDiagram', '    actor U as 用户', '    participant V as 前端', '    participant API as 后端', '    participant DB as 数据库');
      for (const t of byEntity[ent]) {
        L.push('    U->>V: 触发: ' + t.trigger, '    V->>API: POST /api/xxx/{id}/transition', '    API->>DB: UPDATE status ' + t.from + '->' + t.to, '    API-->>V: { success }', '    V-->>U: ' + t.entity + ' ' + t.from + ' -> ' + t.to + '（' + t.condition + '）');
      }
      L.push('```');
      idx++;
    }
  } else {
    L.push('', '> 当前模型未定义实体状态转换，按业务需要补充。', '');
  }
  L.push('---', '', '## 4. 权限校验流程', '', '```mermaid', 'sequenceDiagram', '    actor U as 用户', '    participant V as 前端路由', '    participant G as 全局守卫', '    participant API as 后端 API', '    U->>V: 访问页面 /xxx', '    V->>G: 路由守卫触发', '    G->>G: 检查登录状态', '    alt 未登录', '        G-->>U: 重定向到登录页', '    else 已登录', '        G->>G: 检查角色权限', '        alt 无权限', '            G-->>U: 重定向到 403 页面', '        else 有权限', '            G-->>V: 放行', '            V->>API: 请求业务数据', '            API-->>V: 数据', '            V-->>U: 渲染页面', '        end', '    end', '```', '', '---', '', '## 5. 异常处理流程', '', '```mermaid', 'sequenceDiagram', '    actor U as 用户', '    participant V as 前端', '    participant API as 后端', '    U->>V: 操作', '    V->>API: 请求', '    alt 网络异常', '        API-->>V: 超时/无响应', '        V-->>U: 提示网络异常 + 重试按钮', '    else 业务错误', '        API-->>V: 4xx + 错误信息', '        V-->>U: 表单内联提示 / Toast', '    else 系统错误', '        API-->>V: 5xx', '        V-->>U: 系统繁忙提示 + 上报日志', '    else 成功', '        API-->>V: 2xx', '        V-->>U: 成功反馈 + 刷新数据', '    end', '```', '', genFooterMark());
  return L.join('\n');
}

function genStateMatrix(model) {
  const entities = model.entities || [];
  const transitions = extractTransitions(model.raw);
  const entitiesWithStates = entities.filter(e => e.states.length > 0);
  const L = [];
  L.push('# 03 - 状态矩阵 (技术规格)', '', '> 本文档定义所有实体的状态枚举与状态流转规则，作为状态机实现的依据。', '', '---', '', '## 1. 文档说明', '', '本文档从需求模型提取实体状态枚举与转换规则，用于前后端状态同步与校验。', '', '---', '', '## 2. 状态枚举清单', '', '| 实体 | 状态值 | 显示名称 | 颜色标识 |', '|------|--------|---------|---------|');
  let hasStates = false;
  for (const e of entitiesWithStates) {
    hasStates = true;
    // 尝试解析状态对象
    const section = extractSection(model.raw, 'entities');
    if (section) {
      const items = parseArrayItems(section);
      for (const { raw } of items) {
        const f = parseItemFields(raw);
        if ((f.displayName || f.name) === e.name) {
          const stateObjs = parseSubObjectArray(raw, 'statuses');
          if (stateObjs.length > 0) {
            for (const s of stateObjs) {
              L.push('| ' + e.name + ' | ' + (s.value || '') + ' | ' + (s.label || '') + ' | ' + (s.color || 'default') + ' |');
            }
          } else {
            for (const s of e.states) L.push('| ' + e.name + ' | ' + s + ' | ' + s + ' | default |');
          }
          break;
        }
      }
    }
  }
  if (!hasStates) L.push('| - | （无实体定义状态枚举） | - | - |');
  L.push('', '---', '', '## 3. 状态转换矩阵', '', '| 实体 | 起始状态 | 目标状态 | 触发动作 | 前置条件 |', '|------|---------|---------|---------|---------|');
  if (transitions.length > 0) {
    for (const t of transitions) L.push('| ' + t.entity + ' | ' + t.from + ' | ' + t.to + ' | ' + t.trigger + ' | ' + t.condition + ' |');
  } else {
    L.push('| - | - | - | - | - |');
  }
  L.push('', '---', '', '## 4. 状态机图', '');
  // 按 entity 分组生成状态机图
  const byEntity = {};
  for (const t of transitions) {
    if (!byEntity[t.entity]) byEntity[t.entity] = [];
    byEntity[t.entity].push(t);
  }
  let idx = 1;
  for (const ent of Object.keys(byEntity)) {
    // v5.19 P0-1：空壳状态机防御（与 04 分支流程段同源缺陷）——
    // 转移 from/to 全空时跳过 mermaid 块，否则产出 "[*] --> " 悬挂边等非法 stateDiagram
    const validTransSm = byEntity[ent].filter(t => t.from && t.to);
    if (validTransSm.length === 0) {
      L.push('', '### 4.' + idx + ' ' + ent + ' 状态机', '', '（本流程无状态流转数据）', '');
      idx++;
      continue;
    }
    L.push('', '### 4.' + idx + ' ' + ent + ' 状态机', '', '```mermaid', 'stateDiagram-v2');
    // 收集所有状态
    const states = new Set();
    for (const t of validTransSm) { states.add(t.from); states.add(t.to); }
    for (const s of states) L.push('    [*] --> ' + s);
    for (const t of validTransSm) L.push('    ' + t.from + ' --> ' + t.to + ' : ' + t.trigger);
    L.push('```');
    idx++;
  }
  if (Object.keys(byEntity).length === 0) {
    L.push('', '> 当前模型未定义状态转换，按业务需要补充状态机图。', '');
  }
  L.push('', '---', '', '## 5. 状态校验规则', '', '| 规则 | 说明 |', '|------|------|', '| 后端校验 | 每次状态变更必须校验转换合法性，非法转换返回 422 |', '| 前端展示 | 根据当前状态动态显示可执行的操作按钮 |', '| 日志记录 | 状态变更记录操作日志，含操作人、时间、前后状态 |', '| 并发控制 | 状态变更使用乐观锁（version 字段）防止并发冲突 |', '', genFooterMark());
  return L.join('\n');
}

function genRouteTable(model) {
  const pages = model.pages || [];
  const roles = model.roles || [];
  const L = [];
  L.push('# 04 - 路由表 (技术规格)', '', '> 本文档定义前端路由配置，覆盖路径、组件、权限、布局等。', '', '---', '', '## 1. 文档说明', '', '本文档基于需求模型中的 ' + pages.length + ' 个页面生成路由表，作为前端路由配置的依据。', '', '---', '', '## 2. 路由总表', '', '| 路由路径 | 页面 ID | 页面名称 | 页面类型 | 关联实体 | 允许角色 |', '|---------|---------|---------|---------|---------|---------|');
  for (const pg of pages) {
    // 推导可见角色
    const visibleRoles = roles.filter(r => {
      if (Array.isArray(r.pageVisibility) && r.pageVisibility.length > 0) {
        return r.pageVisibility.some(v => v === pg.id || v === pg.name);
      }
      return true;
    }).map(r => r.name);
    L.push('| ' + pg.route + ' | ' + pg.id + ' | ' + pg.name + ' | ' + pageTypeLabel(pg.type) + ' | ' + (pg.entity || '-') + ' | ' + (visibleRoles.length > 0 ? visibleRoles.join(' / ') : '全部角色') + ' |');
  }
  if (pages.length === 0) L.push('| - | - | （无页面定义） | - | - | - |');
  L.push('', '---', '', '## 3. 路由配置示例', '', '```typescript', '// router/routes.ts', 'import { lazy } from "react";', '');
  for (const pg of pages) {
    const compName = pg.id.charAt(0).toUpperCase() + pg.id.slice(1).replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + 'Page';
    L.push('const ' + compName + ' = lazy(() => import("@/pages/' + pg.id + '"));');
  }
  L.push('', 'export const routes = [');
  for (const pg of pages) {
    const compName = pg.id.charAt(0).toUpperCase() + pg.id.slice(1).replace(/-([a-z])/g, (_, c) => c.toUpperCase()) + 'Page';
    L.push('  {');
    L.push('    path: "' + pg.route + '",');
    L.push('    element: <' + compName + ' />,');
    L.push('    meta: {');
    L.push('      pageId: "' + pg.id + '",');
    L.push('      title: "' + pg.name + '",');
    L.push('      entity: "' + (pg.entity || '') + '",');
    L.push('      type: "' + pg.type + '",');
    L.push('    },');
    L.push('  },');
  }
  L.push('];', '```', '', '---', '', '## 4. 路由守卫', '', '```typescript', '// router/guard.ts', 'export function requireAuth(to: RouteLocation, from: RouteLocation, next: Function) {', '  const user = useUserStore();', '  if (!user.isLoggedIn) {', '    next({ path: "/login", query: { redirect: to.fullPath } });', '    return;', '  }', '  // 检查角色权限', '  const allowedRoles = to.meta?.allowedRoles as string[] | undefined;', '  if (allowedRoles && !allowedRoles.some(r => user.roles.includes(r))) {', '    next({ path: "/403" });', '    return;', '  }', '  next();', '}', '```', '', '---', '', '## 5. 特殊路由', '', '| 路由 | 用途 |', '|------|------|', '| /login | 登录页（无需鉴权） |', '| /403 | 无权限页 |', '| /404 | 未找到页 |', '| / | 默认重定向到第一个有权限的页面 |', '', genFooterMark());
  return L.join('\n');
}

function genApiContractDraft(model) {
  const entities = model.entities || [];
  const pages = model.pages || [];
  const L = [];
  L.push('# 05 - API 接口契约 (技术规格)', '', '> 本文档定义前后端接口契约，包括 RESTful API 的请求/响应格式、参数规范、错误码等。', '', '---', '', '## 1. 文档说明', '', '本文档基于需求模型中的实体推导 RESTful API 契约，作为前后端联调的依据。', '', '---', '', '## 2. 通用规范', '', '### 2.1 请求头', '', '| Header | 说明 |', '|--------|------|', '| Authorization | Bearer {JWT token} |', '| Content-Type | application/json |', '| X-Request-Id | 请求追踪 ID（前端生成 UUID） |', '', '### 2.2 统一响应格式', '', '```json', '{', '  "code": 0,', '  "message": "success",', '  "data": { ... },', '  "requestId": "xxx-xxx-xxx"', '}', '```', '', '### 2.3 分页参数规范', '', '| 参数 | 类型 | 默认值 | 说明 |', '|------|------|--------|------|', '| page | int | 1 | 页码（从 1 开始） |', '| size | int | 20 | 每页条数（最大 100） |', '| sort | string | - | 排序字段，格式：`field,asc` 或 `field,desc` |', '', '### 2.4 分页响应格式', '', '```json', '{', '  "code": 0,', '  "data": {', '    "list": [...],', '    "total": 100,', '    "page": 1,', '    "size": 20', '  }', '}', '```', '', '---', '', '## 3. 接口清单', '');
  let apiIdx = 1;
  for (const e of entities) {
    const moduleName = (e.id || '').toLowerCase() || 'item';
    L.push('', '### 3.' + apiIdx + ' ' + e.name + ' (' + e.id + ')', '');
    // 列表
    L.push('#### ' + e.id + '-01 列表查询', '', '- **Method**: GET', '- **URL**: /api/' + moduleName + 's', '- **Query**: page, size, sort, keyword, ' + (e.fields[0] ? e.fields[0].name : 'name'), '- **Response**: `{ list: ' + e.id + '[], total, page, size }`', '');
    // 详情
    L.push('#### ' + e.id + '-02 详情查询', '', '- **Method**: GET', '- **URL**: /api/' + moduleName + 's/{id}', '- **Response**: ' + e.id + ' 对象', '');
    // 新增
    L.push('#### ' + e.id + '-03 新增', '', '- **Method**: POST', '- **URL**: /api/' + moduleName + 's', '- **Body**: ' + e.id + ' 对象（不含 id）', '- **Response**: `{ id: string }`', '');
    // 编辑
    L.push('#### ' + e.id + '-04 编辑', '', '- **Method**: PUT', '- **URL**: /api/' + moduleName + 's/{id}', '- **Body**: ' + e.id + ' 对象（可变字段）', '- **Response**: `{ success: true }`', '');
    // 删除
    L.push('#### ' + e.id + '-05 删除', '', '- **Method**: DELETE', '- **URL**: /api/' + moduleName + 's/{id}', '- **Response**: `{ success: true }`', '');
    // 状态转换
    if (e.states && e.states.length > 0) {
      L.push('#### ' + e.id + '-06 状态转换', '', '- **Method**: POST', '- **URL**: /api/' + moduleName + 's/{id}/transition', '- **Body**: `{ to: string, reason: string }`', '- **Response**: `{ success: true }`', '');
    }
    apiIdx++;
  }
  L.push('', '---', '', '## 4. 错误码定义', '', '| HTTP 状态码 | 业务码 | 含义 | 处理建议 |', '|------------|--------|------|---------|', '| 200 | 0 | 成功 | - |', '| 400 | 10001 | 参数错误 | 前端表单校验 |', '| 401 | 10002 | 未登录 | 重定向到登录页 |', '| 403 | 10003 | 无权限 | 提示无权限 |', '| 404 | 10004 | 资源不存在 | 提示并返回列表 |', '| 422 | 10005 | 业务校验失败 | 显示具体错误信息 |', '| 429 | 10006 | 请求过于频繁 | 提示稍后重试 |', '| 500 | 20001 | 系统错误 | 提示系统繁忙 + 上报日志 |', '| 502 | 20002 | 网关错误 | 提示服务不可用 |', '| 504 | 20003 | 网关超时 | 提示网络超时 + 重试 |', '', '---', '', '## 5. 鉴权方式', '', '### 5.1 登录', '', '- **POST /api/auth/login**', '- **Body**: `{ username, password }`', '- **Response**: `{ token, refreshToken, user }`', '', '### 5.2 Token 刷新', '', '- **POST /api/auth/refresh**', '- **Body**: `{ refreshToken }`', '- **Response**: `{ token, refreshToken }`', '', '### 5.3 退出', '', '- **POST /api/auth/logout**', '', '---', '', '## 6. Mock 数据方案', '', '| 阶段 | 方案 |', '|------|------|', '| 前端开发 | 本地 Mock（Mock.js / MSW） |', '| 联调 | 后端提供 Swagger 文档 + Mock 服务 |', '| 测试 | 测试环境真实接口 |', '', 'Mock 数据需覆盖：' + entities.map(e => e.name).join('、') + ' 等 ' + entities.length + ' 个实体的列表/详情/新增/编辑/删除场景。', '', genFooterMark());
  return L.join('\n');
}

function genErrorAndEmptyStates(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const L = [];
  L.push('# 06 - 错误与空状态 (技术规格)', '', '> 本文档定义系统各场景下的错误提示、空状态、加载状态的设计规范与实现方案。', '', '---', '', '## 1. 文档说明', '', '本文档基于页面清单与实体定义，统一错误与空状态的设计与实现规范。', '', '---', '', '## 2. 错误状态', '', '### 2.1 错误分类', '', '| 类型 | 触发场景 | 提示方式 | 持续时间 |', '|------|---------|---------|---------|', '| 表单校验错误 | 字段必填、格式、长度校验 | 输入框下方红色文字 | 持续显示 |', '| 业务错误 | 接口返回 4xx | Toast / Notification | 3 秒 |', '| 系统错误 | 接口返回 5xx | 全屏错误页 + 重试按钮 | 持续显示 |', '| 网络错误 | 请求超时、断网 | Toast + 重试按钮 | 持续显示 |', '| 权限错误 | 无权限访问 | 403 页面 | 持续显示 |', '', '### 2.2 错误提示文案规范', '', '| 场景 | 文案 |', '|------|------|', '| 必填字段为空 | {字段名}不能为空 |', '| 字符串超长 | {字段名}不能超过 {n} 个字符 |', '| 数值越界 | {字段名}必须在 {min}-{max} 之间 |', '| 格式错误 | {字段名}格式不正确 |', '| 网络异常 | 网络异常，请检查网络后重试 |', '| 系统繁忙 | 系统繁忙，请稍后重试 |', '| 无权限 | 您无权访问此功能 |', '| 资源不存在 | 资源不存在或已被删除 |', '', '### 2.3 错误页设计', '', '```mermaid', 'flowchart LR', '    Err[错误发生] --> Type{错误类型}', '    Type -->|表单错误| Inline[输入框内联提示]', '    Type -->|业务错误| Toast[Toast 全局提示]', '    Type -->|系统错误| Page[全屏错误页]', '    Type -->|权限错误| Forbid[403 页面]', '    Type -->|未找到| NotFound[404 页面]', '```', '', '---', '', '## 3. 空状态', '', '### 3.1 空状态场景', '', '| 场景 | 触发条件 | 展示内容 |', '|------|---------|---------|', '| 列表为空 | 查询结果为 0 条 | 空状态图 + "暂无数据" + 新增按钮 |', '| 搜索无结果 | 搜索后无匹配 | 空状态图 + "未找到匹配数据" + 重置按钮 |', '| 详情不存在 | 资源被删除 | 空状态图 + "资源不存在" + 返回按钮 |', '| 关联数据为空 | 关联标签页无数据 | 空状态图 + "暂无关联数据" |', '', '### 3.2 各页面空状态', '');
  for (const pg of pages) {
    const ent = entities.find(e => e.id === pg.entity || e.name === pg.entity);
    L.push('', '#### ' + pg.id + ' ' + pg.name, '', '| 场景 | 展示内容 | 操作 |', '|------|---------|------|', '| 首次进入无数据 | 空状态图 + "暂无' + (ent ? ent.name : pg.name) + '数据" | [' + (ent ? '新增' + ent.name : '新增') + '] 按钮 |', '| 搜索无结果 | 空状态图 + "未找到匹配数据" | [重置搜索] 按钮 |', '| 筛选无结果 | 空状态图 + "当前筛选条件下无数据" | [清空筛选] 按钮 |');
  }
  L.push('', '---', '', '## 4. 加载状态', '', '### 4.1 加载状态分类', '', '| 场景 | 加载方式 |', '|------|---------|', '| 页面首次进入 | 全屏 Skeleton 骨架屏 |', '| 表格数据请求 | 表格区域 Loading 遮罩 |', '| 表单提交 | 按钮 Loading + 禁用 |', '| 详情数据请求 | 卡片 Skeleton |', '| 下拉数据请求 | Select 占位符 "加载中..." |', '', '### 4.2 加载时长建议', '', '| 时长 | 处理 |', '|------|------|', '| < 100ms | 不显示 Loading |', '| 100ms - 1s | 显示 Loading 遮罩 |', '| > 1s | 显示 Skeleton + 进度提示 |', '| > 5s | 显示超时提示 + 重试 |', '', '---', '', '## 5. 实现方案', '', '### 5.1 通用错误处理', '', '```typescript', '// utils/request.ts', 'instance.interceptors.response.use(', '  (response) => response.data,', '  (error) => {', '    const { response } = error;', '    if (!response) {', '      message.error("网络异常，请检查网络后重试");', '      return Promise.reject(error);', '    }', '    const { status, data } = response;', '    switch (status) {', '      case 401: redirectToLogin(); break;', '      case 403: message.error("您无权访问此功能"); break;', '      case 404: message.error("资源不存在或已被删除"); break;', '      case 422: message.error(data.message || "业务校验失败"); break;', '      case 500: message.error("系统繁忙，请稍后重试"); break;', '      default: message.error(data.message || "未知错误");', '    }', '    return Promise.reject(error);', '  }', ');', '```', '', '### 5.2 通用空状态组件', '', '```tsx', '// components/common/EmptyState.tsx', 'interface EmptyStateProps {', '  description?: string;', '  image?: ReactNode;', '  action?: ReactNode;', '}', 'export function EmptyState({ description = "暂无数据", image, action }: EmptyStateProps) {', '  return (', '    <div className="empty-state">', '      {image || <EmptyImage />}', '      <p>{description}</p>', '      {action}', '    </div>', '  );', '}', '```', '', genFooterMark());
  return L.join('\n');
}

// ==========================================
// v5.2.2：Test 文档生成器（从模型数据生成完整测试内容）
// ==========================================

function genAcceptanceCriteria(model) {
  const pages = model.pages || [];
  const entities = model.entities || [];
  const L = [];
  L.push('# 00 - 验收标准', '', '> 本文档定义系统各页面及全局的验收标准，作为产品交付验收的依据。', '', '---', '', '## 1. 验收原则', '', '1. **功能完整性**：所有 PRD 中定义的功能点均需实现并通过验收', '2. **数据准确性**：页面展示数据与后端返回数据一致', '3. **交互规范性**：操作流程符合 PRD 及 UX 设计规范', '4. **异常容错性**：异常场景有友好提示，不出现白屏或崩溃', '5. **权限正确性**：各角色权限控制准确无遗漏', '', '---', '', '## 2. 各页面验收条件', '');
  let pIdx = 1;
  for (const pg of pages) {
    const ent = entities.find(e => e.id === pg.entity || e.name === pg.entity);
    const num = String(pIdx).padStart(2, '0');
    L.push('', '### 页面 ' + pg.id + ' - ' + pg.name, '', '| 编号 | 验收条件 | 优先级 | 验收结果 |', '|------|----------|--------|----------|');
    L.push('| AC-P' + num + '-01 | 页面正常加载，展示 loading 状态后渲染数据 | P0 | 待验收 |');
    L.push('| AC-P' + num + '-02 | ' + (ent ? ent.name : pg.name) + '列表数据正确分页展示（默认每页 20 条） | P0 | 待验收 |');
    if (pg.type === 'crud_list' || pg.type === 'tree_list') {
      L.push('| AC-P' + num + '-03 | 搜索条件输入后能正确触发查询并刷新列表 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-04 | 点击新增按钮弹出表单，填写后能成功创建' + (ent ? ent.name : '数据') + ' | P0 | 待验收 |');
      L.push('| AC-P' + num + '-05 | 点击编辑按钮弹出表单并预填数据，修改后能成功保存 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-06 | 点击删除按钮有二次确认，确认后能成功删除 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-07 | 表格支持按字段排序 | P1 | 待验收 |');
      L.push('| AC-P' + num + '-08 | 无权限的操作按钮不可见 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-09 | 空数据状态正确展示空状态图 | P1 | 待验收 |');
      if (ent && ent.fields.some(f => f.required === 'true' || f.required === true)) {
        L.push('| AC-P' + num + '-10 | 必填字段未填写时表单校验失败并给出提示 | P0 | 待验收 |');
      }
    } else if (pg.type === 'detail_view') {
      L.push('| AC-P' + num + '-03 | 详情页正确展示' + (ent ? ent.name : '数据') + '所有字段 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-04 | 关联信息标签页能正确切换并展示数据 | P1 | 待验收 |');
      L.push('| AC-P' + num + '-05 | 返回按钮能正确返回列表页 | P0 | 待验收 |');
    } else if (pg.type === 'form_page' || pg.type === 'step_form') {
      L.push('| AC-P' + num + '-03 | 分步表单能正确切换步骤 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-04 | 表单提交后能成功保存数据 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-05 | 表单取消后能正确返回上一页 | P0 | 待验收 |');
    } else if (pg.type === 'dashboard') {
      L.push('| AC-P' + num + '-03 | 指标卡片正确展示数值 | P0 | 待验收 |');
      L.push('| AC-P' + num + '-04 | 图表正确渲染并支持时间范围切换 | P1 | 待验收 |');
    }
    if (ent && ent.states && ent.states.length > 0) {
      L.push('| AC-P' + num + '-11 | ' + ent.name + '状态变更操作正确触发状态转换 | P0 | 待验收 |');
    }
    pIdx++;
  }
  if (pages.length === 0) {
    L.push('', '### 页面：（无页面定义）', '', '| 编号 | 验收条件 | 优先级 | 验收结果 |', '|------|----------|--------|----------|', '| AC-P01-01 | 页面清单待补充后填写 | P0 | 待验收 |');
  }
  L.push('', '---', '', '## 3. 全局验收条件', '', '| 编号 | 验收条件 | 优先级 | 验收结果 |', '|------|----------|--------|----------|', '| AC-G-01 | 所有页面加载时展示 loading 状态 | P0 | 待验收 |', '| AC-G-02 | 所有表单提交有成功/失败反馈 | P0 | 待验收 |', '| AC-G-03 | 所有删除操作有二次确认弹窗 | P0 | 待验收 |', '| AC-G-04 | 所有列表页支持分页且默认每页 20 条 | P0 | 待验收 |', '| AC-G-05 | 所有操作按钮根据权限正确显示/隐藏 | P0 | 待验收 |', '| AC-G-06 | 空数据状态正确展示空状态图 | P1 | 待验收 |', '| AC-G-07 | 网络异常时有友好错误提示 | P1 | 待验收 |', '| AC-G-08 | 页面支持浏览器前进/后退 | P1 | 待验收 |', '| AC-G-09 | 响应式布局在 1280×720 及以上分辨率正常展示 | P1 | 待验收 |', '| AC-G-10 | 登录态过期后自动跳转登录页 | P0 | 待验收 |', '| AC-G-11 | 接口异常不出现白屏 | P0 | 待验收 |', '| AC-G-12 | 操作日志正确记录（含操作人、时间、操作内容） | P1 | 待验收 |', '', '---', '', '## 4. 数据准确性验收', '', '| 编号 | 验收条件 | 优先级 |', '|------|----------|--------|');
  let dIdx = 1;
  for (const e of entities) {
    L.push('| AC-D-' + String(dIdx).padStart(2, '0') + ' | ' + e.name + '列表数据与数据库记录一致 | P0 |');
    dIdx++;
    L.push('| AC-D-' + String(dIdx).padStart(2, '0') + ' | ' + e.name + '新增后列表立即显示新记录 | P0 |');
    dIdx++;
    L.push('| AC-D-' + String(dIdx).padStart(2, '0') + ' | ' + e.name + '编辑后列表数据正确更新 | P0 |');
    dIdx++;
    L.push('| AC-D-' + String(dIdx).padStart(2, '0') + ' | ' + e.name + '删除后列表不再显示该记录 | P0 |');
    dIdx++;
  }
  L.push('', genFooterMark());
  return L.join('\n');
}

function genTestSuggestions(model) {
  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];
  const L = [];
  L.push('# 01 - 测试用例框架', '', '> 本文档定义测试用例的框架结构，覆盖功能测试、边界测试及异常测试。', '', '---', '', '## 1. 功能测试', '', '| 用例编号 | 测试模块 | 测试功能 | 前置条件 | 操作步骤 | 预期结果 | 优先级 |', '|----------|----------|----------|----------|----------|----------|--------|');
  let ftIdx = 1;
  for (const e of entities) {
    const mod = entityToModule(e.id);
    // 列表
    L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '列表查询 | 已登录且有' + e.name + '查询权限 | 1.进入' + e.name + '列表页 2.默认加载第一页数据 | 列表正确显示，分页器显示总数 | P0 |');
    ftIdx++;
    // 搜索
    L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '搜索 | 列表已有数据 | 1.输入关键字 2.点击查询 | 列表按关键字过滤并刷新 | P0 |');
    ftIdx++;
    // 新增
    L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '新增 | 有新增权限 | 1.点击新增 2.填写必填字段 3.提交 | 新增成功，列表出现新记录 | P0 |');
    ftIdx++;
    // 编辑
    L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '编辑 | 列表已有数据 | 1.点击编辑 2.修改字段 3.保存 | 修改成功，列表数据更新 | P0 |');
    ftIdx++;
    // 删除
    L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '删除 | 列表已有数据 | 1.点击删除 2.确认删除 | 删除成功，列表不再显示该记录 | P0 |');
    ftIdx++;
    // 状态转换
    if (e.states && e.states.length > 0) {
      L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | ' + mod + ' | ' + e.name + '状态转换 | 存在' + e.states[0] + '状态的记录 | 1.选择记录 2.触发状态变更 | 状态正确转换，记录显示新状态 | P0 |');
      ftIdx++;
    }
  }
  // 分页测试
  L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | 通用 | 分页功能 | 列表数据 > 20 条 | 1.点击第 2 页 2.切换每页条数 | 分页器正确响应，列表正确切换 | P1 |');
  ftIdx++;
  L.push('| FT-' + String(ftIdx).padStart(3, '0') + ' | 通用 | 排序功能 | 列表已有数据 | 1.点击表头排序图标 | 列表按字段升序/降序排列 | P1 |');
  ftIdx++;

  L.push('', '---', '', '## 2. 边界测试', '', '| 用例编号 | 测试模块 | 测试场景 | 边界条件 | 预期结果 | 优先级 |', '|----------|----------|----------|----------|----------|--------|');
  let btIdx = 1;
  for (const e of entities) {
    const requiredFields = e.fields.filter(f => f.required === 'true' || f.required === true);
    const stringFields = e.fields.filter(f => !f.type || f.type === 'string');
    const numFields = e.fields.filter(f => f.type === 'number');
    if (requiredFields.length > 0) {
      L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '必填字段校验 | ' + requiredFields[0].name + '为空 | 表单校验失败，提示"' + (requiredFields[0].displayName || requiredFields[0].name) + '不能为空" | P0 |');
      btIdx++;
    }
    if (stringFields.length > 0) {
      L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '字符串长度上限 | ' + stringFields[0].name + '输入 256 个字符 | 提示长度超限 | P1 |');
      btIdx++;
    }
    if (numFields.length > 0) {
      L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '数值边界 | ' + numFields[0].name + '输入 -1 / 0 / 最大值 | 按业务规则校验 | P1 |');
      btIdx++;
    }
    L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '列表分页边界 | 跳转到不存在的页码（如总页数+1） | 显示空列表或最后一页 | P1 |');
    btIdx++;
  }
  L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | 通用 | 搜索关键字边界 | 输入特殊字符 <script> | 正确转义，无 XSS | P0 |');
  btIdx++;
  L.push('| BT-' + String(btIdx).padStart(3, '0') + ' | 通用 | 文件上传边界 | 上传超过大小限制的文件 | 提示文件过大 | P1 |');
  btIdx++;

  L.push('', '---', '', '## 3. 异常测试', '', '| 用例编号 | 测试模块 | 异常场景 | 触发方式 | 预期结果 | 优先级 |', '|----------|----------|----------|----------|----------|--------|');
  let etIdx = 1;
  for (const e of entities) {
    L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '接口超时 | Mock 接口延迟 30s | 显示加载状态，超时后提示重试 | P0 |');
    etIdx++;
    L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '接口 500 | Mock 接口返回 500 | 提示系统繁忙，不出现白屏 | P0 |');
    etIdx++;
    L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | ' + entityToModule(e.id) + ' | ' + e.name + '并发新增 | 同时提交两次新增请求 | 仅创建一条记录，提示重复提交 | P1 |');
    etIdx++;
  }
  L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | 通用 | 网络断开 | 操作中断网 | 提示网络异常 + 重试按钮 | P0 |');
  etIdx++;
  L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | 通用 | 登录态过期 | Token 过期后操作 | 自动跳转登录页，登录后恢复操作 | P0 |');
  etIdx++;
  L.push('| ET-' + String(etIdx).padStart(3, '0') + ' | 通用 | 跨标签页同步 | 在另一标签页退出登录 | 当前标签页操作时自动跳转登录 | P1 |');
  etIdx++;

  L.push('', '---', '', '## 4. 测试覆盖度统计', '', '| 类别 | 用例数 |', '|------|--------|', '| 功能测试 | ' + (ftIdx - 1) + ' |', '| 边界测试 | ' + (btIdx - 1) + ' |', '| 异常测试 | ' + (etIdx - 1) + ' |', '| 总计 | ' + (ftIdx + btIdx + etIdx - 3) + ' |', '', genFooterMark());
  return L.join('\n');
}

function genPermissionMatrix(model) {
  const roles = model.roles || [];
  const entities = model.entities || [];
  const pages = model.pages || [];
  const richRoles = extractRolesRich(model.raw);
  const L = [];
  L.push('# 02 - 权限验证矩阵', '', '> 本文档定义权限相关的测试验证矩阵，覆盖功能权限与数据权限的测试用例。', '', '---', '', '## 1. 功能权限测试', '', '| 用例编号 | 页面/功能 | 操作 | 角色 | 预期结果 | 测试结果 |', '|----------|-----------|------|------|----------|----------|');
  let ptIdx = 1;
  // 选取前 3 个实体进行权限测试
  const testEntities = entities.slice(0, 3);
  const testRoles = roles.length > 0 ? roles.slice(0, 4) : [];
  for (const e of testEntities) {
    for (const r of testRoles) {
      // 判断角色对该实体的权限
      const richRole = richRoles.find(rr => rr.id === r.id || rr.name === r.name);
      let hasPerm = true;
      let permType = '全部';
      if (richRole && Array.isArray(richRole.permissions)) {
        const match = richRole.permissions.find(p =>
          p.entity === e.id || p.entity === e.name ||
          p.entity === e.id.toLowerCase() || p.entity === e.name.toLowerCase()
        );
        if (match) {
          const acts = match.actions || [];
          if (acts.length === 0) { hasPerm = true; permType = '全部'; }
          else if (acts.includes('create') || acts.includes('write')) { hasPerm = true; permType = '新增/编辑/删除'; }
          else if (acts.includes('read') || acts.includes('list')) { hasPerm = true; permType = '查看'; }
          else { hasPerm = false; }
        }
      }
      if (hasPerm) {
        L.push('| PT-F-' + String(ptIdx).padStart(3, '0') + ' | ' + e.name + '管理 | 新增 | ' + roleId(r, 0) + ' - ' + r.name + ' | 可见新增按钮，能成功新增 | 待测试 |');
        ptIdx++;
        L.push('| PT-F-' + String(ptIdx).padStart(3, '0') + ' | ' + e.name + '管理 | 编辑 | ' + roleId(r, 0) + ' - ' + r.name + ' | 可见编辑按钮，能成功编辑 | 待测试 |');
        ptIdx++;
        L.push('| PT-F-' + String(ptIdx).padStart(3, '0') + ' | ' + e.name + '管理 | 删除 | ' + roleId(r, 0) + ' - ' + r.name + ' | 可见删除按钮，能成功删除 | 待测试 |');
        ptIdx++;
      } else {
        L.push('| PT-F-' + String(ptIdx).padStart(3, '0') + ' | ' + e.name + '管理 | 新增 | ' + roleId(r, 0) + ' - ' + r.name + ' | 不可见新增按钮，URL 直接访问被拦截 | 待测试 |');
        ptIdx++;
      }
    }
  }
  if (ptIdx === 1) {
    L.push('| PT-F-001 | ' + (pages[0] ? pages[0].name : '主功能') + ' | 新增 | ' + (roles[0] ? roleId(roles[0], 0) + ' - ' + roles[0].name : 'R01 - 默认角色') + ' | 可见新增按钮，能成功新增 | 待测试 |');
    L.push('| PT-F-002 | ' + (pages[0] ? pages[0].name : '主功能') + ' | 删除 | ' + (roles[0] ? roleId(roles[0], 0) + ' - ' + roles[0].name : 'R01 - 默认角色') + ' | 可见删除按钮，能成功删除 | 待测试 |');
  }
  L.push('', '> 验证要点：有权限的操作按钮可见且可执行；无权限的操作按钮不可见；通过 URL 直接访问无权限页面时应被拦截。', '', '---', '', '## 2. 数据权限测试', '', '| 用例编号 | 测试场景 | 角色 | 数据范围 | 预期结果 | 测试结果 |', '|----------|----------|------|----------|----------|----------|');
  let pdIdx = 1;
  for (const r of testRoles) {
    const richRole = richRoles.find(rr => rr.id === r.id || rr.name === r.name);
    let scope = 'all';
    if (richRole && Array.isArray(richRole.permissions)) {
      for (const p of richRole.permissions) {
        if (p.scope && p.scope !== 'all') { scope = p.scope; break; }
      }
    }
    const scopeLabel = scope === 'self' ? '仅本人数据' : scope === 'dept' ? '本部门数据' : scope === 'all' ? '全部数据' : scope;
    L.push('| PT-D-' + String(pdIdx).padStart(3, '0') + ' | ' + (entities[0] ? entities[0].name : '主实体') + '列表数据范围 | ' + roleId(r, 0) + ' - ' + r.name + ' | ' + scopeLabel + ' | 仅展示' + scopeLabel + '，无越权数据 | 待测试 |');
    pdIdx++;
  }
  if (pdIdx === 1) {
    L.push('| PT-D-001 | 主实体列表数据范围 | ' + (roles[0] ? roleId(roles[0], 0) + ' - ' + roles[0].name : 'R01 - 默认角色') + ' | 全部数据 | 展示全部数据 | 待测试 |');
  }
  L.push('', '> 数据权限场景示例：仅查看本人数据 / 查看本部门数据 / 查看全部数据 / 跨部门数据隔离等', '', '---', '', '## 3. 页面访问权限测试', '', '| 用例编号 | 页面 | 允许角色 | 验证方式 | 预期结果 | 测试结果 |', '|----------|------|---------|---------|----------|----------|');
  let ppIdx = 1;
  for (const pg of pages) {
    const visibleRoles = roles.filter(r => {
      const richRole = richRoles.find(rr => rr.id === r.id || rr.name === r.name);
      if (richRole && Array.isArray(richRole.pageVisibility) && richRole.pageVisibility.length > 0) {
        return richRole.pageVisibility.some(v => v === pg.id || v === pg.name);
      }
      return true;
    }).map(r => roleId(r, 0) + ' - ' + r.name);
    L.push('| PT-P-' + String(ppIdx).padStart(3, '0') + ' | ' + pg.name + ' (' + pg.route + ') | ' + (visibleRoles.length > 0 ? visibleRoles.join(', ') : '全部角色') + ' | 1.登录有权限角色访问 2.登录无权限角色访问 | 有权限可访问，无权限跳转 403 | 待测试 |');
    ppIdx++;
  }
  if (ppIdx === 1) {
    L.push('| PT-P-001 | 主页面 | 全部角色 | 1.登录后访问 | 正常访问 | 待测试 |');
  }
  L.push('', genFooterMark());
  return L.join('\n');
}

// ==========================================
// v5.2.2：Handoff 文档生成器
// ==========================================

function genReviewNotes(model) {
  const p = model.project || {};
  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];
  const today = new Date();
  const dateStr = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0') + '-' + String(today.getDate()).padStart(2, '0');
  const L = [];
  L.push('# 评审会议记录', '', '> 本文档用于记录项目评审会议的讨论内容、反馈意见及后续行动项。', '', '---', '', '## 1. 会议信息', '', '| 字段 | 内容 |', '|------|------|', '| 会议日期 | ' + dateStr + ' |', '| 参会人员 | 产品经理、前端开发、后端开发、测试、设计 |', '| Demo 版本 | v5.2.2 |', '| 评审范围 | ' + (p.name || '本项目') + ' PRD 全套文档（' + (13 + 7 + 3) + ' 篇）与原型 Demo |', '| 记录人 | 由 Demora Skill 生成 |', '', '---', '', '## 2. 评审范围概要', '', '| 维度 | 数量 | 说明 |', '|------|------|------|', '| 业务实体 | ' + entities.length + ' | ' + entities.map(e => e.name).join('、') + ' |', '| 用户角色 | ' + roles.length + ' | ' + roles.map(r => r.name).join('、') + ' |', '| 页面数量 | ' + pages.length + ' | ' + pages.map(pg => pg.name).join('、') + ' |', '', '---', '', '## 3. 反馈意见', '', '| 编号 | 反馈内容 | 提出人 | 类型 | 严重程度 | 处理状态 | 负责人 |', '|------|----------|--------|------|----------|----------|--------|', '| FB-01 | ' + (entities[0] ? entities[0].name : '主实体') + '字段定义是否覆盖业务实际需求，需业务方复核 | 产品经理 | 需求变更 | 一般 | 待处理 | 产品经理 |', '| FB-02 | 页面交互流程是否符合用户习惯，需用户测试验证 | 设计 | 体验优化 | 一般 | 待处理 | 设计 |', '| FB-03 | 权限模型是否满足数据隔离需求，需安全评审 | 后端 | 需求变更 | 严重 | 待处理 | 后端 |', '| FB-04 | Mock 数据是否覆盖所有状态枚举与角色组合 | 测试 | 数据问题 | 一般 | 待处理 | 测试 |', '| FB-05 | API 契约是否与前端预期一致，需联调验证 | 前端 | 体验优化 | 一般 | 待处理 | 前端 |', '', '> 反馈类型参考：功能问题 / 体验优化 / 数据问题 / 需求变更 / 建议', '> 严重程度参考：严重 / 一般 / 建议', '> 处理状态参考：待处理 / 处理中 / 已完成 / 已关闭', '', '---', '', '## 4. 行动项', '', '| 编号 | 行动内容 | 负责人 | 截止日期 | 完成状态 |', '|------|----------|--------|----------|----------|', '| AI-01 | 业务方复核 ' + (entities[0] ? entities[0].name : '主实体') + '字段定义 | 产品经理 | ' + dateStr + ' + 7 天 | 待处理 |', '| AI-02 | 完成主要页面的可点击原型与用户测试 | 设计 | ' + dateStr + ' + 14 天 | 待处理 |', '| AI-03 | 后端完成权限模型安全评审并出具评审意见 | 后端 | ' + dateStr + ' + 7 天 | 待处理 |', '| AI-04 | 测试补充 Mock 数据覆盖度（含所有状态与角色） | 测试 | ' + dateStr + ' + 5 天 | 待处理 |', '| AI-05 | 前后端按 API 契约完成首轮联调 | 前端 + 后端 | ' + dateStr + ' + 10 天 | 待处理 |', '| AI-06 | 完成 ' + pages.length + ' 个页面的开发排期确认 | 项目经理 | ' + dateStr + ' + 3 天 | 待处理 |', '', '---', '', '## 5. 关键决策记录', '', '| 决策 ID | 决策内容 | 决策人 | 决策日期 |', '|---------|---------|--------|---------|', '| D-01 | 采用 React + Ant Design 作为前端技术栈 | 产品经理 | ' + dateStr + ' |', '| D-02 | 后端采用 RESTful API 风格 | 后端 | ' + dateStr + ' |', '| D-03 | 权限模型采用 RBAC（基于角色的访问控制） | 后端 | ' + dateStr + ' |', '| D-04 | 数据库选用关系型数据库（MySQL/PostgreSQL） | 后端 | ' + dateStr + ' |', '', '---', '', '## 6. 风险提示', '', '| 风险 ID | 风险描述 | 影响 | 应对措施 |', '|---------|---------|------|---------|');
  for (const e of entities.slice(0, 3)) {
    L.push('| R-' + e.id + ' | ' + entityRisk(e) + ' | ' + e.name + '管理模块 | 在 07-fields.md 与 03-state-matrix.md 中明确校验规则 |');
  }
  L.push('', '---', '', '## 7. 下次会议', '', '| 字段 | 内容 |', '|------|------|', '| 会议日期 | ' + dateStr + ' + 14 天 |', '| 预期议题 | 1. 行动项完成情况复核 2. 用户测试结果讨论 3. 开发排期确认 4. 联调进展同步 |', '', genFooterMark());
  return L.join('\n');
}

// ==========================================
// 页面详情生成（v5.2.2：完全从模型数据生成，不依赖模板占位符）
// ==========================================

function generatePageDetails(root, model, referencesDir) {
  const pageDetailsDir = path.join(root, 'docs', 'prd', '06-page-details');
  if (!fs.existsSync(pageDetailsDir)) fs.mkdirSync(pageDetailsDir, { recursive: true });

  const pages = extractPagesRich(model.raw);
  const entities = model.entities || [];
  const roles = extractRolesRich(model.raw);
  const generatedFiles = [];

  for (const page of pages) {
    if (!page || !page.id) continue;
    const pageId = page.id;
    const pageName = page.name || pageId;
    const pageType = page.type || 'crud_list';
    const entity = page.entity || '';
    const route = page.route || '/' + pageId;
    const ent = entities.find(e => e.id === entity || e.name === entity);
    const visibleRoles = roles.filter(r => {
      if (Array.isArray(r.pageVisibility) && r.pageVisibility.length > 0) {
        return r.pageVisibility.some(v => v === pageId || v === pageName);
      }
      return true;
    }).map(r => r.name);

    const L = [];
    L.push('# ' + pageName + ' - 页面详情', '', '> 本文档定义页面 ' + pageId + ' 的详细设计，包括布局、字段、操作、验收标准等。', '', '---', '', '## 1. 页面信息', '', '| 字段 | 内容 |', '|------|------|', '| 页面 ID | ' + pageId + ' |', '| 页面名称 | ' + pageName + ' |', '| 所属模块 | ' + entityToModule(entity || pageId) + ' |', '| 页面类型 | ' + pageTypeLabel(pageType) + ' |', '| 路由路径 | ' + route + ' |', '| 优先级 | ' + (page.priority || 'P1') + ' |', '| 关联角色 | ' + (visibleRoles.length > 0 ? visibleRoles.join(' / ') : '全部角色') + ' |', '| 关联实体 | ' + (entity || '-') + ' |', '', '---', '', '## 2. 页面目标', '', page.description || ('提供 ' + pageName + ' 的' + pageTypeLabel(pageType).replace('页', '') + '功能，支持' + (ent ? ent.name + '数据' : '业务数据') + '的查询、管理与维护。'), '', '---', '', '## 3. 页面布局', '', '### ASCII 线框图', '', '```');
    if (pageType === 'crud_list' || pageType === 'tree_list') {
      L.push('+----------------------------------------------------------+', '|  [面包屑导航] 首页 / ' + entityToModule(entity || pageId) + ' / ' + pageName + '              |', '+----------------------------------------------------------+', '|  [搜索区]                                                  |', '|  ' + (ent && ent.fields[0] ? ent.fields[0].displayName || ent.fields[0].name : '关键字') + ': [____]  ' + (ent && ent.fields[1] ? ent.fields[1].displayName || ent.fields[1].name : '状态') + ': [____]  [查询] [重置]     |', '+----------------------------------------------------------+', '|  [操作栏]  [+ 新增]  [批量导出]  [批量删除]                 |', '+----------------------------------------------------------+', '|  [数据表格]                                                |');
      const cols = ent && ent.fields.length > 0 ? ent.fields.slice(0, 5).map(f => f.displayName || f.name) : ['字段1', '字段2', '字段3', '状态', '创建时间'];
      L.push('|  | 序号 | ' + cols.join(' | ') + ' | 操作 |   |');
      L.push('|  |------|' + cols.map(() => '------').join('|') + '|------|   |');
      L.push('|  |  1   |  xxx |  xxx |  xxx |  xxx |  xxx |  编辑 |   |');
      L.push('|  |  2   |  xxx |  xxx |  xxx |  xxx |  xxx |  编辑 |   |');
      L.push('+----------------------------------------------------------+', '|  [分页器]  共 N 条  每页 [20] 条  < 1 2 3 ... >              |', '+----------------------------------------------------------+');
    } else if (pageType === 'detail_view') {
      L.push('+----------------------------------------------------------+', '|  [面包屑导航] 首页 / ' + entityToModule(entity || pageId) + ' / 详情                |', '+----------------------------------------------------------+', '|  [返回按钮]                                                |', '+----------------------------------------------------------+', '|  [详情信息卡片]                                            |');
      if (ent) {
        for (const f of ent.fields.slice(0, 6)) L.push('|  ' + (f.displayName || f.name) + ': xxx                                            |');
      }
      L.push('+----------------------------------------------------------+', '|  [关联信息标签页]                                          |', '|  [标签1] [标签2] [标签3]                                    |', '+----------------------------------------------------------+', '|  [标签内容区]                                              |', '+----------------------------------------------------------+');
    } else if (pageType === 'form_page' || pageType === 'step_form') {
      L.push('+----------------------------------------------------------+', '|  [面包屑导航] 首页 / ' + pageName + '                                  |', '+----------------------------------------------------------+', '|  [步骤指示器] 1.基本信息 -> 2.扩展信息 -> 3.确认           |', '+----------------------------------------------------------+', '|  [表单区]                                                  |');
      if (ent) {
        for (const f of ent.fields.slice(0, 6)) L.push('|  ' + (f.displayName || f.name) + ': [____________]                                  |');
      }
      L.push('+----------------------------------------------------------+', '|  [操作区]  [上一步]  [下一步]  [提交]  [取消]              |', '+----------------------------------------------------------+');
    } else if (pageType === 'dashboard') {
      L.push('+----------------------------------------------------------+', '|  [面包屑导航] 首页 / ' + pageName + '                                  |', '+----------------------------------------------------------+', '|  [指标卡片 1]  [指标卡片 2]  [指标卡片 3]  [指标卡片 4]    |', '+----------------------------------------------------------+', '|  [图表区 - 趋势图]                                        |', '|  [图表内容]                                                |', '+----------------------------------------------------------+', '|  [图表区 - 饼图]      |  [图表区 - 柱状图]                |', '|  [图表内容]          |  [图表内容]                        |', '+----------------------------------------------------------+');
    } else {
      L.push('+----------------------------------------------------------+', '|  [页面内容区]                                              |', '+----------------------------------------------------------+');
    }
    L.push('```', '', '---', '', '## 4. 字段说明', '', '### 4.1 搜索区字段', '', '| 字段名 | 字段标签 | 组件类型 | 数据来源 | 默认值 | 说明 |', '|--------|----------|----------|----------|--------|------|');
    if (ent && ent.fields.length > 0) {
      const searchFields = ent.fields.slice(0, 3);
      for (const f of searchFields) {
        const compType = f.type === 'enum' ? 'Select' : f.type === 'date' ? 'DatePicker' : 'Input';
        L.push('| ' + (f.name || '') + ' | ' + (f.displayName || f.name || '') + ' | ' + compType + ' | 用户输入 | - | 用于' + pageName + '列表过滤查询 |');
      }
    } else {
      L.push('| keyword | 关键字 | Input | 用户输入 | - | 模糊搜索 |');
    }
    L.push('', '### 4.2 表格/表单/详情字段', '', '| 字段名 | 字段标签 | 组件类型 | 是否必填 | 校验规则 | 是否可编辑 | 说明 |', '|--------|----------|----------|----------|----------|------------|------|');
    if (ent && ent.fields.length > 0) {
      for (const f of ent.fields) {
        const compType = f.type === 'enum' ? 'Select' : f.type === 'date' ? 'DatePicker' : f.type === 'number' ? 'InputNumber' : 'Input';
        const required = f.required === 'true' || f.required === true ? '是' : '否';
        const validate = f.required === 'true' || f.required === true ? '必填' : '-';
        L.push('| ' + (f.name || '') + ' | ' + (f.displayName || f.name || '') + ' | ' + compType + ' | ' + required + ' | ' + validate + ' | 是 | ' + (f.displayName || f.name || '') + ' |');
      }
    } else {
      L.push('| id | ID | Input | 是 | 必填 | 否 | 主键 |', '| name | 名称 | Input | 是 | 必填 | 是 | 名称 |');
    }
    L.push('', '---', '', '## 5. 操作说明', '', '### 5.1 主要操作', '', '| 操作名称 | 触发方式 | 前置条件 | 处理逻辑 | 成功提示 | 失败提示 |', '|----------|----------|----------|----------|----------|----------|');
    if (pageType === 'crud_list' || pageType === 'tree_list') {
      L.push('| 新增 | 点击 [+ 新增] | 有新增权限 | 弹出表单弹窗，填写后提交创建 | 新增成功 | 新增失败，请重试 |');
      L.push('| 编辑 | 点击行内 [编辑] | 有编辑权限 | 弹出表单弹窗预填数据，修改后保存 | 保存成功 | 保存失败，请重试 |');
      L.push('| 删除 | 点击行内 [删除] | 有删除权限 | 二次确认后调用删除接口 | 删除成功 | 删除失败，请重试 |');
    } else if (pageType === 'detail_view') {
      L.push('| 返回 | 点击 [返回] | - | 返回上一页 | - | - |');
      L.push('| 编辑 | 点击 [编辑] | 有编辑权限 | 跳转到编辑表单 | - | - |');
    } else if (pageType === 'form_page' || pageType === 'step_form') {
      L.push('| 提交 | 点击 [提交] | 必填字段已填写 | 校验通过后调用保存接口 | 提交成功 | 提交失败，请检查后重试 |');
      L.push('| 取消 | 点击 [取消] | - | 返回上一页（不保存） | - | - |');
    } else if (pageType === 'dashboard') {
      L.push('| 切换时间范围 | 点击时间选择器 | - | 重新请求并渲染图表 | - | - |');
    }
    L.push('', '### 5.2 批量操作', '', '| 操作名称 | 触发方式 | 前置条件 | 处理逻辑 | 成功提示 | 失败提示 |', '|----------|----------|----------|----------|----------|----------|');
    if (pageType === 'crud_list' || pageType === 'tree_list') {
      L.push('| 批量删除 | 勾选多行后点击 [批量删除] | 有删除权限 | 二次确认后批量删除 | 批量删除成功 | 部分删除失败，请刷新后重试 |');
      L.push('| 批量导出 | 勾选多行后点击 [批量导出] | 有导出权限 | 调用导出接口下载文件 | 导出成功 | 导出失败，请重试 |');
    } else {
      L.push('| - | - | - | - | - | - |');
    }
    L.push('', '### 5.3 行操作', '', '| 操作名称 | 触发方式 | 前置条件 | 处理逻辑 | 成功提示 | 失败提示 |', '|----------|----------|----------|----------|----------|----------|');
    if (pageType === 'crud_list' || pageType === 'tree_list') {
      L.push('| 查看 | 点击行内 [查看] | 有查看权限 | 跳转到详情页 | - | - |');
      L.push('| 编辑 | 点击行内 [编辑] | 有编辑权限 | 弹出编辑表单 | 保存成功 | 保存失败，请重试 |');
      L.push('| 删除 | 点击行内 [删除] | 有删除权限 | 二次确认后删除 | 删除成功 | 删除失败，请重试 |');
      if (ent && ent.states && ent.states.length > 0) {
        L.push('| 状态变更 | 点击行内 [状态变更] | 有编辑权限 | 弹出状态变更弹窗 | 状态变更成功 | 状态变更失败，请重试 |');
      }
    } else {
      L.push('| - | - | - | - | - | - |');
    }
    L.push('', '---', '', '## 6. 验收标准', '', '- [ ] 页面加载时展示 loading 状态', '- [ ] ' + (ent ? ent.name : '数据') + '列表数据正确分页展示（默认每页 20 条）', '- [ ] 搜索区字段可正常输入并触发查询', '- [ ] 表格数据正确分页展示', '- [ ] 排序功能正常工作', '- [ ] 新增/编辑表单校验正确', '- [ ] 删除操作有二次确认', '- [ ] 批量操作可正确选择并执行', '- [ ] 权限控制正确（无权限的操作按钮不可见）', '- [ ] 空状态正确展示', '- [ ] 加载状态正确展示 loading', '- [ ] 异常状态有友好错误提示');
    if (ent && ent.states && ent.states.length > 0) {
      L.push('- [ ] ' + ent.name + '状态变更操作正确执行');
    }
    L.push('', '---', '', '## 7. 关联文档', '', '| 文档 | 链接 |', '|------|------|', '| 页面清单 | [../05-page-list.md](../05-page-list.md) |', '| 字段定义 | [../07-fields.md](../07-fields.md) |', '| 权限设计 | [../08-permissions.md](../08-permissions.md) |', '| 业务流程 | [../04-business-flow.md](../04-business-flow.md) |', '| 路由表 | [../../spec/04-route-table.md](../../spec/04-route-table.md) |', '| API 契约 | [../../spec/05-api-contract-draft.md](../../spec/05-api-contract-draft.md) |', '', genFooterMark());

    const outPath = path.join(pageDetailsDir, pageId + '-' + pageName + '.md');
    fs.writeFileSync(outPath, L.join('\n'), { encoding: 'utf-8' });
    generatedFiles.push(outPath);
  }
  return generatedFiles;
}

// ==========================================
// v5.19 P0-1：mermaid 语法黑名单自检
// ==========================================

/**
 * v5.19 P0-1：对本次生成的所有 markdown 文件做 mermaid 语法黑名单自检
 * 说明：真正的 mermaid.parse 全量校验在 generate-product-docs.mjs 的 P034 自检中执行；
 * 本脚本在 node 环境运行且 mermaid.min.js 不在本脚本目录，故采用轻量语法黑名单自检——
 * 检查每个 ```mermaid 代码块中不含已知非法模式：
 *   1. `>{{`   —— 旗帜符+六角形误接（mermaid 11.16 报 DIAMOND_START Parse error）
 *   2. `>[]`   —— 旗帜符+空方框
 *   3. 行首空标签节点定义 `^\s*\w+\[\]`（如 S0[]，含 S0[](...) 变体）
 *   4. 尾随箭头 `-->$`（悬挂边）
 *   5. 行内双引号数量为奇数（边标签 |"…"| 缺闭合引号）
 * v5.23：新增规则 5——缺陷背景：P034 parse 自检在 node 无 DOM 环境下因
 * mermaid.min.js 内置 dompurify 缺 addHook 抛 TypeError 而失效，缺闭合引号
 * （如 `P04 -->|"生成报告| P05`）的真实缺陷曾通过校验，故黑名单补引号平衡兜底
 * 命中即 console.error 并置 process.exitCode = 1
 * @param {string[]} files - 本次写出的 markdown 文件绝对路径列表
 * @returns {number} 违规条数（0 = 通过）
 */
function selfCheckMermaid(files) {
  let failed = 0;
  let blockCount = 0;
  for (const file of files) {
    let text = '';
    try { text = fs.readFileSync(file, { encoding: 'utf-8' }); } catch { continue; }
    const blockRegex = /```mermaid[ \t]*\r?\n([\s\S]*?)```/g;
    let m;
    let bi = 0;
    while ((m = blockRegex.exec(text)) !== null) {
      bi++;
      blockCount++;
      const blockName = path.basename(file) + '#mermaid-' + bi;
      // v5.23：改为带行号遍历，供引号平衡检查报告行号
      const lines = m[1].split(/\r?\n/);
      for (let li = 0; li < lines.length; li++) {
        const line = lines[li];
        if (line.includes('>{{')) {
          console.error('[FAIL] mermaid 语法自检未通过: ' + blockName + ' 非法形状拼接 >{{ : ' + line.trim());
          failed++;
        }
        if (line.includes('>[]')) {
          console.error('[FAIL] mermaid 语法自检未通过: ' + blockName + ' 非法空标签 >[] : ' + line.trim());
          failed++;
        }
        if (/^\s*[A-Za-z0-9_]+\[\]/.test(line)) {
          console.error('[FAIL] mermaid 语法自检未通过: ' + blockName + ' 空标签节点 [] : ' + line.trim());
          failed++;
        }
        if (/-->\s*$/.test(line)) {
          console.error('[FAIL] mermaid 语法自检未通过: ' + blockName + ' 尾随箭头 --> : ' + line.trim());
          failed++;
        }
        // v5.23：引号平衡检查——边标签 |"…"| 缺闭合引号时 mermaid 渲染必失败
        //（P034 parse 在 node 环境对带引号 label 块失效，此处黑名单兜底）。
        // 跳过 %% 注释行；局限：块级引号注释（""" / ''' 分隔行）未处理，
        // 此类行含奇数双引号会误报（实际生成场景极少使用）
        if (!line.trim().startsWith('%%')) {
          const dq = (line.match(/"/g) || []).length;
          if (dq % 2 === 1) {
            console.error('[FAIL] mermaid 语法自检未通过: ' + blockName + ' 第 ' + (li + 1) + ' 行双引号数量为奇数（疑似缺失闭合引号）: ' + line.trim());
            failed++;
          }
        }
      }
    }
  }
  if (failed === 0) {
    process.stdout.write('[OK] mermaid 语法黑名单自检通过（' + blockCount + ' 个代码块）\n');
  } else {
    process.exitCode = 1;
  }
  return failed;
}

// ==========================================
// 主入口
// ==========================================

export function main(args = {}) {
  const root = args.root || process.cwd();
  const referencesDir = findReferencesDir();
  if (!referencesDir) {
    process.stderr.write('[FAIL] 未找到 references 目录\n');
    process.exit(1);
  }

  // 加载需求模型
  const model = loadModelRich(root);
  // v5.19 P1-4：加载需求输入原文（供 genBackground 痛点/方案/non-goals 提取；读不到为 null → 模板兜底）
  model.inputText = loadRequirementInput(root);
  process.stdout.write('[INFO] 模型加载完成: ' + model.entities.length + ' 实体, ' +
    model.roles.length + ' 角色, ' + model.pages.length + ' 页面\n');
  // v5.19 P0-1：收集本次写出的所有 md 文件路径，供末尾 mermaid 语法黑名单自检
  const writtenFiles = [];

  // PRD 文档清单（13 篇）
  const prdGenerators = [
    { name: '00-overview.md', gen: genOverview },
    { name: '01-background.md', gen: genBackground },
    { name: '02-target-audience.md', gen: genTargetAudience },
    { name: '03-user-roles.md', gen: genUserRoles },
    { name: '04-business-flow.md', gen: genBusinessFlow },
    { name: '05-page-list.md', gen: genPageList },
    { name: '07-fields.md', gen: genFields },
    { name: '08-permissions.md', gen: genPermissions },
    { name: '09-user-stories.md', gen: genUserStories },
    { name: '10-success-metrics.md', gen: genSuccessMetrics },
    { name: '11-timeline.md', gen: genTimeline },
    { name: '12-risk-assumptions.md', gen: genRiskAssumptions },
    { name: '13-open-questions.md', gen: genOpenQuestions },
  ];

  // Spec 文档清单（7 篇）
  const specGenerators = [
    { name: '00-project-overview.md', gen: genSpecProjectOverview },
    { name: '01-page-architecture.md', gen: genPageArchitecture },
    { name: '02-interaction-flow.md', gen: genInteractionFlow },
    { name: '03-state-matrix.md', gen: genStateMatrix },
    { name: '04-route-table.md', gen: genRouteTable },
    { name: '05-api-contract-draft.md', gen: genApiContractDraft },
    { name: '06-error-and-empty-states.md', gen: genErrorAndEmptyStates },
  ];

  // Test 文档清单（3 篇）
  const testGenerators = [
    { name: '00-acceptance-criteria.md', gen: genAcceptanceCriteria },
    { name: '01-test-suggestions.md', gen: genTestSuggestions },
    { name: '02-permission-matrix.md', gen: genPermissionMatrix },
  ];

  let generated = 0;

  // 生成 PRD 文档
  for (let idx = 0; idx < prdGenerators.length; idx++) {
    const { name, gen } = prdGenerators[idx];
    const content = gen(model);
    const outPath = path.join(root, 'docs', 'prd', name);
    fs.writeFileSync(outPath, content, { encoding: 'utf-8' });
    generated++;
    // v5.19 P0-1：记录本次写出的 md 文件（mermaid 自检用）
    writtenFiles.push(outPath);
    // v5.18 P0-B3：进度可见性——每文档生成后 flush stdout
    process.stdout.write('[PROGRESS] PRD 文档: ' + (idx + 1) + '/' + prdGenerators.length + ' ' + name + '\n');
  }

  // 生成 06-page-details/ 下的页面详情文档
  const pageFiles = generatePageDetails(root, model, referencesDir);
  generated += pageFiles.length;
  // v5.19 P0-1：记录本次写出的 md 文件（mermaid 自检用）
  writtenFiles.push(...pageFiles);
  process.stdout.write('[PROGRESS] page-details: ' + pageFiles.length + ' 个文件\n');

  // 生成 Spec 文档
  for (let idx = 0; idx < specGenerators.length; idx++) {
    const { name, gen } = specGenerators[idx];
    const content = gen(model);
    const outPath = path.join(root, 'docs', 'spec', name);
    fs.writeFileSync(outPath, content, { encoding: 'utf-8' });
    generated++;
    // v5.19 P0-1：记录本次写出的 md 文件（mermaid 自检用）
    writtenFiles.push(outPath);
    process.stdout.write('[PROGRESS] Spec 文档: ' + (idx + 1) + '/' + specGenerators.length + ' ' + name + '\n');
  }

  // 生成 Test 文档
  for (let idx = 0; idx < testGenerators.length; idx++) {
    const { name, gen } = testGenerators[idx];
    const content = gen(model);
    const outPath = path.join(root, 'docs', 'test', name);
    fs.writeFileSync(outPath, content, { encoding: 'utf-8' });
    generated++;
    // v5.19 P0-1：记录本次写出的 md 文件（mermaid 自检用）
    writtenFiles.push(outPath);
    process.stdout.write('[PROGRESS] Test 文档: ' + (idx + 1) + '/' + testGenerators.length + ' ' + name + '\n');
  }

  // 生成 handoff/review-notes.md
  const handoffContent = genReviewNotes(model);
  const handoffPath = path.join(root, 'docs', 'handoff', 'review-notes.md');
  fs.writeFileSync(handoffPath, handoffContent, { encoding: 'utf-8' });
  generated++;
  // v5.19 P0-1：记录本次写出的 md 文件（mermaid 自检用）
  writtenFiles.push(handoffPath);

  // 更新 state.yaml
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (fs.existsSync(stateFile)) {
    let stateText = fs.readFileSync(stateFile, { encoding: 'utf-8' });
    stateText = stateText.replace(/docs_generated:\s*\[\]/, 'docs_generated: [' + generated + ']');
    stateText = stateText.replace(/docs_generated:\s*\d+/, 'docs_generated: ' + generated);
    fs.writeFileSync(stateFile, stateText, { encoding: 'utf-8' });
  }

  // 设计判断产出物集成
  const designDecisionsFile = path.join(root, '.demora', 'design-decisions.md');
  if (fs.existsSync(designDecisionsFile)) {
    const overviewPath = path.join(root, 'docs', 'prd', '00-overview.md');
    if (fs.existsSync(overviewPath)) {
      let overview = fs.readFileSync(overviewPath, { encoding: 'utf-8' });
      if (!/## 设计意图（design-decisions）/.test(overview)) {
        const briefSection = [
          '',
          '',
          '## 设计意图（design-decisions）',
          '',
          '> 由 frontend-design 方法论生成，详见 `.demora/design-decisions.md`（自由形式 markdown）。',
          '> 设计质量的可观测性由 PM 人工评审与 A/B/C 对比验证承担。',
          '> 业界标准方案引入计划详见根目录 AGENTS.md §一.1 原则 4。',
          '',
        ].join('\n');
        overview += briefSection;
        fs.writeFileSync(overviewPath, overview, { encoding: 'utf-8' });
      }
    }
  }

  // v5.19 P0-1：mermaid 语法黑名单自检（生成完所有 md 后执行；命中非法模式置 exitCode=1）
  selfCheckMermaid(writtenFiles);

  process.stdout.write('[OK] PRD 文档生成完成（' + generated + ' 个文档，v5.2.2 完整生成）\n');
  return { ok: true, count: generated };
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
