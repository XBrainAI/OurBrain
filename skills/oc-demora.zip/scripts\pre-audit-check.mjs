// pre-audit-check.mjs
// Audit 前静态契约预检器（v5.14.11 新增）
// v5.18 P0-C3：每条 FAIL/WARN 附 fix_command
// v5.18 P0-A3：P013 从 WARN 升级为 FAIL（标注引擎未加载为阻断性失败）
// v2.1：P018 升级 FAIL + P030 隐藏祖先链锚点检测（D10 根因 B/C 类前置）
// v2.4：P033 显隐状态反模式检测 + C19 P018 自动对齐
// v5.23：P040 表格结构元素标注 + P041 L3 序号型重复 + P042 工作根洁净检测
//        （run-audit D7/D8/D11 增强的静态前置防线）
// v5.24：P042 层级修正（工作根上探 + scaffold 空骨架消误报）+ 新增 P043 筛选显示同步检测 +
//        P038 收集扩展（无 data-action 有 id 的自建监听控件）+ P041 规模感知（≤4 全标合规）
//        （UAT0826 p3/p6 实证缺陷的静态侧修复）
//
// 设计目标：
//   - 在 run-audit.mjs 前执行静态契约预检，提前发现可静态检测的失败模式
//   - 失败时返回结构化错误清单，不启动浏览器（耗时 <1s）
//   - 降低 audit 重试次数（基于 0730-104200 批次真实根因：30-50% 重试可静态拦截）
//
// 检测项：
//   P001: 手动 .l2-marker/.l3-dot 误带 data-zone-id/data-element-id 属性
//   P002: CSS 缺少 [hidden]{display:none!important} 防御规则
//   P003: 导航完备性（data-nav 类型：每个 data-page-id 必须有对应 data-nav）
//         — 覆盖 spec P013(D5) 语义：data-page-id 与 data-nav 一一对应
//   P004: __ANNOTATION_DATA__ 未内联于 index.html（WARN 不阻断）
//   P005: 端口 8800 被占用（跨平台，仅检测不清理）
//   P006: main 内容区 CSS 可见性（display:none/visibility:hidden/color===background）
//         — 覆盖 spec P011(D10) 语义：main 容器不可见自查
//   P007: data-element-id 容器可见性 + .l3-dot display:none 缺激活规则
//   P008: D3 弹窗触发按钮事件线索（onclick/data-action/app.js addEventListener）
//         — 覆盖 spec P012(D3) 语义：[data-open-modal] 按钮事件绑定自查
//   P009: L3 卡片三元组重复（WARN 不阻断）
//   P010: footer 契约预检（WARN 不阻断）
//   P011: D6 启用按钮数预检（v5.15）
//   P012: D3 弹窗目标 modal 存在性预检（v5.15）
//   P013: D10 标注标记完整性预检（v5.15）
//   P014: D9 失败自查 — [data-annotation-active] .l3-dot 激活规则检测（v5.16 新增）
//   P015: 端口占用检测 — isPortFree 检测 + findFreePort 建议空闲端口（v5.18 重构：不 kill，WARN 不阻断）
//   P016: navLinks 语义化预检（v5.16 O-1）
//   P017: D3 modal 事件绑定静态检测（v5.17 Tier D，WARN 不阻断）
//         强化（first-round-bplus-guarantee）：检测"有 modal 容器但缺 data-open-modal 触发器"
//         → FAIL（21 个首轮 D 案例中多数 D3 失败根因）
//   P018: 标注数量一致性静态检测（v5.17 Tier D；v2.1 升级 FAIL 阻断）
//         根因：p2/p3 首轮审计前预检已 WARN 声明数 vs DOM 数不一致，WARN 不阻断导致无效审计；
//               p8 l3DotCount 54 vs dataElementIdCount 40（手写 dot 冗余）
//   P019: Nav link href 唯一性强制检测（first-round-bplus-guarantee，FAIL）
//         根因：tw-dsf r1 所有 href="#"，审计去重后只检测 1 个 → D10 无法导航
//   P020: 标注元素必须在 [data-page-id] 内（first-round-bplus-guarantee，FAIL）
//         根因：tw-dsf R-100 全局 sidebar 不在页面内 → D9_l2_coop FAIL
//   P021: 页面隐藏机制检测（first-round-bplus-guarantee，WARN）
//         根因：tw-dsf 用 style="display:none" 而非 hidden 属性 → 显隐不一致
//   P022: Nav link 数量与页面数匹配检测（first-round-bplus-guarantee，FAIL）
//         根因：wb-dsf 0804-154709 首轮 D，3 nav links vs 8 pages → D5/D10 大量失败
//   P023: data-element-id 必须放在块级容器上（first-round-bplus-guarantee，FAIL）
//         根因：wb-dsf2 0805-175557 首轮 D，data-element-id on button → .l3-dot rect=0x0
//         调整（first-round-bplus-guarantee-v2）：BUTTON 移出 inlineTags
//           根因：codex-dsf 38 个 data-element-id on BUTTON 实测 D8/D10 全 pass
//   P024: data-zone-id 容器必须有 anno-zone 类（first-round-bplus-guarantee，FAIL）
//         根因：wb-dsf2 0805-175557 首轮 D，缺 anno-zone → D9 协同高亮失败
//   P025: demo 必须有 data-annotation-root 属性（first-round-bplus-guarantee，FAIL）
//         根因：wb-dsf 0805-073203 首轮 D，缺 data-annotation-root → D0/D10 失败
//   P026: 首屏页面不能有 hidden 属性残留（first-round-bplus-guarantee，FAIL）
//         根因：wb-dsf 0805-073203 首轮 D，P01 hidden 残留 → 整页深蓝 → D10 全失败
//   P027: Nav link href-data-nav 一致性 + href 目标存在性（first-round-bplus-guarantee-v2，FAIL/WARN）
//         根因：tw-dsf2 r1 nav link href="#P023"（应为 #P02）— href 唯一故 P019 PASS，但目标不存在
//   P028: 空 .l2-marker 检测（first-round-bplus-guarantee-v2，FAIL）
//         根因：AI 写 HTML 时插入空 <span class="l2-marker"></span>，引擎 ensureMarkers 跳过不填序号 → D5 fail
//   P029: 重复 data-element-id 检测（first-round-bplus-guarantee-v2，FAIL）
//         根因：动态表格行模板复用同一 id，querySelector 只返回第一个 → D10 L3 dots 只激活第一行
//   P030: 隐藏祖先链锚点检测（v2.1，WARN 不阻断）
//         根因：anno-zone/data-element-id 位于 display:none 的祖先容器（wstep/stepPanel/SECTION）
//               → rect=0x0，D10 必败（p2/p3 案例：隐藏 wstep/stepPanel 内的标注必致 D10 rect=0x0）
//   P031: 触发器语义预检（v2.3，WARN 不阻断）
//         根因：btn-primary 等启发式类误判——业务按钮无 data-open-modal 也无业务属性时
//               将被 D3 运行时启发式误判为弹窗触发器（与 run-audit 选择器收紧同步的静态侧预检）
//   P032: role=dialog 位置检查（v2.3，WARN 不阻断）
//         根因：v2.2 p6 实证——role=dialog 在内层 .modal-box，事件委托 closest 命中内层
//               隐藏错元素（1 close fail + 3 级联失败）
//   P033: 显隐状态反模式检测（v2.4，WARN 不阻断）
//         根因：v2.3 p6 实证——分页函数以 style.display !== 'none' 反推筛选态，
//               行因翻页隐藏后被永久误判为已筛掉（状态污染不可逆）→ 5 个标注 rect=0x0
//   P035: 导航研发编码检测（v5.19 P1-5，WARN 不阻断）
//         契约：导航菜单项只显示业务名称，禁止显示 P01/01 等研发编码（编码仅存于 data-page-id）
//   P036: 空交互按钮静态检测（v5.19 P1-6，WARN 不阻断）
//         契约：业务按钮须有实际业务状态变化（数据增删改/视图切换/校验反馈/界面更新），
//               toast 仅可作辅助反馈不可单独成立——仅报"块体仅含一条 toast 语句"的确定嫌疑
//   P037: 跨页联动枚举一致性（v5.21 新增，FAIL 阻断 — HTML data-* 消费值必须能在 app.js 中解析为字面量）
//   P038: 筛选数据流检测（fix-double-trigger-dead-interactions 新增，WARN 不阻断）
//         根因：fto UAT——filterRisk 调 renderDashboard 但处理链从不读取 heroRiskFilter 控件值，
//               统计数字不变（无操作筛选）；SELECT/INPUT 的 case 链 BFS 深度 ≤3 须命中
//               action 选择器 / 元素 id / el.value 之一
//         v5.24：收集扩展至无 data-action 但有 id 且被自建 change/input 监听的 SELECT/INPUT
//               （UAT0826 p6 statusFilter 实证），以监听回调体为判定起点套用同一数据流判定
//   P039: 消费属性存在性检测（fix-double-trigger-dead-interactions 新增，WARN 不阻断）
//         根因：同上 UAT——filterStatusQuick 读 data-code 但 chip 元素只携带 data-status，
//               getAttribute 恒为 null（属性名错位）；case 体读取的 data-* 须被对应
//               data-action 元素实际携带
//   P040: 表格结构元素标注检测（v5.23 新增，index.html 命中 FAIL / app.js 疑似 WARN）
//         契约：tr/td/th/tbody/thead 禁止携带 data-element-id（破坏 table-row 布局），
//               须迁至行内首个交互元素（button/a 等）或行内 <span> 包裹
//               （enhance-prototype C20 可自动迁移）
//   P041: L3 序号型重复检测（v5.23 新增，WARN 不阻断 — run-audit D8 序号型检测的静态前置版）
//         根因：codex-dsf-p3 实证——"待办任务行1/2/3" 三卡归一化后三元组仅差序号
//               （T-001/002/003），建议同类元件仅标注首个实例
//         v5.24 契约分流：同类组 ≤4 实例全部标注合规（不再告警）；>4 实例才应精简至首个
//   P042: 工作根洁净检测（v5.23 新增，v5.24 层级修正，FAIL 阻断 — 从项目根向上探测 agent
//         工作根（技能包/req-cases 特征祖先），工作根无 state.yaml 的 .demora/ 或空
//         delivery/demo/docs/inbox → FAIL；项目根仅查 .demora（空 delivery 为 scaffold
//         合法骨架不再报），根因通常为历史错误 cwd 运行写入型脚本）
//   P043: 筛选显示同步静态检测（v5.24 新增，WARN 不阻断 — 状态位全集双分支写入与 display
//         仅 '1' 子集赋值不对称，疑似 filtered='0' 行未隐藏，违反 v2.4 全量重算契约）
//
// Tier 关系：enhance-prototype.mjs 自动修正 C1-C11（覆盖 P019/P021/P024/P023/P025/P026 + 隐藏元素 data-element-id 剥离 + 空 .l2-marker 移除），
//           pre-audit-check P019-P029 作为兜底检查（覆盖全部 11 项）。
//           P017 强化 + P020 + P022 + 禁止手写 .l2-marker 由 AI 手动处理（引擎 WARN 提示）。
//
// 真实根因依据（0730-104200 批次 case-01/06 重试历史）：
//   - case-01 重试2: 手动 .l2-marker 误带 data-zone-id → D5/D9/D10 连锁失败
//   - case-01 重试3: [hidden] 被 display:flex 覆盖 → D3 modal 关闭失败
//   - case-06 重试2: nav 仅 5 个 data-nav 但 DOM 有 8 个 data-page-id → D10 P05/P06/P07 全未激活
//   - case-01/06 重试1: 端口 8800 冲突 → 加载错误应用
//
// 用法：
//   node scripts/pre-audit-check.mjs --demo <demo-path>
//
// 退出码：0=预检通过（含 WARN），1=预检失败（有 FAIL 项）

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { isPortFree, findFreePort } from './lib/port-utils.mjs';

function log(msg) { process.stdout.write(msg + '\n'); }

// ===== 参数解析 =====
function parseArgs(argv) {
  const args = { demo: null, port: 8800, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') args.help = true;
    else if (a === '--demo') args.demo = argv[++i];
    else if (a === '--port') args.port = parseInt(argv[++i], 10);
  }
  return args;
}

function showHelp() {
  console.log(`Demora audit 前静态契约预检器 (v5.14.11)

用法：
  node scripts/pre-audit-check.mjs --demo <demo-path> [--port 8800]

参数：
  --demo <path>    demo 目录路径（包含 index.html）
  --port <num>     audit 将使用的 HTTP 端口（默认 8800，用于预检占用）

退出码：0=预检通过（含 WARN），1=预检失败（有 FAIL 项）`);
}

// ===== P001: 手动 marker 误带属性 =====
// 真实根因：case-01 重试2，手动 .l2-marker 带 data-zone-id 导致 ensureMarkers 重复创建嵌套 marker
function checkP001(htmlContent) {
  const issues = [];
  // 检测 <span class="l2-marker" ... data-zone-id="...">
  const l2Regex = /<span\s+class="[^"]*l2-marker[^"]*"[^>]*data-zone-id\s*=/g;
  let match;
  while ((match = l2Regex.exec(htmlContent)) !== null) {
    issues.push('手动 .l2-marker 携带 data-zone-id 属性（ensureMarkers 会重复创建嵌套 marker，导致 D5/D10 连锁失败）');
    break; // 命中一次即可
  }
  // 检测 <span class="l3-dot" ... data-element-id="...">
  const l3Regex = /<span\s+class="[^"]*l3-dot[^"]*"[^>]*data-element-id\s*=/g;
  while ((match = l3Regex.exec(htmlContent)) !== null) {
    issues.push('手动 .l3-dot 携带 data-element-id 属性（ensureMarkers 会重复创建嵌套 dot）');
    break;
  }
  return issues;
}

// ===== P002: [hidden] 防御规则 =====
// 真实根因：case-01 重试3，.pg-modal-mask{display:flex} 覆盖 modal 的 hidden 属性
function checkP002(htmlContent, cssContent) {
  const issues = [];
  const allCss = htmlContent + '\n' + cssContent;
  // 检测是否有 [hidden] 选择器且含 display:none!important
  const hiddenDefRegex = /\[hidden\]\s*\{[^}]*display\s*:\s*none\s*!important[^}]*\}/i;
  if (!hiddenDefRegex.test(allCss)) {
    issues.push('CSS 缺少 [hidden]{display:none!important} 防御规则（modal 的 hidden 属性会被 display:flex 覆盖，导致 D3 关闭失败）');
  }
  return issues;
}

// ===== P003: 导航完备性（data-nav 类型）=====
// 真实根因：case-06 重试2，nav 仅 5 个 data-nav 但 DOM 有 8 个 data-page-id
function checkP003(htmlContent) {
  const issues = [];
  // 提取所有 data-page-id 值
  const pageIds = new Set();
  const pageRegex = /data-page-id\s*=\s*"([^"]+)"/g;
  let match;
  while ((match = pageRegex.exec(htmlContent)) !== null) {
    pageIds.add(match[1]);
  }
  // 提取所有 data-nav 值
  const navIds = new Set();
  const navRegex = /data-nav\s*=\s*"([^"]+)"/g;
  while ((match = navRegex.exec(htmlContent)) !== null) {
    navIds.add(match[1]);
  }
  // 求差集：pageIds 中有但 navIds 中没有的
  // 仅当有 data-nav 类型导航时才检测（若无 data-nav，说明用 hash 类型，跳过）
  if (navIds.size > 0) {
    const missing = [];
    pageIds.forEach(pid => {
      if (!navIds.has(pid)) missing.push(pid);
    });
    if (missing.length > 0) {
      issues.push('以下页面无 data-nav 导航入口：' + missing.join(', ') + '（audit D10 无法激活这些页面的标注）');
    }
  }
  return issues;
}

// ===== P004: __ANNOTATION_DATA__ 内联位置（WARN 不阻断）=====
// 真实根因：case-06 将 __ANNOTATION_DATA__ 放在 app.js，导致 check-business-fill 静态校验降级
// 正则收紧：必须匹配赋值语句（= {），排除 if 语句和注释中的字符串
function checkP004(htmlContent) {
  const issues = [];
  // 匹配 window.__ANNOTATION_DATA__ = {（赋值语句，非 if 判断/注释）
  // 排除：if (window.__ANNOTATION_DATA__) / // ...window.__ANNOTATION_DATA__...
  const dataRegex = /window\.__ANNOTATION_DATA__\s*=\s*\{/;
  // 额外检查：赋值语句不能在注释中（// 或 /* */）
  const lines = htmlContent.split('\n');
  let found = false;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (dataRegex.test(line)) {
      // 检查是否在注释中（简单检查行首是否为 // 或在 /* */ 块内）
      const trimmed = line.trim();
      if (trimmed.startsWith('//') || trimmed.startsWith('*')) continue;
      found = true;
      break;
    }
  }
  if (!found) {
    issues.push('建议将 __ANNOTATION_DATA__ 内联于 index.html（当前可能在 app.js，导致静态校验降级为 WARN）');
  }
  return issues;
}

// ===== P005: 端口占用预检（跨平台）=====
// 真实根因：case-01/06 重试1，端口 8800 被前 case 残留 HTTP 服务器占用
// Windows 实现注意：
//   - execSync 默认 shell（cmd.exe）不支持管道符 |，findstr 会失效
//   - powershell -Command 在某些环境下调用异常
//   - 稳健方案：直接调 netstat -ano（无管道），用 Node 自己过滤含 ":port " 的行
function checkP005(port) {
  const issues = [];
  try {
    let output;
    if (process.platform === 'win32') {
      // Windows: netstat -ano 输出全部连接，用 Node 过滤
      output = execSync('netstat -ano', { encoding: 'utf-8', timeout: 5000 });
    } else {
      // Unix: lsof -i:8800 或 ss -tlnp
      try {
        output = execSync(`lsof -i:${port} 2>/dev/null`, { encoding: 'utf-8', timeout: 3000 });
      } catch (e) {
        output = execSync(`ss -tlnp 2>/dev/null`, { encoding: 'utf-8', timeout: 3000 });
      }
    }
    if (output && output.trim().length > 0) {
      // Windows: 过滤含 ":port "（带空格，避免匹配 88000）且状态为 LISTENING 的行
      // Unix: lsof/ss 输出已针对特定端口过滤，直接检查非空
      let lines = output.split('\n').filter(l => l.trim().length > 0);
      if (process.platform === 'win32') {
        // Windows netstat 输出格式：TCP  127.0.0.1:8800  0.0.0.0:0  LISTENING  12345
        lines = lines.filter(l => {
          // 匹配 ":port " 后跟空格（避免 8800 匹配 88000）
          const portRegex = new RegExp(':' + port + '\\s');
          return portRegex.test(l) && /LISTENING/i.test(l);
        });
      } else {
        // Unix lsof/ss 输出过滤表头
        lines = lines.filter(l => !l.includes('COMMAND') && !l.includes('Local'));
      }
      if (lines.length > 0) {
        if (process.platform === 'win32') {
          issues.push(`端口 ${port} 被占用，audit 会加载错误页面。释放命令：Stop-Process -Id <pid> -Force（pid 为 netstat 最后一列）`);
        } else {
          issues.push(`端口 ${port} 被占用，audit 会加载错误页面。释放命令：kill -9 <pid>（pid 见 lsof 输出）`);
        }
        log('  [INFO] 端口占用详情:');
        lines.slice(0, 5).forEach(l => log('    ' + l.trim()));
      }
    }
  } catch (e) {
    // 命令执行失败（可能命令不存在或端口未占用），跳过预检
    log('  [INFO] 端口预检跳过（netstat/lsof/ss 不可用）');
  }
  return issues;
}

// ===== 公共函数（P006-P010 使用） =====
// 从 HTML 提取所有 <style> 块内容
function extractStyleBlocks(html) {
  const blocks = [];
  const regex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let m;
  while ((m = regex.exec(html)) !== null) blocks.push(m[1]);
  return blocks.join('\n');
}
function escapeRegex(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

// 从 HTML 提取 __ANNOTATION_DATA__ 对象字面量（平衡括号匹配，M4 修复）
function extractAnnotationData(html) {
  const marker = 'window.__ANNOTATION_DATA__';
  const idx = html.indexOf(marker);
  if (idx === -1) return null;
  // 跳过赋值符号和空白
  let i = idx + marker.length;
  while (i < html.length && /[=\s]/.test(html[i])) i++;
  if (html[i] !== '{') return null;
  // 平衡括号匹配（支持嵌套对象/数组/字符串）
  let depth = 0;
  let inStr = false;
  let strCh = '';
  let start = i;
  for (; i < html.length; i++) {
    const c = html[i];
    if (inStr) {
      if (c === '\\') { i++; continue; }
      if (c === strCh) inStr = false;
    } else {
      if (c === '"' || c === "'" || c === '`') { inStr = true; strCh = c; }
      else if (c === '{' || c === '[') depth++;
      else if (c === '}' || c === ']') {
        depth--;
        if (depth === 0) { i++; break; }
      }
    }
  }
  return html.slice(start, i);
}

// ===== P006: main 内容区 CSS 可见性 =====
// 真实根因：wb-dsf-0805 P01/P02 main 深蓝背景导致 D10 L3 39/39 失败
// 修正 A3（覆盖 background 简写）+ A5（兼容单/无引号 role）
function checkP006(htmlContent, cssContent) {
  const issues = [];
  const allCss = extractStyleBlocks(htmlContent) + '\n' + cssContent;
  // Step 1: 提取 main 容器选择器（A5：[role="main"] 兼容单/无引号）
  const mainSelectors = [
    { sel: 'main', re: /(^|[\s},])main\s*\{/m },
    { sel: '[role="main"]', re: /\[role\s*=\s*["']?main["']?\]\s*\{/i },
    { sel: '.main-content', re: /\.main-content\s*\{/i },
    { sel: '#main-content', re: /#main-content\s*\{/i },
    { sel: '.page-main', re: /\.page-main\s*\{/i },
  ];
  for (const { sel, re } of mainSelectors) {
    // 找到选择器定义块
    const m = re.exec(allCss);
    if (!m) continue;
    // 提取该块的声明内容（到下一个 } ）
    const blockStart = m.index + m[0].length - 1; // 指向 {
    const blockEnd = allCss.indexOf('}', blockStart);
    if (blockEnd === -1) continue;
    const block = allCss.slice(blockStart, blockEnd);
    // 检测 display:none / visibility:hidden
    if (/display\s*:\s*none/i.test(block)) {
      issues.push(`主内容区 ${sel} 被 CSS 设为 display:none，D10 会报 L3 rect=0x0 全失败`);
    }
    if (/visibility\s*:\s*hidden/i.test(block)) {
      issues.push(`主内容区 ${sel} 被 CSS 设为 visibility:hidden，D10 会报 L3 rect=0x0 全失败`);
    }
  }
  // Step 2: 检测 main 容器 color 与 background 完全相同（A3：覆盖 background 简写）
  // 仅检测显式相同值，不推断继承（避免假阳性）
  const colorSameRegex = /(main|\.main-content)\s*\{([^}]*)\}/gi;
  let cm;
  while ((cm = colorSameRegex.exec(allCss)) !== null) {
    const blockContent = cm[2];
    // 提取 color 和 background/background-color 值（A3：精确属性名匹配）
    const colorMatch = blockContent.match(/(?:^|;|\s)color\s*:\s*(#[0-9a-f]{3,8}|\w+)/i);
    const bgMatch = blockContent.match(/(?:^|;|\s)background(?:-color)?\s*:\s*(#[0-9a-f]{3,8}|\w+)/i);
    if (colorMatch && bgMatch) {
      const cVal = colorMatch[1].toLowerCase();
      const bVal = bgMatch[1].toLowerCase();
      // 若 background 是简写含多个值（如 linear-gradient），跳过（只比对纯色值）
      if (!/gradient|url\(|repeat|center|left|right|top|bottom|cover|contain/i.test(bVal) && cVal === bVal) {
        issues.push(`主内容区 color 与 background 值相同（${cVal}），文本不可见（D10 会报 L3 激活失败）`);
      }
    }
  }
  return issues;
}

// ===== P007: data-element-id 容器可见性 =====
function checkP007(htmlContent, cssContent) {
  const issues = [];
  const allCss = extractStyleBlocks(htmlContent) + '\n' + cssContent;
  // 检测 [data-element-id] { display:none } 或 .xxx[data-element-id] { visibility:hidden }
  const regex = /\[[^]]*data-element-id[^]]*\][^{]*\{[^}]*(display\s*:\s*none|visibility\s*:\s*hidden)[^}]*\}/i;
  if (regex.test(allCss)) {
    issues.push('存在 data-element-id 容器被 CSS 设为不可见，D8/D10 会报 L3 元件不响应');
  }
  // 检测 .l3-dot { display:none } 但排除标注引擎自身设计（激活后 display:block 的正常逻辑）
  // 标注引擎正常模式：.l3-dot { display:none } + [data-annotation-active] .l3-dot { display:block }
  // 仅当 .l3-dot 有 display:none 且无 [data-annotation-active] 激活规则时才告警
  const dotHiddenRegex = /\.l3-dot\s*\{[^}]*display\s*:\s*none[^}]*\}/i;
  const dotActiveRegex = /\[data-annotation-active\][^{]*\.l3-dot[^{]*\{[^}]*display\s*:\s*block[^}]*\}/i;
  if (dotHiddenRegex.test(allCss) && !dotActiveRegex.test(allCss)) {
    issues.push('.l3-dot 被 CSS 设为 display:none 且无 [data-annotation-active] 激活规则，D9/D10 L3 协同必然失败');
  }
  return issues;
}

// ===== P008: D3 弹窗触发按钮事件线索 =====
// 修正 A4：线索4（事件委托）降权为弱线索，仅在线索1-3 全 miss 时作为参考
function checkP008(htmlContent, cssContent, demoDir) {
  const issues = [];
  // 提取所有弹窗触发按钮的 id 和 class
  const triggerRegex = /<(?:button|a|span)[^>]*(?:data-open-modal|class="[^"]*btn-(?:new|add)[^"]*")[^>]*>/gi;
  const triggers = [];
  let m;
  while ((m = triggerRegex.exec(htmlContent)) !== null) {
    const tag = m[0];
    const idMatch = tag.match(/id\s*=\s*"([^"]+)"/);
    const classMatch = tag.match(/class\s*=\s*"([^"]+)"/);
    triggers.push({ id: idMatch?.[1], class: classMatch?.[1], tag });
  }
  if (triggers.length === 0) return issues; // 无弹窗触发按钮，跳过

  // 读取 app.js（若存在）
  let appJs = '';
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (fs.existsSync(appJsPath)) appJs = fs.readFileSync(appJsPath, 'utf-8');

  for (const t of triggers) {
    const clues = [];
    // 线索1: onclick 属性（含 HTML onclick= 和 JS .onclick= 赋值）
    if (/onclick\s*=/.test(t.tag)) clues.push('onclick');
    // 线索2: data-action 属性
    if (/data-action\s*=/.test(t.tag)) clues.push('data-action');
    // 线索3: app.js 中有对应 id/class 的事件绑定（M1 修复：补 $() 辅助函数 + .onclick= 赋值模式）
    if (t.id) {
      const idPattern = `getElementById\\(['"]${escapeRegex(t.id)}['"]\\)|querySelector\\(['"]#${escapeRegex(t.id)}['"]\\)|\\$\\(['"]${escapeRegex(t.id)}['"]\\)|\\$\\(['"]#${escapeRegex(t.id)}['"]\\)`;
      if (new RegExp(idPattern).test(appJs)) {
        clues.push('app.js addEventListener');
      }
      // M1 修复：$() 风格 demo 的 .onclick= 属性赋值（0803 glm52 案例真实风格）
      if (new RegExp(`\\$\\(['"]${escapeRegex(t.id)}['"]\\)\\.onclick\\s*=`).test(appJs) ||
          new RegExp(`getElementById\\(['"]${escapeRegex(t.id)}['"]\\)\\.onclick\\s*=`).test(appJs)) {
        clues.push('app.js onclick赋值');
      }
    }
    if (t.class) {
      const cls = t.class.split(/\s+/)[0];
      if (new RegExp(`getElementsByClassName\\(['"]${escapeRegex(cls)}['"]\\)|querySelectorAll\\(['"]\\.${escapeRegex(cls)}['"]\\)`).test(appJs)) {
        clues.push('app.js addEventListener');
      }
    }
    // 线索4: 事件委托（M2 修复：仅作参考日志，不参与 pass 判定）
    const hasDelegate = /addEventListener\(['"]click['"]/.test(appJs) && /\.closest\(/.test(appJs);
    // 判定（M2 修复）：线索1-3 全 miss → FAIL（事件委托不救场，仅作参考）
    if (clues.length === 0) {
      const delegateNote = hasDelegate ? '（注：检测到事件委托但不作为通过依据）' : '';
      issues.push(`弹窗触发按钮 ${t.id || t.class || '(无id/class)'} 无任何事件绑定线索` +
        `（onclick/data-action/app.js addEventListener 均未检测到），D3 弹窗闭环必然失败${delegateNote}`);
    }
  }
  return issues;
}

// ===== P009: L3 卡片三元组重复 =====
// 修正 M3（受限 Function 解析替代直接 eval）+ M4（平衡括号提取）+ A1（WARN 不阻断）
// v5.14.18 修复 3：与 D8 语义对齐（三元组 trim + 跳过空三元组 + 包装结构兼容）
// v5.14.18 修复 7：新增同页内 id 重复检测（收窄为同页，跨页 id 复用是引擎设计支持）
// 注意：__ANNOTATION_DATA__ 是 JS 对象字面量（key 无引号），非合法 JSON，JSON.parse 会失败
// M3 折中方案：用 Function 构造器在受限 scope（无 this/无 arguments/无全局）中解析
function checkP009(htmlContent) {
  const issues = [];
  const dataStr = extractAnnotationData(htmlContent);
  if (!dataStr) return issues; // P004 已检测数据缺失，这里跳过
  let data;
  try {
    // M3：受限 Function 解析（比 eval 安全：无本地作用域访问，仅返回表达式值）
    // 数据源是本地静态 demo/index.html，AI 生成，风险可控
    data = new Function('"use strict"; return (' + dataStr + ')')();
  } catch (e) {
    // 解析失败，跳过（P004 兜底）
    return issues;
  }
  if (!data || typeof data !== 'object') return issues;

  // v5.14.18 修复 3：包装结构兼容（{version, pages: {P01:...}} vs 扁平 {P01:...}）
  // 对齐引擎 annotation-engine.js L102-103 的解包逻辑
  const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
    ? data.pages
    : data;
  const metaKeys = ['version', 'metadata', 'config', 'pages'];
  const pages = {};
  for (const pageId of Object.keys(rawData)) {
    if (metaKeys.includes(pageId)) continue;
    const pageObj = rawData[pageId];
    if (pageObj && typeof pageObj === 'object' && Array.isArray(pageObj.L3)) {
      pages[pageId] = pageObj;
    }
  }

  // 三元组判重（跨页，与 D8 语义一致）
  const groups = {}; // key: "element|function|response" → [cardId...]
  for (const pageId of Object.keys(pages)) {
    const l3 = pages[pageId].L3 || [];
    for (let idx = 0; idx < l3.length; idx++) {
      const card = l3[idx];
      // v5.14.18 修复 3：与 D8 一致，三元组各字段 trim
      const element = (card.element || '').trim();
      const func = (card.function || '').trim();
      const response = (card.response || '').trim();
      // v5.14.18 修复 3：跳过空三元组（无 element 的卡片不参与判重）
      if (!element && !func && !response) continue;
      const key = `${element}|${func}|${response}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(card.id || `${pageId}-L3-${idx}`);
    }
  }
  const dups = Object.entries(groups).filter(([_, ids]) => ids.length > 1);
  if (dups.length > 0) {
    const totalCards = dups.reduce((s, [_, ids]) => s + ids.length, 0);
    issues.push(`L3 卡片三元组重复：${dups.length} 组，共 ${totalCards} 张卡片重复，` +
      `D8_l3_duplication 会判 warn。重复卡片：` +
      dups.map(([key, ids]) => `[${ids.join(', ')}]`).join(' '));
  }

  // v5.14.18 修复 7：同页内 id 重复检测（收窄为同页，跨页 id 复用是引擎设计支持）
  // 同页内 id 重复比三元组重复更严重：会导致 querySelector 只命中第一张，与 P-A2 联动
  const samePageIdDups = [];
  for (const pageId of Object.keys(pages)) {
    const l3 = pages[pageId].L3 || [];
    const seenInPage = {};
    for (let idx = 0; idx < l3.length; idx++) {
      const card = l3[idx];
      if (!card.id) continue; // 无 id 的卡片不参与 id 判重（避免 undefined 误判）
      // v5.14.18 修复 P-3：累加计数（原 seenInPage[card.id] + 1 在 ≥3 次时仍报 2）
      seenInPage[card.id] = (seenInPage[card.id] || 0) + 1;
      if (seenInPage[card.id] > 1) {
        samePageIdDups.push({ pageId, id: card.id, count: seenInPage[card.id] });
      }
    }
  }
  if (samePageIdDups.length > 0) {
    issues.push(`L3 卡片同页内 id 重复：${samePageIdDups.length} 个 id 在同页内重复，` +
      `会导致 querySelector 只命中第一张卡片，与 P-A2(不闪烁)/P-A3(重复展示) 联动。` +
      `重复项：` + samePageIdDups.map(d => `[${d.pageId}:${d.id}×${d.count}]`).join(' '));
  }
  return issues;
}

// ===== P010: footer 契约预检 =====
// 修正 A2：WARN 不阻断（无 audit 维度兜底，FAIL 过严）
// v5.14.18 修复 F-1：body flex 检测改为块提取法，避免单条正则的 lookahead 跨块误匹配
function checkP010(htmlContent, cssContent) {
  const issues = [];
  const pageRegex = /data-page-id\s*=\s*"([^"]+)"[^>]*>([\s\S]*?)(?=data-page-id\s*=\s*"|$)/g;
  let match;
  let pagesChecked = 0;
  while ((match = pageRegex.exec(htmlContent)) !== null) {
    const pageId = match[1];
    const pageContent = match[2];
    pagesChecked++;
    if (!/<footer[\s>]/i.test(pageContent)) {
      issues.push(`页面 ${pageId} 缺少 <footer> 元素（R-7 footer 契约）`);
    } else if (/<footer[^>]*>\s*<\/footer>/i.test(pageContent)) {
      issues.push(`页面 ${pageId} 的 <footer> 元素为空（R-7 要求含版权/版本信息）`);
    }
  }
  if (pagesChecked === 0) {
    if (!/<footer[\s>]/i.test(htmlContent)) {
      issues.push('demo 缺少全局 <footer> 元素（R-7 footer 契约）');
    }
  }
  // v5.14.18 新增：检测 body 是否为横向 flex/grid 容器（会导致注入的 footer 漂移到右侧）
  // 使用块提取法：从 body { ... } 块内判断，避免单条正则的 lookahead 跨块扫描到 footer CSS
  const allCss = extractStyleBlocks(htmlContent) + '\n' + (cssContent || '');
  const bodyBlockRegex = /body\s*\{([^}]*)\}/gi;
  let bodyMatch;
  while ((bodyMatch = bodyBlockRegex.exec(allCss)) !== null) {
    const bodyBlock = bodyMatch[1];
    const hasFlex = /display\s*:\s*flex\b/i.test(bodyBlock);
    const hasGrid = /display\s*:\s*grid\b/i.test(bodyBlock);
    const hasColumnDirection = /flex-direction\s*:\s*column\b/i.test(bodyBlock);
    if ((hasFlex && !hasColumnDirection) || hasGrid) {
      issues.push('body 被设为横向 flex/grid 容器，注入的 footer 会漂移到右侧（R-7 footer 契约）。请改为 body 内部用 .layout/.app-shell 容器做 flex 布局，或 body { display:flex; flex-direction:column }');
      break; // 一次告警即可
    }
  }
  return issues;
}

// ===== P011: D6 按钮响应率预检 — 启用按钮数检测 =====
// v5.15 新增：D6 无静态预检覆盖，0 启用按钮时应预警
//   rk3 P-10 修复：原实现用 disabled/gi 全文匹配（命中 CSS/注释），且退化为"全 disabled 才告警"，
//     残留空 for 循环死代码。改为按 button 标签属性精确统计，0 启用按钮即 WARN。
function checkP011(htmlContent, demoDir) {
  const issues = [];
  // v5.16 S-7 修复：P011 增强为每页按钮数统计
  //   根因：原实现只统计总数，不按页面拆分，无法检出"单页无按钮"或"单页全 disabled"
  //   修复：按 data-page-id 拆分统计，每页独立告警
  const pageRegex = /<section[^>]*data-page-id=["']([^"']+)["'][^>]*>([\s\S]*?)(?=<section[^>]*data-page-id=|<\/body>)/gi;
  let pageMatch;
  let hasAnyPage = false;
  while ((pageMatch = pageRegex.exec(htmlContent)) !== null) {
    hasAnyPage = true;
    const pageId = pageMatch[1];
    const pageContent = pageMatch[2];
    const buttonTags = pageContent.match(/<button\b[^>]*>/gi) || [];
    const enabledButtons = buttonTags.filter(t => !/\bdisabled\b/i.test(t)).length;
    if (buttonTags.length > 0 && enabledButtons === 0) {
      issues.push({ level: 'WARN', code: 'P011', msg: '页面 ' + pageId + ': 所有 ' + buttonTags.length + ' 个 button 均为 disabled，D6 按钮响应率审计将无可用按钮', fix_command: '移除 button 标签的 disabled 属性，或 node scripts/enhance-prototype.mjs --demo demo' });
    }
    if (enabledButtons === 0 && buttonTags.length === 0) {
      issues.push({ level: 'WARN', code: 'P011', msg: '页面 ' + pageId + ': 无任何 button，D6 按钮响应率审计将无可用按钮', fix_command: '在页面 ' + pageId + ' 内添加至少 1 个启用的 <button> 元素' });
    }
  }
  // 兜底：无 data-page-id 页面时回退到全量统计
  if (!hasAnyPage) {
    const buttonTags = htmlContent.match(/<button\b[^>]*>/gi) || [];
    if (buttonTags.length === 0) return issues;
    const enabledButtons = buttonTags.filter(t => !/\bdisabled\b/i.test(t)).length;
    if (enabledButtons === 0) {
      issues.push({ level: 'WARN', code: 'P011', msg: '所有 ' + buttonTags.length + ' 个 button 均为 disabled，D6 按钮响应率审计将无可用按钮', fix_command: '移除 button 标签的 disabled 属性，或 node scripts/enhance-prototype.mjs --demo demo' });
    }
  }
  return issues;
}

// ===== P012: D3 弹窗目标存在性预检 =====
// v5.15 新增：检测 [data-open-modal] 的目标 modal 是否存在于 DOM
//   rk3 P-10 修复：原 FAIL 级误伤 JS 动态创建的 modal（运行时注入 DOM，静态 HTML 无）。
//     降为 WARN 并标注动态创建可豁免（与 D3 MutationObserver 场景对齐）。
function checkP012(htmlContent, demoDir) {
  const issues = [];
  // v5.16 S-7 修复：P012 增强 — 检测 app.js 是否动态创建 modal
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  let appJsContent = '';
  if (fs.existsSync(appJsPath)) {
    appJsContent = fs.readFileSync(appJsPath, 'utf-8');
  }
  const openModalMatches = htmlContent.matchAll(/data-open-modal\s*=\s*["']([^"']+)["']/gi);
  for (const m of openModalMatches) {
    const targetId = m[1];
    // 检测 #targetId 或 [data-modal-id="targetId"] 是否存在
    const idExists = htmlContent.includes('id="' + targetId + '"') || htmlContent.includes("id='" + targetId + "'");
    const modalIdExists = htmlContent.includes('data-modal-id="' + targetId + '"');
    if (!idExists && !modalIdExists) {
      // v5.16 S-7：检查 app.js 是否动态创建该 modal
      const jsCreated = appJsContent.includes(targetId) || appJsContent.includes('modal');
      const msg = jsCreated
        ? '弹窗触发按钮 data-open-modal="' + targetId + '" 的目标 modal #' + targetId + ' 不在静态 HTML（app.js 可能动态创建，D3 运行时审计将以 MutationObserver 为准）'
        : '弹窗触发按钮 data-open-modal="' + targetId + '" 的目标 modal #' + targetId + ' 不在静态 HTML 且 app.js 未检测到创建逻辑';
      issues.push({ level: 'WARN', code: 'P012', msg: msg, fix_command: '在 index.html 中添加 <div id="' + targetId + '" class="modal" hidden>...</div>，或在 app.js 中动态创建该 modal' });
    }
  }
  return issues;
}

// ===== P013: D10 标注标记完整性预检 =====
// v5.15 新增：检测 data-zone-id 元素是否有 .l2-marker，data-element-id 是否有 .l3-dot
// v5.18 P0-A3：从 WARN 升级为 FAIL（阻断性）——标注引擎未加载时 D5/D10 必然全失败，
//             静态预检应直接拦截，避免无效 audit 重试
// v2.3 契约修正（建议 6a 轻修法）：当"有 data-zone-id 但无 .l2-marker"时，
//   若 index.html 含引擎注入标记（[demora-annotation-js]，即 enhance-prototype 的
//   INJECT_JS_START/END 注释标记）→ 降为 INFO 不阻断：
//     依据：v2.2 实证 6/6 案例首次 pre-audit 100% FAIL 于本项均为假阳性——
//           annotation-engine.js 的 ensureMarkers() 运行时会为每个 data-zone-id 自动创建
//           .l2-marker（.l3-dot 同理），静态契约（HTML 必须已有 marker）与运行时契约
//           （引擎自动创建）矛盾，agent 白费 1.5-8.9m/案
//   若无注入标记 → 维持 FAIL（真·引擎未加载，修复命令不变）
function checkP013(htmlContent, demoDir) {
  const issues = [];
  // v2.3：引擎注入标记检测（enhance-prototype.mjs INJECT_JS_START/END 均含 [demora-annotation-js]）
  const engineInjected = htmlContent.includes('[demora-annotation-js]');
  // 检测是否有 data-zone-id 但无 .l2-marker（标注引擎未加载的强信号）
  const zoneIdCount = (htmlContent.match(/data-zone-id\s*=/gi) || []).length;
  const l2MarkerCount = (htmlContent.match(/class\s*=\s*["'][^"']*l2-marker/gi) || []).length;
  if (zoneIdCount > 0 && l2MarkerCount === 0) {
    if (engineInjected) {
      // v2.3 契约修正：引擎已注入 → marker 由运行时 ensureMarkers 自动创建，降为 INFO 不阻断
      issues.push({ level: 'INFO', code: 'P013', msg: 'P013: 有 ' + zoneIdCount + ' 个 data-zone-id 但无 .l2-marker——标注引擎已注入，.l2-marker 将由运行时 ensureMarkers 自动创建（v2.3 P013 契约修正），不阻断' });
    } else {
      issues.push({ level: 'FAIL', code: 'P013', msg: '有 ' + zoneIdCount + ' 个 data-zone-id 但无 .l2-marker（标注引擎未加载）。修复：node scripts/enhance-prototype.mjs --demo demo 重新注入标注引擎；若注入标记存在则检查 annotation-engine.js 是否被覆盖', fix_command: 'node scripts/enhance-prototype.mjs --demo demo  # FAIL 阻断：重新注入标注引擎（annotation-engine.js）' });
    }
  }
  const elementIdCount = (htmlContent.match(/data-element-id\s*=/gi) || []).length;
  const l3DotCount = (htmlContent.match(/class\s*=\s*["'][^"']*l3-dot/gi) || []).length;
  if (elementIdCount > 0 && l3DotCount === 0) {
    if (engineInjected) {
      // v2.3 契约修正：引擎已注入 → dot 由运行时 ensureMarkers 自动创建，降为 INFO 不阻断
      issues.push({ level: 'INFO', code: 'P013', msg: 'P013: 有 ' + elementIdCount + ' 个 data-element-id 但无 .l3-dot——标注引擎已注入，.l3-dot 将由运行时 ensureMarkers 自动创建（v2.3 P013 契约修正），不阻断' });
    } else {
      issues.push({ level: 'FAIL', code: 'P013', msg: '有 ' + elementIdCount + ' 个 data-element-id 但无 .l3-dot（标注引擎未加载）。修复：node scripts/enhance-prototype.mjs --demo demo 重新注入标注引擎；若注入标记存在则检查 annotation-engine.js 是否被覆盖', fix_command: 'node scripts/enhance-prototype.mjs --demo demo  # FAIL 阻断：重新注入标注引擎（annotation-engine.js）' });
    }
  }
  return issues;
}

// ===== P014: D9 失败自查 — [data-annotation-active] .l3-dot 激活规则检测 =====
// v5.16 新增（spec Tier 2 Task 6.4）
//   根因：D9 标注面板交互链路验证依赖 .l3-dot 在 [data-annotation-active] 状态下
//         切换为 display:block。若 CSS 缺少该激活规则，D9/D10 L3 dot 激活会全失败。
//   判定标准：CSS 中应至少 1 条匹配以下模式之一：
//     - [data-annotation-active] 与 .l3-dot 共同出现在同一选择器（含组合选择器）
//     - .l3-dot.is-active 选择器
//     - .l3-dot[data-annotation-active] 选择器
//   与 P007 的区别：P007 仅在 .l3-dot 有 display:none 时才检测激活规则缺失；
//                   P014 无条件检测激活规则是否存在（覆盖无 display:none 但缺激活规则的场景）
function checkP014(htmlContent, cssContent) {
  const issues = [];
  const allCss = extractStyleBlocks(htmlContent) + '\n' + (cssContent || '');
  // 过滤 CSS 注释（避免注释中的关键词导致误判，如 /* [data-annotation-active] .l3-dot { display:block } */）
  const cssWithoutComments = allCss
    .replace(/\/\*[\s\S]*?\*\//g, '')  // 移除 /* */ 块注释
    .replace(/\/\/.*$/gm, '');          // 移除 // 行注释（如存在）
  const lines = cssWithoutComments.split('\n');
  let found = false;
  for (const line of lines) {
    // 同一行内同时包含 data-annotation-active 和 l3-dot（选择器组合，如 [data-annotation-active] .l3-dot { ... }）
    if (/data-annotation-active/i.test(line) && /l3-dot/i.test(line)) {
      found = true; break;
    }
    // .l3-dot.is-active 选择器
    if (/l3-dot\.is-active/i.test(line)) {
      found = true; break;
    }
    // .l3-dot[data-annotation-active] 选择器
    if (/l3-dot\[data-annotation-active\]/i.test(line)) {
      found = true; break;
    }
  }
  if (!found) {
    issues.push({ level: 'FAIL', code: 'P014', msg: 'CSS 缺少 [data-annotation-active] .l3-dot { display:block } 或 .l3-dot.is-active 激活规则，D9/D10 L3 dot 激活会全失败。修复建议：添加 [data-annotation-active] .l3-dot { display: block; } 规则', fix_command: '在 <style> 中添加：[data-annotation-active] .l3-dot { display: block; }' });
  }
  return issues;
}

// ===== P015: 端口占用检测 + 建议空闲端口（v5.18 重构：从"清理 + kill"改为"检测 + 建议"）=====
//   原实现（v5.16）：调用 cleanupPort kill 残留进程
//   新实现（v5.18）：只检测端口是否被占用，不 kill；被占时建议下一个空闲端口
//   原因：用户约束"不 kill 任何冲突端口"（无法确认被占端口真实用途）
//   判定标准：
//     - isPortFree 返回 true（端口空闲）→ [OK]
//     - isPortFree 返回 false（端口被占）→ [WARN] 不阻断，建议用 findFreePort 找到的空闲端口
//       （run-audit 启动时会用 findFreePort 自动累加找空闲端口，不再硬阻断）
async function checkP015(port) {
  const issues = [];
  const portFree = await isPortFree(port, { logger: log });
  if (!portFree) {
    // 检测下一个空闲端口（从 port+1 开始，最多尝试 20 个）
    const nextFree = await findFreePort(port + 1, 20, { logger: log });
    const suggest = nextFree !== null
      ? '建议用 --port ' + nextFree + ' 重跑，或 run-audit 会自动切换到此端口'
      : '从 ' + (port + 1) + ' 起连续 20 个端口均被占用，请手动指定空闲端口';
    issues.push({
      level: 'WARN',
      code: 'P015',
      msg: '端口 ' + port + ' 被占用（不 kill 冲突进程）。' + suggest,
      fix_command: nextFree !== null
        ? 'node scripts/pre-audit-check.mjs --demo demo --port ' + nextFree + '  # 切换到空闲端口'
        : 'node scripts/pre-audit-check.mjs --demo demo --port <空闲端口>  # 手动指定空闲端口'
    });
  }
  return issues;
}

// ===== P016: navLinks 语义化预检（v5.16 O-1 新增）=====
//   根因：precheck-compliance navLinks text 仅 "P01"~"P07" 占位符，无语义化中文标签
//   修复：检测纯占位符文本（P01-P99, Page1-Page99 等），WARN 提示替换为语义化标签
function checkP016(htmlContent, demoDir) {
  const issues = [];
  // 匹配 data-nav="..." 的导航项及其文本内容
  const navMatches = htmlContent.matchAll(/data-nav\s*=\s*["']([^"']+)["'][^>]*>([^<]+)</gi);
  for (const m of navMatches) {
    const navId = m[1];
    const navText = m[2].trim();
    // 检测纯占位符文本（P01-P99, Page1-Page99, 页面1-页面99 等）
    if (/^(P\d{2}|Page\s*\d+|页面\s*\d+)$/i.test(navText)) {
      issues.push({ level: 'WARN', code: 'P016', msg: '导航项 ' + navId + ' 文本为占位符 "' + navText + '"，建议替换为语义化中文标签', fix_command: '将 nav link 文本 "' + navText + '" 替换为语义化中文标签（如"工作台"/"案件台账"/"统计分析"）' });
    }
  }
  // 也检测 a[href="#nav-PXX"] 的 hash 链接文本
  const hashNavMatches = htmlContent.matchAll(/href\s*=\s*["']#nav-([^"']+)["'][^>]*>([^<]+)</gi);
  for (const m of hashNavMatches) {
    const navId = m[1];
    const navText = m[2].trim();
    if (/^(P\d{2}|Page\s*\d+|页面\s*\d+)$/i.test(navText)) {
      issues.push({ level: 'WARN', code: 'P016', msg: '导航项 #nav-' + navId + ' 文本为占位符 "' + navText + '"，建议替换为语义化中文标签', fix_command: '将 nav link 文本 "' + navText + '" 替换为语义化中文标签（如"工作台"/"案件台账"/"统计分析"）' });
    }
  }
  return issues;
}

// ===== P017: D3 modal 事件绑定静态检测（v5.17 Tier D 新增）=====
//   注：spec 原编号为 P016，但 P016 已被 v5.16 O-1 navLinks 语义化占用，故改编号为 P017
//   背景：A/B 测试 codex-dsf 1st 审计 D3 失败 — "查看全部案件" 有 data-open-modal 但无事件绑定
//   与 P008 的区别：P008 检测按钮 id/class 在 app.js 中的引用（FAIL 级）；
//                   P017 检测 modalId 在 app.js 中的引用（WARN 级，互补非冗余）
//   判定：[data-open-modal] 按钮无 onclick 且 app.js 不含 modalId/openModal → WARN（非阻断）
function checkP017(htmlContent, demoDir) {
  const issues = [];
  // first-round-bplus-guarantee 强化：检测"有 modal 容器但缺 data-open-modal 触发器"
  //   根因：21 个首轮 D 案例中多数 D3 modal 失败，弹窗触发按钮缺 data-open-modal 属性
  //   注意：modal class 正则仅匹配完整 class 名 "modal"（不匹配 modal-title/modal-mask 等）
  //         兼容单双引号；data-modal 属性也算 modal 容器
  const modalClassRegex = /class\s*=\s*["'](?:[^"']*\s)?modal(?:\s[^"']*)?["']/gi;
  const modalAttrRegex = /\bdata-modal\b/i;
  const triggerRegex = /\bdata-open-modal\s*=/gi;
  const modalClassCount = (htmlContent.match(modalClassRegex) || []).length;
  const modalAttrCount = modalAttrRegex.test(htmlContent) ? 1 : 0;
  const triggerCount = (htmlContent.match(triggerRegex) || []).length;
  const modalCount = modalClassCount + modalAttrCount;
  if (modalCount > 0 && triggerCount === 0) {
    issues.push({
      level: 'FAIL',
      code: 'P017',
      msg: '存在 ' + modalCount + ' 个 modal 容器但无 [data-open-modal] 触发器，D3 闭环测试将失败。\n' +
        '  修复示例：\n' +
        '    <button data-open-modal="pledgeModal">新建质押</button>\n' +
        '    ...\n' +
        '    <div id="pledgeModal" class="modal">...</div>\n' +
        '  预期效果：D3 可检测到 data-open-modal 触发器并完成弹窗闭环',
      fix_command: '为 modal 容器添加触发器：<button data-open-modal="modalId">打开</button>，modalId 需与 modal 的 id 一致'
    });
  }
  const openModalBtns = htmlContent.matchAll(/data-open-modal\s*=\s*["']([^"']+)["']/gi);
  // 读取 app.js
  let appJsContent = '';
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (fs.existsSync(appJsPath)) {
    appJsContent = fs.readFileSync(appJsPath, 'utf-8');
  }
  for (const m of openModalBtns) {
    const modalId = m[1];
    // 查找该按钮标签是否有 onclick 属性（向后查找 <...> 标签边界）
    const btnTagStart = m.index;
    const btnTagEnd = htmlContent.indexOf('>', btnTagStart);
    const btnTag = btnTagEnd > 0 ? htmlContent.slice(btnTagStart, btnTagEnd) : '';
    const hasOnclick = /onclick\s*=/.test(btnTag);
    // 检测 app.js 是否含 modalId 或 openModal/showModal 函数
    const hasListener = appJsContent.includes(modalId) || appJsContent.includes('openModal') || appJsContent.includes('showModal');
    if (!hasOnclick && !hasListener) {
      issues.push({ level: 'WARN', code: 'P017', msg: '[data-open-modal="' + modalId + '"] 按钮无事件绑定（D3 将失败）。修复：添加 onclick 或在 app.js 中 addEventListener 绑定 openModal(' + modalId + ')', fix_command: '为按钮添加 onclick="openModal(\'' + modalId + '\')" 或在 app.js 中：document.querySelector(\'[data-open-modal=\"' + modalId + '\"]\').addEventListener(\'click\', () => openModal(\'' + modalId + '\'))' });
    }
  }
  return issues;
}

// ===== P018: 标注数量一致性静态检测（v5.17 Tier D 新增；v2.1 升级 FAIL）=====
//   注：spec 原编号为 P017，因 P016 冲突顺延为 P018
//   背景：tw-dsf2 多次审计失败于 D10 — 标注声明与 DOM 不一致
//   v2.1 升级：p2/p3 案例中声明数 vs DOM 数不一致在首轮审计前的预检中就已 WARN，
//             但 WARN 不阻断导致无效审计重试 → 升级 FAIL 静态拦截
//   判定：__ANNOTATION_DATA__ 声明的 L3 总数 vs DOM [data-element-id] 数量不一致 → FAIL（阻断）
function checkP018(htmlContent) {
  const issues = [];
  const dataStr = extractAnnotationData(htmlContent);
  if (!dataStr) return issues; // 无标注数据，P004 已兜底
  let data;
  try {
    data = new Function('"use strict"; return (' + dataStr + ')')();
  } catch (e) {
    return issues; // 解析失败，P009 已兜底
  }
  if (!data || typeof data !== 'object') return issues;

  // 解包：{version, pages: {P01:...}} vs 扁平 {P01:...}
  const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
    ? data.pages
    : data;
  const metaKeys = ['version', 'metadata', 'config', 'pages'];

  // 统计声明的 L3 总数（遍历所有页面的 L3 数组）
  let declaredL3 = 0;
  for (const pageId of Object.keys(rawData)) {
    if (metaKeys.includes(pageId)) continue;
    const pageObj = rawData[pageId];
    if (pageObj && typeof pageObj === 'object' && Array.isArray(pageObj.L3)) {
      declaredL3 += pageObj.L3.length;
    }
  }

  // 统计 DOM [data-element-id] 数量
  // v2.1：剥离 script/style/comment 后计数（P029/C11 同模式）
  //   根因：注入的 annotation-engine.js 代码含 data-element-id 选择器字符串（3 处），
  //         全文计数被污染 → 升级 FAIL 后会在正常 demo 上误报阻断（冒烟实测假一致）
  const cleanHtmlP018 = htmlContent
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const domL3Matches = cleanHtmlP018.match(/data-element-id\s*=/gi) || [];
  const domL3 = domL3Matches.length;

  // 数量不一致 → FAIL（v2.1 升级：p2/p3 预检 WARN 未阻断导致无效审计，改为静态拦截）
  if (declaredL3 > 0 && domL3 > 0 && declaredL3 !== domL3) {
    issues.push({ level: 'FAIL', code: 'P018', msg: '标注数量不一致：__ANNOTATION_DATA__ 声明 L3 ' + declaredL3 + ' 个，DOM data-element-id ' + domL3 + ' 个（D10 将报激活失败）。修复：删除手写 .l3-dot 或对齐 __ANNOTATION_DATA__ 声明数', fix_command: '删除手写 .l3-dot（node scripts/enhance-prototype.mjs --demo demo 自动处理）或对齐 __ANNOTATION_DATA__ 声明数' });
  }
  return issues;
}

// ===== P019-P026: first-round-bplus-guarantee 新增（兜底 enhance-prototype.mjs 自动修正）=====

// P019: Nav link href 唯一性强制检测
//   根因：tw-dsf r1 所有 nav links 用 href="#"，审计去重后只检测到 1 个 → D10 无法导航
//   判定：[data-nav] 元素的 href 重复 → FAIL（强制阻断）
//   注意：正则用 \bdata-nav\s*= 精确匹配属性名（不匹配 data-nav-type 等）
// P027: Nav link href-data-nav 一致性 + href 目标存在性（first-round-bplus-guarantee-v2 新增）
//   根因：tw-dsf2 r1 nav link href="#P023"（应为 #P02）— href 唯一故 P019 PASS，但目标页面不存在
//   判定：href 与 data-nav 不一致且目标 [id=hrefVal]/[data-page-id=hrefVal] 均不存在 → FAIL（高概率 typo）
//         href 与 data-nav 不一致但目标存在 → WARN（低概率问题）
//   注意：href 为空或 "#" 交给 P019 处理；endsWith "-" / "_" 前缀匹配覆盖 codex-dsf "#nav-P01" 模式
function checkP019(htmlContent) {
  const issues = [];
  // 匹配含 data-nav 属性的開标签（兼容单双引号）
  const navTagRegex = /<\w+\s[^>]*\bdata-nav\s*=\s*["'][^"']*["'][^>]*>/gi;
  const hrefs = [];
  let m;
  while ((m = navTagRegex.exec(htmlContent)) !== null) {
    const hrefMatch = m[0].match(/href\s*=\s*["']([^"']*)["']/i);
    hrefs.push(hrefMatch ? hrefMatch[1] : '');
  }
  // 检测重复 href（出现 ≥ 2 次的值）
  const seen = {};
  const duplicates = [];
  for (const h of hrefs) {
    seen[h] = (seen[h] || 0) + 1;
    if (seen[h] === 2) duplicates.push(h);
  }
  if (duplicates.length > 0) {
    const dupCount = duplicates.reduce((s, h) => s + seen[h], 0);
    issues.push({
      level: 'FAIL',
      code: 'P019',
      msg: 'Nav link href 重复：' + dupCount + ' 个 nav link 使用重复 href（' + duplicates.slice(0, 3).map(h => '"' + h + '"').join(', ') + '）。审计去重后只检测到唯一链接，D10 将无法导航到所有页面。\n' +
        '  修复示例：\n' +
        '    <a href="#P01" data-nav="P01">工作台</a>\n' +
        '    <a href="#P02" data-nav="P02">案件台账</a>\n' +
        '    <a href="#P03" data-nav="P03">统计分析</a>\n' +
        '  预期效果：审计将检测到 ' + hrefs.length + ' 个唯一 nav link，D10 可正常导航',
      fix_command: '为每个 nav link 设置唯一 href（如 #P01/#P02/#P03），或 node scripts/enhance-prototype.mjs --demo demo  # C1 自动修正'
    });
  }
  return issues;
}

// P027: Nav link href-data-nav 一致性 + href 目标存在性（first-round-bplus-guarantee-v2 新增）
//   详见 checkP019 上方注释。本函数处理"href 唯一但可能错误"的场景。
function checkP027(htmlContent) {
  const issues = [];
  // 匹配含 data-nav 属性的開标签（与 P019 同正则）
  const navTagRegex = /<\w+\s[^>]*\bdata-nav\s*=\s*["']([^"']*)["'][^>]*>/gi;
  // 预提取所有 [id=...] 和 [data-page-id=...] 值，用于目标存在性检查
  const idValues = new Set();
  const idRegex = /\bid\s*=\s*["']([^"']+)["']/gi;
  let idM;
  while ((idM = idRegex.exec(htmlContent)) !== null) {
    idValues.add(idM[1]);
  }
  const pageIdValues = new Set();
  const pageIdRegex = /\bdata-page-id\s*=\s*["']([^"']+)["']/gi;
  let pM;
  while ((pM = pageIdRegex.exec(htmlContent)) !== null) {
    pageIdValues.add(pM[1]);
  }

  const typos = [];
  const warnings = [];
  let navMatch;
  while ((navMatch = navTagRegex.exec(htmlContent)) !== null) {
    const fullTag = navMatch[0];
    const dataNavVal = navMatch[1];
    const hrefMatch = fullTag.match(/\shref\s*=\s*["']([^"']*)["']/i);
    const href = hrefMatch ? hrefMatch[1] : '';
    // 去除前导 # 得到 hrefVal（如 "#P023" → "P023"，"#nav-P01" → "nav-P01"）
    const hrefVal = href.replace(/^#/, '');

    // 情况 1：href 为空或 "#" → 交给 P019 处理（重复 href 检测）
    if (hrefVal === '') continue;

    // 情况 2：href 与 data-nav 一致（含前缀匹配）→ PASS
    //   一致：hrefVal == dataNavVal（如 "#P01" vs "P01"）
    //   前缀匹配：hrefVal endsWith "-" + dataNavVal（如 "#nav-P01" vs "P01"）
    //             hrefVal endsWith "_" + dataNavVal
    if (hrefVal === dataNavVal) continue;
    if (dataNavVal && (hrefVal.endsWith('-' + dataNavVal) || hrefVal.endsWith('_' + dataNavVal))) continue;

    // 情况 3：href 与 data-nav 不一致 → 检查 href 目标是否存在
    const hasIdMatch = idValues.has(hrefVal);
    const hasPageMatch = pageIdValues.has(hrefVal);
    if (!hasIdMatch && !hasPageMatch) {
      // href 目标不存在 + 与 data-nav 不一致 → 高概率 typo
      typos.push({ href: href, dataNav: dataNavVal, hrefVal: hrefVal });
    } else {
      // href 目标存在但与 data-nav 不一致 → 低概率问题，仅 WARN
      warnings.push({ href: href, dataNav: dataNavVal, hrefVal: hrefVal });
    }
  }

  if (typos.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P027',
      msg: typos.length + ' 个 nav link href 与 data-nav 不一致且目标不存在（高概率 typo）：' +
        typos.slice(0, 3).map(t => `href="${t.href}" vs data-nav="${t.dataNav}"`).join('; ') +
        '。href 目标 [id="' + typos[0].hrefVal + '"] / [data-page-id="' + typos[0].hrefVal + '"] 均不存在，D5/D10 hash 导航将失败。\n' +
        '  修复示例：\n' +
        '    <a href="#' + typos[0].dataNav + '" data-nav="' + typos[0].dataNav + '">...</a>\n' +
        '  预期效果：href 与 data-nav 一致，hash 导航可正确定位页面',
      fix_command: '修正 href 使其与 data-nav 一致：<a href="#' + typos[0].dataNav + '" data-nav="' + typos[0].dataNav + '">'
    });
  }
  if (warnings.length > 0) {
    issues.push({
      level: 'WARN',
      code: 'P027',
      msg: warnings.length + ' 个 nav link href 与 data-nav 不一致但目标存在（低概率问题）：' +
        warnings.slice(0, 3).map(w => `href="${w.href}" vs data-nav="${w.dataNav}"`).join('; ') +
        '。建议统一 href 与 data-nav 值以避免歧义。',
      fix_command: '统一 href 与 data-nav 值：将 href="' + warnings[0].href + '" 改为 href="#' + warnings[0].dataNav + '"'
    });
  }
  return issues;
}

// P028: 空 .l2-marker 检测（first-round-bplus-guarantee-v2 新增）
//   根因：AI 写 HTML 时插入空 <span class="l2-marker"></span>（textContent 为空），
//         标注引擎 ensureMarkers 检测到已存在 .l2-marker 则跳过不填充数字序号
//         → D5_l2_marker_seq 检测到 marker 无序号 → fail
//   判定：HTML 中存在 class 含 l2-marker 且 textContent 为空的 <span> → FAIL
//   正则：匹配 <span class="...l2-marker..."></span>（开闭标签紧邻或仅含空白）
//   修复：删除空 marker 让引擎自动创建，或填充数字序号
function checkP028(htmlContent) {
  const issues = [];
  // 去除 script/style/comment 后扫描，避免 JS 模板字符串中的占位符导致假阳性
  const cleanHtml = htmlContent
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const emptyL2MarkerRegex = /<span\s+[^>]*\bclass\s*=\s*["'][^"']*\bl2-marker\b[^"']*["'][^>]*>\s*<\/span>/gi;
  const matches = cleanHtml.match(emptyL2MarkerRegex) || [];
  if (matches.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P028',
      msg: '存在 ' + matches.length + ' 个空 .l2-marker（无 textContent），D5_l2_marker_seq 将 fail。修复：删除空 marker 让引擎自动创建带数字序号，或填充数字序号',
      fix_command: '删除空 <span class="l2-marker"></span> 让引擎自动创建，或填充数字序号（如 <span class="l2-marker">1</span>）；或 node scripts/enhance-prototype.mjs --demo demo  # C5 自动修正'
    });
  }
  return issues;
}

// P029: 重复 data-element-id 检测（first-round-bplus-guarantee-v2 新增）
//   根因：动态表格行模板复用同一 data-element-id，renderReport/renderCaseList 生成 N 行时 id 重复
//         → 标注引擎 querySelector('[data-element-id="xxx"]') 只返回第一个匹配
//         → D10 L3 dots 只激活第一个匹配的行，其余行无标注
//   判定：HTML 中存在重复的 data-element-id 值 → FAIL
//   注意：去除 script/style/comment 后扫描，避免 JS 模板字符串中的占位符导致假阳性
//   修复：动态表格行模板用唯一 id（如 data-element-id="case-row-${idx}"）
function checkP029(htmlContent) {
  const issues = [];
  const cleanHtml = htmlContent
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const elementIdRegex = /\bdata-element-id\s*=\s*["']([^"']+)["']/gi;
  const counts = {};
  let m;
  while ((m = elementIdRegex.exec(cleanHtml)) !== null) {
    counts[m[1]] = (counts[m[1]] || 0) + 1;
  }
  const dups = Object.keys(counts).filter(id => counts[id] > 1);
  if (dups.length > 0) {
    const totalDup = dups.reduce((s, id) => s + counts[id], 0);
    issues.push({
      level: 'FAIL',
      code: 'P029',
      msg: '存在 ' + dups.length + ' 个重复的 data-element-id（共 ' + totalDup + ' 次出现：' +
        dups.slice(0, 3).map(id => '"' + id + '" x' + counts[id]).join(', ') +
        (dups.length > 3 ? '...' : '') + '），D10 L3 dots 只激活第一个匹配。修复：动态表格行模板用唯一 id',
      fix_command: '为重复的 data-element-id 添加唯一后缀：data-element-id="' + dups[0] + '-${idx}"（动态模板用行号 idx 拼接唯一 id）'
    });
  }
  return issues;
}

// P020: 标注元素必须在 [data-page-id] 内
//   根因：tw-dsf R-100 全局 sidebar 不在页面内 → D9.3 点击 marker 后查 zone 找不到
//   判定：[data-zone-id]/[data-element-id] 不在任何 [data-page-id] 范围内 → FAIL
//   注意：去除 script/style/comment 后扫描，避免模板字符串假阳性
function checkP020(htmlContent) {
  const issues = [];
  // 去除 script/style/comment，避免 JS 模板字符串中的 data-zone-id 导致假阳性
  const stripped = htmlContent
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  // 构建 page 范围：每个 data-page-id 出现位置到下一个 data-page-id（或字符串末尾）
  const pageStarts = [];
  const pageRegex = /data-page-id\s*=\s*["'][^"']*["']/gi;
  let pm;
  while ((pm = pageRegex.exec(stripped)) !== null) {
    pageStarts.push(pm.index);
  }
  if (pageStarts.length === 0) return issues; // 无页面，P003 已兜底
  // 扫描标注元素，检查是否在任一 page 范围内
  const annoRegex = /data-(?:zone-id|element-id)\s*=\s*["']([^"']+)["']/gi;
  const orphans = [];
  let am;
  while ((am = annoRegex.exec(stripped)) !== null) {
    const pos = am.index;
    let inPage = false;
    for (let i = 0; i < pageStarts.length; i++) {
      const start = pageStarts[i];
      const end = i + 1 < pageStarts.length ? pageStarts[i + 1] : stripped.length;
      if (pos >= start && pos < end) { inPage = true; break; }
    }
    if (!inPage) orphans.push(am[1]);
  }
  if (orphans.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P020',
      msg: orphans.length + ' 个标注元素不在任何 [data-page-id] 页面内：' + orphans.slice(0, 3).join(', ') + '。D9/D10 将无法在可见页面内找到这些元素。\n' +
        '  修复示例：\n' +
        '    将 <div data-zone-id="' + orphans[0] + '">...</div> 移入对应页面：\n' +
        '    <section data-page-id="P01">\n' +
        '      ...\n' +
        '      <div data-zone-id="' + orphans[0] + '">...</div>\n' +
        '    </section>\n' +
        '  预期效果：D9_l2_coop 可在可见页面内找到 zone → 高亮激活成功',
      fix_command: '将标注元素 <div data-zone-id="' + orphans[0] + '"> 移入对应 <section data-page-id="PXX"> 容器内'
    });
  }
  return issues;
}

// P021: 页面隐藏机制检测
//   根因：tw-dsf 用 style="display:none" 而非 hidden 属性 → flex/grid 布局可能覆盖
//   判定：[data-page-id] 用 style="display:none" 且无 hidden 属性 → WARN（非阻断）
//   注意：hidden 属性检测用 (?:^|\s)hidden(?:\s*=|\s|>|/) 排除 class="hidden" / data-hidden 等
function checkP021(htmlContent) {
  const issues = [];
  const tagRegex = /<\w+\s[^>]*\bdata-page-id\s*=\s*["']([^"']*)["'][^>]*>/gi;
  const wrongHide = [];
  let m;
  while ((m = tagRegex.exec(htmlContent)) !== null) {
    const fullTag = m[0];
    const pageId = m[1];
    const hasHidden = /(?:^|\s)hidden(?:\s*=|\s|>|\/)/i.test(fullTag);
    const hasDisplayStyle = /style\s*=\s*["'][^"']*display\s*:\s*none[^"']*["']/i.test(fullTag);
    if (!hasHidden && hasDisplayStyle) {
      wrongHide.push(pageId);
    }
  }
  if (wrongHide.length > 0) {
    issues.push({
      level: 'WARN',
      code: 'P021',
      msg: '页面 ' + wrongHide.join(', ') + ' 用 style="display:none" 隐藏而非 hidden 属性。flex/grid 布局可能覆盖 inline style。\n' +
        '  修复建议：使用 hidden 属性 + CSS [hidden]{display:none!important}',
      fix_command: '将 style="display:none" 替换为 hidden 属性，并在 CSS 中添加 [hidden]{display:none!important}；或 node scripts/enhance-prototype.mjs --demo demo  # C2 自动修正'
    });
  }
  return issues;
}

// P022: Nav link 数量与页面数匹配检测
//   根因：wb-dsf 0804-154709 首轮 D，3 nav links vs 8 pages → D5/D10 大量失败
//   判定：[data-nav] 数量 < [data-page-id] 数量 → FAIL
function checkP022(htmlContent) {
  const issues = [];
  const navCount = (htmlContent.match(/\bdata-nav\s*=\s*["']/gi) || []).length;
  const pageCount = (htmlContent.match(/\bdata-page-id\s*=\s*["']/gi) || []).length;
  if (pageCount > 0 && navCount < pageCount) {
    issues.push({
      level: 'FAIL',
      code: 'P022',
      msg: 'Nav link 数量(' + navCount + ') < 页面数(' + pageCount + ')。' + (pageCount - navCount) + ' 个页面无法导航，D5/D10 将失败。\n' +
        '  修复示例：为每个 [data-page-id] 添加对应的 nav link\n' +
        '    <a href="#P01" data-nav="P01">工作台</a>\n' +
        '    <a href="#P02" data-nav="P02">案件台账</a>\n' +
        '  预期效果：nav link 数量 ≥ 页面数，D5/D10 可激活所有页面',
      fix_command: '为缺失的 ' + (pageCount - navCount) + ' 个页面各添加一个 nav link：<a href="#PXX" data-nav="PXX">页面名</a>'
    });
  }
  return issues;
}

// P023: data-element-id 必须放在块级容器上
//   根因：wb-dsf2 0805-175557 首轮 D，data-element-id on button → .l3-dot rect=0x0
//   判定：[data-element-id] 在内联元素（INPUT/A/SPAN/I/LABEL/SELECT/TEXTAREA）上 → FAIL
//   注意：BUTTON 已移出 inlineTags（first-round-bplus-guarantee-v2）
//     根因：codex-dsf 38 个 data-element-id on BUTTON 实测 D8/D10 全 pass，
//           标注引擎对 BUTTON 上 data-element-id 能正常创建 .l3-dot（绝对定位）
//     C4 不再包裹 BUTTON（避免破坏按钮布局）
function checkP023(htmlContent) {
  const issues = [];
  const inlineTags = ['INPUT', 'A', 'SPAN', 'I', 'LABEL', 'SELECT', 'TEXTAREA'];
  const tagRegex = /<(\w+)\s[^>]*\bdata-element-id\s*=\s*["'][^"']*["'][^>]*>/gi;
  const wrongInline = [];
  let m;
  while ((m = tagRegex.exec(htmlContent)) !== null) {
    const tagName = m[1].toUpperCase();
    if (inlineTags.includes(tagName)) {
      const idMatch = m[0].match(/data-element-id\s*=\s*["']([^"']*)["']/i);
      wrongInline.push({ tag: tagName, id: idMatch ? idMatch[1] : '' });
    }
  }
  if (wrongInline.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P023',
      msg: wrongInline.length + ' 个 data-element-id 放在内联元素上：' + wrongInline.slice(0, 3).map(e => e.tag + '#' + e.id).join(', ') + '。标注引擎注入的 .l3-dot 作为子元素无法渲染（rect=0x0），D8/D10 将失败。\n' +
        '  修复示例：\n' +
        '    <div data-element-id="btn-save">\n' +
        '      <button>保存</button>\n' +
        '    </div>\n' +
        '  预期效果：.l3-dot 作为 div 子元素可正常渲染',
      fix_command: '将 data-element-id 从 <' + wrongInline[0].tag + '> 移到块级容器上：<div data-element-id="' + wrongInline[0].id + '"><' + wrongInline[0].tag.toLowerCase() + '>...</' + wrongInline[0].tag.toLowerCase() + '></div>'
    });
  }
  return issues;
}

// P024: data-zone-id 容器必须有 anno-zone 类
//   根因：wb-dsf2 0805-175557 首轮 D，缺 anno-zone → D9 协同高亮失败
//   判定：[data-zone-id] 元素的 class 不含 anno-zone → FAIL
function checkP024(htmlContent) {
  const issues = [];
  const tagRegex = /<\w+\s[^>]*\bdata-zone-id\s*=\s*["']([^"']*)["'][^>]*>/gi;
  const missingClass = [];
  let m;
  while ((m = tagRegex.exec(htmlContent)) !== null) {
    const fullTag = m[0];
    const zoneId = m[1];
    const classMatch = fullTag.match(/class\s*=\s*["']([^"']*)["']/i);
    const classes = classMatch ? classMatch[1].split(/\s+/) : [];
    if (!classes.includes('anno-zone')) {
      missingClass.push(zoneId);
    }
  }
  if (missingClass.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P024',
      msg: missingClass.length + ' 个 data-zone-id 容器缺 anno-zone 类：' + missingClass.slice(0, 3).join(', ') + '。D9 协同高亮依赖 .anno-zone CSS 选择器。\n' +
        '  修复示例：\n' +
        '    <div data-zone-id="R-1" class="anno-zone">...</div>\n' +
        '  预期效果：D9 协同高亮可正常激活',
      fix_command: '为 data-zone-id 容器添加 anno-zone 类：<div data-zone-id="' + missingClass[0] + '" class="anno-zone">；或 node scripts/enhance-prototype.mjs --demo demo  # C3 自动修正'
    });
  }
  return issues;
}

// P025: demo 必须有 data-annotation-root 属性
//   根因：wb-dsf 0805-073203 首轮 D，缺 data-annotation-root → D0/D10 失败
//   判定：无 [data-annotation-root] 元素 → FAIL
//   注意：去除 HTML 注释后检测，避免注释中提及属性名导致假阴性
function checkP025(htmlContent) {
  const issues = [];
  const stripped = htmlContent.replace(/<!--[\s\S]*?-->/g, '');
  if (!/\bdata-annotation-root\b/i.test(stripped)) {
    issues.push({
      level: 'FAIL',
      code: 'P025',
      msg: 'demo 缺 [data-annotation-root] 属性。标注引擎和审计依赖此根节点定位标注区域。\n' +
        '  修复示例：\n' +
        '    <main data-annotation-root>...</main>\n' +
        '  预期效果：D0/D10 可正确定位标注根节点',
      fix_command: '为根容器添加 data-annotation-root 属性：<main data-annotation-root>...</main>；或 node scripts/enhance-prototype.mjs --demo demo  # C4 自动修正'
    });
  }
  return issues;
}

// P026: 首屏页面不能有 hidden 属性残留
//   根因：wb-dsf 0805-073203 首轮 D，P01 hidden 残留 → 整页深蓝 → D10 全失败
//   判定：第一个 [data-page-id] 元素有 hidden 属性 → FAIL
function checkP026(htmlContent) {
  const issues = [];
  const tagRegex = /<\w+\s[^>]*\bdata-page-id\s*=\s*["']([^"']*)["'][^>]*>/gi;
  const m = tagRegex.exec(htmlContent);
  if (m) {
    const fullTag = m[0];
    const pageId = m[1];
    const hasHidden = /(?:^|\s)hidden(?:\s*=|\s|>|\/)/i.test(fullTag);
    if (hasHidden) {
      issues.push({
        level: 'FAIL',
        code: 'P026',
        msg: '首屏页面 ' + pageId + ' 有 hidden 属性残留。页面内容不可见导致 D10 标注全部失败。\n' +
          '  修复示例：移除首屏页面的 hidden 属性\n' +
          '    <section data-page-id="' + pageId + '">...</section>\n' +
          '  预期效果：首屏页面可见，D10 标注正常激活',
        fix_command: '移除首屏页面 ' + pageId + ' 的 hidden 属性：<section data-page-id="' + pageId + '">；或 node scripts/enhance-prototype.mjs --demo demo  # C6 自动修正'
      });
    }
  }
  return issues;
}

// P030: 隐藏祖先链锚点检测（v2.1 新增）
//   根因：anno-zone/data-element-id 位于 display:none 的祖先容器（wstep/stepPanel/SECTION）内，
//         元素 rect=0x0 → D10 必败（p2/p3 案例：隐藏 wstep/stepPanel 内的标注必致 D10 rect=0x0）
//   判定：anno-zone 或 data-element-id 所在元素的静态 HTML 祖先链中有 style 含 display:none
//         （或 hidden 属性）的容器 → WARN（不自动修——隐藏逻辑可能是设计需要，如步骤向导）
//   实现：轻量栈式标签解析（逐标签压栈/出栈，跟踪携带 display:none/hidden 的开区间）；
//         void 元素与自闭合标签不压栈；闭标签从栈顶向下匹配同名标签弹出（容错未闭合标签）
//   排除：[data-page-id] 祖先不算隐藏（页面切换机制是正常 hidden，audit 导航激活后 rect 正常）
//   局限：仅检测静态 HTML（运行时 JS 动态显隐无法静态判定，由 runtime 审计兜底）
function checkP030(htmlContent) {
  const issues = [];
  // 去除 script/style/comment，避免 JS 模板字符串/注释中的标签污染解析栈
  const stripped = htmlContent
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const tagRegex = /<(\/?)(\w+)([^>]*)>/g;
  // HTML void 元素（无闭标签，不压栈）
  const voidTags = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  const hiddenAnchors = [];
  const stack = []; // 栈元素: { tag, hidden }（hidden = 该容器自身 display:none 或 hidden 属性）
  let m;
  while ((m = tagRegex.exec(stripped)) !== null) {
    const isClose = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3] || '';
    if (isClose) {
      // 从栈顶向下找最近的同名标签弹出（容错中间未闭合的标签）
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) { stack.length = i; break; }
      }
      continue;
    }
    const selfClose = /\/\s*$/.test(attrs);
    // 隐藏判定（与 C9/enhance-prototype 同款正则语义）：
    //   style 含 display:none，或独立 hidden 属性（不匹配 class="...hidden..." / data-hidden）
    const hasDisplayStyle = /\sstyle\s*=\s*["'][^"']*display\s*:\s*none[^"']*["']/i.test(attrs);
    const hasHiddenAttr = /(?:^|\s)hidden(?:\s*=\s*["'][^"']*["'])?(?=\s|\/|$)/i.test(attrs);
    // 锚点判定：class 含 anno-zone，或携带 data-element-id
    const isAnnoZone = /class\s*=\s*["'][^"']*\banno-zone\b[^"']*["']/i.test(attrs);
    const hasElementId = /\sdata-element-id\s*=\s*["'][^"']*["']/i.test(attrs);
    // 排除页面切换机制：祖先链中 [data-page-id] 容器的 hidden 属正常路由隐藏
    if ((isAnnoZone || hasElementId) && stack.some(el => el.hidden && !el.isPage)) {
      const idMatch = attrs.match(/\bdata-(?:zone|element)-id\s*=\s*["']([^"']*)["']/i);
      const idHint = idMatch ? idMatch[1] : tag;
      const hiddenParent = [...stack].reverse().find(el => el.hidden && !el.isPage);
      hiddenAnchors.push(idHint + '（隐藏祖先 <' + hiddenParent.tag + '>）');
    }
    if (!selfClose && !voidTags.has(tag)) {
      stack.push({
        tag,
        hidden: hasDisplayStyle || hasHiddenAttr,
        isPage: /\sdata-page-id\s*=\s*["'][^"']*["']/i.test(attrs),
      });
    }
  }
  if (hiddenAnchors.length > 0) {
    issues.push({
      level: 'WARN',
      code: 'P030',
      msg: hiddenAnchors.length + ' 个标注锚点位于隐藏祖先链内：' + hiddenAnchors.slice(0, 3).join('; ') + (hiddenAnchors.length > 3 ? '...' : '') +
        '。隐藏容器内的标注审计时 rect=0x0，D10 必败（p2/p3 案例：隐藏 wstep/stepPanel 内的标注必致 D10 rect=0x0）。' +
        '若该区域需标注，应移出隐藏容器或重构为常显',
      fix_command: '手动处理（不自动修——隐藏逻辑可能是设计需要）：将标注锚点移出 display:none/hidden 的祖先容器，或将该区域重构为常显；若隐藏步骤无需标注，移除该区域的 anno-zone/data-element-id 属性'
    });
  }
  return issues;
}

// P031: 触发器语义预检（v2.3 新增，建议 1③）
//   根因：btn-primary 等启发式类误判——D3 运行时把 btn-primary 按钮当弹窗触发器，
//         但业务按钮（提交/保存等）并非弹窗触发器 → D3 误判失败
//   同步口径（与 run-audit 运行时选择器收紧一致，规则相同）：
//     - 显式 data-open-modal → 契约触发器，永不排除 → OK
//     - btn-primary 等启发式类命中且带 data-route/data-action/data-nav → 运行时已排除 → OK
//     - 两者都无 → WARN：将被 D3 启发式误判为弹窗触发器
//   静态可判的 class 启发式子集：btn-primary / btn-new / btn-add（与 P008 触发器正则同源）
//   注意：类名尾部用 (?![\w-]) 精确词边界，避免误匹配 btn-primary-x 等其他类名
function checkP031(htmlContent) {
  const issues = [];
  // 去除 script/style/comment，避免 JS 模板字符串中的按钮导致假阳性
  const cleanHtml = htmlContent
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const btnRegex = /<button\b[^>]*\bclass\s*=\s*["'][^"']*\bbtn-(?:primary|new|add)(?![\w-])[^"']*["'][^>]*>([\s\S]*?)<\/button>/gi;
  const misjudged = [];
  let m;
  while ((m = btnRegex.exec(cleanHtml)) !== null) {
    const tag = m[0];
    // 显式 data-open-modal → 契约触发器，永不排除
    if (/\bdata-open-modal\s*=/i.test(tag)) continue;
    // 带 data-route/data-action/data-nav → 运行时已排除
    if (/\bdata-(?:route|action|nav)\s*=/i.test(tag)) continue;
    // 两者都无 → 将被 D3 启发式误判，记录命中的启发式类名（用于逐条明细）
    const clsMatch = tag.match(/\bclass\s*=\s*["'][^"']*\b(btn-(?:primary|new|add))(?![\w-])/i);
    const cls = clsMatch ? clsMatch[1] : 'btn-primary';
    // 按钮文本提取（>...</button> 间内容，去嵌套标签与空白，截断 20 字符）
    const rawText = m[1].replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    const text = rawText.length > 20 ? rawText.slice(0, 20) + '...' : (rawText || '(无文本)');
    misjudged.push({ text, cls });
  }
  if (misjudged.length > 0) {
    issues.push({
      level: 'WARN',
      code: 'P031',
      msg: 'P031: ' + misjudged.length + ' 个按钮将被 D3 启发式误判（btn-primary 保留类契约见 SKILL）\n' +
        misjudged.map(b => "  - 按钮 '" + b.text + "' 使用 " + b.cls + " 类但既无 data-open-modal 也无业务属性——将被 D3 启发式误判为弹窗触发器").join('\n') +
        '\n  修复：业务按钮改用 btn-accent 等非保留类，或弹窗触发器补 data-open-modal',
      fix_command: '业务按钮改用 btn-accent 等非保留类；确为弹窗触发器的按钮补 data-open-modal="modalId"'
    });
  }
  return issues;
}

// P032: role=dialog 位置检查（v2.3 新增，建议 2②）
//   根因：v2.2 p6 实证——role="dialog" 在内层 .modal-box，事件委托
//         closest('.modal,[role=dialog]') 命中内层隐藏错元素（1 close fail + 3 级联）
//   判定：role="dialog" 所在标签本身是 modal 容器（class 含 modal 或含 data-modal-id）→ OK；
//         其最近祖先（静态向上 1-3 层标签）是 modal 容器 → WARN（role=dialog 应在最外层容器）
//   近似性说明：静态解析用轻量栈式标签匹配（regex 找 role="dialog" 标签 + 祖先栈回溯
//         最多 3 层），未构建完整 DOM 树；>3 层嵌套或 JS 运行时移动的场景不覆盖（由
//         运行时审计兜底）
function checkP032(htmlContent) {
  const issues = [];
  // 去除 script/style/comment，避免 JS 模板字符串中的标签污染解析栈
  const stripped = htmlContent
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const tagRegex = /<(\/?)(\w+)([^>]*)>/g;
  // HTML void 元素（与 P030 同清单，无闭标签不压栈）
  const voidTags = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  const misplaced = [];
  const stack = []; // 栈元素: { tag, isModal }（isModal = 该容器是 modal 容器）
  let m;
  while ((m = tagRegex.exec(stripped)) !== null) {
    const isClose = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3] || '';
    if (isClose) {
      // 从栈顶向下找最近的同名标签弹出（容错中间未闭合的标签，与 P030 同款）
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) { stack.length = i; break; }
      }
      continue;
    }
    // modal 容器判定：class 完整含 "modal" 词（与 C12/P017 同款正则，不匹配 modal-box）或含 data-modal-id
    const isModalContainer = /class\s*=\s*["'](?:[^"']*\s)?modal(?:\s[^"']*)?["']/i.test(attrs) || /\bdata-modal-id\s*=/i.test(attrs);
    if (/\brole\s*=\s*["']?dialog["']?/i.test(attrs) && !isModalContainer) {
      // 该标签不是 modal 容器 → 静态向上 1-3 层祖先找最近的 modal 容器
      for (let lvl = 1; lvl <= 3 && stack.length - lvl >= 0; lvl++) {
        const anc = stack[stack.length - lvl];
        if (anc.isModal) {
          misplaced.push('role=dialog 在 <' + tag + '> 上，其上第 ' + lvl + ' 层 <' + anc.tag + '> 才是 modal 容器');
          break;
        }
      }
    }
    const selfClose = /\/\s*$/.test(attrs);
    if (!selfClose && !voidTags.has(tag)) {
      stack.push({ tag, isModal: isModalContainer });
    }
  }
  if (misplaced.length > 0) {
    issues.push({
      level: 'WARN',
      code: 'P032',
      msg: 'P032: role=dialog 嵌套错位（' + misplaced.length + ' 处）：' + misplaced.slice(0, 3).join('；') + (misplaced.length > 3 ? '...' : '') +
        '——事件委托将隐藏错元素（v2.2 p6 实证：closest 命中内层元素致 1 close fail + 3 级联）。修复：将 role=dialog 移到最外层 modal 容器',
      fix_command: '将 role="dialog" 从内层元素移到最外层 modal 容器开标签上（class 含 modal 的那个）'
    });
  }
  return issues;
}

// P033: 显隐状态反模式检测（v2.4 新增，建议 1③）
//   根因：v2.3 p6 实证——分页函数以 row.style.display !== 'none' 反推筛选态，
//         行因翻页隐藏后被永久误判为已筛掉（状态污染不可逆）→ 5 个标注 rect=0x0、agent 三轮修复。
//         修复法：独立 data-filtered 状态位 + display 全量重算（display 仅作输出，禁止反推业务状态）
//   判定（静态正则，近似检测）：
//     特征1：style.display !== 'none' / != 'none'（读取比较——反推"当前可见"业务状态）且
//            上下文（±2 行）含 filter/visible/show/hide/page/row/tab 关键词，同时排除
//            modal/mask/dialog 语境（弹窗显隐工具模式是合理使用——v2.4 p6 预验实证：
//            masks[i].style.display !== 'none' 用于"关闭所有弹窗"，与状态污染无关）
//     特征2：style.display === 'none' / == 'none'（读取比较）且上下文（±2 行）含
//            filter/visible/show/hide/page 关键词（隐藏/筛选逻辑共用 display 的强信号）
//   近似性说明：行级正则 + 关键词窗口，不做 AST 数据流分析——合理的临时显隐判断（如展开/折叠切换）
//         也可能命中 → level 用 WARN 不阻断，由 agent 结合上下文判断是否重构
//   局限：跨行写法（比较符与 'none' 换行）不命中；app.js 之外的 JS 不扫描
function checkP033(demoDir) {
  const issues = [];
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) return issues; // 无 app.js，跳过
  const appJs = fs.readFileSync(appJsPath, 'utf-8');
  const lines = appJs.split('\n');
  const hits = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const ctxStart = Math.max(0, i - 2);
    const ctxEnd = Math.min(lines.length - 1, i + 2);
    const ctx = lines.slice(ctxStart, ctxEnd + 1).join('\n');
    const isModalCtx = /(modal|mask|dialog)/i.test(ctx);
    // 特征1：读取比较 style.display != 'none' / !== 'none'（!==? 覆盖两种不等比较）
    //   需上下文关键词命中 + 非 modal 语境（v2.4 预验修正：裸匹配会对弹窗 mask 工具函数误报）
    if (/style\.display\s*!==?\s*['"]none['"]/.test(line)) {
      if (/(filter|visible|show|hide|page|row|tab)/i.test(ctx) && !isModalCtx) {
        hits.push({ line: i + 1, snippet: line.trim() });
      }
      continue;
    }
    // 特征2：读取比较 style.display == 'none' / === 'none' + 上下文（±2 行）含筛选/显隐/分页关键词
    if (/style\.display\s*===?\s*['"]none['"]/.test(line)) {
      if (/(filter|visible|show|hide|page)/i.test(ctx) && !isModalCtx) {
        hits.push({ line: i + 1, snippet: line.trim() });
      }
    }
  }
  if (hits.length > 0) {
    const detail = hits.slice(0, 5)
      .map(h => '    L' + h.line + ': ' + (h.snippet.length > 70 ? h.snippet.slice(0, 70) + '...' : h.snippet))
      .join('\n');
    issues.push({
      level: 'WARN',
      code: 'P033',
      msg: 'P033: 检测到读取 style.display 反推业务状态的模式（' + hits.length + ' 处）——分页/筛选共用 display 会导致状态污染（v2.3 p6 实证：行被翻页隐藏后永久误判为已筛掉）。修复：用独立 data-* 状态位记录筛选/分页态，display 仅作输出、每次全量重算\n' + detail +
        (hits.length > 5 ? '\n    ...（其余 ' + (hits.length - 5) + ' 处省略）' : ''),
      fix_command: "改用独立 data-* 状态位（如 row.dataset.filtered === '1'）记录筛选/分页态；渲染时从状态位全量重算 display（row.style.display = keep ? '' : 'none'），禁止读取 display 反推业务状态"
    });
  }
  return issues;
}

// P035: 导航研发编码检测（v5.19 P1-5 新增）
//   契约：导航菜单项只显示业务名称，禁止显示 P01/01 等研发编码；
//         页面编码仅存于 data-page-id 属性（nav link 的 data-nav/href 是属性值，不算可见文本）
//   判定（仅限导航容器范围内的可见文本——正文标题/表格中的 P01 不算）：
//     ①导航容器内文本仅为 P\d{1,2} 或 0\d 的独立 span（如 <span class="nav-no">01</span>）
//     ②导航链接（<a>）可见文本以 P0\d/P1\d 或行首 0\d[ .、-] 开头（如 "P01 培育工作台"）
//   导航容器判定：<nav> 标签，或 class 含 nav/sidebar 子串的容器
//   误报控制：只查 span/a 的可见文本节点（data-page-id/data-nav 等属性值天然不参与匹配）；
//             同一编码 token 去重只报一次（span 与其所在的 a 链接命中同一编号不重复报）
function checkP035(htmlContent) {
  const issues = [];
  // 去除 script/style/comment，避免 JS 模板字符串中的标签/文本导致假阳性
  const stripped = htmlContent
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  // 第一步：栈式解析定位导航容器的字符区间（开标签起始 → 对应闭标签结束）
  const tagRegex = /<(\/?)(\w+)([^>]*)>/g;
  const voidTags = new Set(['area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr']);
  const navRanges = [];
  const stack = []; // 栈元素: { tag, start, isNav }
  let m;
  while ((m = tagRegex.exec(stripped)) !== null) {
    const isClose = m[1] === '/';
    const tag = m[2].toLowerCase();
    const attrs = m[3] || '';
    if (isClose) {
      // 从栈顶向下找最近的同名标签弹出（容错未闭合标签，与 P030 同款）
      for (let i = stack.length - 1; i >= 0; i--) {
        if (stack[i].tag === tag) {
          if (stack[i].isNav) navRanges.push([stack[i].start, m.index + m[0].length]);
          stack.length = i;
          break;
        }
      }
      continue;
    }
    const selfClose = /\/\s*$/.test(attrs);
    const clsMatch = attrs.match(/class\s*=\s*["']([^"']*)["']/i);
    const isNav = tag === 'nav' || (clsMatch && /(nav|sidebar)/i.test(clsMatch[1]));
    if (!selfClose && !voidTags.has(tag)) {
      stack.push({ tag, start: m.index, isNav: !!isNav });
    }
  }
  if (navRanges.length === 0) return issues; // 无导航容器，跳过
  const inNavRange = (start, end) => navRanges.some(r => start >= r[0] && end <= r[1]);
  const extractText = (html) => html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
  const findings = [];
  const seenTokens = new Set();
  // ① 导航容器内文本仅为 P\d{1,2} / 0\d 的独立 span
  const spanRegex = /<span\b[^>]*>([\s\S]*?)<\/span>/gi;
  while ((m = spanRegex.exec(stripped)) !== null) {
    if (!inNavRange(m.index, m.index + m[0].length)) continue;
    const text = extractText(m[1]);
    if (/^P\d{1,2}$/i.test(text) || /^0\d$/.test(text)) {
      const token = text.toUpperCase();
      if (!seenTokens.has(token)) { seenTokens.add(token); findings.push(text); }
    }
  }
  // ② 导航链接可见文本以 P0\d/P1\d 或行首 0\d[ .、-] 开头（编码后须跟分隔符或文本结束，避免误伤业务词）
  const linkRegex = /<a\b[^>]*>([\s\S]*?)<\/a>/gi;
  while ((m = linkRegex.exec(stripped)) !== null) {
    if (!inNavRange(m.index, m.index + m[0].length)) continue;
    const text = extractText(m[1]);
    if (!text) continue;
    const tokenMatch = text.match(/^(P[01]\d|0\d)(?=[\s .、:\-·]|$)/i);
    if (tokenMatch) {
      const token = tokenMatch[1].toUpperCase();
      if (!seenTokens.has(token)) {
        seenTokens.add(token);
        findings.push(text.length > 20 ? text.slice(0, 20) + '...' : text);
      }
    }
  }
  // v5.19 P1-5：每个命中编码一条 WARN
  findings.forEach(text => {
    issues.push({
      level: 'WARN',
      code: 'P035',
      msg: 'P035: 导航项显示研发编码（' + text + '）——导航只应显示业务名称，页面编码仅存于 data-page-id',
      fix_command: "删除导航内的编号 span（如 <span class=\"nav-no\">" + text + "</span>）或将导航链接文本改为纯业务名称；页面编码仅保留在 data-page-id / data-nav 属性中（契约见 SKILL.md v5.19 P1-5 导航 label 契约）"
    });
  });
  return issues;
}

// P036: 空交互按钮静态检测（v5.19 P1-6 新增）
//   契约：业务按钮须有实际业务状态变化（数据增删改/视图切换/表单校验反馈/界面状态更新），
//         toast 仅可作辅助反馈，不可单独成立为功能实现
//   启发式（保守，仅报确定嫌疑）：在 app.js 中找函数声明/箭头 handler/case（data-action）分支块，
//     块体剔除注释/空行/break; 后仅含一条语句且为 toast 调用（toast(/showToast(/showMessage( 开头）→ 嫌疑
//   保守原则：toast + 其他语句混合的不报（避免误报）；块体 > 40 行跳过；无 app.js 时 SKIP 不报错
//   局限：行级正则 + 花括号深度配对（非 AST）——模板字符串内的花括号可能干扰块体边界，
//         保守取向只可能漏报不会扩大误报面
function checkP036(demoDir) {
  const issues = [];
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) return issues; // 无 app.js，SKIP 不报错
  const appJs = fs.readFileSync(appJsPath, 'utf-8');
  const lines = appJs.split('\n');

  // 提取块体有效语句：剔除空行、注释（行/块注释）、break;
  const collectStmts = (bodyLines) => {
    const stmts = [];
    let inBlockComment = false;
    for (const raw of bodyLines) {
      let line = raw;
      if (inBlockComment) {
        const end = line.indexOf('*/');
        if (end === -1) continue;
        line = line.slice(end + 2);
        inBlockComment = false;
      }
      const bs = line.indexOf('/*');
      if (bs !== -1) {
        const be = line.indexOf('*/', bs);
        if (be === -1) { line = line.slice(0, bs); inBlockComment = true; }
        else line = line.slice(0, bs) + line.slice(be + 2);
      }
      const t = line.trim();
      if (!t || t.startsWith('//')) continue;
      if (/^break\s*;?$/i.test(t)) continue;
      stmts.push(t);
    }
    return stmts;
  };

  // toast 调用判定：toast( / showToast( / showMessage(（允许 window. / app. 等对象前缀）
  const isToastCall = (stmt) => /^(?:\w+\.)*(?:toast|showToast|showMessage)\s*\(/.test(stmt);

  // 从 startLine 行 startCol 列（{ 所在处）做花括号深度配对，返回 { bodyLines, endLine } 或 null（未闭合）
  const extractBraceBody = (startLine, startCol) => {
    let depth = 1; // header 行的 { 已计入
    const bodyLines = [];
    for (let j = startLine; j < lines.length; j++) {
      const seg = j === startLine ? lines[j].slice(startCol + 1) : lines[j];
      let closeIdx = -1;
      for (let k = 0; k < seg.length; k++) {
        if (seg[k] === '{') depth++;
        else if (seg[k] === '}') {
          depth--;
          if (depth === 0) { closeIdx = k; break; }
        }
      }
      if (closeIdx !== -1) {
        bodyLines.push(seg.slice(0, closeIdx));
        return { bodyLines, endLine: j };
      }
      bodyLines.push(seg);
    }
    return null; // 未闭合（文件截断），跳过
  };

  const suspects = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    let fm;
    // 函数声明：function name(...) {
    if ((fm = line.match(/(?:async\s+)?function\s+(\w+)\s*\([^)]*\)\s*\{/))) {
      const braceCol = fm.index + fm[0].length - 1;
      const block = extractBraceBody(i, braceCol);
      if (block && block.bodyLines.length <= 40) {
        const stmts = collectStmts(block.bodyLines);
        if (stmts.length === 1 && isToastCall(stmts[0])) {
          suspects.push({ name: fm[1], line: i + 1, snippet: stmts[0] });
        }
      }
      continue;
    }
    // 箭头 handler：const/let/var name = (...) => { 或 name = arg => {
    if ((fm = line.match(/(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?(?:\([^)]*\)|[A-Za-z_$][\w$]*)\s*=>\s*\{/))) {
      const braceCol = fm.index + fm[0].length - 1;
      const block = extractBraceBody(i, braceCol);
      if (block && block.bodyLines.length <= 40) {
        const stmts = collectStmts(block.bodyLines);
        if (stmts.length === 1 && isToastCall(stmts[0])) {
          suspects.push({ name: fm[1], line: i + 1, snippet: stmts[0] });
        }
      }
      continue;
    }
    // data-action 分支：case 'xxx':
    if ((fm = line.match(/^\s*case\s+['"]([\w-]+)['"]\s*:/))) {
      const bodyLines = [];
      let j = i + 1;
      for (; j < lines.length; j++) {
        const t = lines[j].trim();
        if (/^case\s+['"]/.test(t) || /^default\s*:/.test(t)) break;
        if (t.startsWith('}')) break; // switch 闭合
        bodyLines.push(lines[j]);
      }
      if (bodyLines.length > 0 && bodyLines.length <= 40) {
        const stmts = collectStmts(bodyLines);
        if (stmts.length === 1 && isToastCall(stmts[0])) {
          suspects.push({ name: "data-action='" + fm[1] + "'", line: i + 1, snippet: stmts[0] });
        }
      }
      if (j > i + 1) i = j - 1; // 跳过已消费的 case 体
      continue;
    }
  }
  // v5.19 P1-6：每个嫌疑一条 WARN
  suspects.forEach(s => {
    issues.push({
      level: 'WARN',
      code: 'P036',
      msg: 'P036: 按钮 ' + s.name + ' 的处理仅含 toast 提示（L' + s.line + ': ' + (s.snippet.length > 60 ? s.snippet.slice(0, 60) + '...' : s.snippet) + '）——业务按钮须有实际状态变化（数据增删改/视图切换/校验反馈），toast 不可单独成立',
      fix_command: "为按钮 " + s.name + " 补充实际业务状态变化（数据增删改/视图切换/表单校验反馈/界面状态更新），toast 仅作辅助反馈——契约见 SKILL.md「业务填充（强制）」操作性定义（v5.19 P1-6）"
    });
  });
  return issues;
}

// P037: 跨页联动枚举一致性（v5.21 新增，FAIL 阻断）
//   契约：HTML 中经 getAttribute('data-xxx') / dataset.xxx 消费、用于过滤/匹配/查找的
//         自定义属性值，必须与 app.js 数据层的枚举字面量完全一致（含大小写与语言）
//   根因：p10 UAT 实测——P01 漏斗按钮 data-stage="MATCHING"（英文），app.js 数据层 stage 为中文
//         （匹配中等），gotoFunnel 将英文值写入过滤器后匹配 0 条 → P06 洽谈列表空白，
//         select 赋值静默失败回退"全部阶段"，UI 与数据不一致
//   白名单（框架/路由语义属性不检查）：data-nav/data-page-id/data-zone-id/data-element-id/
//         data-action/data-open-modal/data-annotation-toggle/data-code/data-seq/data-route/data-target
//   判定：index.html 中被 app.js 消费的 data-xxx="值"，其值必须能作为 token（词边界）在
//         app.js 中找到（对象键、字符串字面量或数字均可）；找不到 = 过滤必然落空
//   误报控制：仅检查被消费的属性（未被 app.js 读取的 data-* 不检查）；(属性, 值) 去重只报
//             一次；空值跳过；无 app.js 时记 WARN 跳过不计 fail
function checkP037(demoDir) {
  const issues = [];
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) {
    issues.push({
      level: 'WARN',
      code: 'P037',
      msg: 'P037: demo/assets/app.js 不存在，跳过跨页联动枚举一致性检测'
    });
    return issues;
  }
  const htmlContent = fs.readFileSync(path.join(demoDir, 'index.html'), 'utf-8');
  const appJs = fs.readFileSync(appJsPath, 'utf-8');

  // 框架/路由语义属性豁免（由导航完备性等既有维度保障）
  const WHITELIST = new Set([
    'data-nav', 'data-page-id', 'data-zone-id', 'data-element-id', 'data-action',
    'data-open-modal', 'data-annotation-toggle', 'data-code', 'data-seq', 'data-route', 'data-target'
  ]);

  // 第一步：从 app.js 提取被消费的 data-* 属性名集合
  const consumed = new Set();
  let m;
  const attrRe = /\bgetAttribute\(\s*['"]data-([a-z0-9-]+)['"]\s*\)/g;
  while ((m = attrRe.exec(appJs)) !== null) consumed.add('data-' + m[1]);
  const datasetRe = /\bdataset\.([a-zA-Z0-9]+)/g;
  while ((m = datasetRe.exec(appJs)) !== null) {
    // camelCase → kebab-case（如 stageName → data-stage-name）
    consumed.add('data-' + m[1].replace(/([a-z0-9])([A-Z])/g, '$1-$2').toLowerCase());
  }

  // 第二步：从 index.html 提取被消费且不在白名单的 (属性名, 值)；distinct 去重、空值跳过
  const seen = new Set();
  const pairs = [];
  const htmlAttrRe = /\sdata-([a-z0-9-]+)="([^"]*)"/g;
  while ((m = htmlAttrRe.exec(htmlContent)) !== null) {
    const attr = 'data-' + m[1];
    const value = m[2];
    if (!value.trim()) continue;
    if (WHITELIST.has(attr) || !consumed.has(attr)) continue;
    const key = attr + '\u0000' + value;
    if (seen.has(key)) continue;
    seen.add(key);
    pairs.push({ attr, value });
  }

  // 第三步：值必须能作为 token 在 app.js 中找到（前后均非 [\w$]，对象键/字符串字面量/数字均可）
  const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenInAppJs = (value) => {
    const esc = escapeRegExp(value);
    try {
      return new RegExp('(?<![\\w$])' + esc + '(?![\\w$])').test(appJs);
    } catch (e) {
      // 运行环境不支持 lookbehind：退化为捕获组边界 exec 匹配
      return new RegExp('(^|[^\\w$])' + esc + '($|[^\\w$])').exec(appJs) !== null;
    }
  };
  pairs.forEach(p => {
    if (tokenInAppJs(p.value)) return;
    issues.push({
      level: 'FAIL',
      code: 'P037',
      msg: p.attr + '="' + p.value + '" 未在 app.js 中找到对应字面量——该值用于过滤/匹配时将导致目标区域空白，请与数据层枚举对齐'
    });
  });
  return issues;
}

// P038: 筛选数据流检测（fix-double-trigger-dead-interactions 新增，WARN 不阻断）
//   契约 R-11：筛选类控件（SELECT/INPUT 携带 data-action）的处理链必须读取控件当前值
//             并使其影响渲染输出——无操作筛选（调渲染函数但不读值）属数据流断裂
//   根因：fto UAT 实证——case 'filterRisk': renderDashboard(); toast('已按风险等级筛选')
//         调了渲染函数，但 renderDashboard 及其调用链从不读取 heroRiskFilter 控件值，
//         统计数字不变（用户以为筛选生效，实际什么都没发生）
//   方法：收集 index.html 中携带 data-action 的 SELECT/INPUT 控件 → 定位 handleDemoAction
//         内 case 'X' 分支体（复用 P036 的 case 体收集方式，兼容单行 case）→ BFS 深度 ≤3
//         追踪被调函数定义体 → 任一文本命中以下之一即 PASS：
//         (a) 引号包裹的 action 名（覆盖 $('[data-action="X"]') 选择器写法）
//         (b) 控件元素 id 字符串；(c) case 体直接读取 el.value / ev.target.value
//   v5.24 扩展：控件收集增加"无 data-action 但有 id 且 app.js 引用该 id（$('#id')/
//         getElementById('id')/querySelector('#id')）且附近（±15 行）存在 change/input
//         监听注册"的 SELECT/INPUT（根因：UAT0826 p6 实证——statusFilter 无 data-action
//         走自建 change 监听，v5.22 只收 data-action 控件导致零检测）；对其以监听回调体为
//         判定起点，套用同一数据流判定（回调/链上读 this.value/el.value 或控件 id 引用）
//   保守原则：case 不存在（AI 可能自建监听）跳过；被调函数全部找不到定义（无法追踪）
//             不报；按钮类筛选（chip 等）由 D6 运行时覆盖，仅查 SELECT/INPUT
function checkP038(demoDir) {
  const issues = [];
  const htmlPath = path.join(demoDir, 'index.html');
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) return issues; // 无 app.js，SKIP 不报错
  const htmlContent = fs.readFileSync(htmlPath, 'utf-8');
  const appJs = fs.readFileSync(appJsPath, 'utf-8');
  const lines = appJs.split('\n');
  const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // 第一步：收集 index.html 中携带 data-action 的 SELECT/INPUT 筛选控件（记录 action 名与元素 id 若有）
  const controls = [];
  const tagRe = /<(select|input)\b[^>]*?data-action\s*=\s*["']([\w-]+)["'][^>]*>/gi;
  let tm;
  while ((tm = tagRe.exec(htmlContent)) !== null) {
    const idMatch = tm[0].match(/\bid\s*=\s*["']([\w-]+)["']/);
    controls.push({ action: tm[2], id: idMatch ? idMatch[1] : null });
  }

  // v5.24 第二步：收集无 data-action 但有 id 的 SELECT/INPUT——须 app.js 引用该 id 且附近（±15 行）
  // 存在 change/input 监听注册（自建监听形态；±15 窗口为近似关联，误绑的监听由后续值读取判定兜底）
  const seenIds = new Set(controls.map(c => c.id).filter(Boolean));
  const plainTagRe = /<(select|input)\b[^>]*>/gi;
  const idRefPattern = (id) => new RegExp(
    '(?:\\$\\(\\s*[\'"]#' + escapeRegExp(id) + '[\'"]\\s*\\)' +
    '|getElementById\\(\\s*[\'"]' + escapeRegExp(id) + '[\'"]\\s*\\)' +
    '|querySelector\\(\\s*[\'"]#' + escapeRegExp(id) + '[\'"]\\s*\\))');
  const listenerRegRe = /addEventListener\s*\(\s*['"](?:change|input)['"]/;
  while ((tm = plainTagRe.exec(htmlContent)) !== null) {
    const tag = tm[0];
    if (/\bdata-action\s*=\s*["']/.test(tag)) continue; // data-action 型已收集
    const idMatch = tag.match(/\bid\s*=\s*["']([\w-]+)["']/);
    if (!idMatch || seenIds.has(idMatch[1])) continue;
    const id = idMatch[1];
    const idRefRe = idRefPattern(id);
    let regLine = -1;
    for (let i = 0; i < lines.length && regLine === -1; i++) {
      if (!idRefRe.test(lines[i])) continue;
      // 优先：同一行内 id 引用 + change/input 监听注册（$('#X').addEventListener('change', ...)）
      if (listenerRegRe.test(lines[i])) { regLine = i; break; }
      // 回退：±15 行窗口内距离最近的监听注册（var el = $('#X'); el.addEventListener(...) 变量中转形态）
      let best = -1, bestDist = 16;
      for (let j = Math.max(0, i - 15); j <= Math.min(lines.length - 1, i + 15); j++) {
        if (!listenerRegRe.test(lines[j])) continue;
        if (Math.abs(j - i) < bestDist) { best = j; bestDist = Math.abs(j - i); }
      }
      regLine = best;
    }
    if (regLine === -1) continue; // 无监听注册，无法定位处理链，跳过
    seenIds.add(id);
    controls.push({ action: null, id: id, regLine: regLine });
  }
  if (controls.length === 0) return issues;

  // 定位 handleDemoAction 分发函数体范围：定义行 + 花括号配对求结束行（未闭合则取文件末尾）
  // 注意排除注释行——demo app.js 顶部可能有 "// 定义 window.handleDemoAction = function ..." 说明注释
  // v5.24：分发函数仅 data-action 型控件的判定需要；id 型控件走监听回调，无分发函数时不整体退出
  const isCodeLine = (l) => { const t = l.trim(); return t !== '' && !t.startsWith('//') && !t.startsWith('*') && !t.startsWith('/*'); };
  const defIdx = lines.findIndex(l => isCodeLine(l) &&
    /handleDemoAction\s*=\s*(?:async\s*)?function/.test(l) || isCodeLine(l) && /function\s+handleDemoAction\s*\(/.test(l));
  let handlerEnd = lines.length - 1;
  if (defIdx !== -1) {
    const open = lines[defIdx].indexOf('{');
    if (open !== -1) {
      let depth = 0;
      let done = false;
      for (let j = defIdx; j < lines.length && !done; j++) {
        const seg = j === defIdx ? lines[j].slice(open) : lines[j];
        for (let k = 0; k < seg.length; k++) {
          if (seg[k] === '{') depth++;
          else if (seg[k] === '}') { depth--; if (depth === 0) { handlerEnd = j; done = true; break; } }
        }
      }
    }
  }

  // 提取 case 'X' 分支体文本（复用 P036 的 case 体收集方式；兼容单行 case 与同行多 case 标签）
  // 返回分支体文本；case 不存在返回 null
  const extractCaseBody = (action) => {
    if (defIdx === -1) return null; // v5.24：无分发函数时 action 型判定已跳过（防御性守卫）
    const caseRe = new RegExp('case\\s+["\']' + escapeRegExp(action) + '["\']\\s*:');
    for (let i = defIdx; i <= handlerEnd; i++) {
      const cm = lines[i].match(caseRe);
      if (!cm) continue;
      let rest = lines[i].slice(cm.index + cm[0].length);
      // 同行还有后续 case 标签（如 case 'a': case 'b':）→ 剥到最后一个 case 冒号之后
      let lm;
      while ((lm = rest.match(/\bcase\s+["'][\w-]+["']\s*:/)) !== null) {
        rest = rest.slice(lm.index + lm[0].length);
      }
      const t = rest.trim();
      // 冒号后为空或为块起始 { → 多行体：收集到下一个 case/default/switch 闭合前（P036 方式）
      if (t === '' || t === '{') {
        const bodyLines = [];
        for (let j = i + 1; j <= handlerEnd; j++) {
          const tt = lines[j].trim();
          if (/^case\s+["']/.test(tt) || /^default\s*:/.test(tt) || tt.startsWith('}')) break;
          bodyLines.push(lines[j]);
        }
        return bodyLines.join('\n');
      }
      // 单行 case（如 case 'filterRisk': renderDashboard(); toast('...'); break;）→ 直接用该行剩余文本
      return rest;
    }
    return null;
  };

  // 在 app.js 中查找函数定义并提取函数体（花括号深度配对，P036 extractBraceBody 模式）
  // 支持：function NAME(...) / var NAME = function / const NAME = (...) => / obj.NAME = function
  const findFnBody = (name) => {
    const esc = escapeRegExp(name);
    const patterns = [
      '(?:async\\s+)?function\\s+' + esc + '\\s*\\([^)]*\\)\\s*\\{',
      '(?:const|let|var)\\s+' + esc + '\\s*=\\s*(?:async\\s*)?function[^{]*\\{',
      '(?:const|let|var)\\s+' + esc + '\\s*=\\s*(?:async\\s*)?(?:\\([^)]*\\)|[A-Za-z_$][\\w$]*)\\s*=>\\s*\\{',
      '(?:^|[^\\w$.])' + esc + '\\s*=\\s*(?:async\\s*)?function[^{]*\\{'
    ];
    for (let i = 0; i < lines.length; i++) {
      for (const p of patterns) {
        const fm = lines[i].match(new RegExp(p));
        if (!fm) continue;
        const braceCol = fm.index + fm[0].length - 1;
        let depth = 1; // 定义行匹配段末尾的 { 已计入
        const bodyLines = [];
        for (let j = i; j < lines.length; j++) {
          const seg = j === i ? lines[j].slice(braceCol + 1) : lines[j];
          let closeIdx = -1;
          for (let k = 0; k < seg.length; k++) {
            if (seg[k] === '{') depth++;
            else if (seg[k] === '}') { depth--; if (depth === 0) { closeIdx = k; break; } }
          }
          if (closeIdx !== -1) { bodyLines.push(seg.slice(0, closeIdx)); return bodyLines.join('\n'); }
          bodyLines.push(seg);
        }
        return null; // 函数体未闭合
      }
    }
    return null; // 未找到定义（内置 API / 方法调用 / 外部函数）
  };

  // v5.24 新增：提取 change/input 监听注册行的回调体（id 型控件的判定起点）
  // 行内匿名/箭头函数 → 花括号深度配对（P036 extractBraceBody 模式）；
  // 具名函数引用（addEventListener('change', applyIndustryFilter)）→ 查函数定义体
  const extractListenerBody = (lineIdx) => {
    const regRe = /addEventListener\s*\(\s*['"](?:change|input)['"]\s*,\s*/;
    const rm = lines[lineIdx].match(regRe);
    if (!rm) return null;
    const rest = lines[lineIdx].slice(rm.index + rm[0].length);
    const fnm = rest.match(/(?:function[^{]*|=>)\s*\{/);
    if (fnm) {
      const braceCol = rm.index + rm[0].length + fnm.index + fnm[0].length - 1;
      let depth = 1; // 回调起始 { 已计入
      const bodyLines = [];
      for (let j = lineIdx; j < lines.length; j++) {
        const seg = j === lineIdx ? lines[j].slice(braceCol + 1) : lines[j];
        let closeIdx = -1;
        for (let k = 0; k < seg.length; k++) {
          if (seg[k] === '{') depth++;
          else if (seg[k] === '}') { depth--; if (depth === 0) { closeIdx = k; break; } }
        }
        if (closeIdx !== -1) { bodyLines.push(seg.slice(0, closeIdx)); return bodyLines.join('\n'); }
        bodyLines.push(seg);
      }
      return null; // 回调体未闭合
    }
    const nm = rest.match(/^([A-Za-z_$][\w$]*)\s*[\),]/);
    if (nm) return findFnBody(nm[1]); // 具名函数引用
    return null; // 无法识别的回调形态（bind 链等），跳过
  };

  // 从文本提取被调函数名（排除关键字与控制结构）
  const CALL_KEYWORDS = new Set(['if', 'for', 'while', 'switch', 'catch', 'return', 'function',
    'typeof', 'new', 'delete', 'void', 'in', 'of', 'do', 'else', 'try', 'finally', 'throw',
    'case', 'break', 'continue', 'var', 'let', 'const', 'await', 'yield']);
  const extractCallees = (text) => {
    const names = new Set();
    const re = /\b([A-Za-z_$][\w$]*)\s*\(/g;
    let mm;
    while ((mm = re.exec(text)) !== null) {
      if (!CALL_KEYWORDS.has(mm[1])) names.add(mm[1]);
    }
    return names;
  };

  controls.forEach(ctrl => {
    // v5.24：判定起点——data-action 型 = case 分支体；id 型 = 监听回调体
    let entryBody = null;
    if (ctrl.action != null) {
      if (defIdx === -1) return; // 无统一分发函数（AI 可能自建监听），跳过（v5.22 原行为）
      entryBody = extractCaseBody(ctrl.action);
    } else {
      entryBody = extractListenerBody(ctrl.regLine);
    }
    if (entryBody == null || entryBody.trim() === '') return; // 起点不存在或无法提取，跳过
    const caseBody = entryBody;
    // BFS 深度 ≤3 追踪：起点 = 第 0 层，起点直接调用 = 第 1 层，逐层展开到第 3 层
    const texts = [caseBody];
    let tracked = 0;
    const visited = new Set();
    const queue = [...extractCallees(caseBody)].map(n => ({ name: n, depth: 1 }));
    while (queue.length > 0) {
      const item = queue.shift();
      if (item.depth > 3 || visited.has(item.name)) continue;
      visited.add(item.name);
      const body = findFnBody(item.name);
      if (body == null) continue; // 找不到定义，跳过该函数
      tracked++;
      texts.push(body);
      extractCallees(body).forEach(n => queue.push({ name: n, depth: item.depth + 1 }));
    }
    // 命中判定（任一即 PASS）：
    //   data-action 型：(a) 引号包裹的 action 名 (b) 元素 id 字符串 (c) case 体直接读 el.value
    //   id 型（v5.24）：(b) 元素 id 字符串（链上重新查询控件）(c) 链上任一处读取 .value（含 this.value）
    let hit;
    if (ctrl.action != null) {
      const actionStrRe = new RegExp('["\']' + escapeRegExp(ctrl.action) + '["\']');
      const idStrRe = ctrl.id ? new RegExp('["\']' + escapeRegExp(ctrl.id) + '["\']') : null;
      hit = texts.some(t => actionStrRe.test(t)) ||
        (idStrRe != null && texts.some(t => idStrRe.test(t))) ||
        /\b(?:el|ev\.target)\.value\b/.test(caseBody);
    } else {
      const idStrRe = new RegExp('["\']' + escapeRegExp(ctrl.id) + '["\']');
      hit = texts.some(t => idStrRe.test(t)) || texts.some(t => /\.value\b/.test(t));
    }
    // 未命中且至少成功追踪到 1 个函数定义才报；全找不到定义 = 无法追踪，保守不报
    // v5.24：id 型控件（无 data-action，自建 change/input 监听）单独成报文后跳过 data-action 版
    if (!hit && tracked > 0 && ctrl.action == null) {
      issues.push({
        level: 'WARN',
        code: 'P038',
        msg: "P038: 筛选控件 #" + ctrl.id + "（无 data-action，自建 change/input 监听）的处理链未引用控件值（疑似无操作筛选）——筛选处理须读取控件当前值（this.value/控件 id 引用）并使其影响渲染输出（契约 R-11）",
        fix_command: "让 #" + ctrl.id + " 的监听回调读取控件当前值（this.value 或 $('#" + ctrl.id + "').value）并使其参与过滤/渲染计算（参考 readTaskFilters → applyTaskFilters 的筛选数据流写法）"
      });
      return; // id 型报完即止，不再走 data-action 版报文
    }
    if (!hit && tracked > 0) {
      issues.push({
        level: 'WARN',
        code: 'P038',
        msg: "P038: 筛选控件 data-action='" + ctrl.action + "' 的处理链未引用控件值（疑似无操作筛选）——筛选处理须读取控件当前值（action 选择器/元素 id/el.value）并使其影响渲染输出（契约 R-11）",
        fix_command: "让 data-action='" + ctrl.action + "' 的处理链读取控件当前值（如 document.querySelector('[data-action=\"" + ctrl.action + "\"]').value）并使其参与过滤/渲染计算（参考 readTaskFilters → applyTaskFilters 的筛选数据流写法）"
      });
    }
  });
  return issues;
}

// P039: 消费属性存在性检测（fix-double-trigger-dead-interactions 新增，WARN 不阻断）
//   契约 R-11：处理函数读取的 data-* 属性名必须与携带对应 data-action 的元素实际属性对齐
//   根因：fto UAT 实证——case 'filterStatusQuick' 使用 switch 前统一的
//         var code = el.getAttribute('data-code')，但 chip 元素只携带 data-status，
//         读取恒为 null → sel.value = code || 'ALL' 永远回退 'ALL'（属性名错位）
//   方法：(1) 收集 handleDemoAction 内 switch 之前的属性读取变量映射（变量名 → data-属性）
//         (2) 对每个 action X 双扫描（index.html + app.js）收集携带 X 的元素行上的全部
//             data-* 属性名（模板字符串生成的动态元素以此覆盖），白名单属性两侧排除
//         (3) case 'X' 体引用映射变量（词边界匹配，排除 obj.code 属性访问形式）或直接
//             getAttribute('data-A')，而 X 元素属性集合不含 data-A → WARN
//   保守原则：case 不存在（AI 可能自建监听）跳过；行级扫描以覆盖动态元素
function checkP039(demoDir) {
  const issues = [];
  const htmlPath = path.join(demoDir, 'index.html');
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) return issues; // 无 app.js，SKIP 不报错
  const htmlLines = fs.readFileSync(htmlPath, 'utf-8').split('\n');
  const appLines = fs.readFileSync(appJsPath, 'utf-8').split('\n');
  const escapeRegExp = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // v5.22 注释敏感度加固（Task 9）：剥离注释——行注释 //... 与块注释 /* ... */（跨行），
  // 字符串字面量内的 // 与 /* 不剥离（防 URL 等被误截断）；思路复用 checkP036 collectStmts 的注释剔除，
  // 供 case 体引用扫描与 attrRead 映射提取只扫代码内容（Task 8 实测：注释含 "data-code" 字样曾触发误报）
  const stripComments = (text) => {
    let out = '';
    let quote = null; // 非 null 表示处于 ' " ` 字符串字面量内
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (quote != null) {
        out += ch;
        if (ch === '\\' && i + 1 < text.length) { out += text[i + 1]; i++; }
        else if (ch === quote) quote = null;
        continue;
      }
      if (ch === '"' || ch === "'" || ch === '`') { quote = ch; out += ch; continue; }
      if (ch === '/' && text[i + 1] === '/') {
        while (i < text.length && text[i] !== '\n') i++; // 行注释：跳至行尾（保留换行符）
        continue;
      }
      if (ch === '/' && text[i + 1] === '*') {
        const end = text.indexOf('*/', i + 2);
        i = end === -1 ? text.length : end + 1; // 块注释：整体跳过（可跨行）
        continue;
      }
      out += ch;
    }
    return out;
  };

  // 定位 handleDemoAction 分发函数体范围（与 P038 相同的定位方式；排除注释行防误匹配说明注释）
  const isCodeLine = (l) => { const t = l.trim(); return t !== '' && !t.startsWith('//') && !t.startsWith('*') && !t.startsWith('/*'); };
  const defIdx = appLines.findIndex(l => isCodeLine(l) &&
    /handleDemoAction\s*=\s*(?:async\s*)?function/.test(l) || isCodeLine(l) && /function\s+handleDemoAction\s*\(/.test(l));
  if (defIdx === -1) return issues; // 无统一分发函数，SKIP
  let handlerEnd = appLines.length - 1;
  {
    const open = appLines[defIdx].indexOf('{');
    if (open !== -1) {
      let depth = 0;
      let done = false;
      for (let j = defIdx; j < appLines.length && !done; j++) {
        const seg = j === defIdx ? appLines[j].slice(open) : appLines[j];
        for (let k = 0; k < seg.length; k++) {
          if (seg[k] === '{') depth++;
          else if (seg[k] === '}') { depth--; if (depth === 0) { handlerEnd = j; done = true; break; } }
        }
      }
    }
  }
  // switch 起始行（映射收集只看函数体内 switch 之前的区域）
  let switchIdx = -1;
  for (let i = defIdx; i <= handlerEnd; i++) {
    if (/^\s*switch\s*\(/.test(appLines[i])) { switchIdx = i; break; }
  }
  if (switchIdx === -1) return issues;

  // 第一步：switch 之前区域的属性读取变量映射（如 var code = el.getAttribute('data-code')）
  const varAttrMap = new Map(); // 变量名 → data-属性名
  const mapRe = /(?:var|let|const)\s+(\w+)\s*=\s*(?:ev\.target|el|target)\.getAttribute\(\s*['"]data-([\w-]+)['"]\s*\)/;
  // v5.22 注释敏感度加固：attrRead 映射提取只扫代码行（先剥离行/块注释再匹配），注释里的 getAttribute 不建立映射
  const preSwitchCode = stripComments(appLines.slice(defIdx + 1, switchIdx).join('\n')).split('\n');
  for (const codeLine of preSwitchCode) {
    const mm = codeLine.match(mapRe);
    if (mm) varAttrMap.set(mm[1], 'data-' + mm[2]);
  }
  if (varAttrMap.size === 0) return issues; // 无属性读取映射，无从检测

  // 词边界匹配变量引用（排除 obj.code 属性访问形式）；运行环境不支持 lookbehind 时退化为捕获组边界
  const wordIn = (word, text) => {
    const esc = escapeRegExp(word);
    try {
      return new RegExp('(?<![.\\w$])' + esc + '(?![\\w$])').test(text);
    } catch (e) {
      return new RegExp('(^|[^.\\w$])' + esc + '(?![\\w$])').test(text);
    }
  };

  // 提取 case 'X' 分支体文本（与 P038 相同的提取方式：兼容单行 case 与同行多 case 标签）
  const extractCaseBody = (action) => {
    const caseRe = new RegExp('case\\s+["\']' + escapeRegExp(action) + '["\']\\s*:');
    for (let i = defIdx; i <= handlerEnd; i++) {
      const cm = appLines[i].match(caseRe);
      if (!cm) continue;
      let rest = appLines[i].slice(cm.index + cm[0].length);
      let lm;
      while ((lm = rest.match(/\bcase\s+["'][\w-]+["']\s*:/)) !== null) {
        rest = rest.slice(lm.index + lm[0].length);
      }
      const t = rest.trim();
      if (t === '' || t === '{') {
        const bodyLines = [];
        for (let j = i + 1; j <= handlerEnd; j++) {
          const tt = appLines[j].trim();
          if (/^case\s+["']/.test(tt) || /^default\s*:/.test(tt) || tt.startsWith('}')) break;
          bodyLines.push(appLines[j]);
        }
        return bodyLines.join('\n');
      }
      return rest; // 单行 case
    }
    return null;
  };

  // 第二步：双扫描收集每个 action 的元素 data-* 属性集合（index.html 静态 + app.js 模板字符串动态）
  const WHITELIST = new Set(['data-action', 'data-nav', 'data-route', 'data-open-modal', 'data-close',
    'data-page-id', 'data-zone-id', 'data-element-id', 'data-annotation-toggle', 'data-seq', 'data-modal-id']);
  const actionAttrs = new Map(); // action 名 → Set(该 action 元素行上的 data-* 属性名，白名单除外)
  const collectAttrs = (fileLines) => {
    fileLines.forEach(line => {
      const am = line.match(/data-action\s*=\s*["']([\w-]+)["']/);
      if (!am) return;
      const act = am[1];
      if (!actionAttrs.has(act)) actionAttrs.set(act, new Set());
      const attrs = actionAttrs.get(act);
      const attrRe = /\bdata-([\w-]+)\s*=/g;
      let mm;
      while ((mm = attrRe.exec(line)) !== null) {
        const attr = 'data-' + mm[1];
        if (!WHITELIST.has(attr)) attrs.add(attr);
      }
    });
  };
  collectAttrs(htmlLines);
  collectAttrs(appLines);

  // 第三步：逐 case 检查读取的属性是否被携带该 action 的元素实际携带
  actionAttrs.forEach((attrs, act) => {
    const body = extractCaseBody(act);
    if (body == null || body.trim() === '') return; // case 不存在（AI 可能自建监听），跳过
    // v5.22 注释敏感度加固：扫描前先剥离 case 体注释（行/块、跨行），注释中的变量名/data-* 字样不再计为引用
    const codeBody = stripComments(body);
    // case 体直接读取的 data-* 属性
    const readAttrs = new Set();
    const gRe = /getAttribute\(\s*['"]data-([\w-]+)['"]\s*\)/g;
    let g;
    while ((g = gRe.exec(codeBody)) !== null) readAttrs.add('data-' + g[1]);
    // case 体引用的映射变量 → 其对应属性
    varAttrMap.forEach((attr, vname) => {
      if (wordIn(vname, codeBody)) readAttrs.add(attr);
    });
    readAttrs.forEach(attr => {
      if (attrs.has(attr)) return;
      issues.push({
        level: 'WARN',
        code: 'P039',
        msg: "P039: 动作 '" + act + "' 的处理读取 " + attr + "，但所有 data-action='" + act + "' 元素均未携带该属性（读取恒为 null）——处理读取的属性名须与元素属性对齐（契约 R-11）",
        fix_command: "统一属性名：为所有 data-action='" + act + "' 元素补上 " + attr + " 属性，或将处理改为读取元素实际携带的属性（对照生成该元素的模板字符串修改）"
      });
    });
  });
  return issues;
}

// ===== P040: 表格结构元素标注检测（v5.23 新增）=====
//   契约：data-element-id 禁止置于表格结构元素（tr/td/th/tbody/thead）——置于 table-row 布局
//         元素上会破坏表格渲染（.l3-dot 锚点 rect 异常，D10 激活失败）
//   根因：codex-dsf-p3 fto-risk-platform 实证——动态表格行模板将 data-element-id 注入 <tr>
//         开始标签（app.js L549-554 拼接模式），运行期 D7/D10 布局类失败
//   方法：精确部分（index.html 静态 HTML）——正则 <(tr|td|th|tbody|thead)\b[^>]*data-element-id=
//         命中 → FAIL（列出标签+行号）；[^>]* 不跨 '>'，故 <td><button data-element-id=... 中
//         属性属 button 不会误判为 td 携带；全文匹配后按匹配偏移回算行号（兼容跨行标签）
//         启发部分（app.js 字符串模板）——命中疑似模式仅 WARN（避免误报，提示人工核查）：
//           (a) 直接注入：app.js 命中与 index.html 相同的正则（模板字符串中表格标签直接携带属性）
//           (b) 拼接注入：含"未闭合 <tr 开始标签"（<tr\b[^>]*['"`]\s*\+ 即 tr 标签字符串字面量
//               不含 > 即被 + 拼接，或 <tr\b[^>]*\$\{ 模板插值形式）且上下 3 行窗口内存在
//               "独立属性片段字符串"（['"`]\s+data-element-id=，即字面量以空白+data-element-id=
//               开头的拼接片段，如 ' data-element-id="P06-L3-004"'）→ 疑似注入 tr 开始标签；
//               排除下一片段即 '>'（标签闭合片段）的写法以降低误报——'<tr class="x"' + firstRow
//               命中（firstRow 为属性片段），'<td><button ...' + firstSwitch 不命中（td 拼接不在
//               检测范围且 button 携带属性合法）；要求片段前置空白可排除 setAttribute('data-element-id')
//               类 API 调用行的误匹配
//   修复：enhance-prototype C20 可自动迁移（迁至行内首个交互元素或行内 <span> 包裹），重跑后复查
function checkP040(demoDir) {
  const issues = [];
  const htmlPath = path.join(demoDir, 'index.html');
  const htmlContent = fs.readFileSync(htmlPath, 'utf-8');
  const TABLE_ATTR_RE = /<(tr|td|th|tbody|thead)\b[^>]*\bdata-element-id\s*=/gi;
  // 按全文匹配偏移回算行号（匹配偏移前 的换行数 + 1）
  const lineOf = (content, index) => content.slice(0, index).split('\n').length;

  // 精确部分：index.html 静态 HTML 命中 → FAIL（列出标签+行号）
  const htmlHits = [];
  let m;
  TABLE_ATTR_RE.lastIndex = 0;
  while ((m = TABLE_ATTR_RE.exec(htmlContent)) !== null) {
    htmlHits.push('<' + m[1].toLowerCase() + '> @L' + lineOf(htmlContent, m.index));
  }
  if (htmlHits.length > 0) {
    issues.push({
      level: 'FAIL',
      code: 'P040',
      msg: 'P040: 表格结构元素携带 data-element-id（' + htmlHits.length + ' 处：' + htmlHits.join('、') + '，index.html）——data-element-id 禁止置于表格结构元素（破坏 table-row 布局），请迁移至行内首个交互元素（button/a 等）或用行内 <span> 包裹——enhance-prototype C20 可自动迁移，重跑 enhance-prototype 后复查',
      fix_command: 'node scripts/enhance-prototype.mjs --demo demo  # C20 自动迁移表格结构元素上的 data-element-id 至行内交互元素/行内 <span>，完成后重跑 pre-audit-check 复查'
    });
  }

  // 启发部分：app.js 字符串模板中的疑似模式 → WARN（仅提示人工核查）
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (fs.existsSync(appJsPath)) {
    const appJs = fs.readFileSync(appJsPath, 'utf-8');
    // (a) 直接注入：与 index.html 相同的正则命中模板字符串
    const directHits = [];
    TABLE_ATTR_RE.lastIndex = 0;
    while ((m = TABLE_ATTR_RE.exec(appJs)) !== null) {
      directHits.push('L' + lineOf(appJs, m.index));
    }
    if (directHits.length > 0) {
      issues.push({
        level: 'WARN',
        code: 'P040',
        msg: 'P040: app.js 模板字符串中表格结构元素疑似直接携带 data-element-id（' + directHits.length + ' 处：' + directHits.join('、') + '）——data-element-id 禁止置于表格结构元素（破坏 table-row 布局），请人工核查并迁移至行内首个交互元素（button/a 等）或用行内 <span> 包裹',
        fix_command: '人工核查上述行：将 data-element-id 迁移至行内首个交互元素（button/a 等）或用行内 <span> 包裹（enhance-prototype C20 可自动迁移静态部分）'
      });
    }
    // (b) 拼接注入：未闭合 <tr 开始标签 + 上下 3 行窗口内的独立属性片段字符串
    const lines = appJs.split('\n');
    const fragRe = /['"`]\s+data-element-id\s*=/; // 独立属性片段（前置空白区分 setAttribute 调用）
    const unclosedTrConcatRe = /<tr\b[^>]*['"`]\s*\+/; // '<tr class="x"' + var 模式
    const unclosedTrTplRe = /<tr\b[^>]*\$\{/; // `<tr class="x"${var}> 模式
    const suspectLines = [];
    lines.forEach((line, i) => {
      const um = line.match(unclosedTrConcatRe);
      const tm = line.match(unclosedTrTplRe);
      if (!um && !tm) return;
      // 拼接模式下紧随 + 的下一片段若为 '>'（标签闭合片段），属性注入点在标签闭合之后，跳过
      if (um && /^\s*['"`]\s*>/.test(line.slice(um.index + um[0].length))) return;
      for (let j = Math.max(0, i - 3); j <= Math.min(lines.length - 1, i + 3); j++) {
        if (fragRe.test(lines[j])) { suspectLines.push('L' + (i + 1)); break; }
      }
    });
    if (suspectLines.length > 0) {
      issues.push({
        level: 'WARN',
        code: 'P040',
        msg: 'P040: app.js 疑似将 data-element-id 拼接注入 <tr> 开始标签（' + suspectLines.join('、') + '，动态表格行模板）——data-element-id 禁止置于表格结构元素（破坏 table-row 布局），请人工核查注入点并迁移至行内首个交互元素（button/a 等）或用行内 <span> 包裹',
        fix_command: '人工核查上述行：将属性片段改注入行内 button/a 或 <span> 元素（enhance-prototype C20 可自动迁移，重跑 enhance-prototype 后复查）'
      });
    }
  }
  return issues;
}

// ===== P041: L3 序号型重复检测（v5.23 新增，WARN 不阻断）=====
//   与 run-audit D8 序号型重复检测（运行时版）互补——本检测是其静态前置版
//   根因：codex-dsf-p3 fto-risk-platform 实证——"待办任务行1/2/3" 三卡 function 完全相同、
//         response 仅差 T-001/002/003 序号，本质是同类元件的重复标注（D8 序号型 warn 的静态根源）
//   方法：复用 P009/P018 的 __ANNOTATION_DATA__ 提取（extractAnnotationData 平衡括号截取 +
//         受限 Function 解析）与解包逻辑（{version, pages: {...}} vs 扁平 {...}）；
//         归一化规则：
//           - function/trigger/response：先替换 [A-Z]{1,3}-?\d+（如 T-001/P04/FTO12）→ #ID#，
//             再替换剩余纯数字串 → #N#
//           - element：仅去尾部数字（"待办任务行1" → "待办任务行"，保留名称中部编号）
//         判定：归一化后 element|function|trigger|response 四元组相同的组内数量
//               ≤4 → 跳过（v5.24 契约分流：小规模同类全标合规，不再告警）；
//               >4 → 每页每组 1 条 WARN（不 FAIL，仅建议同类元件精简至首个实例）
function checkP041(htmlContent) {
  const issues = [];
  const dataStr = extractAnnotationData(htmlContent);
  if (!dataStr) return issues; // 无标注数据，P004 已兜底
  let data;
  try {
    data = new Function('"use strict"; return (' + dataStr + ')')();
  } catch (e) {
    return issues; // 解析失败，P009 已兜底
  }
  if (!data || typeof data !== 'object') return issues;

  // 解包：{version, pages: {P01:...}} vs 扁平 {P01:...}（与 P009/P018 一致）
  const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
    ? data.pages
    : data;
  const metaKeys = ['version', 'metadata', 'config', 'pages'];

  // 字段归一化：序号 → 占位符（#ID# 覆盖 T-001/P04 形态，#N# 覆盖剩余纯数字）
  const normField = (s) => String(s || '')
    .replace(/[A-Z]{1,3}-?\d+/g, '#ID#')
    .replace(/\d+/g, '#N#');
  // element 仅去尾部数字（含尾部空白前的数字）
  const stripElement = (s) => String(s || '').replace(/\d+\s*$/, '').trim();

  for (const pageId of Object.keys(rawData)) {
    if (metaKeys.includes(pageId)) continue;
    const pageObj = rawData[pageId];
    if (!pageObj || typeof pageObj !== 'object' || !Array.isArray(pageObj.L3)) continue;
    const groups = {}; // key: 归一化四元组 → [{id, element}]
    for (let idx = 0; idx < pageObj.L3.length; idx++) {
      const card = pageObj.L3[idx];
      const element = (card.element || '').trim();
      const func = (card.function || '').trim();
      const trigger = (card.trigger || '').trim();
      const response = (card.response || '').trim();
      // 跳过空卡片（与 P009 一致，无 element 且无 function/response 不参与判重）
      if (!element && !func && !response) continue;
      const key = stripElement(element) + '|' + normField(func) + '|' + normField(trigger) + '|' + normField(response);
      if (!groups[key]) groups[key] = [];
      groups[key].push({ id: card.id || (pageId + '-L3-' + (idx + 1)), element: element });
    }
    for (const key of Object.keys(groups)) {
      const g = groups[key];
      // v5.24 契约分流（用户裁决）：同类组 ≤4 实例全部标注是正确行为（小规模全标合规，跳过告警）；
      // >4 实例才应精简至首个（组内卡片 >1 即 WARN，维持 v5.23 报文）。实现从简：以组内卡片数为规模依据
      if (g.length <= 4) continue;
      const name = stripElement(g[0].element) || g[0].element || '(空)';
      issues.push({
        level: 'WARN',
        code: 'P041',
        msg: 'P041: 页面 ' + pageId + ' 存在同类重复标注（' + name + '×' + g.length + '），建议同类元件仅标注首个实例——卡片 [' + g.map(c => c.id).join(', ') + '] 归一化后 function/trigger/response 仅差序号',
        fix_command: '保留同类元件首个实例的标注（' + g[0].id + '），删除其余 ' + (g.length - 1) + ' 张序号变体卡片，并对齐 DOM data-element-id 数量（P018 校验声明数与 DOM 数一致）'
      });
    }
  }
  return issues;
}

// ===== P042: 工作根洁净检测（v5.23 新增，v5.24 层级修正，FAIL 阻断）=====
//   v5.23 三重失效实证（UAT0826）：
//     (1) workRoot = dirname(demoDir) = 项目根——差一层，看不到工作根级污染
//         （真实案例：p3/p6 工作根残留空 .demora/delivery，项目根本身干净）
//     (2) req-cases 测试工作区豁免方向反了——被污染的恰是"req-cases + 技能包同级"结构，
//         豁免令工作根层检测整体失效
//     (3) 唯一一次真实报障是误报——把 scaffold 合法创建的项目根内空 delivery 骨架判残留，
//         AI 删除后 package-delivery 又重建（空 delivery 是 Phase 1 正常结构）
//   v5.24 判定：
//     工作根 = 从项目根（demo 父目录）向上逐级探测，最近的满足以下任一特征的祖先目录：
//       (a) 存在同时含 SKILL.md + skill-manifest.json 的子目录（技能包特征）
//       (b) 存在 req-cases 子目录（测试工作区特征）
//     未探测到特征祖先 → 工作根与项目根重合（v5.23 兼容回退）
//     检测规则：
//       - 工作根存在无 state.yaml 的 .demora/ → FAIL（不受 req-cases 豁免）
//       - 工作根存在空的 delivery/demo/docs/inbox → FAIL（req-cases 豁免不再作用于工作根层）
//       - 项目根存在无 state.yaml 的 .demora/ → FAIL（保留 v5.23 项目根本身检测）
//       - 项目根内的空 delivery 等不再报（scaffold 合法骨架，消除 v5.23 误报）；
//         工作根与项目根重合时同理只查 .demora
function checkP042(demoDir) {
  const issues = [];
  const projectRoot = path.dirname(path.resolve(demoDir)); // 项目根 = demo 父目录
  const residue = [];

  // 判定目录是否具有"agent 工作根"特征：(a) 技能包子目录 或 (b) req-cases 子目录
  const hasWorkspaceFeature = (dir) => {
    try {
      if (fs.existsSync(path.join(dir, 'req-cases'))) return true;
      for (const name of fs.readdirSync(dir)) {
        const sub = path.join(dir, name);
        try {
          if (!fs.statSync(sub).isDirectory()) continue;
          if (fs.existsSync(path.join(sub, 'SKILL.md')) &&
              fs.existsSync(path.join(sub, 'skill-manifest.json'))) return true;
        } catch (e) { /* 单个子目录 stat 失败跳过 */ }
      }
    } catch (e) { /* readdir 失败视为无特征 */ }
    return false;
  };

  // 从项目根向上逐级探测最近的特征祖先（限 10 层，防误攀至无关高层目录；UAT 实证工作根为项目根直系祖先 1-2 层内）
  let workRoot = null;
  let cur = projectRoot;
  for (let up = 0; up <= 10; up++) {
    if (hasWorkspaceFeature(cur)) { workRoot = cur; break; }
    const parent = path.dirname(cur);
    if (parent === cur) break; // 到达文件系统根
    cur = parent;
  }

  // .demora 存在但无 state.yaml → 残留/误建（正常 state 目录必含 state.yaml）
  const checkDemoraResidue = (dir, layer) => {
    const demoraDir = path.join(dir, '.demora');
    if (!fs.existsSync(demoraDir)) return;
    try {
      if (fs.statSync(demoraDir).isDirectory() &&
          !fs.existsSync(path.join(demoraDir, 'state.yaml'))) {
        residue.push(demoraDir + '（' + layer + ' .demora 无 state.yaml，残留/误建）');
      }
    } catch (e) { /* stat 失败视为不可判定，跳过 */ }
  };
  // 空的 delivery/demo/docs/inbox 目录（空 = 无任何文件与子目录）
  const checkEmptyDirs = (dir, layer) => {
    for (const name of ['delivery', 'demo', 'docs', 'inbox']) {
      const p = path.join(dir, name);
      if (!fs.existsSync(p)) continue;
      try {
        if (!fs.statSync(p).isDirectory()) continue;
        if (fs.readdirSync(p).length === 0) residue.push(p + '（' + layer + ' 空目录）');
      } catch (e) { /* 读取失败视为不可判定，跳过 */ }
    }
  };

  if (workRoot) {
    // 工作根层：.demora 与空交付目录均检测，req-cases 豁免不再作用于本层
    checkDemoraResidue(workRoot, '工作根');
    if (workRoot !== projectRoot) {
      checkEmptyDirs(workRoot, '工作根');
      // 项目根层：仅保留 .demora 检测（空 delivery 等为 scaffold 合法骨架，v5.24 不再报）
      checkDemoraResidue(projectRoot, '项目根');
    }
    // 工作根与项目根重合：只查 .demora（空 delivery 为 scaffold 合法骨架，避免误报）
  } else {
    // 未探测到工作根特征：v5.23 兼容回退，项目根层仅查 .demora
    checkDemoraResidue(projectRoot, '项目根');
  }

  if (residue.length > 0) {
    const rootLabel = workRoot ? ('工作根：' + workRoot) : ('项目根：' + projectRoot + '（未探测到工作根特征）');
    issues.push({
      level: 'FAIL',
      code: 'P042',
      msg: 'P042: 存在残留目录（' + residue.join('；') + '），请删除后重跑；根因通常为历史上以错误 cwd 运行写入型脚本（' + rootLabel + '）',
      fix_command: '删除上述残留目录后重跑 pre-audit-check；后续写入型脚本须在正确 cwd（项目根）运行'
    });
  }
  return issues;
}

// ===== P044: Timeline 埋点齐全性检测（v5.25.2 新增，FAIL 阻断）=====
//   根因（0830 轮 p4/p6 实证）：executor 跳过 check-structure（state 缺 phase2_check_completed_at）
//   或埋点不齐时，审计后耗时归因失明——设计段/收尾段耗时无法定位，40m 目标的归因数据链断裂
//   逻辑：state.yaml 含 phase2_started_at 时，phase2_enhance_completed_at 与
//         phase2_check_completed_at 必须齐备（audit_started_at 在 pre-audit 阶段合法缺失，不检查）
//   降级：无 state.yaml 或无 phase2_started_at（旧项目）→ WARN 跳过（向后兼容）
function checkP044(demoDir) {
  const issues = [];
  const projectRoot = path.dirname(path.resolve(demoDir));
  const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) {
    issues.push({ level: 'WARN', msg: 'P044: state.yaml 不存在，跳过 Timeline 埋点齐全性检测' });
    return issues;
  }
  const stateText = fs.readFileSync(stateFile, 'utf-8');
  if (!/^phase2_started_at:/m.test(stateText)) {
    issues.push({ level: 'WARN', msg: 'P044: state.yaml 无 phase2_started_at（旧版本项目），跳过 Timeline 埋点齐全性检测' });
    return issues;
  }
  for (const field of ['phase2_enhance_completed_at', 'phase2_check_completed_at']) {
    if (!new RegExp('^' + field + ':', 'm').test(stateText)) {
      issues.push({
        level: 'FAIL',
        msg: 'P044: Timeline 埋点缺失 ' + field + '（' + (field === 'phase2_enhance_completed_at'
          ? 'enhance-prototype.mjs 未运行或未写戳'
          : 'check-structure.mjs 未运行或未写戳——S-1~S-15 静态契约层可能被整体跳过') + '）——审计后耗时归因将失明，须补跑对应脚本',
      });
    }
  }
  return issues;
}

// ===== P043: 筛选显示同步静态检测（v5.24 新增，WARN 不阻断）=====
//   契约（SKILL.md v2.4 显隐状态位契约）：display 仅作输出、每次全量重算——
//   写入状态位（dataset.X = cond ? '1' : '0'，全集双分支）后，display 重算须覆盖所有行
//   （含状态位为 '0' 的行，赋 'none' 隐藏），否则筛选计数与可见行数不一致
//   根因（UAT0826 p6 实证）：applyPage() 只对 filtered==='1' 的匹配行设 style.display，
//         filtered='0' 行永不隐藏——筛选后计数文本"共 2 条"更新但 12 行全可见
//   方法（启发式静态分析 demo/assets/app.js，正则轻量实现）：
//     (1) 状态位写入：dataset.X = ... ? '1' : '0'（全集双分支写入，命中收集键名 X）
//     (2) 子集 display：.filter(... dataset.X === '1' ...) 之后 15 行窗口内存在 style.display 赋值
//         （display 重算仅覆盖 '1' 子集）
//     (3) 无补偿判定（须同时满足才 WARN）：
//         (a) 全文件无 "style.display = ... dataset.X ..."（无按状态位全量重算 display 的写法）
//         (b) 全文件无 dataset.X === '0' 的引用（无对 '0' 行的补偿分支）
//   启发式局限（从简实现，注释声明）：
//     - 仅识别 '1'/'0' 字符串状态位模式，dataset.hidden/show 等布尔态不识别
//     - 行集选择器是否同源不做语义分析（p6 模式依赖同一 dataset 键名关联）
//     - 状态位写入与 display 赋值分处互相调用的函数链时，靠 15 行窗口近似关联
function checkP043(demoDir) {
  const issues = [];
  const appJsPath = path.join(demoDir, 'assets', 'app.js');
  if (!fs.existsSync(appJsPath)) return issues; // 无 app.js，跳过
  const appJs = fs.readFileSync(appJsPath, 'utf-8');
  const lines = appJs.split('\n');
  const lineOf = (content, index) => content.slice(0, index).split('\n').length;

  // (1) 状态位双分支写入：dataset.X = cond ? '1' : '0'（全集写入——双分支覆盖全部行）
  const stateWriteRe = /\.dataset\.([A-Za-z_$][\w$]*)\s*=\s*[^;\n]+?\?\s*['"]1['"]\s*:\s*['"]0['"]/g;
  const stateKeys = new Set();
  let m;
  while ((m = stateWriteRe.exec(appJs)) !== null) {
    stateKeys.add(m[1]);
  }
  if (stateKeys.size === 0) return issues;

  for (const key of stateKeys) {
    const escKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // (2) 子集 display：.filter(...) 谓词引用 dataset.X === '1'，且其后 15 行窗口内有 style.display 赋值
    const subsetFilterRe = new RegExp(
      '\\.filter\\s*\\(\\s*(?:function\\s*\\([^)]*\\)\\s*\\{[^}]*|(?:[A-Za-z_$][\\w$]*)\\s*=>\\s*[^)]*)' +
      '(?:return\\s+)?[A-Za-z_$][\\w$]*\\.dataset\\.' + escKey + '\\s*===?\\s*[\'"]1[\'"]', 'g');
    let subsetDisplayHit = false;
    while ((m = subsetFilterRe.exec(appJs)) !== null) {
      const startLine = lineOf(appJs, m.index);
      for (let j = startLine - 1; j < Math.min(lines.length, startLine + 14); j++) {
        if (/style\.display\s*=/.test(lines[j])) { subsetDisplayHit = true; break; }
      }
      if (subsetDisplayHit) break;
    }
    if (!subsetDisplayHit) continue;
    // (3) 无补偿判定：(a) 无按状态位全量重算 display（style.display 赋值表达式引用 dataset.X）
    //                (b) 无 '0' 态补偿分支（全文件无 dataset.X === '0' 引用）
    const fullRecomputeRe = new RegExp('style\\.display\\s*=[^;\\n]*dataset\\.' + escKey);
    const zeroBranchRe = new RegExp('dataset\\.' + escKey + '\\s*===?\\s*[\'"]0[\'"]');
    if (fullRecomputeRe.test(appJs) || zeroBranchRe.test(appJs)) continue;
    issues.push({
      level: 'WARN',
      code: 'P043',
      msg: 'P043: 筛选状态位写入与 display 赋值行集不对称（疑似 filtered=\'0\' 行未隐藏，违反 v2.4 全量重算契约），建议 display 重算覆盖所有状态分支（状态位 dataset.' + key + '：写状态位遍历全集，赋 display 仅遍历 \'1\' 子集且无 \'0\' 行补偿分支）',
      fix_command: '让 display 重算覆盖所有状态分支：遍历行集全集按 dataset.' + key + ' 赋值（如 row.style.display = row.dataset.' + key + " === '1' ? '' : 'none'），或在状态位写入的同一全集循环内同步赋 display"
    });
  }
  return issues;
}

// ===== 主流程 =====
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.demo) { showHelp(); process.exit(args.help ? 0 : 2); }

  const demoDir = path.resolve(args.demo);
  const indexPath = path.join(demoDir, 'index.html');
  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在: ' + indexPath);
    process.exit(2);
  }

  log('======================================================================');
  log('pre-audit-check.mjs — 静态契约预检 (v5.14.11)');
  log('======================================================================');
  log('  demo: ' + demoDir);
  log('  port: ' + args.port);

  // 读取 index.html
  const htmlContent = fs.readFileSync(indexPath, 'utf-8');

  // 读取 style.css（如果存在）
  let cssContent = '';
  const cssPath = path.join(demoDir, 'assets', 'style.css');
  if (fs.existsSync(cssPath)) {
    cssContent = fs.readFileSync(cssPath, 'utf-8');
  }
  // 也检查 demo/assets/css/style.css 等常见路径
  const cssPath2 = path.join(demoDir, 'assets', 'css', 'style.css');
  if (fs.existsSync(cssPath2)) {
    cssContent += '\n' + fs.readFileSync(cssPath2, 'utf-8');
  }

  let failCount = 0;
  let warnCount = 0;

  // P001: 手动 marker 误带属性
  log('\n[P001] 检测手动 marker 误带属性...');
  const p001Issues = checkP001(htmlContent);
  if (p001Issues.length > 0) {
    failCount++;
    p001Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] 无手动 marker 误带属性');
  }

  // P002: [hidden] 防御规则
  log('\n[P002] 检测 [hidden] 防御规则...');
  const p002Issues = checkP002(htmlContent, cssContent);
  if (p002Issues.length > 0) {
    failCount++;
    p002Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] [hidden] 防御规则存在');
  }

  // P003: 导航完备性
  log('\n[P003] 检测导航完备性（data-nav 类型）...');
  const p003Issues = checkP003(htmlContent);
  if (p003Issues.length > 0) {
    failCount++;
    p003Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] 导航完备性正常');
  }

  // P004: __ANNOTATION_DATA__ 内联位置（WARN 不阻断）
  log('\n[P004] 检测 __ANNOTATION_DATA__ 内联位置...');
  const p004Issues = checkP004(htmlContent);
  if (p004Issues.length > 0) {
    warnCount++;
    p004Issues.forEach(i => log('  [WARN] ' + i));
  } else {
    log('  [OK] __ANNOTATION_DATA__ 已内联于 index.html');
  }

  // P015: 端口占用检测（必须在 P005 之前执行：先检测占用，再 P005 报 FAIL）
  //   v5.18 重构：从"清理 + kill"改为"检测 + 建议下一个空闲端口"，不 kill 冲突进程
  log('\n[P015] 检测端口 ' + args.port + ' 占用...');
  const p015Issues = await checkP015(args.port);
  if (p015Issues.length > 0) {
    p015Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 端口 ' + args.port + ' 空闲');
  }

  // P005: 端口占用预检（在 P015 预清理之后执行；P015 已清理则 P005 应 [OK]，
  //   仅当端口被无法清理的进程占用时才 [FAIL]，表示真正的端口冲突）
  log('\n[P005] 检测端口 ' + args.port + ' 占用...');
  const p005Issues = checkP005(args.port);
  if (p005Issues.length > 0) {
    failCount++;
    p005Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] 端口 ' + args.port + ' 未被占用');
  }

  // P006: main 内容区 CSS 可见性（v5.14.18 新增，组A 重试治理）
  log('\n[P006] 检测 main 内容区 CSS 可见性...');
  const p006Issues = checkP006(htmlContent, cssContent);
  if (p006Issues.length > 0) {
    failCount++;
    p006Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] main 内容区可见性正常');
  }

  // P007: data-element-id 容器可见性（v5.14.18 新增）
  log('\n[P007] 检测 data-element-id 容器可见性...');
  const p007Issues = checkP007(htmlContent, cssContent);
  if (p007Issues.length > 0) {
    failCount++;
    p007Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] data-element-id 容器可见性正常');
  }

  // P008: D3 弹窗触发按钮事件线索（v5.14.18 新增）
  log('\n[P008] 检测 D3 弹窗触发按钮事件线索...');
  const p008Issues = checkP008(htmlContent, cssContent, demoDir);
  if (p008Issues.length > 0) {
    failCount++;
    p008Issues.forEach(i => log('  [FAIL] ' + i));
  } else {
    log('  [OK] D3 弹窗触发按钮事件线索正常');
  }

  // P009: L3 卡片三元组重复（v5.14.18 新增，WARN 不阻断，A1）
  log('\n[P009] 检测 L3 卡片三元组重复...');
  const p009Issues = checkP009(htmlContent);
  if (p009Issues.length > 0) {
    warnCount++;
    p009Issues.forEach(i => log('  [WARN] ' + i));
  } else {
    log('  [OK] L3 卡片三元组无重复');
  }

  // P010: footer 契约预检（v5.14.18 新增，WARN 不阻断，A2）
  log('\n[P010] 检测 footer 契约...');
  const p010Issues = checkP010(htmlContent, cssContent);
  if (p010Issues.length > 0) {
    warnCount++;
    p010Issues.forEach(i => log('  [WARN] ' + i));
  } else {
    log('  [OK] footer 契约正常');
  }

  // P011: D6 按钮响应率预检（v5.15 新增）
  log('\n[P011] 检测 D6 启用按钮数...');
  const p011Issues = checkP011(htmlContent, demoDir);
  if (p011Issues.length > 0) {
    p011Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] D6 启用按钮数正常');
  }

  // P012: D3 弹窗目标存在性预检（v5.15 新增）
  log('\n[P012] 检测 D3 弹窗目标 modal 存在性...');
  const p012Issues = checkP012(htmlContent, demoDir);
  if (p012Issues.length > 0) {
    p012Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] D3 弹窗目标 modal 存在性正常');
  }

  // P013: D10 标注标记完整性预检（v5.15 新增；v2.3 契约修正：引擎已注入时降为 INFO 不阻断）
  log('\n[P013] 检测 D10 标注标记完整性...');
  const p013Issues = checkP013(htmlContent, demoDir);
  if (p013Issues.length > 0) {
    p013Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else if (i.level === 'INFO') { log('  [INFO] ' + i.msg); } // v2.3：INFO 不计 FAIL/WARN，不阻断
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] D10 标注标记完整性正常');
  }

  // P014: D9 失败自查 — [data-annotation-active] .l3-dot 激活规则检测（v5.16 新增）
  log('\n[P014] 检测 D9 L3 dot 激活规则...');
  const p014Issues = checkP014(htmlContent, cssContent);
  if (p014Issues.length > 0) {
    p014Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] D9 L3 dot 激活规则存在');
  }

  // v5.16 O-1 新增：P016 navLinks 语义化预检
  const p016Issues = checkP016(htmlContent, demoDir);
  if (p016Issues.length > 0) {
    p016Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] navLinks 语义化正常');
  }

  // v5.17 Tier D 新增：P017 D3 modal 事件绑定静态检测（WARN 非阻断）
  log('\n[P017] 检测 D3 modal 事件绑定...');
  const p017Issues = checkP017(htmlContent, demoDir);
  if (p017Issues.length > 0) {
    p017Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] D3 modal 事件绑定正常');
  }

  // v5.17 Tier D 新增：P018 标注数量一致性静态检测（v2.1 升级 FAIL 阻断）
  log('\n[P018] 检测标注数量一致性...');
  const p018Issues = checkP018(htmlContent);
  if (p018Issues.length > 0) {
    p018Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 标注数量一致性正常');
  }

  // first-round-bplus-guarantee 新增：P019-P026（兜底 enhance-prototype.mjs 自动修正）
  log('\n[P019] 检测 Nav link href 唯一性...');
  const p019Issues = checkP019(htmlContent);
  if (p019Issues.length > 0) {
    p019Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] Nav link href 无重复');
  }

  // first-round-bplus-guarantee-v2 新增：P027 href-data-nav 一致性 + href 目标存在性
  log('\n[P027] 检测 Nav link href-data-nav 一致性 + href 目标存在性...');
  const p027Issues = checkP027(htmlContent);
  if (p027Issues.length > 0) {
    p027Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] Nav link href 与 data-nav 一致');
  }

  // first-round-bplus-guarantee-v2 新增：P028 空 .l2-marker 检测
  log('\n[P028] 检测空 .l2-marker...');
  const p028Issues = checkP028(htmlContent);
  if (p028Issues.length > 0) {
    p028Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 无空 .l2-marker');
  }

  // first-round-bplus-guarantee-v2 新增：P029 重复 data-element-id 检测
  log('\n[P029] 检测重复 data-element-id...');
  const p029Issues = checkP029(htmlContent);
  if (p029Issues.length > 0) {
    p029Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] data-element-id 无重复');
  }

  log('\n[P020] 检测标注元素是否在 [data-page-id] 内...');
  const p020Issues = checkP020(htmlContent);
  if (p020Issues.length > 0) {
    p020Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 标注元素均在 [data-page-id] 内');
  }

  log('\n[P021] 检测页面隐藏机制...');
  const p021Issues = checkP021(htmlContent);
  if (p021Issues.length > 0) {
    p021Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 页面隐藏机制正常');
  }

  log('\n[P022] 检测 Nav link 数量与页面数匹配...');
  const p022Issues = checkP022(htmlContent);
  if (p022Issues.length > 0) {
    p022Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] Nav link 数量与页面数匹配');
  }

  log('\n[P023] 检测 data-element-id 是否在块级容器上...');
  const p023Issues = checkP023(htmlContent);
  if (p023Issues.length > 0) {
    p023Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] data-element-id 均在块级容器上');
  }

  log('\n[P024] 检测 data-zone-id 容器是否有 anno-zone 类...');
  const p024Issues = checkP024(htmlContent);
  if (p024Issues.length > 0) {
    p024Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] data-zone-id 容器均有 anno-zone 类');
  }

  log('\n[P025] 检测 data-annotation-root 属性...');
  const p025Issues = checkP025(htmlContent);
  if (p025Issues.length > 0) {
    p025Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] data-annotation-root 属性存在');
  }

  log('\n[P026] 检测首屏页面 hidden 残留...');
  const p026Issues = checkP026(htmlContent);
  if (p026Issues.length > 0) {
    p026Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 首屏页面无 hidden 残留');
  }

  // v2.1 新增：P030 隐藏祖先链锚点检测（WARN 不阻断——隐藏逻辑可能是设计需要）
  log('\n[P030] 检测隐藏祖先链内的标注锚点...');
  const p030Issues = checkP030(htmlContent);
  if (p030Issues.length > 0) {
    p030Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 无标注锚点位于隐藏祖先链内');
  }

  // v2.3 新增：P031 触发器语义预检（WARN 不阻断——与 run-audit 运行时选择器收紧同步的静态侧预检）
  log('\n[P031] 检测将被 D3 启发式误判的按钮（btn-primary 保留类契约）...');
  const p031Issues = checkP031(htmlContent);
  if (p031Issues.length > 0) {
    p031Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 无将被 D3 启发式误判的按钮');
  }

  // v2.3 新增：P032 role=dialog 位置检查（WARN 不阻断）
  log('\n[P032] 检测 role=dialog 位置...');
  const p032Issues = checkP032(htmlContent);
  if (p032Issues.length > 0) {
    p032Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] role=dialog 均位于 modal 容器层或无嵌套错位');
  }

  // v2.4 新增：P033 显隐状态反模式检测（WARN 不阻断——静态正则近似检测，合理的临时显隐判断也可能命中）
  log('\n[P033] 检测 app.js 显隐状态反模式（读取 style.display 反推业务状态）...');
  const p033Issues = checkP033(demoDir);
  if (p033Issues.length > 0) {
    p033Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 未检测到读取 style.display 反推业务状态的模式');
  }

  // v5.19 P1-5 新增：P035 导航研发编码检测（WARN 不阻断——导航只应显示业务名称）
  log('\n[P035] 检测导航项是否显示研发编码（P01/01 等）...');
  const p035Issues = checkP035(htmlContent);
  if (p035Issues.length > 0) {
    p035Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 导航项均显示业务名称（无研发编码）');
  }

  // v5.19 P1-6 新增：P036 空交互按钮静态检测（WARN 不阻断——仅报"块体仅含一条 toast 语句"的确定嫌疑）
  log('\n[P036] 检测空交互按钮（处理仅含 toast 提示）...');
  const p036Issues = checkP036(demoDir);
  if (p036Issues.length > 0) {
    p036Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 无仅含 toast 提示的空交互处理函数');
  }

  // v5.21 新增：P037 跨页联动枚举一致性检测（FAIL 阻断——HTML data-* 消费值必须能在 app.js 中解析为字面量）
  log('\n[P037] 检测跨页联动枚举一致性（HTML data-* 消费值 vs app.js 数据层枚举）...');
  const p037Issues = checkP037(demoDir);
  const p037Fails = p037Issues.filter(i => i.level === 'FAIL');
  if (p037Fails.length > 0) {
    failCount++;
    log('  [FAIL] P037: 跨页联动枚举不一致（' + p037Fails.length + ' 处）');
    p037Fails.forEach(i => log('        ' + i.msg));
  } else if (p037Issues.length > 0) {
    p037Issues.forEach(i => { warnCount++; log('  [WARN] ' + i.msg); });
  } else {
    log('  [OK] P037: 跨页联动枚举一致（HTML data-* 消费值均可在 app.js 中解析为字面量）');
  }

  // fix-double-trigger-dead-interactions 新增：P038 筛选数据流检测（WARN 不阻断——SELECT/INPUT 筛选的处理链须读取控件当前值）
  log('\n[P038] 检测筛选控件数据流（SELECT/INPUT 的处理链是否读取控件值）...');
  const p038Issues = checkP038(demoDir);
  if (p038Issues.length > 0) {
    p038Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 筛选控件处理链均引用控件值（或无 SELECT/INPUT 筛选控件）');
  }

  // fix-double-trigger-dead-interactions 新增：P039 消费属性存在性检测（WARN 不阻断——case 读取的 data-* 须被对应元素携带）
  log('\n[P039] 检测消费属性存在性（动作处理读取的 data-* 是否被元素携带）...');
  const p039Issues = checkP039(demoDir);
  if (p039Issues.length > 0) {
    p039Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 动作处理读取的 data-* 属性均与元素属性对齐（或无属性读取映射）');
  }

  // v5.23 新增：P040 表格结构元素标注检测（index.html 精确 FAIL + app.js 字符串模板启发 WARN）
  log('\n[P040] 检测表格结构元素标注（tr/td/th/tbody/thead 携带 data-element-id）...');
  const p040Issues = checkP040(demoDir);
  if (p040Issues.length > 0) {
    p040Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 表格结构元素（tr/td/th/tbody/thead）无 data-element-id 标注');
  }

  // v5.23 新增：P041 L3 序号型重复检测（WARN 不阻断——run-audit D8 序号型检测的静态前置版）
  // v5.24：规模感知——同类组 ≤4 实例全标合规不再告警，>4 实例才建议精简至首个
  log('\n[P041] 检测 L3 序号型重复标注（归一化后仅差序号的同类卡片，≤4 实例组合规）...');
  const p041Issues = checkP041(htmlContent);
  if (p041Issues.length > 0) {
    p041Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] L3 卡片无序号型同类重复');
  }

  // v5.23 新增：P042 工作根洁净检测（FAIL 阻断——demo 父目录的 .demora 残留/空交付目录）
  // v5.24：层级修正——从项目根向上探测 agent 工作根（技能包/req-cases 特征），工作根层检测不再被 req-cases 豁免
  log('\n[P042] 检测工作根洁净度（向上探测工作根的残留目录）...');
  const p042Issues = checkP042(demoDir);
  if (p042Issues.length > 0) {
    p042Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 工作根/项目根无残留目录');
  }

  // v5.24 新增：P043 筛选显示同步静态检测（WARN 不阻断——状态位全集写入与 display 子集赋值不对称）
  log('\n[P043] 检测筛选显示同步（状态位写入与 display 赋值行集对称性）...');
  const p043Issues = checkP043(demoDir);
  if (p043Issues.length > 0) {
    p043Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
      if (i.fix_command) { log('         fix: ' + i.fix_command); }
    });
  } else {
    log('  [OK] 筛选状态位与 display 赋值对称（或无状态位筛选模式）');
  }

  // v5.25.2 新增：P044 Timeline 埋点齐全性检测（FAIL 阻断——归因观测防线）
  log('\n[P044] 检测 Timeline 埋点齐全性（phase2_enhance/check_completed_at）...');
  const p044Issues = checkP044(demoDir);
  if (p044Issues.length > 0) {
    p044Issues.forEach(i => {
      if (i.level === 'FAIL') { failCount++; log('  [FAIL] ' + i.msg); }
      else { warnCount++; log('  [WARN] ' + i.msg); }
    });
  } else {
    log('  [OK] Timeline 埋点齐全（enhance/check 完成时间戳齐备）');
  }

  // 汇总
  log('\n======================================================================');
  log('[SUMMARY] 预检结果: ' + failCount + ' FAIL, ' + warnCount + ' WARN');
  log('======================================================================');
  if (failCount > 0) {
    log('>>> 预检失败，请按上述错误清单修复 demo 后再执行 run-audit.mjs');
    process.exit(1);
  } else {
    log('>>> 预检通过' + (warnCount > 0 ? '（有 ' + warnCount + ' 个 WARN 不阻断）' : '') + '，可执行 run-audit.mjs');
    process.exit(0);
  }
}

main().catch(e => {
  log('[FAIL] 预检异常: ' + e.message);
  process.exit(1);
});
