// gate-baseline.mjs
// 门禁脚本完整性基线（v5.14 新增 — P2-10 防御"考生改考卷"）
//
// 缺陷定位：审计 final §2.2 来源 A L264 — 执行者在同一会话内修改门禁判定逻辑后重跑通过。
// 修复方案：BUILD 阶段生成 7 个门禁脚本的 SHA-256 基线，运行时各脚本启动自检，
//   不一致则 FAIL 退出，要求从 BUILD 重跑。
//
// 门禁脚本清单（7 个）：
//   validator.mjs / verify-demo-runtime.mjs / quality-check.mjs /
//   check-structure.mjs / run-audit.mjs / package-delivery.mjs / verify-delivery.mjs
//
// 用法：
//   1. BUILD 阶段：node scripts/gate-baseline.mjs --generate <skill-root>
//      生成 <skill-root>/gate-scripts-baseline.json
//   2. 运行时：各门禁脚本调用 verifyGateScriptIntegrity(__filename)
//      读取基线并自检，不一致返回 {ok:false, expected, actual}
//
// 退出码：0=通过/基线已生成，1=自检失败

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// v5.16 优化：单次会话内 verifyGateScriptIntegrity 结果缓存
// 同一 Node 进程内多次校验同一脚本时直接返回，避免重复 fs.readFileSync + SHA-256 计算
// 缓存键：scriptPath（函数签名仅单参数，baseline 在函数内从基线文件读取，无需参与键）
const gateVerifyCache = new Map();

// 7 个门禁脚本（相对 scripts/ 目录的相对路径）
const GATE_SCRIPTS = [
  'validator.mjs',           // 注：在 references/methodology/schemas/ 下，特殊处理
  'verify-demo-runtime.mjs',
  'quality-check.mjs',
  'check-structure.mjs',
  'run-audit.mjs',
  'package-delivery.mjs',
  'verify-delivery.mjs',
];

// validator.mjs 的特殊路径（在 references/methodology/schemas/ 下，相对 skillRoot）
const VALIDATOR_PATH_MAP = {
  'validator.mjs': ['references', 'methodology', 'schemas', 'validator.mjs'],
};

/**
 * 计算文件 SHA-256
 */
function fileSha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

/**
 * 查找 skill 包根目录（含 SKILL.md 的目录）
 */
function findSkillRoot(scriptDir) {
  let dir = scriptDir;
  for (let i = 0; i < 5; i++) {
    if (fs.existsSync(path.join(dir, 'SKILL.md'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return null;
}

/**
 * 生成基线文件（BUILD 阶段调用）
 * @param {string} skillRoot Skill 包根目录
 * @returns {string} 基线文件路径
 */
export function generateBaseline(skillRoot) {
  const scriptsDir = path.join(skillRoot, 'scripts');
  const hashes = {};
  for (const name of GATE_SCRIPTS) {
    let filePath;
    if (VALIDATOR_PATH_MAP[name]) {
      filePath = path.join(skillRoot, ...VALIDATOR_PATH_MAP[name]);
    } else {
      filePath = path.join(scriptsDir, name);
    }
    const hash = fileSha256(filePath);
    if (hash) {
      hashes[name] = hash;
    } else {
      console.warn(`[WARN] 门禁脚本缺失，跳过: ${name} (${filePath})`);
    }
  }
  const baseline = {
    generatedAt: new Date().toISOString(),
    scripts: hashes,
  };
  const baselinePath = path.join(skillRoot, 'gate-scripts-baseline.json');
  fs.writeFileSync(baselinePath, JSON.stringify(baseline, null, 2), 'utf-8');
  return baselinePath;
}

/**
 * 验证单个门禁脚本完整性（运行时调用）
 * @param {string} scriptPath 当前脚本的绝对路径（通常是 __filename 或 import.meta.url 转换后）
 * @returns {{ok:boolean, skipped?:boolean, reason?:string, expected?:string, actual?:string, scriptName?:string}}
 */
export function verifyGateScriptIntegrity(scriptPath) {
  // v5.16 优化：先查缓存，命中则直接返回（避免重复 fs.readFileSync + SHA-256 计算）
  if (gateVerifyCache.has(scriptPath)) {
    return gateVerifyCache.get(scriptPath);
  }

  // 原有校验逻辑封装为 IIFE，保留全部 8 处 return 路径
  const result = (() => {
    const scriptName = path.basename(scriptPath);
    // 仅对 7 个门禁脚本生效
    if (!GATE_SCRIPTS.includes(scriptName)) {
      return { ok: true, skipped: true, reason: `非门禁脚本（${scriptName}），跳过完整性校验` };
    }

    // 查找基线文件：skill 包根目录下的 gate-scripts-baseline.json
    const scriptDir = path.dirname(scriptPath);
    const skillRoot = findSkillRoot(scriptDir);
    if (!skillRoot) {
      return { ok: true, skipped: true, reason: '未找到 Skill 包根目录（开发态/独立运行），跳过完整性校验' };
    }
    const baselinePath = path.join(skillRoot, 'gate-scripts-baseline.json');
    if (!fs.existsSync(baselinePath)) {
      return { ok: true, skipped: true, reason: '基线文件不存在（未运行 BUILD 阶段生成），跳过完整性校验' };
    }

    // 读取基线并比对
    let baseline;
    try {
      baseline = JSON.parse(fs.readFileSync(baselinePath, 'utf-8'));
    } catch (e) {
      return { ok: true, skipped: true, reason: `基线文件解析失败: ${e.message}，跳过完整性校验` };
    }
    const expected = baseline.scripts && baseline.scripts[scriptName];
    if (!expected) {
      return { ok: true, skipped: true, reason: `基线中无 ${scriptName} 记录，跳过完整性校验` };
    }

    const actual = fileSha256(scriptPath);
    if (!actual) {
      return { ok: false, reason: `脚本文件不存在: ${scriptPath}`, scriptName };
    }
    if (actual !== expected) {
      return {
        ok: false,
        expected,
        actual,
        scriptName,
        reason: `${scriptName} 被修改（期望 ${expected.slice(0, 12)}, 实际 ${actual.slice(0, 12)}）`,
      };
    }
    return { ok: true, scriptName, expected, actual };
  })();

  // 缓存校验结果（含 ok/skipped/fail 各种情况），后续同 scriptPath 调用直接复用
  gateVerifyCache.set(scriptPath, result);
  return result;
}

// CLI 入口：--generate <skill-root>
const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('gate-baseline.mjs') || process.argv[1].endsWith('gate-baseline'));
if (isDirectRun) {
  const args = process.argv.slice(2);
  if (args[0] === '--generate' && args[1]) {
    const skillRoot = path.resolve(args[1]);
    if (!fs.existsSync(skillRoot)) {
      console.error(`[FAIL] Skill 包根目录不存在: ${skillRoot}`);
      process.exit(1);
    }
    const baselinePath = generateBaseline(skillRoot);
    console.log(`[OK] 门禁脚本基线已生成: ${baselinePath}`);
    process.exit(0);
  }
  console.error('用法: node scripts/gate-baseline.mjs --generate <skill-root>');
  process.exit(2);
}
