# audit 失败一次性修复指引（详版）

> SKILL.md「audit 失败一次性修复指引」的详版参考。核心原则：audit 失败时，AI 必须一次性读取 `[FIX_SUGGESTIONS]` 块并按指引修复，禁止读源码、禁止反复重试。

## 1. 修复流程

1. **读取 `[FIX_SUGGESTIONS_BEGIN]` ... `[FIX_SUGGESTIONS_END]` 块**（JSON 数组），每项含：
   - `dimension`：失败维度（D10/D3/D5/D9 等）
   - `root_cause`：可能根因（多个）
   - `fix_pattern`：修复模式描述
   - `evidence_selector`：可执行的证据收集命令（grep / node -e）
   - `detection_logic`：该维度检测逻辑摘要
   - `diagnostics`：浏览器 DOM 状态快照
2. **按 `evidence_selector` 收集证据**，判断哪个 `root_cause` 命中
3. **修复前先读 `demo/fix-suggestions.json`**（v2.1 新增，run-audit 失败时自动写入的结构化建议，体积小一个量级，是修复推理的首选输入）
4. **按 `fix_pattern` 修复**后重新运行审计
5. **重试时使用 `--retry` 模式**：`node scripts/run-audit.mjs --demo <demo-dir> --retry`（等价 --dimensions-only + 跳过截图/self-diagnostics；维度检测仍全量）
   - **修改 demo 任何文件后必须先重跑 `diagnose-runtime` 再 `--retry`**（A4 新鲜度门禁会拒绝过期诊断）
   - **仅最终验收跑全量审计**（不带 --retry）

## 2. 禁止行为

- **严禁读取 run-audit.mjs 源码**定位失败原因（违反将导致审计失败判定无效）。失败原因必须用 `[FIX_SUGGESTIONS]` 块（`detection_logic` 字段 + `evidence_selector` 命令）
- **禁止盲目重试**（重试前必须按 fix_pattern 修复）
- **禁止超过 2 次重试**（2 次仍失败应人工介入或回退上一稳定版本）

## 3. 退出码语义（v5.17 审计硬超时）

- `0` = 全通过；`1` = 有 FAIL（正常完成）
- `2` = 硬超时（HARD_TIMEOUT_MS=900000，15 min）触发，视为审计失败需修复，**禁止轮询等待**
- `124` = shell 超时（不应出现；出现说明硬超时失效，需排查）
- AI 调用 run-audit 时 timeout_ms 应设 `960000`（16 min > 硬超时，让硬超时先触发）

## 4. 审计对象身份验证（P0-1）

run-audit 启动前预读取 demo/index.html 的 title + data-page-id 数量；审计完成后比对 detectedPages，不匹配 → FAIL 退出（防御并发端口冲突审计了错误 demo）。
