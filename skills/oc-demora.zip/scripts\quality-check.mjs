// quality-check.mjs
// 基本质量门禁（v5.0 精简版 + v5.1 Q-6 AI 产出侧自检）
//
// 六维度检查：
//   Q-1: 目录结构完整性（demo/index.html 存在且非空）
//   Q-2: 业务填充完整性（无 __FILL_BUSINESS__ 占位标记）
//   Q-3: 文档生成完整性（docs/ 目录非空）
//   Q-4: 状态机推进（final_approved = true）
//   Q-5: 业界方案闭环校验（htmlhint 静态分析，无 htmlhint 时降级为基本 HTML 检查）
//   Q-6: AI 产出侧自检清单（v5.1 新增，规则化检查，不增加 LLM 调用）
//
// v5.1 Sprint 1 P0-5（来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion）：
//   - 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
//   - PM 决策：不增加 LLM 调用，仅规则化检查
//   - 检查项：DOCTYPE / viewport / lang / signature element / typography / 反 AI 默认审美 / 占位文本
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { spawnSync } from 'child_process';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';
import { readStateYaml } from './lib/state-cache.mjs';
import { SHELL_SIGNATURES } from './lib/hash-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

/**
 * Q-5 业界方案闭环校验：调用 htmlhint 静态分析 HTML
 *
 * 策略（保持 Skill 包零外部依赖原则）：
 *   1. 优先用项目根目录的 htmlhint（用户在自己的项目内 npm install htmlhint 后可用）
 *   2. 找不到 htmlhint 时降级为基本 HTML 检查（doctype、未闭合标签、img alt）
 *
 * v5.14.19 C3 缓存：基于 demo/index.html mtime+size 缓存 htmlhint 结果
 *   收益：AI Edit 未改 index.html 时跳过 spawnSync（省 1-5s）
 *   失效：mtime 或 size 变化时缓存失效（AI Edit 会更新 mtime → 自动失效）
 *   位置：.demora/.htmlhint-cache.json
 *   注意：降级路径不缓存（正则检查本身 < 50ms）
 *
 * @param {string} projectRoot 项目根目录（含 .demora）
 * @param {string} demoDir Demo 目录
 * @param {string} htmlFile index.html 完整路径
 * @returns {{skipped?:boolean, message?:string, errors:number, warnings:number, details:string[]}}
 */
function runHtmlhintCheck(projectRoot, demoDir, htmlFile) {
  // 候选 htmlhint CLI 路径：技能包自身 / 项目根 / 当前工作目录 / demora 开发态根
  // projectRoot 是用户运行 quality-check 时所在的项目根（含 .demora 目录）
  // process.cwd() 兼容在 demora 开发态项目根直接运行测试的场景
  // SOURCE 结构：scripts/ → skill-template/ → templates/ → src/ → demora/（4 级）
  // BUILD 结构：scripts/ → <pkg>/ → build/ → demora/（3 级）
  // 注意：htmlhint 1.9.x 的 CLI 入口是 dist/cli/htmlhint.js（不是 dist/cli.js）
  const candidates = [
    // v5.23：技能包自身 node_modules 置于最前（构建后 dist 包预装 htmlhint，
    //   消除 htmlhint 可达性随环境漂移导致的 Q-5 降级——UAT0824 opencode 环境 3/3 降级根因）
    path.join(__dirname, '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(projectRoot, 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(process.cwd(), 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(__dirname, '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    path.join(__dirname, '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    // BUILD 包：scripts/ → <pkg>/ → build/ → demora/（3 级向上到 demora 根）
    path.join(__dirname, '..', '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
    // SOURCE 包：scripts/ → skill-template/ → templates/ → src/ → demora/（4 级向上到 demora 根）
    path.join(__dirname, '..', '..', '..', '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'),
  ];
  let htmlhintCli = null;
  for (const p of candidates) {
    if (fs.existsSync(p)) { htmlhintCli = p; break; }
  }

  // 有 htmlhint：subprocess 调用（--format json 便于解析）
  // 关键：demoDir 必须转为绝对路径，否则当 cwd=projectRoot 时 htmlhint 会将相对路径
  // 解析为 cwd/demoDir（即 projectRoot/projectRoot/demo），导致找不到文件返回空结果
  // cwd 设为 projectRoot 以便 htmlhint 从该目录向上查找 .htmlhintrc 配置文件
  if (htmlhintCli) {
    // v5.14.19 C3 缓存：基于 index.html mtime+size 判断是否可跳过 spawnSync
    //   场景：quality-check 在 AI 阶段 3-4 多次运行，若 index.html 未变则跳过 htmlhint 子进程
    //   失效条件：mtime 或 size 变化（AI Edit 会更新 mtime → 自动失效）
    //   不缓存降级路径（正则检查 < 50ms）和 skip 路径（输出解析失败）
    let cacheHit = false;
    const cacheFile = path.join(projectRoot, '.demora', '.htmlhint-cache.json');
    try {
      const stat = fs.statSync(htmlFile);
      const cacheKey = `${stat.mtimeMs}|${stat.size}`;
      if (fs.existsSync(cacheFile)) {
        const cached = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
        if (cached.key === cacheKey && cached.result && !cached.result.skipped) {
          log('  [INFO] Q-5: htmlhint 缓存命中（index.html 未变），跳过子进程调用');
          cacheHit = true;
          return cached.result;
        }
      }
    } catch (e) {
      // 缓存读取失败（文件不存在/JSON 解析失败/stat 失败），继续执行 spawnSync
    }

    const absDemoDir = path.resolve(demoDir);
    const result = spawnSync(process.execPath, [htmlhintCli, absDemoDir, '--format', 'json'], {
      encoding: 'utf-8',
      cwd: path.resolve(projectRoot),
      maxBuffer: 5 * 1024 * 1024,
      timeout: 30000,
      windowsHide: true,
    });
    let errors = 0, warnings = 0, details = [];
    // v5.2.4 修复：Demora 标注系统约定的布尔属性白名单
    // 原因：annotation-guide.md §3/§4 约定 data-annotation-root/toggle/close 为布尔属性
    //   但 htmlhint 的 attr-value-not-empty 规则要求所有属性必须有值 → 误报
    //   audit-warehouse-v5.2 发现 3 个误报告警
    const BOOLEAN_ATTR_WHITELIST = [
      'data-annotation-root',
      'data-annotation-toggle',
      'data-annotation-close',
    ];
    try {
      const parsed = JSON.parse(result.stdout || '[]');
      if (Array.isArray(parsed)) {
        for (const file of parsed) {
          if (file.messages && Array.isArray(file.messages)) {
            for (const msg of file.messages) {
              // 过滤白名单布尔属性的 attr-value-not-empty 误报
              if (msg.rule && msg.rule.id === 'attr-value-not-empty') {
                const isWhitelisted = BOOLEAN_ATTR_WHITELIST.some(attr =>
                  msg.message && msg.message.includes(attr));
                if (isWhitelisted) continue;
              }
              if (msg.type === 'error') errors++;
              else if (msg.type === 'warning') warnings++;
              details.push(`${msg.rule.id}: ${msg.message} (line ${msg.line})`);
            }
          }
        }
      }
    } catch (e) {
      // htmlhint 输出无法解析，视为 skip
      return { skipped: true, message: `htmlhint 输出解析失败: ${e.message}`, errors: 0, warnings: 0, details: [] };
    }
    const retVal = { errors, warnings, details };
    // C3 缓存写入：仅缓存非 skip 结果（skip 是异常状态，不应缓存）
    if (!cacheHit) {
      try {
        const stat = fs.statSync(htmlFile);
        const cacheKey = `${stat.mtimeMs}|${stat.size}`;
        fs.writeFileSync(cacheFile, JSON.stringify({ key: cacheKey, result: retVal, ts: Date.now() }), 'utf-8');
      } catch (e) {
        // 缓存写入失败不影响结果
      }
    }
    return retVal;
  }

  // 无 htmlhint：降级为基本 HTML 检查
  // 检查项：doctype、html 闭合标签、head/body 配对、未闭合的 div/section、img alt
  // v5.23：降级输出候选路径探测结果列表（便于诊断环境问题——
  //   htmlhint 可达性随环境漂移时，可据此定位缺失环节）
  log('  [WARN] Q-5: htmlhint 不可用，已探测路径:');
  for (const p of candidates) {
    log(`         - ${fs.existsSync(p) ? '[存在]' : '[缺失]'} ${p}`);
  }
  const rawHtml = fs.readFileSync(htmlFile, 'utf-8');
  // 关键：剥离 <style>...</style>、<script>...</script>、HTML 注释 <!-- ... --> 内容后再计数 HTML 标签
  // 原因：CSS/JS 注释与 HTML 注释中可能包含 "<head>" / "<body>" 等文本
  //   （如标注系统注释 "注入 Demo 的 <head>" / "注入 annotation-panel.html 到 <body> 末尾"），
  //   会被正则误判为标签未配对
  const html = rawHtml
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '');
  const errors = [];
  const warnings = [];

  // doctype 检查
  if (!/<!doctype\s+html>/i.test(rawHtml.slice(0, 200))) {
    errors.push('缺少 <!DOCTYPE html> 声明');
  }

  // html/head/body 配对检查
  // 注意：HTML 中 <html lang="zh-CN"> 的 lang 属性会被 \b 边界匹配，需正确处理
  for (const tag of ['html', 'head', 'body']) {
    const openCount = (html.match(new RegExp(`<${tag}\\b[^>]*>`, 'gi')) || []).length;
    const closeCount = (html.match(new RegExp(`</${tag}\\s*>`, 'gi')) || []).length;
    if (openCount !== closeCount) {
      errors.push(`<${tag}> 标签未配对: open=${openCount}, close=${closeCount}`);
    }
  }

  // 简单的块级元素闭合检查（基于计数）
  for (const tag of ['div', 'section', 'main', 'header', 'footer', 'nav', 'aside', 'article']) {
    const openCount = (html.match(new RegExp(`<${tag}\\b[^>]*>`, 'gi')) || []).length;
    const closeCount = (html.match(new RegExp(`</${tag}\\s*>`, 'gi')) || []).length;
    if (openCount !== closeCount) {
      errors.push(`<${tag}> 标签未配对: open=${openCount}, close=${closeCount}`);
    }
  }

  // img 标签 alt 属性检查（warning）
  const imgTags = html.match(/<img\b[^>]*>/gi) || [];
  for (const img of imgTags) {
    if (!/\balt\s*=/.test(img)) {
      warnings.push(`img 标签缺少 alt 属性: ${img.slice(0, 50)}`);
    }
  }

  return {
    errors: errors.length,
    warnings: warnings.length,
    details: [...errors, ...warnings],
    degraded: true,  // v5.14 修复 F4：标记为降级检查
    reason: 'htmlhint 不可用，已降级为基本 HTML 检查（doctype/标签配对/img alt）',
  };
}

/**
 * Q-6 AI 产出侧自检清单（v5.1 新增）
 *
 * 来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion
 * 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
 * PM 决策：不增加 LLM 调用，仅规则化检查
 *
 * 检查项（基于 v0-hardrules-supplement.md 与 frontend-design/SKILL.md 契约）：
 *   - DOCTYPE 声明（错误）
 *   - viewport meta（错误）
 *   - html lang 属性（错误）
 *   - 标注契约 data-zone-id（错误）
 *   - 标注契约 data-element-id（错误）
 *   - 标注契约 data-annotation-toggle（错误）
 *   - 占位文本 TODO/FIXME/Loading（错误）
 *   - 反 AI 默认审美：warm cream #F4F1EA 背景（警告，非错误）
 *   - 反 AI 默认审美：terracotta #B8864A 强调色（警告）
 *   - 反 AI 默认审美：indigo/blue 主色（警告）
 *   - signature element 缺失提示（警告：无 SVG / 无独特视觉元素）
 *
 * @param {string} htmlFile index.html 完整路径
 * @returns {{errors:number, warnings:number, details:string[]}}
 */
function runAiOutputSelfCheck(htmlFile) {
  const html = fs.readFileSync(htmlFile, 'utf-8');
  const errors = [];
  const warnings = [];

  // 错误级检查（FAIL）

  // 1. DOCTYPE 声明
  if (!/<!doctype\s+html>/i.test(html.slice(0, 200))) {
    errors.push('缺少 <!DOCTYPE html> 声明（v0-hardrules-supplement.md §三 强制 COMPLETE 代码）');
  }

  // 2. viewport meta
  if (!/<meta\s+name=["']viewport["']/i.test(html)) {
    errors.push('缺少 <meta name="viewport"> 响应式视口（frontend-design/SKILL.md "responsive down to mobile"）');
  }

  // 3. html lang 属性
  if (!/<html\s+[^>]*lang=/i.test(html)) {
    errors.push('缺少 <html lang="..."> 语言属性（a11y 基线）');
  }

  // 4-6. 标注契约（Demora 核心差异化能力）
  // v5.2.1 修复：支持布尔属性（data-annotation-toggle 无 = 也算合法）
  if (!/data-zone-id\s*=/.test(html)) {
    errors.push('缺少 data-zone-id 属性（标注契约 L2 区域标识，详见 annotation-guide.md）');
  }
  if (!/data-element-id\s*=/.test(html)) {
    errors.push('缺少 data-element-id 属性（标注契约 L3 元件标识）');
  }
  // 支持 data-annotation-toggle="" 和 data-annotation-toggle（布尔）
  if (!/data-annotation-toggle(\s*=|\s|>)/.test(html)) {
    errors.push('缺少 data-annotation-toggle 属性（标注契约 标注开关）');
  }

  // 7. 占位文本
  // v5.2.1 修复：移除 'placeholder'（合法 HTML 属性名，不是占位文本）
  const placeholders = ['TODO', 'FIXME', 'Loading...', 'Demo - 待 AI 设计', '__FILL_BUSINESS__', '待填充'];
  for (const p of placeholders) {
    if (html.includes(p)) {
      errors.push(`检测到占位文本 "${p}"（v0-hardrules-supplement.md §三 强制 COMPLETE 代码）`);
    }
  }

  // 警告级检查（WARN，不阻塞 pass，但提示 AI 可能落入默认审美）

  // v5.2.1 修复：剥离 enhance-prototype.mjs 注入的标注系统内容后再检查颜色
  // 原因：注入的 annotation-styles.css 含 var(--primary, #3b82f6) 等 fallback 值，
  //   这些不是 AI 产出的主色，而是标注引擎的默认 fallback
  // v5.2.4 修复：原正则期望 >>> [demora-...:begin] <<< 格式，但 enhance-prototype.mjs
  //   实际注入格式为 <!-- [demora-annotation-xxx] start --> ... <!-- [demora-annotation-xxx] end -->
  //   导致 Q-6 误报 #3b82f6（audit-warehouse-v5.2 发现）
  const demoraInjectedPatterns = [
    // 旧格式（向后兼容）
    /\/\*\s*>>>\s*\[demora-[^\]]*\s*:begin\]\s*<<<\s*\*\/[\s\S]*?\/\*\s*>>>\s*\[demora-[^\]]*\s*:end\]\s*<<<\s*\*\//g,
    /<!--\s*>>>\s*\[demora-[^\]]*\s*:begin\]\s*<<<\s*-->[\s\S]*?<!--\s*>>>\s*\[demora-[^\]]*\s*:end\]\s*<<<\s*-->/g,
    // 新格式（v5.2.4）：匹配 enhance-prototype.mjs 实际注入的 <!-- [demora-annotation-xxx] start -->...end -->
    /<!--\s*\[demora-annotation-[^\]]*\]\s*start\s*-->[\s\S]*?<!--\s*\[demora-annotation-[^\]]*\]\s*end\s*-->/g,
  ];
  let aiAuthoredHtml = html;
  for (const pat of demoraInjectedPatterns) {
    aiAuthoredHtml = aiAuthoredHtml.replace(pat, '');
  }

  // 8. 反 AI 默认审美：warm cream 背景
  // frontend-design/SKILL.md 明确禁止的 3 种默认风之一
  const warmCreamPatterns = ['#F4F1EA', '#f4f1ea', '#F4F1E8', '#f4f1e8', 'rgba(244, 241, 234'];
  for (const p of warmCreamPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 warm cream 背景 ${p}（frontend-design/SKILL.md 默认风 1，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 9. 反 AI 默认审美：terracotta 强调色
  const terracottaPatterns = ['#B8864A', '#b8864a', '#C66B3D', '#c66b3d', '#B8860B', '#b8860b'];
  for (const p of terracottaPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 terracotta 强调色 ${p}（frontend-design/SKILL.md 默认风 1，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 10. 反 AI 默认审美：indigo/blue 主色
  // v0 硬规则禁止，与 frontend-design 同源
  const indigoPatterns = ['#6366F1', '#6366f1', '#4F46E5', '#4f46e5', '#3B82F6', '#3b82f6', '#2563EB', '#2563eb'];
  for (const p of indigoPatterns) {
    if (aiAuthoredHtml.includes(p)) {
      warnings.push(`检测到 indigo/blue 主色 ${p}（v0-hardrules-supplement.md §五 禁默认色清单，请确认是否为 brief 明确要求）`);
      break;
    }
  }

  // 11. signature element 提示（不强制，仅提示）
  // frontend-design/SKILL.md "Spend boldness in one place. Let the signature element be the one memorable thing"
  // 启发式检测：是否包含 SVG / canvas / 独特视觉元素
  const hasSvg = /<svg[\s>]/i.test(html);
  const hasCanvas = /<canvas[\s>]/i.test(html);
  const hasDataViz = /class=["'][^"']*\b(chart|viz|signature|hero|signature-element)\b/i.test(html);
  if (!hasSvg && !hasCanvas && !hasDataViz) {
    warnings.push('未检测到明显的 signature element（SVG/canvas/独特视觉类），建议参考 frontend-design/SKILL.md "Signature element" 章节');
  }

  return {
    errors: errors.length,
    warnings: warnings.length,
    details: [...errors, ...warnings],
  };
}

export async function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();

  // v5.23：隐式根防护——解析根无 .demora/state.yaml 时硬 FAIL，禁止在错误 cwd 隐式创建项目根
  //   根因：UAT0824 opencode-ox- 案例 AI 以工作根为 cwd 调用 quality-check，
  //         findProjectRoot 找不到项目根 fallback cwd，在工作根残留 .demora/、delivery/
  if (!fs.existsSync(path.join(projectRoot, '.demora', 'state.yaml'))) {
    log('[FAIL] 项目根无效: ' + projectRoot + '（缺少 .demora/state.yaml）');
    log('       请在项目目录内运行，或用 --project-root 显式指定；禁止在错误目录隐式创建项目结构');
    process.exit(1);
  }

  // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
  try {
    const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
    const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
    if (!integrity.ok && !integrity.skipped) {
      log(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}`);
      log('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本');
      process.exit(1);
    }
  } catch (e) { /* gate-baseline.mjs 不可用时跳过（开发态兼容） */ }

  log('======================================================================');
  log('quality-check.mjs — 质量门禁 (v5.0)');
  log('======================================================================');

  let pass = 0, fail = 0;
  let q5Degraded = false;  // v5.14 修复 F4：Q-5 降级标记，供 quality-report 写入（P1-7 联动）
  // v5.14 修复 F3：各 Q 项 fail/warn 计数，用于 quality-report 动态分类 critical/major + 逐项明细
  // critical = q1Fail + q2Fail + q6Fail（影响结构/契约/自检）
  // major    = q3Fail + q4Fail + q5Fail（影响文档/状态/规范）
  let q1Fail = 0, q2Fail = 0, q3Fail = 0, q4Fail = 0, q5Fail = 0, q6Fail = 0, q7Fail = 0, q8Fail = 0;
  let q1Detail = '', q2Detail = '', q3Detail = '', q4Detail = '', q5Detail = '', q6Detail = '', q7Detail = '', q8Detail = '';
  let q3Warn = 0, q4Warn = 0, q7Warn = 0, q8Warn = 0;  // Q-3/Q-4/Q-7/Q-8 仅 WARN 级别（不阻塞 pass）

  // Q-1: 目录结构（内联检查，避免循环 import）
  // v5.6 收紧（audit 模式）：从 size > 50 升级为 size >= 5000 + 非空骨架特征
  //   原因：v5.5 audit 场景发现 size > 50 阈值过低，空骨架（含 enhance-prototype 注入的
  //         标注系统 CSS/JS）也能通过 Q-1，导致 quality-check 在 demo 未设计时就 PASS
  //   对齐：与 verify-delivery.mjs V-2 阈值保持一致（>= 5000 bytes + 非空骨架特征）
  //   特征字符串：scaffold-project.mjs 生成的占位标题 + enhance-prototype 注入注释
  //
  // v5.6 兼容（非 audit 模式 / sim-project）：保持原 size > 50 阈值
  //   原因：sim-runner 流水线的 demo/index.html 是 demo-builder.mjs 生成的占位骨架
  //         （含 "Demo - 待 AI 设计"），不是真实 HTML
  //         sim-project 流程不要求 AI 阶段 2 已完成，保持向后兼容
  //   用法：audit 场景通过 DEMORA_AUDIT_MODE=1 启用严格检查
  const isAuditModeQ1 = process.env.DEMORA_AUDIT_MODE === '1';
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');
  // v5.16 Task 9.4：SHELL_SIGNATURES 改用 lib/hash-utils.mjs（删除本地 SHELL_SIGNATURES_Q1 定义）
  //   原本地定义 L380-384 与 verify-delivery.mjs L79-83 重复，已抽取为共享常量
  if (fs.existsSync(indexPath)) {
    const indexSize = fs.statSync(indexPath).size;
    const indexContent = fs.readFileSync(indexPath, 'utf-8');
    const isShell = SHELL_SIGNATURES.some(sig => indexContent.includes(sig));
    if (isAuditModeQ1) {
      // audit 模式：严格检查（>= 5000 bytes + 非空骨架）
      if (indexSize >= 5000 && !isShell) {
        log(`  [OK] Q-1: Demo 结构完整 (${(indexSize / 1024).toFixed(2)} KB, audit 模式)`);
        pass++;
        q1Detail = `audit 模式通过（${(indexSize / 1024).toFixed(2)} KB, 非空骨架）`;
      } else if (isShell) {
        log(`  [FAIL] Q-1: demo/index.html 是空骨架（含占位特征字符串，size=${indexSize} bytes）`);
        log('         说明：scaffold-project.mjs 生成的空骨架未由 AI 阶段 2 替换为真实 HTML');
        fail++; q1Fail++;
        q1Detail = `空骨架（size=${indexSize} bytes，含占位特征字符串）`;
      } else {
        log(`  [FAIL] Q-1: demo/index.html 大小 ${indexSize} bytes < 5000（疑似空骨架，audit 模式）`);
        fail++; q1Fail++;
        q1Detail = `audit 模式大小不足（${indexSize} bytes < 5000）`;
      }
    } else {
      // 非 audit 模式：保持原 size > 50 阈值（sim-project 兼容）
      if (indexSize > 50) {
        log(`  [OK] Q-1: Demo 结构完整 (${indexSize} bytes)`);
        pass++;
        q1Detail = `非 audit 模式通过（${indexSize} bytes）`;
      } else {
        log(`  [FAIL] Q-1: Demo 结构不完整（size=${indexSize} <= 50）`);
        fail++; q1Fail++;
        q1Detail = `大小不足（${indexSize} bytes <= 50）`;
      }
    }
  } else {
    log('  [FAIL] Q-1: demo/index.html 不存在');
    fail++; q1Fail++;
    q1Detail = 'demo/index.html 不存在';
  }

  // Q-2: 业务填充（检测占位标记）
  if (fs.existsSync(indexPath)) {
    const html = fs.readFileSync(indexPath, 'utf-8');
    if (!html.includes('__FILL_BUSINESS__')) {
      log('  [OK] Q-2: 无占位标记残留');
      pass++;
      q2Detail = '无 __FILL_BUSINESS__ 残留';
    } else {
      log('  [FAIL] Q-2: 仍有 __FILL_BUSINESS__ 占位标记');
      fail++; q2Fail++;
      q2Detail = '仍有 __FILL_BUSINESS__ 占位标记';
    }
  }

  // Q-3: 文档目录
  const docsDir = path.join(projectRoot, 'docs');
  if (fs.existsSync(docsDir)) {
    const files = fs.readdirSync(docsDir, { withFileTypes: true });
    const hasContent = files.some(f => f.isFile() || (f.isDirectory() && fs.readdirSync(path.join(docsDir, f.name)).length > 0));
    if (hasContent) {
      log('  [OK] Q-3: 文档目录非空');
      pass++;
      q3Detail = 'docs/ 非空';
    } else {
      log('  [WARN] Q-3: 文档目录为空（可能未运行 generate-prd.mjs）');
      q3Warn++;
      q3Detail = 'docs/ 为空（可能未运行 generate-prd.mjs）';
    }
  } else {
    log('  [WARN] Q-3: docs/ 目录不存在');
    q3Warn++;
    q3Detail = 'docs/ 目录不存在';
  }

  // 检查 state.yaml
  const statePath = path.join(projectRoot, '.demora', 'state.yaml');
  if (fs.existsSync(statePath)) {
    // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
    const state = readStateYaml(projectRoot);
    if (/final_approved:\s*true/.test(state)) {
      log('  [OK] Q-4: final_approved = true');
      pass++;
      q4Detail = 'final_approved = true';
    } else {
      log('  [WARN] Q-4: final_approved 未设为 true');
      q4Warn++;
      q4Detail = 'final_approved 未设为 true';
    }
  } else {
    q4Detail = 'state.yaml 不存在';
  }

  // Q-5: 业界方案闭环校验（htmlhint 静态分析）
  // P3-2 交付物：通过 htmlhint 验证 HTML 规范性（标签闭合、属性完整、doctype 等）
  // Skill 包零外部依赖原则：htmlhint 不是 Skill 包 dependencies，优先用项目根的（用户 npm install 后），
  // 无则降级为基于正则的基本 HTML 检查
  if (fs.existsSync(indexPath)) {
    const q5Result = runHtmlhintCheck(projectRoot, demoDir, indexPath);
    if (q5Result.skipped) {
      log(`  [WARN] Q-5: ${q5Result.message}`);
      q5Detail = `skipped: ${q5Result.message}`;
    } else if (q5Result.degraded) {
      // v5.14 修复 F4：降级检查文案不得含"htmlhint 通过"
      if (q5Result.errors > 0) {
        log(`  [FAIL] Q-5: 基本检查检出 ${q5Result.errors} 个错误（htmlhint 不可用，已降级）`);
        q5Result.details.slice(0, 5).forEach(d => log(`         - ${d}`));
        fail++; q5Fail++;
        q5Detail = `降级检查 ${q5Result.errors} 个错误（htmlhint 不可用）`;
      } else {
        log(`  [WARN] Q-5: htmlhint 不可用，已降级为基本检查（${q5Result.warnings} 个警告，0 个错误）`);
        log('  [INFO] Q-5: 降级检查范围窄于 htmlhint，可能存在漏检（如 id-unique）');
        pass++;  // 降级通过仍计 pass，但 quality-report 需记录 q5_degraded
        q5Degraded = true;  // 标志位，供 quality-report 写入（P1-7 联动）
        q5Detail = `降级检查通过（${q5Result.warnings} 警告，htmlhint 不可用）`;
      }
    } else if (q5Result.errors > 0) {
      log(`  [FAIL] Q-5: htmlhint 检出 ${q5Result.errors} 个错误, ${q5Result.warnings} 个警告`);
      q5Result.details.slice(0, 5).forEach(d => log(`         - ${d}`));
      fail++; q5Fail++;
      q5Detail = `htmlhint ${q5Result.errors} 错误, ${q5Result.warnings} 警告`;
    } else if (q5Result.warnings > 0) {
      log(`  [OK] Q-5: htmlhint 通过（${q5Result.warnings} 个警告，0 个错误）`);
      pass++;
      q5Detail = `htmlhint 通过（${q5Result.warnings} 警告）`;
    } else {
      log(`  [OK] Q-5: htmlhint 通过（0 errors, 0 warnings）`);
      pass++;
      q5Detail = 'htmlhint 通过（0 errors, 0 warnings）';
    }
  }

  // Q-6: AI 产出侧自检清单（v5.1 新增）
  // 来源：P3-1A Evals 闭环 + P3-1E Superpowers verification-before-completion
  // 借鉴 Superpowers 指令化措辞："Run the command, read the output, then claim the result"
  // PM 决策：不增加 LLM 调用，仅规则化检查
  //
  // sim-project 空壳降级（与 v5.0.1 R1 修复逻辑一致）：
  //   sim-project 的 demo/index.html 是空壳（仅标注系统注入，无真实业务内容），
  //   Q-6 错误级检查（标注契约/占位文本）会失败，属预期。
  //   检测空壳特征：包含 "Demo - 待 AI 设计" 或 "AI: 基于 frontend-design skill 方法论从零设计"
  //   空壳场景下 Q-6 错误降级为 WARN，不阻塞 pass。
  //
  // v5.6 收紧：DEMORA_AUDIT_MODE=1 时禁用 sim 空壳降级
  //   原因：v5.4 自动阶段 6/7 时序错位，audit 场景的 demo 是空骨架，但 quality-check
  //         因 sim 空壳降级 PASS，导致 package-delivery 把空壳打包到 delivery/
  //   修复：audit 模式（DEMORA_AUDIT_MODE=1）下，空壳场景仍按 FAIL 处理，
  //         强制 AI 必须完成阶段 2（HTML 设计）后才能通过 Q-6
  //   用法：runAutoPhasesPhase3 调用 quality-check 时传 DEMORA_AUDIT_MODE=1
  if (fs.existsSync(indexPath)) {
    const q6Result = runAiOutputSelfCheck(indexPath);
    const htmlContent = fs.readFileSync(indexPath, 'utf-8');
    const isSimShell = htmlContent.includes('Demo - 待 AI 设计') ||
                       htmlContent.includes('AI: 基于 frontend-design skill 方法论从零设计') ||
                       htmlContent.includes('AI 基于 frontend-design skill 方法论从零设计');
    const isAuditMode = process.env.DEMORA_AUDIT_MODE === '1';
    if (isSimShell && q6Result.errors > 0 && isAuditMode) {
      // v5.6 audit 模式：空壳场景按 FAIL 处理，禁止降级
      log(`  [FAIL] Q-6: AI 产出侧自检未通过（sim-project 空壳 + DEMORA_AUDIT_MODE=1，禁用降级）`);
      log(`         错误数: ${q6Result.errors}`);
      q6Result.details.forEach(d => log(`         - ${d}`));
      log('  [INFO] Q-6: audit 场景要求 AI 阶段 2 已完成 HTML 设计，禁止空壳降级');
      fail++; q6Fail++;
      q6Detail = `audit 模式空壳未通过（${q6Result.errors} 错误）`;
    } else if (isSimShell && q6Result.errors > 0) {
      // sim-project 空壳场景（非 audit 模式）：错误降级为 WARN
      log(`  [WARN] Q-6: AI 产出侧自检跳过（sim-project 空壳，${q6Result.errors} 项降级为提示）`);
      q6Result.details.forEach(d => log(`         - ${d}`));
      log('  [INFO] Q-6: 真实 AI 产出场景将严格执行所有检查项');
      pass++;
      q6Detail = `sim 空壳降级（${q6Result.errors} 项降级为提示）`;
    } else if (q6Result.errors > 0) {
      log(`  [FAIL] Q-6: AI 产出侧自检未通过（${q6Result.errors} 个错误）`);
      q6Result.details.forEach(d => log(`         - ${d}`));
      fail++; q6Fail++;
      q6Detail = `AI 自检未通过（${q6Result.errors} 错误）`;
    } else if (q6Result.warnings > 0) {
      log(`  [OK] Q-6: AI 产出侧自检通过（${q6Result.warnings} 个提示）`);
      pass++;
      q6Detail = `AI 自检通过（${q6Result.warnings} 提示）`;
    } else {
      log(`  [OK] Q-6: AI 产出侧自检通过（0 errors, 0 warnings）`);
      pass++;
      q6Detail = 'AI 自检通过（0 errors, 0 warnings）';
    }
  }

  // Q-7: 项目根洁净度扫描（v5.14.17 批次5 R-2 新增）
  //   根因：A/B 测试 codex-dsf 根目录残留 conversation-log-*.md / _rebuild/ / _*.js 调试文件
  //         这些文件是 AI demo 生成过程中的调试产物，不应进入项目根目录
  //   实现：扫描项目根目录（非递归）的调试文件特征，输出 warn（不阻塞 pass）
  //   检测特征：
  //     1. conversation-log-*.md / conversion-log-*.md（AI 会话日志残留）
  //     2. _rebuild/ 目录（重建目录）
  //     3. _*.js / _*.tmp 文件（调试 JS/临时文件）
  //     4. *.log 文件（运行时日志残留，如 package-round3.log / verify-round3.log）
  {
    const rootEntries = fs.existsSync(projectRoot)
      ? fs.readdirSync(projectRoot, { withFileTypes: true })
      : [];
    const junkFiles = [];
    for (const entry of rootEntries) {
      const name = entry.name;
      // 特征 1：会话日志残留（conversation-log-* / conversion-log-*）
      // v5.16 S-1 修复：仅匹配带日期/时间戳后缀的会话日志，排除合法的 conversation-log.yaml（Q-8 已校验）
      if (/^(conversation|conversion)-log-\d{4}.*\.(md|txt|yaml|json)$/i.test(name)) {
        junkFiles.push(name);
        continue;
      }
      // 特征 2：_rebuild/ 目录
      if (entry.isDirectory() && /^_rebuild$/i.test(name)) {
        junkFiles.push(name + '/');
        continue;
      }
      // 特征 3：_*.js / _*.tmp 调试文件
      // v5.15 rk3 P-3 修复：恢复 ^ 锚定 + 显式前缀清单
      //   根因：原 /_.*\.(...)$/i 无 ^ 锚定，mock_data.json/status_map.json/skill_manifest.json
      //         等合法业务文件全误判。现仅匹配下划线开头的调试文件。
      if (/^_.*\.(js|tmp|txt|cjs|mjs|json|css)$/i.test(name)) {
        junkFiles.push(name);
        continue;
      }
      // v5.15 P1-1：新增 .t-shim*.mjs 模式（WorkBuddy shim 残留）
      if (/^\.t-shim/i.test(name)) { junkFiles.push(name); continue; }
      // v5.15 P1-1：新增 .tmp-* 前缀模式（临时文件）
      if (/^\.tmp-/i.test(name)) { junkFiles.push(name); continue; }
      // v5.15 rk3 P-3：补 debug-/dbg- 前缀（patent-cultivation/patent-fto 实测残留）
      // v5.16 S-1 修复：补 diag- 前缀（tw-dsf 实测残留 diag-all/diag-d10/diag-l3 等）
      if (/^(debug|dbg|diag)-/i.test(name)) { junkFiles.push(name); continue; }
      // v5.16 S-1 修复：无特征前缀的调试脚本检测（tw-dsf 实测残留 srv.mjs/verify-delivery-run.mjs）
      const knownDebugScripts = ['srv.mjs', 'verify-delivery-run.mjs', 'diagnose-button-failure.mjs'];
      if (knownDebugScripts.includes(name)) { junkFiles.push(name); continue; }
      // 特征 4：*.log 运行时日志（package-round3.log / verify-round3.log 等）
      if (/\.log$/i.test(name)) {
        junkFiles.push(name);
        continue;
      }
    }
    // v5.15 P1-1：扫描 .demora/ 子目录（消除 Q-7 盲区）
    //   根因：调试文件可能落在 .demora/ 内，原 Q-7 仅扫项目根导致盲区
    //   范围：_*.js/tmp/txt/cjs/mjs/json/css + conversation/conversion-log-* + _*.txt
    //   rk3 P-3 修复：补 debug-/dbg- 文件 + .tmp-* 目录（patent-cultivation/patent-fto/wb-hy2 实测残留）
    const demoraDir = path.join(projectRoot, '.demora');
    if (fs.existsSync(demoraDir)) {
      const demoraEntries = fs.readdirSync(demoraDir, { withFileTypes: true });
      for (const entry of demoraEntries) {
        const name = entry.name;
        if (/^_.*\.(js|tmp|txt|cjs|mjs|json|css)$/i.test(name)) {
          junkFiles.push('.demora/' + name);
        }
        if (/^(conversation|conversion)-log-\d{4}.*\.(md|txt|yaml|json)$/i.test(name)) {
          junkFiles.push('.demora/' + name);
        }
        // rk3 P-3：补 debug-/dbg- 调试文件（不以 _ 开头，原模式漏检）
        // v5.16 S-1 修复：补 diag- 前缀
        if (/^(debug|dbg|diag)-.*\.(js|mjs|cjs|tmp|txt)$/i.test(name)) {
          junkFiles.push('.demora/' + name);
        }
        // rk3 P-3：补 .tmp-* 目录（.demora/.tmp-full-package/ 残留）
        if (entry.isDirectory() && /^\.tmp-/i.test(name)) {
          junkFiles.push('.demora/' + name + '/');
        }
      }
    }
    if (junkFiles.length > 0) {
      q7Warn = junkFiles.length;
      q7Detail = `项目根残留 ${junkFiles.length} 个调试文件: ${junkFiles.slice(0, 5).join(', ')}${junkFiles.length > 5 ? ' ...' : ''}`;
      log(`  [WARN] Q-7: 项目根洁净度告警（${junkFiles.length} 个调试文件残留，不阻塞）`);
      junkFiles.slice(0, 5).forEach(f => log(`         - ${f}`));
      if (junkFiles.length > 5) log(`         ... 还有 ${junkFiles.length - 5} 个`);
      log('         清理建议：删除会话日志/调试 JS/运行时 log，保持项目根洁净');
      pass++;  // WARN 不阻塞，计入 pass
    } else {
      log('  [OK] Q-7: 项目根洁净度通过（无调试文件残留）');
      pass++;
      q7Detail = '项目根洁净（0 调试文件）';
    }
  }

  // Q-8: 状态文件完整性检查（v5.15 P2-2 新增）
  //   根因：quality-report 可能引用陈旧快照（generated_at 未刷新、state 文件空置未告警）
  //   实现：检查 decisions.yaml/context.yaml/conversation-log.yaml 是否空置，输出 warn（不阻塞 pass）
  //   检查项：
  //     1. decisions.yaml: decisions[] 为空 → warn
  //     2. context.yaml: design_methodology_read !== true → warn
  //     3. conversation-log.yaml: 记录 < 3 条 → warn
  {
    const decisionsPath = path.join(projectRoot, '.demora', 'decisions.yaml');
    const contextPath = path.join(projectRoot, '.demora', 'context.yaml');
    const convLogPath = path.join(projectRoot, '.demora', 'conversation-log.yaml');
    const q8Warnings = [];

    // 1. decisions.yaml: decisions[] 非空 = 内联数组有内容 或 块状格式有列表项
    if (fs.existsSync(decisionsPath)) {
      const decisionsContent = fs.readFileSync(decisionsPath, 'utf-8');
      const inlineNonEmpty = /decisions\s*:\s*\[[^\]]+\]/.test(decisionsContent);
      const blockNonEmpty = /decisions\s*:\s*\n\s*-\s+/.test(decisionsContent);
      if (!inlineNonEmpty && !blockNonEmpty) {
        q8Warnings.push('decisions.yaml decisions[] 为空');
      }
    } else {
      q8Warnings.push('decisions.yaml 不存在');
    }

    // 2. context.yaml: design_methodology_read !== true
    if (fs.existsSync(contextPath)) {
      const contextContent = fs.readFileSync(contextPath, 'utf-8');
      if (!/design_methodology_read\s*:\s*true/.test(contextContent)) {
        q8Warnings.push('context.yaml design_methodology_read !== true');
      }
    } else {
      q8Warnings.push('context.yaml 不存在');
    }

    // 3. conversation-log.yaml: 记录 < 3 条（统计 YAML 列表项）
    if (fs.existsSync(convLogPath)) {
      const convContent = fs.readFileSync(convLogPath, 'utf-8');
      const recordMatches = convContent.match(/^\s*-\s+\S/gm) || [];
      if (recordMatches.length < 3) {
        q8Warnings.push(`conversation-log.yaml 记录数 ${recordMatches.length} < 3`);
      }
      // v5.25 P1-2：批量补记检测（≥3 条完全相同时间戳 → 疑似批量补记，违反 v5.23 即时追加纪律）
      //   根因：0828 轮 ≥4 案例批量补记（如 zc/p10 四条同戳 12:44:18），耗时归因出现 81~98 分钟黑洞
      //   修复方向：通过 scripts/append-conversation-log.mjs 追加（时间戳一律取机器当前时间）
      //   v5.25.1 误报修正：改为全串精确匹配——事件即时连续追加的合法条目毫秒位不同（.702/.708/.709），
      //   0828 轮批量补记为整串复制（含毫秒完全相同），秒级归并会把前者误判为补记（0829 轮 cb/p4 实证 5 组误报）
      const tsMatches = convContent.match(/\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|\+08:00)?/g) || [];
      const tsCounts = {};
      for (const t of tsMatches) {
        tsCounts[t] = (tsCounts[t] || 0) + 1;
      }
      const dupGroups = Object.entries(tsCounts).filter(([, c]) => c >= 3);
      if (dupGroups.length > 0) {
        q8Warnings.push(`conversation-log.yaml 疑似批量补记（${dupGroups.length} 组时间戳各出现 ≥3 次且含毫秒完全相同，如 ${dupGroups[0][0]}），应即时调用 scripts/append-conversation-log.mjs 追加`);
      }
      // v5.25.2 F3：阶段覆盖度检测（phase 1/2/3 各至少 1 条留痕）
      //   根因：0830 轮 p6 仅 5 条日志且 Phase 1（归档/scaffold/建模）零记录——耗时归因与流程追溯断链
      //   修复方向：各阶段事件即时调用 append-conversation-log.mjs --phase N
      const phaseMatches = [...convContent.matchAll(/^\s*phase:\s*(\d+)/gm)].map(m => m[1]);
      if (phaseMatches.length > 0) {
        const phaseSet = new Set(phaseMatches);
        const missingPhases = ['1', '2', '3'].filter(p => !phaseSet.has(p));
        if (missingPhases.length > 0) {
          q8Warnings.push(`conversation-log.yaml 阶段覆盖不全（缺 phase ${missingPhases.join('/')} 留痕，带 phase 条目共 ${phaseMatches.length} 条）——各阶段事件须即时调用 scripts/append-conversation-log.mjs --phase N 留痕`);
        }
      }
      // 无 phase 字段的历史格式日志跳过本检测（向后兼容，不误报）
    } else {
      q8Warnings.push('conversation-log.yaml 不存在');
    }

    if (q8Warnings.length > 0) {
      q8Warn = q8Warnings.length;
      q8Detail = `状态文件不完整: ${q8Warnings.join('; ')}`;
      log(`  [WARN] Q-8: 状态文件完整性告警（${q8Warnings.length} 项，不阻塞）`);
      q8Warnings.forEach(w => log(`         - ${w}`));
      pass++;  // WARN 不阻塞，计入 pass
    } else {
      log('  [OK] Q-8: 状态文件完整性通过');
      pass++;
      q8Detail = '状态文件完整';
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}`);
  log('======================================================================');

  // 生成 quality-report.yaml
  // v5.14 修复 F3：移除硬编码 critical: 0，动态分类 critical/major + 逐项明细 + q5_degraded 标记
  //   critical = q1Fail + q2Fail + q6Fail（影响结构/契约/自检）
  //   major    = q3Fail + q4Fail + q5Fail（影响文档/状态/规范）
  const demoraDir = path.join(projectRoot, '.demora');
  if (fs.existsSync(demoraDir)) {
    const criticalCount = q1Fail + q2Fail + q6Fail;
    const majorCount = q3Fail + q4Fail + q5Fail;
    // YAML 字符串转义：detail 中的特殊字符（冒号、引号）需引号包裹
    const yamlStr = (s) => {
      if (!s) return '""';
      if (/[:#{}\[\],&*!|>'"%@`]/.test(s) || /^\s|\s$/.test(s)) {
        return '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
      }
      return s;
    };
    const q1Result = q1Fail > 0 ? 'fail' : 'pass';
    const q2Result = q2Fail > 0 ? 'fail' : 'pass';
    const q3Result = q3Fail > 0 ? 'fail' : (q3Warn > 0 ? 'warn' : 'pass');
    const q4Result = q4Fail > 0 ? 'fail' : (q4Warn > 0 ? 'warn' : 'pass');
    const q5Result = q5Fail > 0 ? 'fail' : (q5Degraded ? 'degraded' : 'pass');
    const q6Result = q6Fail > 0 ? 'fail' : 'pass';
    const q7Result = q7Fail > 0 ? 'fail' : (q7Warn > 0 ? 'warn' : 'pass');
    const q8Result = q8Fail > 0 ? 'fail' : (q8Warn > 0 ? 'warn' : 'pass');
    // v5.15 P2-2：强制刷新 generated_at 为当前时间（消除陈旧快照）
    const generatedAt = new Date().toISOString();
    const reportLines = [
      '# quality-report.yaml — 自动生成',
      `passed: ${fail === 0}`,
      `defects: ${fail}`,
      `critical: ${criticalCount}`,
      `major: ${majorCount}`,
      `checks_passed: ${pass}`,
      `checks_failed: ${fail}`,
      `q5_degraded: ${q5Degraded}`,
      `generated_at: "${generatedAt}"`,
      '',
      '# 逐项明细（v5.14 新增）',
      'checks:',
      `  - name: Q-1`,
      `    result: ${q1Result}`,
      `    detail: ${yamlStr(q1Detail)}`,
      `  - name: Q-2`,
      `    result: ${q2Result}`,
      `    detail: ${yamlStr(q2Detail)}`,
      `  - name: Q-3`,
      `    result: ${q3Result}`,
      `    detail: ${yamlStr(q3Detail)}`,
      `  - name: Q-4`,
      `    result: ${q4Result}`,
      `    detail: ${yamlStr(q4Detail)}`,
      `  - name: Q-5`,
      `    result: ${q5Result}`,
      `    detail: ${yamlStr(q5Detail)}`,
      `  - name: Q-6`,
      `    result: ${q6Result}`,
      `    detail: ${yamlStr(q6Detail)}`,
      `  - name: Q-7`,
      `    result: ${q7Result}`,
      `    detail: ${yamlStr(q7Detail)}`,
      `  - name: Q-8`,
      `    result: ${q8Result}`,
      `    detail: ${yamlStr(q8Detail)}`,
    ];
    fs.writeFileSync(path.join(demoraDir, 'quality-report.yaml'), reportLines.join('\n') + '\n', 'utf-8');
    log('  [OK] 已生成 quality-report.yaml');

    // v5.15 rk3 P-4 修复：移除 quality-check 强制置 final_approved = true
    //   根因：quality-check 通过即写 final_approved=true，单方面满足 package-delivery 硬门禁，
    //         绕过 verify-delivery V-1~V-13 哈希终检（第二道门闩失效）。
    //   正确语义：final_approved 由 verify-delivery 通过后（哈希防漂移校验通过）统一置位，
    //         quality-check 仅负责质量报告生成，不越权改写阶段门禁标志。
  }

  if (fail > 0) {
    log('>>> 质量门禁未通过');
    return { ok: false, pass, fail };
  }
  log('>>> 质量门禁通过');
  return { ok: true, pass, fail };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('quality-check.mjs') || process.argv[1].endsWith('quality-check'));
if (isDirectRun) {
  main().then(result => process.exit(result.ok ? 0 : 1)).catch(e => { console.error(e); process.exit(1); });
}
