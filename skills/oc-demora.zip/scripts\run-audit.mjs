// run-audit.mjs
// Demora 通用浏览器审计脚本（v5.2.7）
// v2.2：D3 无弹窗设计豁免（决策A）+ D7 修正（text-align 归一化 start/end + 数字列豁免，依据 p2 实证）
// v2.3：D3 触发器启发式收紧（btn-primary 类命中且带 data-route/data-action/data-nav 的排除；显式 data-open-modal 永不排除）
//        + D3 逐页探测（D2 后停在最后一页导致单屏探 0 → 误走 n/a 豁免的修正）
//        + D3 豁免收紧三分支（buttons==0 但存在弹窗容器 → warn 非 n/a，见 v2.3 按钮契约）
// v5.18 P0-A4：diagnose-result.json 新鲜度硬门禁 + --skip-diagnose 豁免
// v5.18 P0-A5：--retry 模式 + fix-suggestions.json + 失败维度截图瘦身
// v5.22：D6 业务状态签名判定——responded 升级为"业务状态签名 + 结构信号"语义：
//        点击前后临时隐藏 .toast 取 body.innerText + [data-action] 快照 + 内联 style 快照做签名对比，
//        从判定中移除 mutated/consoleLogged/toastVisible 三个假响应源
//        （toast-only 空交互、同值重渲染不再误判为响应）；toast/console 降级为报告信号
//        （[TOAST-ONLY] 标记 + totalToastOnly 独立计数，供诊断不参与阈值判定）；
//        D6_FIX_TEMPLATES 追加 toast-only 空交互与同值重渲染两条根因模板
// v5.23：三组审计增强（基于 fto-risk-platform UAT 实证缺陷）：
//        1. D7 逐页表格完整性检测——原视觉启发式只在初始页跑一次，<tr> 因
//           [data-element-id]{display:inline-flex} 布局坍塌漏检；现挂载于 D10 逐页导航
//           循环逐页检查：tr 非法直系子节点 / 可见行 display≠table-row / 行列数一致性
//        2. D8 密度双向检测——三元组精确判重漏检序号型重复（"待办任务行1/2/3"），
//           新增序号型重复检测（字段归一化判重）；新增交互元件类型覆盖率检测
//           （逐页采样，未标注类型占比>10% 且 >=3 告警，消除"52 个 button 仅 35 个
//           标注"不告警的盲区）
//        3. D11 docs/index.html mermaid 浏览器渲染校验（新维度）——PRD 引号 typo
//           （如 |"生成报告|）静态检查不报错、交付后浏览器才报 Syntax error；
//           用真实浏览器渲染全部 .mermaid 块做交付前拦截
//        记账影响：dimensions 键 17 -> 20（新增 D8_l3_sequence_dup /
//        D8_element_coverage / D11_docs_mermaid，DIMENSION_SUMMARY 动态计数无需同步）
// v5.24：五组审计增强（基于 UAT0826 三案例盲区实证，spec fix-uat0826-blindspots-v524）：
//        1. D8_element_coverage 重构——类型键改语义键（tagName + aria-label / 关联 label /
//           data-action / 文本截断30，优先语义属性）；选择器扩展 [role="button"] /
//           [tabindex] / 携带 data-action 的任意元素；规模分流校验（N<=4 全部实例须标注，
//           N>4 首个可见实例标注 + 卡片 element 名含同类说明）；页级判定升级——缺标类型
//           占比>10% 且 >=1 → WARN，页覆盖率<90% 或缺标类型>=3 → FAIL；明细落盘
//           audit-result.json 顶层 d8_coverage_details，WARN/FAIL 结果串含页码+缺标
//           类型样本（上限 20 条）
//        2. D8_l3_sequence_dup 规模感知——v5.24 契约下 <=4 实例组全部标注是正确行为，
//           仅 >4 实例组告警
//        3. D6 控件收集扩展——select / input[type=text] 纳入响应判定（select 换首个
//           非当前项 + dispatch change；input 填非空值 + dispatch input；复用 v5.22
//           业务状态签名判定）；仅携带 data-action 的控件做 responded 判定，纯装饰
//           控件只计数不判定（控制无监听控件误报）；测后恢复控件原值
//        4. 新增 D6_filter_consistency 筛选往返一致性探针（挂 D10 循环，导航 settle 后、
//           L2/L3 点击前触发）——对可见 select[data-action] / select[id]（及
//           search/filter/kw/关键词/搜索 命中的 input[text]）触发变更后断言"共 N 条"
//           计数文本与可见表格行数一致：不一致 FAIL，无计数文本且无任何可见状态变化
//           WARN；测后恢复原值，每页每控件只测一次，探针异常不阻塞主流程
//        5. D10 导航后公共区域断言（docScrollTop=0 + 首个可见 header/nav rect.top>=-1，
//           违例并入 D7 收口族判 FAIL；D7 未被 --dimensions 选中时降级 [WARN] 记入
//           WARN_DETAILS）+ D7 初始态 document 溢出检测（.app-shell 存在
//           且 scrollHeight > clientHeight+4 → WARN，骨架 footer 应注入滚动容器内）
//        记账影响：dimensions 键 20 -> 21（新增 D6_filter_consistency，DIMENSION_SUMMARY
//        动态计数无需同步）
//
// ============================================================
// [PROTECTED] 本文件受 SKILL.md 源码禁令保护，AI 严禁直接读取。
// 失败原因请使用审计输出的 [FIX_SUGGESTIONS] 块（含 detection_logic 字段）。
// 违反此禁令将导致审计失败判定无效。
// ============================================================
//
// 设计目标：
//   - 零场景定制：自动从 demo HTML 探测 PAGES / nav 链接 / modal 关闭按钮
//   - 截图标准环节：每个测试步骤自动截图保存到 demo/screenshots/
//   - 运行时交互验证：不仅检查静态结构，更验证点击后的实际行为
//
// 测试维度：
//   D0: 页面加载 + 控制台错误 + 4 项最小契约 + 截图
//   D1: 逐页 L2/L3 锚定率统计 + 每页截图
//   D2: 导航点击 → 页面切换验证（用户视角，非引擎视角）+ 截图
//   D3: 弹窗关闭按钮运行时验证（v5.14 闭环验证：触发→显示→关闭→隐藏）+ 截图
//       v2.2 决策A：无弹窗设计豁免——探测不到弹窗且无触发按钮时记 n/a（pass）不计 warn
//       v2.3 收紧：①触发器启发式收紧（btn-primary 类命中且带 data-route/data-action/data-nav 排除，
//                  显式 data-open-modal 永不排除）；②逐页探测（D2 后停在末页，单屏探 0 → 漏检）；
//                  ③豁免三分支（buttons==0 且有弹窗容器 → warn+fix_command；仅零容器才 n/a）
//   D4: L2 marker 闪烁采样（5 次采样 transform 是否变化）+ 截图
//   D5: v5.2.5 三项修复验证（findVisibleElement / suppressRefresh / L2 marker 序号）
//   D6: 按钮点击响应率（v5.14 修正：豁免 disabled 按钮；v5.22 业务状态签名判定：toast/console 降级报告信号）+ 截图
//   D7: 视觉启发式检查（v5.14 新增：固定元素交叠 + 空白大块 + 首屏文本密度）+ 截图
//   D8: 运行时 L3 元件交互验证（v5.14 新增：消除 S-11 静态 HTML 定向修补，DOM 断言 + click 响应检测）+ 截图
//   D9: 标注面板交互链路验证（v5.14 新增：开关显隐 + L2/L3 点击响应 + 关闭按钮 + 左侧页面协同激活检测）+ 截图
//       v5.14 修正：D9.3/D9.4 新增"面板-页面协同激活"检查（is-highlighted/is-active），
//                  覆盖用户报告"标注面板激活但左侧页面未激活"缺陷
//   D10: 逐页 L2/L3 全量激活验证（v5.14.2 新增：每页所有 L2 marker + 所有 L3 dot 逐个点击验证激活 + 截图）
//        背景：D8 只遍历 3 页 × 8 元件，D9 只点击 1 个 L2 + 1 个 L3，无法覆盖全量激活
//        实现：遍历所有页面，每页浏览器内批量点击所有 L2/L3，验证 zone/dot 激活 + 面板卡片激活
//        性能：浏览器内批量验证，单页 ~9s，8 页 ~75s（无性能瓶颈）
//   D11: docs/index.html mermaid 渲染校验（v5.23 新增：新开 page 以 file:// 加载 docs 页，
//        展开全部 details 触发惰性渲染后，逐块检查 svg 产出与 Syntax error 文案；
//        docs 未生成记 n/a 不计 fail，与 D3 无弹窗豁免同模式）
//
// v5.2.7 改进：
//   - 端口冲突防御：启动前主动清理占用端口的残留进程
//   - D3 弹窗验证增强：主动点击 .btn-new/.btn-add 等触发打开弹窗，不再依赖默认可见
//   - D6 采样上限调整：15 → 10（加速小场景审计）
//   - 截图命名规范：统一为 <label>-D<N>-<step>.jpeg（D7 fullPage 保留 .png）
//
// v5.14.2 改进（基于 dist 0728-153033-GLM-5.2 的 A/B 跑结果诊断）：
//   - D2 navLinks 扩展：支持 data-nav / data-route 属性导航（B 类 SPA demo 常用）
//   - D2 skip 消息修正：区分"真单页"与"多页无导航"，避免误导性 "single page" 标记
//   - D3 modalSelectors 扩展：新增 .modal-overlay / .pg-modal-mask / .modal-wrap / .modal-container / .modal-backdrop / .layui-layer / .ant-modal
//   - D3 openBtnSelectors 扩展：新增 [onclick*="openModal"] / [onclick*="showModal"] / [onclick*="openDialog"] 等内联触发检测
//   - D6 modalVisible 检测同步扩展：4 处 beforeState/afterState 全部覆盖 .modal-overlay 等动态弹窗
//   - D3 强制隐藏弹窗兜底同步扩展：确保动态创建的 .modal-overlay 等也能被清理
//
// v5.14.3 改进（基于 dist 0729-063958-GLM-5.2 的 A/B 跑结果诊断）：
//   - Playwright ESM 依赖路径修复：createRequire 从 cwd（项目目录）解析 playwright
//     原因：dist 包在 oc-demora/scripts/，ESM import 基于脚本位置找不到项目目录的 playwright
//     影响：B 跑 AI 被迫复制 run-audit.mjs 到项目目录运行
//   - gate-baseline 完整性校验强化：检测脚本是否在合法 scripts 目录（父目录有 skill-manifest.json）
//     原因：AI 复制脚本后 gate-baseline.mjs 找不到被 skip（"开发态兼容"），防御失效
//   - D10 导航四重兜底：新增方式3 [data-target-page] 点击 + 方式4 派发 popstate/hashchange 事件
//     原因：B 跑 D10 首轮 hidden 切换绕过 route() → injectAnnotationMarkers()，导致 127 个标注未激活
//
// v5.14.4 改进（基于 dist 0729-134335-GLM-5.2 的 A/B 跑结果诊断）：
//   - D10 L2/L3 查询范围修复：限定到当前可见页面 [data-page-id]:not([hidden])
//     原缺陷：document.querySelectorAll('.l2-marker' / '.l3-dot') 全局查询返回所有页面的标注
//            导致每页测试全部 N 个标注 × M 页 = N×M 次测试，隐藏页面的标注必然失败
//            实测：B 跑 37 L2 × 10 页 = 370 次测试，首轮 970 个标注未激活
//     修复：visiblePage.querySelectorAll() 只测当前页面的标注，总数 = 各页标注之和
//   - D10 L2 新增可见性过滤：getBoundingClientRect() 跳过隐藏 marker（与 L3 逻辑对齐）
//
// v5.14.5 改进（基于 dist 0729-173137-GLM-5.2 的 A/B 跑结果诊断）：
//   - D10.0 标注模式激活验证：点击 toggle 后验证 data-annotation-active 属性已设置
//     原盲区：只点击 toggle 不验证结果，标注引擎未激活时后续测试全部无效
//   - D10 每页导航后标注模式保持验证：防 app.js 路由切换清除 data-annotation-active
//     背景：部分 demo 的 app.js 路由逻辑会重置 body 属性，导致标注模式被关闭
//   - D10.2/D10.3 视觉可见性检查：computed style 检查 display/opacity/visibility
//     原盲区：只检查 getBoundingClientRect() 尺寸，不检查 computed style
//     背景：用户报告"b-run 左侧页面缺失全部标注（面板标注齐全）"，D10 通过但标注不可见
//     修复：标注图标 display:none/opacity:0/visibility:hidden → FAIL（不再假阳性通过）
//
// v5.14.6 改进（基于 dist 0730-060310-GLM-5.2 的 A/B 跑结果诊断）：
//   - D10 L3 存在性断言：有 data-element-id 但 0 个 .l3-dot → FAIL
//     根因：标注引擎不负责动态创建 .l3-dot，AI 经常忘记写，D10 报告 L3 0/0 误判为"通过"
//     修复：检测 data-element-id > 0 但 .l3-dot = 0 → FAIL（不再假阳性通过）
//   - 标注引擎 ensureMarkers() 自动创建 .l2-marker 和 .l3-dot（annotation-engine.js v5.2.8）
//     根治"AI 忘记写 marker/dot"导致"左侧页面缺失标注"的反复问题
//     AI 只需写 data-zone-id / data-element-id 属性，标注引擎自动创建 marker/dot 子元素
//
// v5.14.7 改进（基于 dist 0730-060310-GLM-5.2 的 A/B 跑结果诊断）：
//   - P1 修复：summary.total 与 dimensions 计数口径不一致
//     根因：D5.1/D5.2 执行 pass++/fail++ 但不写 dimensions；D9.2/D9.3/D9.4 pass 路径不写 dimensions
//     影响：A 跑 total=16 但 dimensions 只有 11 项，缺口 5 项
//     修复：D5.1 新增 D5_l2_marker_seq；D5.2 新增 D5_multi_page_anchor；
//           D9 拆分为 4 个子维度 D9_toggle_show / D9_l2_coop / D9_l3_coop / D9_panel_close
//           dimensions 数量从 11 增至 16，与 total 完全对齐
//   - P2 修复：D6 skip→pass 反向漏洞
//     根因：D6 "无启用按钮"判 pass，AI 可将所有按钮加 disabled 让 demo 完全不可交互仍过 D6
//     修复：D6 skip 改为 warn，企业级应用 0 启用按钮视为异常信号
//
// v5.14.8 改进（基于 dist 0730-081150-GLM-5.2 的 B 跑结果诊断）：
//   - D9.3 L2 marker 点击逻辑修复：盲目点击 markers[1] → 改为点击第一个可见 marker
//     根因：D9.3 盲目点击 DOM 顺序第二个 marker，不检查可见性。若 markers[1] 在隐藏页面，
//           findVisibleElement 找不到对应 zone → is-highlighted 不生效 → D9.3 必然 FAIL。
//           AI 被迫在 demo app.js 中加捕获阶段监听器定向 hack（反向工程审计逻辑）。
//     修复：遍历 markers 找第一个 getBoundingClientRect + computed style 可见的 marker 点击。
//           与 D9.4 L3 dot 逻辑对齐，消除 AI 定向 hack 的动机。
//
// 用法：
//   node scripts/run-audit.mjs --demo <demo-path> [--port 8800] [--label <name>]
//
// 退出码：0=全部通过，1=有 FAIL，2=参数错误

import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { createRequire } from 'module';
import { spawn, execSync } from 'child_process';
import http from 'http';
import { safeRemoveFileSync, safeCleanFilesSync, detectShim } from './lib/platform-utils.mjs';
import { readStateYaml, invalidate } from './lib/state-cache.mjs';
import { isPortFree, findFreePort } from './lib/port-utils.mjs';
// v5.18 P0-A2：D3/D9/D10 浏览器内谓词迁移到 lib/audit-probes.mjs（单一事实源）
//   与 diagnose-runtime.mjs 共用同一套谓词，保证"诊断过 = 审计过"
//   使用方式：page.evaluate(probes.fn, arg) — probes 函数自包含，可序列化到浏览器执行
//   注意：复杂批量 evaluate（D3 open+verify+retry / D9.3/D9.4 协同+遮挡）保留内联以维持
//         v5.17 Tier B2 批量化性能优化；其核心判定逻辑（isVisible querySelectorAll /
//         targetZoneHighlighted / targetDotActive 身份校验）已与 probes 对齐
import * as probes from './lib/audit-probes.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// v5.14.16 根治修复：createRequire 从 __dirname 解析（消除 cwd 依赖导致的版本漂移）
//   根因（v5.14.3 缺陷）：createRequire(process.cwd()) 依赖不可控的 cwd
//         - agent cwd 在 skill 目录内 → 解析到 dist 预装 playwright（1.61.1）✅
//         - agent cwd 在被审计项目目录 → 解析失败 → agent 现场安装最新版（1.62.1）❌
//         导致同一 dist 跑出不同 playwright 版本，A/B 跑结果不可比
//   修复：createRequire 从 __dirname 解析，路径固定为 <skillDir>/scripts/dummy.js
//         require.resolve 向上查找：<skillDir>/scripts/node_modules → <skillDir>/node_modules
//         <skillDir>/node_modules/playwright 永远指向 dist 预装版本（生产环境 skill 带 node_modules）
//   前提：生产环境 agent 平台安装的 skill 带 node_modules（已确认）
const skillDirRequire = createRequire(path.join(__dirname, 'dummy.js'));

// 集中管理 audit 等待时间常量（便于后续调优）
// 设计意图：将散落在 D0~D10 各处的硬编码 setTimeout/waitForTimeout 数值收敛为命名常量，
//           调优时只需修改一处；浏览器上下文（page.evaluate 内部）需通过参数注入使用。
const WAIT_TIMES = {
  ANNOTATION_SETTLE: 50,       // D10 标注激活后 DOM 渲染等待（原 150ms，CSS class 切换 <50ms 即可读取）
  BUTTON_RESPONSE: 200,        // D6 按钮点击后 MutationObserver 即时返回兜底（原 500ms）
  NAV_LINK_SETTLE: 200,        // D5.2 navLink 切换等待（原 500ms）
  MODAL_SHOW: 2000,            // D3 弹窗显示谓词超时（原固定 timeout，现谓词快速返回）
  PAGE_LOAD: 3000,             // D0 页面加载兜底（与 waitForFunction readyState 超时对齐）
};

// v5.17 Tier C：内置硬超时（15 min）— 防 shell timeout 杀 wrapper 不杀 node 导致孤儿进程
//   背景：A/B 测试 codex-dsf 1st 审计 shell timeout 600s，node+Edge 孤儿进程继续运行 + 16 min 轮询浪费
//   实现：硬超时触发时 browser.close() + stopHttpServer() + process.exit(2)
//   SKILL.md 指引：AI 调用时 timeout_ms=960000（> 硬超时 900s），exit code 2 = 硬超时需修复不轮询
const HARD_TIMEOUT_MS = 900_000;

// v5.18 P0-A1：D3 isVisible querySelectorAll 修复（多弹窗首匹配误报）

// v5.14.16 修复 F（批次1）：[WARN] 行收集器
//   根因：G-1 grep 过滤器排除 [WARN] 行 — agent 用 grep 过滤输出丢失 [WARN]
//   修复：收集所有 [WARN] 行到 warnDetails 数组，[SUMMARY] 后强制输出 warn 详情块
//         agent 即使 grep 过滤也无法丢失（详情块是结构化输出，grep 难以整体排除）
const warnDetails = [];
// v5.16 Tier 3 Task 4：--dimensions-only 模式标志
//   仅输出 [SUMMARY] + 维度摘要表 + [FIX_SUGGESTIONS] 块，跳过 [INFO]/[OK]/[FAIL] 详细日志
//   目标：AI 重试审计时上下文消耗降低 80%+（原 10-50KB → <2KB）
//   注：[DIMENSION_SUMMARY] 和 [FIX_SUGGESTIONS] 块通过 console.log 直接输出，绕过此过滤器
let dimensionsOnly = false;
function log(msg) {
  if (typeof msg === 'string' && msg.includes('[WARN]')) {
    warnDetails.push(msg.replace(/^\s+/, '').replace(/^\[WARN\]\s*/, ''));
  }
  // v5.16 Tier 3：--dimensions-only 模式下仅输出摘要性内容
  //   允许：[SUMMARY]、>>> 评级行、=== 分隔线
  //   跳过：[INFO]/[OK]/[FAIL]/[WARN] 详细行、缩进明细、空行
  if (dimensionsOnly && typeof msg === 'string') {
    const trimmed = msg.trimStart();
    if (!trimmed) return; // 空行跳过
    const allowed = trimmed.startsWith('[SUMMARY]') ||
                    trimmed.startsWith('>>>') ||
                    trimmed.startsWith('===');
    if (!allowed) return;
  }
  process.stdout.write(msg + '\n');
}

// v5.18 P0 修复：logAlways — 关键流程控制信息直出（绕过 dimensionsOnly 过滤器）
//   根因：p1 案例 4 次 --retry 被 A4 新鲜度门禁秒拒，门禁输出的 3 行 [FAIL] 提示
//         经 log() 被 --retry 隐含的 dimensionsOnly 过滤器吞掉（仅放行 [SUMMARY]/>>>/===），
//         agent 只看到两行 banner，连续 4 次盲试并误判为端口占用（实际端口空闲）
//   行为：与 log() 输出格式一致（无前缀），保留 [WARN] 收集副作用，但不做 dimensionsOnly 过滤
//   先例：[FIX_SUGGESTIONS] / [DIMENSION_SUMMARY] 块同样用直出绕过过滤器
function logAlways(msg) {
  if (typeof msg === 'string' && msg.includes('[WARN]')) {
    warnDetails.push(msg.replace(/^\s+/, '').replace(/^\[WARN\]\s*/, ''));
  }
  process.stdout.write(msg + '\n');
}

// ===== 参数解析 =====
function parseArgs(argv) {
  const args = { demo: null, port: 8800, label: 'audit', help: false, dimensionsOnly: false, debugEvalCount: false, skipDiagnose: false, retry: false, dimensions: null };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') args.help = true;
    else if (a === '--demo') args.demo = argv[++i];
    else if (a === '--port') args.port = parseInt(argv[++i], 10);
    else if (a === '--label') args.label = argv[++i];
    // v5.16 Tier 3 Task 4：仅输出维度摘要 + FIX_SUGGESTIONS（AI 重试时降低上下文消耗）
    else if (a === '--dimensions-only') args.dimensionsOnly = true;
    // v5.18 P1：只跑指定维度（逗号分隔，如 D3,D10），修复轮快速验证用
    //   D0 基础检查始终执行；部分维度通过不写 runtime_audit_passed；最终验收必须全量审计
    else if (a === '--dimensions') args.dimensions = argv[++i];
    // v5.17 Tier B5：opt-in evaluate 调用计数器（仅 V2/B5 性能验证使用，正常审计零开销）
    else if (a === '--debug-eval-count') args.debugEvalCount = true;
    else if (a === '--skip-diagnose') args.skipDiagnose = true;
    // v5.18 P0-A5：--retry 模式 = --dimensions-only + 跳过截图 + 跳过 self-diagnostics
    //   用途：修复后重跑，仅校验维度评级是否回升，降低上下文消耗（输出 < 2KB）
    //   仅最终验收轮不带 --retry 跑全量审计
    else if (a === '--retry') { args.retry = true; args.dimensionsOnly = true; }
  }
  return args;
}

function showHelp() {
  console.log(`Demora 通用浏览器审计 (v5.2.7)

用法：
  node scripts/run-audit.mjs --demo <demo-path> [--port 8800] [--label <name>] [--dimensions-only]

参数：
  --demo <path>          demo 目录路径（包含 index.html）
  --port <num>           本地 HTTP 端口（默认 8800）
  --label <name>         审计标签（用于报告命名，默认 'audit'）
  --dimensions-only      仅输出 [SUMMARY] + 维度摘要表 + [FIX_SUGGESTIONS] 块
                         跳过 [INFO]/[OK]/[FAIL] 详细日志（AI 重试时降低 80%+ 上下文消耗）
  --debug-eval-count     统计 page.evaluate 调用次数并输出（仅性能验证用，正常审计勿用）
  --skip-diagnose        跳过 diagnose-result.json 新鲜度检查（仅在 Playwright 不可用时使用）
  --retry                重试模式（等价 --dimensions-only + 跳过截图 + 跳过 self-diagnostics），仅用于修复后重跑
  --dimensions <list>    只执行指定维度（逗号分隔，如 D3,D10；有效值 D0,D2-D11，无 D1）
                         D0 基础检查始终执行（页面加载/页面与导航探测/标注激活是后续维度前置条件）
                         跳过的维度在 DIMENSION_SUMMARY 标注 skip: excluded by --dimensions
                         仅用于修复轮快速验证；部分维度通过不写 runtime_audit_passed，最终验收必须全量审计

退出码：0=全部通过，1=有 FAIL，2=参数错误`);
}

// ===== v5.18 端口处理：isPortFree / findFreePort 已抽取到 lib/port-utils.mjs =====
//   历史：v5.2.7 引入 cleanupPort（kill 进程），v5.16 Task 7.1 抽取到 lib，v5.18 重构为不 kill 的检测模式
//   调用方式：const freePort = await findFreePort(port, 20, { logger: log });
//   返回值契约：number=空闲端口（可能等于 startPort 或累加后的端口），null=全部被占用 → 调用方 exit(1)

// ===== 启动本地 HTTP 服务器 =====
let httpServerProc = null;
// v5.17 Tier C：browser 提升为模块级变量，供硬超时回调访问（原为 main() 内局部变量）
let browser = null;

function startHttpServer(demoDir, port) {
  return new Promise((resolve, reject) => {
    // 使用 Python http.server（cwd=demoDir）
    // 注意：spawn 不需要 shell，参数直接传递
    const args = ['-m', 'http.server', String(port), '--bind', '127.0.0.1'];
    httpServerProc = spawn('python', args, {
      cwd: demoDir,
      stdio: 'ignore',
      detached: false,
      shell: false,
    });
    httpServerProc.on('error', (e) => {
      log('[WARN] python http.server 启动失败: ' + e.message + '，尝试用 node 静态服务器');
      // 备选：用 node 内置 http 模块启动一个简易静态服务器
      resolve(startNodeStaticServer(demoDir, port));
    });
    // 轮询 URL 直到响应
    let attempts = 0;
    const maxAttempts = 20;
    const poll = () => {
      attempts++;
      const req = http.get(`http://127.0.0.1:${port}/`, (res) => {
        res.resume();
        if (res.statusCode === 200 || res.statusCode === 301 || res.statusCode === 200) {
          resolve(true);
        } else {
          if (attempts < maxAttempts) setTimeout(poll, 300);
          else resolve(false);
        }
      });
      req.on('error', () => {
        if (attempts < maxAttempts) setTimeout(poll, 300);
        else resolve(false);
      });
      req.setTimeout(1000, () => { req.destroy(); if (attempts < maxAttempts) setTimeout(poll, 300); else resolve(false); });
    };
    setTimeout(poll, 500);
  });
}

// 备选：Node 内置静态服务器
function startNodeStaticServer(demoDir, port) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let urlPath = req.url.split('?')[0];
      if (urlPath === '/') urlPath = '/index.html';
      const filePath = path.join(demoDir, urlPath);
      if (!fs.existsSync(filePath)) {
        res.writeHead(404); res.end('Not Found'); return;
      }
      const ext = path.extname(filePath);
      const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
      fs.createReadStream(filePath).pipe(res);
    });
    server.listen(port, '127.0.0.1', () => {
      httpServerProc = server;
      resolve(true);
    });
    server.on('error', () => resolve(false));
  });
}

function stopHttpServer() {
  try {
    if (httpServerProc) {
      if (typeof httpServerProc.kill === 'function') {
        httpServerProc.kill();
      } else if (httpServerProc.close) {
        httpServerProc.close();
      }
      httpServerProc = null;
    }
  } catch (e) { /* 忽略 */ }
  // v5.18 P1-D3：移除"通过端口杀进程"的 PowerShell 兜底
  //   根因：Get-NetTCPConnection + Stop-Process 是历史 ETIMEDOUT 耗时源（PowerShell 启动 + 端口扫描数秒），
  //         且违反"不 kill 任何冲突端口"约束（无法确认被占端口真实用途，强杀可能误杀其他服务）
  //   现状：端口治理由 findFreePort 在启动时完成（被占自动累加找空闲端口），此处只需关闭自己启动的 server
}

// ===== P015: 上下文 token 计数检查（v5.16 P0-4 修复 / Task 11.3 改为非阻断）=====
//   根因：SKILL.md 只有软指令"上下文 > 200K tokens 时必须触发 Context Compaction"
//         无脚本强制检查，AI 无法自感知 → wb-dsf 345K tokens 未压缩
//   v5.16 P0-4 修复：run-audit 前检查 .demora/context-token-count.txt
//   v5.16 Task 11.3：> 200K 由 FAIL 阻断改为 WARN 非阻断（实测 5 案例全部 <200K，
//     AI 估算值不可靠，P015 检查形同虚设；spec.md L220 / tasks.md SubTask 11.3）
function checkP015(projectRoot) {
  const tokenFile = path.join(projectRoot, '.demora', 'context-token-count.txt');
  if (!fs.existsSync(tokenFile)) {
    return { level: 'WARN', code: 'P015', msg: '未提供 context-token-count.txt，无法检查上下文治理（建议 AI 每轮审计前写入当前 token 计数）' };
  }
  const raw = fs.readFileSync(tokenFile, 'utf-8').trim();
  const tokenCount = parseInt(raw, 10);
  if (isNaN(tokenCount)) {
    return { level: 'WARN', code: 'P015', msg: 'context-token-count.txt 内容非数字: ' + raw.substring(0, 50) };
  }
  // v5.16 Task 11.3：P015 改为非阻断 WARN（spec.md L220 / tasks.md SubTask 11.3）
  //   原实现：> 200K 时 FAIL 阻断审计 → AI 必须先触发 Context Compaction
  //   新实现：> 200K 时 WARN 但不阻断，继续审计（实测 5 案例全部 <200K，从未触发 Compaction；
  //           AI 估算值不可靠，P015 检查形同虚设，故降级为参考性 WARN）
  if (tokenCount > 200000) {
    return { level: 'WARN', code: 'P015', msg: '上下文 token 计数 ' + tokenCount + ' > 200K，建议触发 Context Compaction（非阻断，继续审计）' };
  }
  return null;
}

// ===== v5.16 Tier 3 Task 3：结构化失败诊断输出（[FIX_SUGGESTIONS] 块）=====
//   目标：审计失败时输出 dimension/root_cause/fix_pattern/evidence_selector 四字段模板，
//         消除 AI 读 run-audit.mjs 源码定位失败的需求（原 5-26 min/次 → 目标 1-3 min/次）
//   策略：按 dimension 返回所有可能根因模板，AI 根据 diagnostics + evidence_selector 自行判断

// D10 失败根因模板（6 种，v5.18 新增重复 id 根因）
// v5.17 Tier E2：每个模板增加 detection_logic 字段，描述检测逻辑摘要（AI 无需读源码即可理解检测原理）
const D10_FIX_TEMPLATES = [
  { dimension: 'D10', root_cause: 'main 容器 display:none 导致标注不可见', detection_logic: 'D10 逐页点击 .l2-marker/.l3-dot，激活后检查 marker 的 computed style（display/opacity/visibility）+ getBoundingClientRect 尺寸 > 0；main display:none 会导致内部 marker 不可见', fix_pattern: '检查 demo/assets/style.css 中 main { display: ... }，移除 display:none 或改为 display:block', evidence_selector: 'grep -n "display:\\s*none" demo/assets/style.css' },
  { dimension: 'D10', root_cause: '前景色与背景色相同导致标注不可见', detection_logic: 'D10 检查 marker 的 computed style display/opacity/visibility + 尺寸，但不检查颜色对比度；CSS 激活规则缺失（.l3-dot.is-active 无高对比色）时 marker 视觉不可见但 D10 通过', fix_pattern: '确保 main 文本色与背景色对比度 >= 4.5:1（WCAG AA）', evidence_selector: 'node -e "const p=require(\"path\");const c=require(\"fs\").readFileSync(p.join(\"demo\",\"assets\",\"style.css\"),\"utf8\");console.log(c.match(/color[^;]*/gi))"' },
  { dimension: 'D10', root_cause: '__ANNOTATION_DATA__ 全局变量缺失', detection_logic: 'D10 前置检查 window.__ANNOTATION_DATA__ 存在性 + 解包 pages 结构（支持 {version,pages} 包装与扁平 {P01} 两种结构），无数据则该页跳过', fix_pattern: '确保 demo/index.html 或 app.js 中赋值 window.__ANNOTATION_DATA__ = { pages: {...} }', evidence_selector: 'grep -rn "__ANNOTATION_DATA__" demo/index.html demo/assets/app.js' },
  { dimension: 'D10', root_cause: 'data-annotation-active .l3-dot CSS 激活规则缺失', detection_logic: 'D10.0 检查 [data-annotation-active] 属性是否设置；D10.3 L3 激活后检查 .l3-dot.is-active class 是否存在 + computed style 视觉可见', fix_pattern: '在 style.css 添加 [data-annotation-active="true"] .l3-dot.is-active { background: <high-contrast-color>; border: 2px solid <accent>; }', evidence_selector: 'grep -n "data-annotation-active.*l3-dot\\|l3-dot.*is-active" demo/assets/style.css' },
  { dimension: 'D10', root_cause: '页面切换时 hidden 属性未正确移除导致标注未注入', detection_logic: 'D10 每页导航后 waitForFunction 谓词检查 [data-page-id] 的 hidden 属性 + style.display，4 重兜底（a[href] click / data-nav click / data-target-page click / popstate 事件）', fix_pattern: '检查 switchPage/route 函数，确保 newPage.hidden = false; oldPage.hidden = true，并触发 injectAnnotationMarkers', evidence_selector: 'grep -n "\\.hidden\\s*=\\|switchPage\\|route(" demo/assets/app.js' },
  { dimension: 'D10', root_cause: '重复 data-element-id 导致 L3 dots 只激活第一行（v5.18 新增）', detection_logic: 'D10 L3 dot 激活通过 querySelector("[data-element-id=xxx]") 定位元素，重复 id 时只返回第一个匹配；动态表格行模板复用同一 id 时，renderReport/renderCaseList 生成 N 行只有第一行有标注', fix_pattern: '检查动态表格行模板，确保每行用唯一 data-element-id（如 data-element-id="case-row-${idx}"）；pre-audit-check P029 会检测静态 HTML 中的重复 id', evidence_selector: 'grep -nE "data-element-id" demo/index.html | sort | uniq -d' },
];

// D3 失败根因模板（3 种）
const D3_FIX_TEMPLATES = [
  { dimension: 'D3', root_cause: '[data-open-modal] 按钮无事件绑定（定向修补特征）', detection_logic: 'D3 点击 [data-open-modal] 触发按钮，poll 检测 modalSelectors 弹窗可见性（offsetWidth>0 + !hidden，超时 MODAL_SHOW=2000ms），失败后 500ms 重试 1 次（flaky 机制），仍失败判 open-fail', fix_pattern: '为每个 [data-open-modal] 添加 onclick 或在 app.js 中 addEventListener("click", () => openModal(id))', evidence_selector: 'grep -n "data-open-modal" demo/index.html demo/assets/app.js' },
  { dimension: 'D3', root_cause: 'modal selector 与 data-open-modal 值不匹配', detection_logic: 'D3 点击触发按钮后 poll 检测 modalSelectors 列表（#modalMask/.modal/[role=dialog]/.modal-overlay 等 14 种）中任一选择器可见，匹配不到判 open-fail', fix_pattern: '确保 [data-modal-id="X"] 与 [data-open-modal="X"] 一一对应', evidence_selector: 'grep -nE "data-(open-)?modal" demo/index.html' },
  { dimension: 'D3', root_cause: '弹窗闭环按钮缺失或无关闭事件', detection_logic: 'D3 弹窗显示后遍历 modalCloseSelectors（#modalClose/.modal-close/[data-close] 等 9 种）在弹窗容器内/全局查找关闭按钮，找不到判 no-close-btn；点击后 poll 检测弹窗隐藏（2000ms 超时），未隐藏判 close-fail', fix_pattern: '每个 modal 必须含 [data-close-modal] 或 .close 按钮，并绑定关闭事件（设置 modal.style.display="none"）', evidence_selector: 'grep -n "data-close-modal\\|class=\\"close\\|modal.*display" demo/index.html demo/assets/app.js' },
];

// D5 失败根因模板（3 种，v5.18 新增空 marker 根因）
const D5_FIX_TEMPLATES = [
  { dimension: 'D5', root_cause: 'data-page-id 数量与预期不符', detection_logic: 'D5.1 统计 [data-page-id] 数量与 detectedPages 对比', fix_pattern: '检查每个 page 容器必须有 data-page-id 唯一标识', evidence_selector: 'grep -c "data-page-id" demo/index.html' },
  { dimension: 'D5', root_cause: 'data-nav 链接与 data-page-id 不匹配', detection_logic: 'D5.2 点击 [data-nav] 链接后检查对应 [data-page-id] 可见性（waitForFunction 谓词）', fix_pattern: '确保每个 [data-nav="X"] 对应一个 [data-page-id="X"]', evidence_selector: 'grep -nE "data-(nav|page-id)=" demo/index.html' },
  { dimension: 'D5', root_cause: '空 .l2-marker 导致 D5_l2_marker_seq fail（v5.18 新增；v5.19 编码升级为 Pn-Ln-xxx）', detection_logic: 'D5_l2_marker_seq 检查每个 .l2-marker 的 textContent 是否为规范编码（v5.19 起：P页-L2-序号 如 P01-L2-001，兼容旧数字序号）；AI 写 HTML 时插入空 <span class="l2-marker"></span>，标注引擎 ensureMarkers 检测到已存在则跳过不填充编码', fix_pattern: '删除空 .l2-marker 让引擎自动创建带 Pn-Ln-xxx 编码的 marker（enhance-prototype C10 已自动修复，重跑 enhance-prototype 即可）', evidence_selector: 'grep -nE "l2-marker" demo/index.html | grep -E "><\\/span>"' },
];

// D9 失败根因模板（3 种）
const D9_FIX_TEMPLATES = [
  { dimension: 'D9', root_cause: 'annotation 面板未显示（display/visibility 隐藏）', detection_logic: 'D9.2 点击 [data-annotation-toggle]，等待 500ms 后穿透 Shadow DOM 检查 .annotation-panel 的 computed style display + offsetWidth/offsetHeight + [data-annotation-active] 属性', fix_pattern: '检查 .annotation-panel 的 display/visibility，确保 toggle 点击后 display:block', evidence_selector: 'grep -n "annotation-panel\\|anno-panel" demo/assets/style.css' },
  { dimension: 'D9', root_cause: 'L2 marker 高亮规则缺失（is-highlighted 未生效）', detection_logic: 'D9.3 点击可见 .l2-marker，poll 等待 .anno-card（2000ms+300ms fallback），检查 .anno-zone.is-highlighted 数量 + .anno-card.is-active 数量 + targetZoneHighlighted 身份校验（限定可见页面查询）', fix_pattern: '添加 .anno-zone.is-highlighted 或 [data-annotation-active] .l2-marker.is-highlighted 规则', evidence_selector: 'grep -n "is-highlighted\\|l2-marker" demo/assets/style.css' },
  { dimension: 'D9', root_cause: 'L3 dot 激活状态 CSS 缺失（is-active 未生效）', detection_logic: 'D9.4 点击可见 .l3-dot（computed style display/opacity/visibility 检查），poll 等待 .anno-card，检查 .l3-dot.is-active 数量 + .anno-card.is-active 数量 + targetDotActive 身份校验', fix_pattern: '添加 .l3-dot.is-active 规则（高对比背景色 + 边框）', evidence_selector: 'grep -n "l3-dot.*is-active\\|is-active.*l3-dot" demo/assets/style.css' },
];

// D6 失败根因模板（5 种：v5.18 新增 2 种，v5.22 新增 2 种假响应根因，v5.24 新增 1 种筛选断链根因）
const D6_FIX_TEMPLATES = [
  { dimension: 'D6', root_cause: '按钮无 JS 事件绑定（cancelModal/prevPage/nextPage 等 handler 缺失）', detection_logic: 'D6 逐个点击启用按钮（非 disabled），poll 检测 DOM 变化（MutationObserver）或 URL hash 变化或 modal 可见性变化；无任何变化判定按钮无响应', fix_pattern: '在 app.js 中为每个按钮 addEventListener 或用事件委托（document.addEventListener("click", e => { const btn = e.target.closest("[data-action]"); ... })）；运行 node scripts/diagnose-button-failure.mjs --demo demo --port 8801 定位真因', evidence_selector: 'grep -nE "addEventListener|onclick|data-action" demo/assets/app.js' },
  { dimension: 'D6', root_cause: '动态行重渲染时按钮脱离 DOM（v5.18 新增）', detection_logic: 'D6 点击按钮后 MutationObserver 兜底 200ms 内检测 DOM 变化；动态表格行重渲染（renderReport/renderCaseList）时按钮被 innerHTML 覆盖，旧按钮引用脱离 DOM，新按钮无事件绑定', fix_pattern: '动态行重渲染后用事件委托重新绑定（document.addEventListener 在初始化时一次绑定，不依赖具体按钮元素）；或重渲染后手动 querySelectorAll(...).forEach(addEventListener)；按钮追加内联 onclick 也可避免脱离', evidence_selector: 'grep -nE "innerHTML|renderReport|renderCaseList" demo/assets/app.js' },
  { dimension: 'D6', root_cause: 'toast-only 空交互：按钮唯一效果是 toast 提示（v5.22 新增）', detection_logic: 'D6 v5.22 业务状态签名判定：点击前后临时隐藏 .toast 取 body.innerText + [data-action] 元素 className/aria-pressed 快照 + 内联 style 快照做对比；签名与结构信号（domNodes/hash/modal/focus/class/aria）均无变化，仅 toast 可见性或 console 输出有变化 → 判 toastOnly（[TOAST-ONLY] 标记，计入未响应）', fix_pattern: '按 SKILL.md P1-6/R-11 契约，toast 不可单独成立为功能实现：须补充业务状态变化（数据增删改/视图切换/校验反馈/界面状态更新），如提交按钮写入数据列表并重渲染、开关按钮切换状态 class 且影响渲染输出，toast 仅作操作结果提示', evidence_selector: 'grep -nE "showToast|toast\\(" demo/assets/app.js' },
  { dimension: 'D6', root_cause: '同值重渲染假响应：handler 调用渲染函数但控件值未参与计算（v5.22 新增）', detection_logic: 'D6 v5.22 业务状态签名判定：MutationObserver 捕获到 mutation（如 textContent 重复赋相同文本）但业务签名（innerText/[data-action]/style 快照）无变化 → 不再判响应；典型如筛选 handler 调用 render 函数却从不读取筛选控件当前值，渲染输出恒定不变', fix_pattern: '按 R-11 筛选实现检查清单：筛选处理须读取控件当前值（select.value/input.checked 等）并使其影响渲染输出（过滤条件真实参与数据筛选/排序），禁止渲染结果与控件值无关的空转重渲染', evidence_selector: 'grep -nE "render|filter|querySelector.*(value|checked)" demo/assets/app.js' },
  { dimension: 'D6', root_cause: '筛选状态位与 display 同步断链（v5.24 新增，D6_filter_consistency）', detection_logic: 'D6_filter_consistency 探针挂 D10 逐页循环：对可见 select[data-action]/select[id]（及 search/filter/kw/关键词/搜索 命中的 input[text]）触发换项 change / 填入首行首格文本前 2 字，400ms 后断言同页 共\\s*\\d+\\s*(条|行|个|件|家|项) 计数文本与可见表格行数一致；不一致 FAIL，无计数文本且无任何可见状态变化 WARN', fix_pattern: '按 v2.4 契约全量重算 display：筛选 handler 须遍历数据全集，写状态位（如 dataset.xxxFiltered）与 style.display 赋值须同一行集覆盖——写状态位遍历全集、赋 display 仅 filter 子集是典型断链（计数变化但表格行不变），重算后同步更新计数文本', evidence_selector: 'grep -nE "display|Filtered|filter" demo/assets/app.js' },
];

// D11 失败根因模板（1 种，v5.23 新增）
const D11_FIX_TEMPLATES = [
  { dimension: 'D11', root_cause: 'PRD mermaid 源码语法错误（引号 typo 等）', detection_logic: 'D11 新开 page 以 file:// 加载项目根 docs/index.html，展开全部 details 触发 mermaid-init.js 惰性渲染，waitForFunction 等待每个 .mermaid 块产出 svg/.mermaid-error/.mermaid-fallback（15s 容错），逐块评估 innerText 含 Syntax error/Error 或无 svg 子节点 → FAIL（块序号 + 首个非空行 40 字符片段）', fix_pattern: '检查 docs/prd/ 对应章节 mermaid 块引号配对（如 |"生成报告| 缺右引号），修复后重跑 generate-product-docs', evidence_selector: 'grep -n "mermaid" docs/index.html | head -30' },
];

// 按维度返回所有根因模板（AI 根据 diagnostics + evidence_selector 自行判断具体根因）
//   决策：若不知道具体根因，输出该 dimension 的所有模板，让 AI 自行判断
function matchFixSuggestion(failedItem) {
  const dim = failedItem.dim;
  if (dim === 'D10') return D10_FIX_TEMPLATES;
  if (dim === 'D3') return D3_FIX_TEMPLATES;
  if (dim === 'D5') return D5_FIX_TEMPLATES;
  if (dim === 'D9') return D9_FIX_TEMPLATES;
  if (dim === 'D6') return D6_FIX_TEMPLATES;
  if (dim === 'D11') return D11_FIX_TEMPLATES;
  return [];
}

/**
 * 输出 [FIX_SUGGESTIONS] 块，引导 AI 按维度修复（避免 AI 读源码定位失败）
 * @param {Array} failedDimensions - 失败维度列表 [{dim, reason, diagnostics}]
 */
function outputFixSuggestions(failedDimensions) {
  if (!failedDimensions || failedDimensions.length === 0) return;

  const suggestions = [];
  for (const f of failedDimensions) {
    const templates = matchFixSuggestion(f);
    for (const t of templates) {
      suggestions.push({
        dimension: t.dimension,
        root_cause: t.root_cause,
        detection_logic: t.detection_logic,
        fix_pattern: t.fix_pattern,
        evidence_selector: t.evidence_selector,
        diagnostics: f.diagnostics || null,
      });
    }
  }

  if (suggestions.length === 0) return;

  // 使用 console.log 直接输出（绕过 log() 过滤器，确保 --dimensions-only 模式也输出）
  console.log('[FIX_SUGGESTIONS_BEGIN]');
  console.log(JSON.stringify(suggestions, null, 2));
  console.log('[FIX_SUGGESTIONS_END]');
}

// ===== v5.16 Tier 3 Task 5：self-diagnostics 收集器（D10/D3/D5/D9 失败时附 DOM 断言结果）=====
//   目标：消除 AI 读源码定位失败的需求，浏览器内 DOM 状态直接附在 FIX_SUGGESTIONS 中
//   注意：在审计末尾（browser.close 前）收集，反映审计结束时的 DOM 状态
//         结构性信息（element 计数、computed style、data 属性）在结束时仍有效

// D10 失败诊断：main computed style / .l3-dot 状态 / __ANNOTATION_DATA__ 结构
async function collectD10Diagnostics(page) {
  return await page.evaluate(() => {
    const main = document.querySelector('main');
    const mainStyle = main ? window.getComputedStyle(main) : null;
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    const data = window.__ANNOTATION_DATA__;
    return {
      mainExists: !!main,
      mainDisplay: mainStyle ? mainStyle.display : null,
      mainVisibility: mainStyle ? mainStyle.visibility : null,
      mainColor: mainStyle ? mainStyle.color : null,
      mainBgColor: mainStyle ? mainStyle.backgroundColor : null,
      annotationDataExists: typeof data !== 'undefined',
      annotationDataType: typeof data,
      annotationDataKeys: data && typeof data === 'object' ? Object.keys(data).slice(0, 10) : [],
      l3DotCount: document.querySelectorAll('.l3-dot').length,
      activeL3DotCount: document.querySelectorAll('.l3-dot.is-active').length,
      l2MarkerCount: document.querySelectorAll('.l2-marker').length,
      dataElementIdCount: document.querySelectorAll('[data-element-id]').length,
      annotationActive: contentRoot.hasAttribute('data-annotation-active'),
    };
  });
}

// D3 失败诊断：弹窗 selector 匹配 / 按钮事件绑定检测
async function collectD3Diagnostics(page) {
  return await page.evaluate(() => {
    const openModalBtns = document.querySelectorAll('[data-open-modal]');
    const modals = document.querySelectorAll('[data-modal-id], .modal, .modal-overlay, .pg-modal-mask, .modal-wrap, .modal-container');
    const closeBtns = document.querySelectorAll('[data-close-modal], .close, .modal-close, .btn-close');
    return {
      openModalBtnCount: openModalBtns.length,
      openModalBtnDetails: Array.from(openModalBtns).slice(0, 5).map(b => ({
        text: (b.textContent || '').trim().substring(0, 30),
        modalId: b.getAttribute('data-open-modal'),
        hasOnclick: b.hasAttribute('onclick'),
        dataAction: b.getAttribute('data-action'),
      })),
      modalCount: modals.length,
      modalDetails: Array.from(modals).slice(0, 5).map(m => m.getAttribute('data-modal-id') || (m.className || '').substring(0, 50)),
      closeBtnCount: closeBtns.length,
    };
  });
}

// D5 失败诊断：data-page-id/data-nav 数量对比表
async function collectD5Diagnostics(page) {
  return await page.evaluate(() => {
    const pages = document.querySelectorAll('[data-page-id]');
    const navLinks = document.querySelectorAll('[data-nav]');
    const aHrefNavs = document.querySelectorAll('a[href]');
    return {
      pageCount: pages.length,
      pageIds: Array.from(pages).map(p => p.getAttribute('data-page-id')),
      dataNavLinkCount: navLinks.length,
      dataNavTargets: Array.from(navLinks).map(n => n.getAttribute('data-nav')),
      aHrefCount: aHrefNavs.length,
    };
  });
}

// D9 失败诊断：面板显示状态 / .anno-zone.is-highlighted / .l3-dot.is-active 状态
async function collectD9Diagnostics(page) {
  return await page.evaluate(() => {
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const panel = sr ? sr.querySelector('.annotation-panel') : null;
    const panelStyle = panel ? window.getComputedStyle(panel) : null;
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    return {
      panelExists: !!panel,
      panelDisplay: panelStyle ? panelStyle.display : null,
      panelVisibility: panelStyle ? panelStyle.visibility : null,
      panelOffsetWidth: panel ? panel.offsetWidth : 0,
      panelOffsetHeight: panel ? panel.offsetHeight : 0,
      annotationActive: contentRoot.hasAttribute('data-annotation-active'),
      annoZoneHighlightedCount: document.querySelectorAll('.anno-zone.is-highlighted').length,
      l2MarkerHighlightedCount: document.querySelectorAll('.l2-marker.is-highlighted').length,
      l3DotActiveCount: document.querySelectorAll('.l3-dot.is-active').length,
      toggleExists: !!document.querySelector('[data-annotation-toggle]'),
      closeBtnExists: !!(sr && sr.querySelector('[data-annotation-close]')),
    };
  });
}

// ===== 主流程 =====
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.demo) { showHelp(); process.exit(args.help ? 0 : 2); }
  // v5.16 Tier 3 Task 4：设置 --dimensions-only 全局标志（影响 log() 过滤行为）
  dimensionsOnly = args.dimensionsOnly;

  // v5.25 P1-3：审计起点计时埋点（audit_started_at → 与 audit-result.json timestamp 配对得出单轮审计耗时）
  //   失败不阻塞审计（非致命）；--dimensions 部分维度模式同样记录
  try {
    const stampRoot = path.dirname(path.resolve(args.demo));
    const stampStateFile = path.join(stampRoot, '.demora', 'state.yaml');
    if (fs.existsSync(stampStateFile)) {
      let stampText = fs.readFileSync(stampStateFile, 'utf-8');
      const stampValue = new Date().toISOString();
      const stampRegex = /^(\s*audit_started_at:\s*).*$/m;
      if (stampRegex.test(stampText)) {
        stampText = stampText.replace(stampRegex, '$1' + stampValue);
      } else {
        stampText = stampText.trimEnd() + '\naudit_started_at: ' + stampValue + '\n';
      }
      fs.writeFileSync(stampStateFile, stampText, 'utf-8');
      if (typeof invalidate === 'function') invalidate(stampRoot);
    }
  } catch (e) { /* 埋点失败不阻塞审计 */ }

  // v5.18 P1：--dimensions 解析与校验（只跑指定维度，修复轮快速验证）
  //   设计约束：
  //   - D0 始终执行：页面加载 / detectedPages+navLinks 探测 / 标注模式激活是 D2~D10 的共享基础设施
  //     （证据：navLinks/detectedPages 在 D0 块内定义，被 D2/D4/D5/D6/D8/D10 引用）
  //   - --dimensions 绝不绕过 A4 新鲜度门禁（门禁在维度执行之前，不受维度选择影响）
  //   - 部分维度通过不写 runtime_audit_passed（见汇总区 gatePassed 分支），最终验收必须全量审计
  // v5.23：新增 D11（docs/index.html mermaid 渲染校验），--dimensions 可选择/跳过
  const VALID_DIMENSIONS = ['D0', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8', 'D9', 'D10', 'D11'];
  let selectedDims = null;
  if (args.dimensions) {
    const wanted = args.dimensions.split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
    const invalid = wanted.filter(d => !VALID_DIMENSIONS.includes(d));
    if (invalid.length > 0) {
      log('[FAIL] --dimensions 含无效维度名: ' + invalid.join(', ') +
        '（有效值: ' + VALID_DIMENSIONS.join(',') + '；无 D1，逐页锚定率已并入 D5.2）');
      process.exit(2);
    }
    selectedDims = new Set(wanted);
    log('[INFO] --dimensions 部分维度模式: ' + [...selectedDims].join(',') +
      '（D0 基础检查始终执行；未选中维度标注 skip；最终验收仍须全量审计）');
  }

  // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
  // v5.14.3 强化：检测脚本是否在合法 scripts 目录（父目录有 skill-manifest.json）
  //   防止 AI 将 run-audit.mjs 复制到项目目录运行以绕过完整性校验
  {
    const scriptDir = __dirname;
    const parentDir = path.dirname(scriptDir);
    const hasManifest = fs.existsSync(path.join(parentDir, 'skill-manifest.json'));
    const hasGateBaseline = fs.existsSync(path.join(scriptDir, 'gate-baseline.mjs'));
    if (!hasManifest) {
      log('[FAIL] run-audit.mjs 不在合法 scripts 目录（父目录未检测到 skill-manifest.json）');
      log('       禁止将门禁脚本复制到项目目录运行，请在原位置执行：');
      log('       node <oc-demora>/scripts/run-audit.mjs --demo <demo-path>');
      process.exit(1);
    }
    if (!hasGateBaseline) {
      log('[FAIL] gate-baseline.mjs 缺失（与 run-audit.mjs 同目录），无法执行完整性校验');
      log('       请从 BUILD 重跑，确保 dist 包完整');
      process.exit(1);
    }
    try {
      const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
      const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
      if (!integrity.ok && !integrity.skipped) {
        log(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}`);
        log('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本');
        process.exit(1);
      }
    } catch (e) {
      log('[FAIL] gate-baseline.mjs 加载失败: ' + e.message);
      process.exit(1);
    }
  }

  const demoDir = path.resolve(args.demo);
  const indexPath = path.join(demoDir, 'index.html');
  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在: ' + indexPath);
    process.exit(2);
  }

  // v5.16 P015：上下文 token 计数检查（P0-4 修复 / Task 11.3 改为非阻断 WARN）
  //   AI 每轮审计前应将 token 计数写入 .demora/context-token-count.txt
  //   v5.16 Task 11.3：> 200K 由 FAIL 阻断改为 WARN 非阻断（实测 5 案例全部 <200K）
  {
    const projectRoot = path.dirname(demoDir);
    const p015 = checkP015(projectRoot);
    if (p015) {
      // Task 11.3 后 P015 永远不返回 FAIL（仅 WARN），保留 FAIL 分支作向后兼容兜底
      if (p015.level === 'FAIL') {
        log('[FAIL] P015: ' + p015.msg);
        process.exit(1);
      } else {
        log('[WARN] P015: ' + p015.msg);
      }
    } else {
      log('[OK] P015: 上下文 token 计数检查通过');
    }
  }

  // 创建截图目录
  const screenshotDir = path.join(demoDir, 'screenshots');
  if (!fs.existsSync(screenshotDir)) fs.mkdirSync(screenshotDir, { recursive: true });

  // v5.14.16 根治修复：审计前清理旧截图（消除 D2 假阳性误判）
  //   根因：多轮审计时 screenshots 目录从不清理，旧 fail 截图残留
  //         例：首轮 D 评级 D2 生成 7 张 D2-nav-click-*-fail.png，修复后重跑 B 评级 D2 全 pass
  //         但旧 fail 截图仍在，人工审查时误判"D2 有 fail 但 audit-result 显示 pass"（假阳性）
  //         7 张 fail 截图大小完全相同（页面无变化）佐证残留特征
  //   修复：审计开始时清空 *.png/*.jpeg（保留目录结构，崩溃后已生成截图仍保留）
  //   v5.14.16 修复 H（批次1）：使用 platform-utils 的 safeRemoveFileSync 替代 fs.rmSync
  //     根因：WorkBuddy safe-delete shim 对 rmSync FAIL_CLOSED，清理被吞掉导致历史截图堆积（G-4）
  //     修复：safeRemoveFileSync 多策略降级（unlinkSync → rmSync），shim 拦截时自动降级
  //   v5.14.16 修复 J（批次2）：改用 safeCleanFilesSync 批量清理 + shim 状态检测
  //     批次1验证：safeRemoveFileSync 在 shim 环境下有效（A/B 测试两案例均通过）
  //     优化：safeCleanFilesSync 封装批量删除逻辑，减少重复代码
  //     增强：清理失败时输出 shim 状态，辅助诊断是否 shim 拦截
  //   影响：每次审计截图集干净，消除新旧截图混杂误导审查
  try {
    const cleanResult = safeCleanFilesSync(screenshotDir, /\.(png|jpeg)$/i);
    if (cleanResult.deleted > 0) {
      log(`[INFO] 清理旧截图 ${cleanResult.deleted} 张（消除多轮审计残留）`);
    }
    if (cleanResult.failed.length > 0) {
      const shimInfo = detectShim().active ? ' [shim active]' : ' [shim inactive]';
      log(`[WARN] 清理旧截图 ${cleanResult.failed.length} 张失败${shimInfo}：${cleanResult.failed.slice(0, 5).join(', ')}${cleanResult.failed.length > 5 ? ' ...' : ''}`);
      log(`       失败文件名（shim 拦截或文件锁，不影响审计）：`);
    }
  } catch (e) {
    log(`[WARN] 清理旧截图失败（不影响审计）: ${e.message}`);
  }

  const URL = `http://127.0.0.1:${args.port}/`;
  const label = args.label;

  log('======================================================================');
  log(`run-audit.mjs — 通用浏览器审计 (v5.17.1 批量化版) [${label}]`);
  log('======================================================================');
  log(`  demo:  ${demoDir}`);
  log(`  URL:   ${URL}`);
  log(`  截图:  ${screenshotDir}`);

  // v5.15 P0-1：审计对象身份预读取（防御端口冲突导致审计错误 demo）
  //   根因：tw-dsf 案例端口 8800 被 codex-dsf 残留 python 占用，审计加载了错误 demo
  //   修复：审计前读取 demo/index.html 的 title + data-page-id 数量，审计后比对
  const demoIndexPath = path.join(demoDir, 'index.html');
  let demoIdentity = { title: '', pageCount: 0 };
  if (fs.existsSync(demoIndexPath)) {
    const htmlContent = fs.readFileSync(demoIndexPath, 'utf-8');
    const titleMatch = htmlContent.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
    demoIdentity.title = titleMatch ? titleMatch[1].trim() : '';
    const pageIdMatches = htmlContent.match(/data-page-id\s*=\s*["'][^"']+["']/gi);
    demoIdentity.pageCount = pageIdMatches ? pageIdMatches.length : 0;
  }
  log('[INFO] 审计对象身份：title="' + demoIdentity.title + '", pages=' + demoIdentity.pageCount);

  // 启动 HTTP 服务器
  log('\n[INFO] 启动本地 HTTP 服务器...');
  // v5.18 端口冲突修复：从"清理 + kill 硬阻断"改为"累加找空闲端口"
  //   原实现（v5.16 Task 7.2）：cleanupPort kill 冲突进程，失败则 exit(1) 硬阻断
  //   问题：用户约束"不 kill 任何冲突端口"（无法确认被占端口真实用途）；
  //         硬阻断导致 AI 反复切换端口 8800/8812/8815 都失败，浪费多轮
  //   新实现：用 findFreePort 从 args.port 开始累加找空闲端口，自动切换
  //         若 args.port 空闲则原样使用；若被占则用 8801, 8802...（最多 20 次）
  //         全部被占才 FAIL + exit(1)
  const freePort = await findFreePort(args.port, 20, { logger: log });
  if (freePort === null) {
    log('[FAIL] 从端口 ' + args.port + ' 起连续 20 个端口均被占用，无法启动 HTTP 服务器');
    log('[FAIL] 建议：1) 检查是否有残留 audit 进程未退出  2) 用 --port 指定其他端口范围');
    process.exit(1);
  }
  if (freePort !== args.port) {
    log('[INFO] 端口 ' + args.port + ' 被占用，改用 ' + freePort + '（不 kill 冲突端口）');
    args.port = freePort;
  } else {
    log('[INFO] 端口 ' + args.port + ' 空闲，直接使用');
  }
  const serverOk = await startHttpServer(demoDir, args.port);
  if (!serverOk) {
    log('[FAIL] HTTP 服务器启动失败（端口 ' + args.port + ' 可能被占用）');
    process.exit(1);
  }
  log('[INFO] HTTP 服务器已启动 (port ' + args.port + ')');

  // v5.18 P0-A4：diagnose-result.json 新鲜度硬门禁
  if (!args.skipDiagnose) {
    const diagnoseResultPath = path.join(args.demo, 'diagnose-result.json');
    let diagnoseError = null;

    if (!fs.existsSync(diagnoseResultPath)) {
      diagnoseError = '诊断结果文件缺失';
    } else {
      try {
        const diagnoseData = JSON.parse(fs.readFileSync(diagnoseResultPath, 'utf-8'));
        if (diagnoseData.exitCode !== 0 && diagnoseData.gate !== 'PASS') {
          diagnoseError = '诊断结果 exitCode !== 0（有失效未修复）';
        } else {
          // 检查新鲜度：diagnose-result.json mtime >= demo/index.html / app.js / style.css
          const diagStat = fs.statSync(diagnoseResultPath);
          const filesToCheck = [
            path.join(args.demo, 'index.html'),
            path.join(args.demo, 'assets', 'app.js'),
            path.join(args.demo, 'assets', 'style.css')
          ];
          for (const f of filesToCheck) {
            if (fs.existsSync(f)) {
              const fStat = fs.statSync(f);
              if (fStat.mtime > diagStat.mtime) {
                diagnoseError = `诊断结果过期（${path.basename(f)} 修改时间晚于 diagnose-result.json）`;
                break;
              }
            }
          }
        }
      } catch (e) {
        diagnoseError = '诊断结果文件解析失败：' + e.message;
      }
    }

    if (diagnoseError) {
      // v5.18 P0 修复：改用 logAlways 直出 — 门禁拒绝属流程控制信息，--retry/--dimensions-only 模式下必须可见
      logAlways('[FAIL] 诊断结果缺失/过期，须先运行 node scripts/diagnose-runtime.mjs --demo ' + args.demo + ' 且 0 失效');
      logAlways('       原因：' + diagnoseError);
      logAlways('       （如需跳过此检查，请使用 --skip-diagnose 参数，仅在 Playwright 不可用时使用）');
      process.exit(1);
    } else {
      logAlways('[OK] diagnose-result.json 新鲜度检查通过');
    }
  } else {
    logAlways('[WARN] --skip-diagnose：已跳过 diagnose-result.json 新鲜度检查（建议仅在 Playwright 不可用时使用）');
  }

  // v5.25.2 F1：check-structure 跳过硬拦截（0830 轮 p4 实证）
  //   根因：p4 executor 跳过 check-structure.mjs（state.yaml 缺 phase2_check_completed_at），
  //         S-1~S-15 静态契约层（含 S-15 P1-1 样板保留）被整体绕过后全链路仍 A 级——无任何下游门禁拦截
  //   修复：run-audit 启动即校验 structure_check_passed: true，缺失硬 FAIL（对齐"门禁必须硬阻断"原则）
  {
    const f1Root = path.dirname(path.resolve(args.demo));
    const f1StateFile = path.join(f1Root, '.demora', 'state.yaml');
    if (fs.existsSync(f1StateFile)) {
      const f1Text = readStateYaml(f1Root);
      if (!/structure_check_passed:\s*true/.test(f1Text)) {
        logAlways('[FAIL] F1 门禁：state.yaml 无 structure_check_passed: true —— check-structure.mjs 未运行或未通过');
        logAlways('       0830 轮 p4 实证：跳过 check-structure 后 S-1~S-15 静态契约层被整体绕过');
        logAlways('       修复：node scripts/check-structure.mjs 通过后重新执行 run-audit.mjs');
        process.exit(1);
      }
      logAlways('[OK] F1 门禁：structure_check_passed = true（check-structure 已通过）');
    }
  }

  browser = null; // v5.17 Tier C：重置模块级 browser（原 let browser; 局部声明已移除）
  let pass = 0, fail = 0, warn = 0;
  // v5.15 P2-3：label 规范化（消除目录名回退导致的 label 异常）
  // v5.15 rk3 P-8 修复：label 规范化
  //   根因：原 `label || 'audit'` 不传 --label 时回退到 'audit'，正是 codex-dsf/patent-cultivation
  //         的 label=audit 根因场景。改为优先用 --label，缺失时从 state.yaml 读 project.slug，再缺失 exit 2。
  let normalizedLabel = label;
  if (!normalizedLabel) {
    // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
    //   demoDir = <projectRoot>/demo，故 projectRoot = path.dirname(demoDir)
    const projectRoot = path.dirname(demoDir);
    const statePath = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(statePath)) {
      const stateText = readStateYaml(projectRoot);
      const slugMatch = stateText.match(/^project[_\s-]*slug\s*:\s*['"]?([^\s'"]+)['"]?/im);
      if (slugMatch) normalizedLabel = slugMatch[1];
    }
  }
  if (!normalizedLabel) {
    log('[FAIL] 未提供 --label 且 state.yaml 无 project.slug，无法确定审计 label');
    process.exit(2);
  }
  const results = { label: normalizedLabel, timestamp: new Date().toISOString(), dimensions: {} };
  // v5.18 P1：--dimensions 部分维度模式标注（audit-result.json 消费方可识别非全量结果）
  if (selectedDims) results.partialRun = true;
  // v5.18 P1：维度选择执行辅助 — 未选中的维度整块跳过执行（非仅跳过日志）
  //   skip 标注写入 results.dimensions，DIMENSION_SUMMARY 中显示 skip: excluded by --dimensions
  function shouldRunDim(dim) { return selectedDims === null || selectedDims.has(dim); }
  function markDimSkipped(keys) {
    for (const k of keys) results.dimensions[k] = 'skip: excluded by --dimensions';
  }

  try {
    // v5.14 修复 F7：run-audit 入包后的降级 stub（Playwright 不可用时显式 FAIL，不再静默通过）
    // v5.14.16：createRequire 从 __dirname 解析（消除 cwd 依赖导致的版本漂移）
    //   优先级：import('playwright') ESM 自动解析 → skillDirRequire 兜底（__dirname/../node_modules）
    //   两路都基于脚本位置，确保始终用 skill 包预装的 playwright（版本一致性）
    // v5.14.9：修复 ESM/CJS 互操作 bug + Windows 优先 msedge（系统自带免下载 chromium）
    //   原 bug：cwdRequire.resolve('playwright') 返回 CJS 入口，ESM import 后 .chromium 在 .default.chromium 上
    //          原 .chromium 永远拿到 undefined，导致即便装了 playwright 也走不通
    //   修复：兼容 .chromium || .default?.chromium
    //   msedge 优先：Windows 系统自带 Edge，免下载 chromium 二进制（~170MB），开箱即用
    let chromium;
    try {
      const pw = await import('playwright');
      chromium = pw.chromium || (pw.default && pw.default.chromium);
    } catch (e) {
      // 兜底：从 __dirname 解析 skill 包预装的 playwright（v5.14.16：不再依赖 cwd）
      try {
        const playwrightEntry = skillDirRequire.resolve('playwright');
        const playwrightPkg = skillDirRequire.resolve('playwright/package.json');
        const playwrightDir = path.dirname(playwrightPkg);
        const pw = await import(pathToFileURL(playwrightEntry).href);
        chromium = pw.chromium || (pw.default && pw.default.chromium);
        if (!chromium) {
          throw new Error('playwright 模块已加载但 chromium 导出缺失（模块格式异常）');
        }
        log('[INFO] Playwright 从 skill 包加载: ' + playwrightDir);
      } catch (e2) {
        log('[FAIL] run-audit 需要 Playwright，skill 包未预装且项目目录无 playwright');
        log('  [INFO] 方式1：运行 node scripts/install-deps.mjs（一键安装）');
        log('  [INFO] 方式2：在 skill 目录运行 npm install playwright');
        log('  [INFO] Windows 可免下载 chromium（自动用系统 Edge），其他系统需 npx playwright install chromium');
        log('  [INFO] run-audit 不得在无 Playwright 环境下静默通过');
        stopHttpServer(args.port);
        process.exit(1);
      }
    }
    // v5.14.9：Windows 优先 msedge（系统自带，免下载 chromium ~170MB）
    // 其他平台优先 chromium（需 npx playwright install chromium）
    if (process.platform === 'win32') {
      try {
        browser = await chromium.launch({ headless: true, channel: 'msedge' });
        log('[OK] 已启动 Microsoft Edge（系统自带，免 chromium 下载）');
      } catch (e1) {
        log('[INFO] msedge 不可用，降级到下载的 chromium');
        browser = await chromium.launch({ headless: true });
        log('[OK] 已启动 chromium');
      }
    } else {
      try {
        browser = await chromium.launch({ headless: true });
      } catch (e1) {
        throw new Error('chromium 启动失败，请运行 npx playwright install chromium: ' + e1.message);
      }
    }
  } catch (e) {
    log('[FAIL] Playwright 不可用: ' + e.message);
    log('       修复方式：node scripts/install-deps.mjs（一键安装）');
    log('       或手动：npm install playwright && npx playwright install chromium');
    stopHttpServer(args.port);
    process.exit(1);
  }

  // v5.17 Tier C：启动硬超时看门狗（browser 就绪后启动，审计结束 process.exit 自动丢弃 timer）
  //   防 shell timeout 杀 wrapper 不杀 node 导致孤儿进程（A/B 测试 codex-dsf 16 min 轮询浪费根因）
  //   exit code 2 = 硬超时，SKILL.md 指引 AI 视为审计失败需修复，不轮询等待
  const hardTimer = setTimeout(async () => {
    console.error('[FATAL] 审计硬超时 ' + (HARD_TIMEOUT_MS / 1000) + 's，强制清理退出');
    // 二级超时：browser.close 最多等 5s，否则强制 exit（防 close 自身挂起）
    const forceExitTimer = setTimeout(() => process.exit(2), 5000);
    forceExitTimer.unref();
    try { if (browser) await browser.close(); } catch (e) { /* 忽略 */ }
    try { stopHttpServer(); } catch (e) { /* 忽略 */ }
    clearTimeout(forceExitTimer);
    process.exit(2);
  }, HARD_TIMEOUT_MS);
  hardTimer.unref(); // 不阻止正常退出（process.exit 时 timer 自动丢弃）

  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  // v5.17 Tier B5：opt-in evaluate 调用计数 + Wall time（仅 --debug-eval-count 时启用，正常审计零开销）
  //   用途：V2/B5 性能验证（spec Task V2/B5）。启用时输出 [PERF] Wall time / evaluate calls。
  //   注意：仅在验证性能指标时使用，生产审计勿加此 flag（wrapper 会引入微小 IPC 开销）。
  const __perfStart = args.debugEvalCount ? Date.now() : 0;
  let __evalCount = 0;
  if (args.debugEvalCount) {
    const __origEval = page.evaluate.bind(page);
    page.evaluate = function(...a) { __evalCount++; return __origEval(...a); };
  }

  const consoleErrors = [];
  page.on('console', msg => { if (msg.type() === 'error') consoleErrors.push(msg.text()); });
  page.on('pageerror', err => consoleErrors.push(err.message));

  // 辅助函数：截图
  // v5.16：截图压缩为 JPEG quality=80（D7 fullPage 除外，保留 PNG — 视觉启发式检测需高保真色彩）
  //   原 PNG 单张 200KB-2MB，JPEG quality=80 约 30-200KB，节省 60-80% 截图 IO
  //   失败证据可读性已验证：文字/标注框/按钮在 quality=80 下仍清晰可辨
  async function screenshot(name) {
    // v5.18 P0-A5：--retry 模式跳过截图（仅最终验收轮保留全量截图，重试轮降低 IO）
    if (args.retry) return null;
    const filePath = path.join(screenshotDir, `${label}-${name}.jpeg`);
    try {
      await page.screenshot({ path: filePath, fullPage: false, type: 'jpeg', quality: 80 });
      log('  [SHOT] ' + path.basename(filePath));
      return filePath;
    } catch (e) {
      log('  [WARN] 截图失败 ' + name + ': ' + e.message);
      return null;
    }
  }

  // ===== D0: 页面加载 =====
  log('\n--- D0: 页面加载 ---');
  try {
    // v5.16 优化：waitUntil 从 'networkidle' 改为 'domcontentloaded'（networkidle 在 SPA 上等待过长）
    //   保留 L560 的 waitForFunction(readyState === 'complete') 兜底，确保 DOM 完整加载
    await page.goto(URL, { timeout: 10000, waitUntil: 'domcontentloaded' });
    log('  [OK] 页面加载成功');
    pass++;
    results.dimensions.D0_load = 'pass';
  } catch (e) {
    log('  [FAIL] 页面加载失败: ' + e.message);
    fail++;
    results.dimensions.D0_load = 'fail: ' + e.message;
    await screenshot('D0-load-fail');
    await browser.close();
    stopHttpServer(args.port);
    process.exit(1);
  }
  await page.waitForFunction(() => document.readyState === 'complete', { timeout: WAIT_TIMES.PAGE_LOAD })
    .catch(() => page.waitForTimeout(400));
  await screenshot('D0-page-loaded');

  // D0.1: 控制台错误
  log('\n--- D0.1: 控制台错误检查 ---');
  if (consoleErrors.length === 0) {
    log('  [OK] 无 JS 控制台错误');
    pass++;
    results.dimensions.D0_console = 'pass';
  } else {
    log('  [WARN] 检测到 ' + consoleErrors.length + ' 个控制台错误:');
    consoleErrors.slice(0, 5).forEach(e => log('    - ' + e));
    warn++;
    // v5.14.10：错误内容摘要写入 dimensions（原仅记录数量，无法事后定位具体错误）
    const errSummary = consoleErrors.slice(0, 3).map(e => e.substring(0, 100)).join(' | ');
    results.dimensions.D0_console = 'warn: ' + consoleErrors.length + ' errors - ' + errSummary;
  }

  // D0.2: 4 项最小契约
  log('\n--- D0.2: 4 项最小契约检查 ---');
  const contracts = await page.evaluate(() => {
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    return {
      hasRoot: !!document.querySelector('[data-annotation-root]'),
      hasToggle: !!document.querySelector('[data-annotation-toggle]'),
      hasZoneId: !!document.querySelector('[data-zone-id]'),
      hasElementId: !!document.querySelector('[data-element-id]'),
      panelExists: !!(sr && sr.querySelector('.annotation-panel')),
    };
  });
  const contractNames = ['hasRoot', 'hasToggle', 'hasZoneId', 'hasElementId', 'panelExists'];
  const contractLabels = ['data-annotation-root', 'data-annotation-toggle', 'data-zone-id', 'data-element-id', '.annotation-panel(in shadow)'];
  let contractFail = 0;
  contractNames.forEach((k, i) => {
    if (contracts[k]) { log('  [OK] ' + contractLabels[i]); }
    else { log('  [FAIL] ' + contractLabels[i]); contractFail++; }
  });
  if (contractFail === 0) { pass++; results.dimensions.D0_contracts = 'pass'; }
  else { fail += contractFail; results.dimensions.D0_contracts = 'fail: ' + contractFail + ' missing'; }

  // ===== 自动探测 PAGES（从 [data-page-id] 元素）=====
  const detectedPages = await page.evaluate(() => {
    const pages = Array.from(document.querySelectorAll('[data-page-id]'));
    return pages.map(p => ({
      id: p.getAttribute('data-page-id'),
      // 探测每个页面对应的 nav 链接（通过 href 中的关键字匹配）
    }));
  });
  // 探测 nav 链接（v5.14.1：扩展检测范围，支持 JS 导航模式）
  // v5.14.10：跳过 hidden 的 a 元素（防 demo 放隐藏空锚点绕过审计，如 <a href="#nav-P01" hidden></a>）
  // v5.14.16 修复 M（批次3）：navLinks.text 提取排除 icon span 内容
  //   根因：导航链接常含 <span class="ic"><i class="icon"></i></span> 等图标元素，
  //         textContent 会把图标字符（如 "◆"、"☰"、"✚"）拼到文本前，导致
  //         D6 pageList label 出现 "◆工作台概览"、"☰案件台账" 等带图标前缀的文本，
  //         影响日志可读性和按钮匹配（substring(0,20) 截断后图标占用宝贵字符位）
  //   修复：提取文本前移除 .ic / .icon / [aria-hidden="true"] / i 元素内容
  //         保留有意义的文字标签，去除装饰性图标字符
  const navLinks = await page.evaluate(() => {
    const links = [];
    // v5.14.16 修复 M：提取元素纯文本（排除 icon span）
    function extractNavText(el) {
      // 克隆元素避免修改原 DOM
      const clone = el.cloneNode(true);
      // 移除图标元素：.ic / .icon / [aria-hidden="true"] / i / svg
      clone.querySelectorAll('.ic, .icon, [aria-hidden="true"], i, svg').forEach(n => n.remove());
      return (clone.textContent || '').trim().substring(0, 20);
    }
    // 1. 传统 hash 导航链接 a[href^="#"]（v5.14.10：排除 hidden 元素）
    document.querySelectorAll('a[href^="#"]:not([hidden])').forEach(a => {
      // v5.14.10：再检查 computed style（hidden 属性可能动态设置）
      const cs = window.getComputedStyle(a);
      if (cs.display === 'none' || cs.visibility === 'hidden') return;
      links.push({ href: a.getAttribute('href'), text: extractNavText(a), type: 'hash' });
    });
    // v5.14.1 新增：JS 导航模式检测
    // 2. data-nav 属性导航（常见于 onclick SPA）
    if (links.length < 2) {
      document.querySelectorAll('[data-nav]').forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          links.push({ href: '#nav-' + el.getAttribute('data-nav'), text: extractNavText(el), type: 'data-nav', navId: el.getAttribute('data-nav') });
        }
      });
    }
    // 3. data-route 属性导航
    if (links.length < 2) {
      document.querySelectorAll('[data-route]').forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          links.push({ href: '#route-' + el.getAttribute('data-route'), text: extractNavText(el), type: 'data-route', routeId: el.getAttribute('data-route') });
        }
      });
    }
    // 去重（按 href）
    const seen = new Set();
    return links.filter(l => {
      if (seen.has(l.href)) return false;
      seen.add(l.href);
      return true;
    });
  });
  log('\n[INFO] 探测到 ' + detectedPages.length + ' 个页面，' + navLinks.length + ' 个导航链接');
  detectedPages.forEach(p => log('  - ' + p.id));
  results.detectedPages = detectedPages;
  results.navLinks = navLinks;

  // 启用标注模式
  log('\n--- 启用标注模式 ---');
  await page.evaluate(() => {
    const toggle = document.querySelector('[data-annotation-toggle]');
    if (toggle) toggle.click();
  });
  await page.waitForTimeout(500);
  await screenshot('D0-annotation-active');

  // ===== D2: 导航点击 → 页面切换验证（v5.2.6 新增 — 用户视角）=====
  // v5.14.10 修复：data-nav/data-route 类型用对应属性选择器（原仅用 a[href] 导致匹配不到元素 → 幽灵 warn）
  //   原缺陷：case-05/07 用 <button data-nav>，D2 用 a[href="#nav-P01"] 匹配不到 → 每次 warn++ 但 d2Fail=0 仍判 pass
  //   修复：按 link.type 分支选择器；warn 累积到 d2Warn 统一写 dimensions（与 D6/D8 模式对齐）
  if (shouldRunDim('D2')) { // v5.18 P1：--dimensions 未含 D2 时整块跳过（跳过执行，非仅跳过日志）
  log('\n--- D2: 导航点击 → 页面切换验证（运行时交互测试）---');
  if (detectedPages.length >= 2 && navLinks.length >= 2) {
    let d2Pass = 0, d2Fail = 0, d2Warn = 0;
    // 测试每个 nav 链接的点击效果
    for (let i = 0; i < Math.min(navLinks.length, detectedPages.length); i++) {
      const link = navLinks[i];
      try {
        // v5.14.10：按 link.type 分支选择器（原仅 a[href] 导致 data-nav 类型匹配不到）
        let linkSelector, clickArg, targetPageId;
        if (link.type === 'data-nav') {
          linkSelector = `[data-nav="${link.navId}"]`;
          clickArg = linkSelector;
          targetPageId = link.navId;
        } else if (link.type === 'data-route') {
          linkSelector = `[data-route="${link.routeId}"]`;
          clickArg = linkSelector;
          targetPageId = link.routeId;
        } else {
          linkSelector = `a[href="${link.href}"]`;
          clickArg = linkSelector;
          targetPageId = null;
        }

        // v5.17 Tier B1：D2 click + 等待 + 状态检查合并为单 evaluate（原 2 次/链接 → 1 次/链接）
        //   原实现：1 click evaluate + waitForFunction(2000ms or 300ms fallback) + 1 state evaluate
        //   新实现：1 evaluate 内 click + poll(2000ms) + 300ms fallback + 状态捕获
        //   不变：检测语义（目标页可见性）、warn 累积逻辑、screenshot 时机（fail 时拍当前状态）
        //   保留：单链接截图（fail 时页面状态仍为该链接的失败状态，未进入下一链接）
        // v5.17.1 修复：Playwright page.evaluate 仅接受单参数，多参数封装为对象（对齐 D3 L1098 模式）
        const navResult = await page.evaluate(async ({ sel, pid }) => {
          const el = document.querySelector(sel);
          if (!el) return { clicked: false, visiblePages: [] };
          el.click();

          if (pid) {
            // 等待目标页可见（对齐原 waitForFunction 2000ms 超时，谓词相同）
            const start = Date.now();
            let becameVisible = false;
            while (Date.now() - start < 2000) {
              const target = document.querySelector(`[data-page-id="${pid}"]`);
              if (target && !target.hidden && target.style.display !== 'none') {
                becameVisible = true;
                break;
              }
              await new Promise(r => setTimeout(r, 50));
            }
            // 300ms fallback（对齐原 .catch(() => waitForTimeout(300)) — 超时后 DOM 渲染兜底）
            if (!becameVisible) {
              await new Promise(r => setTimeout(r, 300));
            }
          } else {
            // 无 targetPageId（a[href] 类型）：等待 300ms（对齐原 waitForTimeout(300)）
            await new Promise(r => setTimeout(r, 300));
          }

          // 验证：检查所有 [data-page-id] 的 hidden 属性
          const pageStates = Array.from(document.querySelectorAll('[data-page-id]')).map(p => ({
            id: p.getAttribute('data-page-id'),
            hidden: p.hasAttribute('hidden') || p.style.display === 'none' || p.hidden,
            visible: p.offsetWidth > 0 || p.offsetHeight > 0,
          }));
          const visiblePages = pageStates.filter(p => !p.hidden && p.visible);
          return { clicked: true, visiblePages };
        }, { sel: clickArg, pid: targetPageId });

        if (!navResult.clicked) {
          log('  [WARN] 导航链接未找到: ' + link.href + ' (selector: ' + linkSelector + ')');
          d2Warn++;
          continue;
        }

        const visiblePages = navResult.visiblePages;
        if (visiblePages.length === 1) {
          log('  [OK] 点击 ' + link.href + ' → 显示 ' + visiblePages[0].id);
          d2Pass++;
        } else if (visiblePages.length === 0) {
          log('  [FAIL] 点击 ' + link.href + ' → 无可见页面（hashchange 监听器可能缺失）');
          d2Fail++;
          await screenshot('D2-nav-click-' + i + '-fail');
        } else {
          log('  [WARN] 点击 ' + link.href + ' → ' + visiblePages.length + ' 个页面可见（应仅 1 个）');
          d2Warn++;
        }
      } catch (e) {
        log('  [FAIL] 导航点击异常: ' + e.message);
        d2Fail++;
      }
    }
    // v5.14.10：warn 累积到 d2Warn 统一写入 dimensions（原 warn++ 不写 dimensions 导致 total 虚高）
    if (d2Fail === 0 && d2Warn === 0) {
      pass++;
      results.dimensions.D2_nav_click = 'pass';
      log('  [OK] D2 全部导航点击切换正确');
    } else if (d2Fail === 0) {
      warn++;
      results.dimensions.D2_nav_click = 'warn: ' + d2Warn + ' nav clicks ambiguous';
      log('  [WARN] D2 导航点击 ' + d2Pass + ' ok, ' + d2Warn + ' warn');
    } else {
      fail += d2Fail;
      results.dimensions.D2_nav_click = 'fail: ' + d2Fail + ' nav clicks did not switch pages';
    }
    await screenshot('D2-nav-click-final');
  } else {
    // v5.15：D2 skip→warn（与 D6 v5.14.7 skip→warn 先例对齐）
    //   根因：skip 计为 pass 使导航功能不完整的 demo 获得 A 级（patent-green 案例实证）
    //   修复：skip 一律计 warn，企业级应用导航功能必须运行时验证
    const skipReason = detectedPages.length < 2
      ? 'single page'
      : 'no nav links (detected ' + detectedPages.length + ' pages but 0 nav links — data-nav/data-route not supported?)';
    log('  [WARN] D2 跳过（计 warn 非 pass）：' + skipReason);
    warn++;
    results.dimensions.D2_nav_click = 'warn: skip — ' + skipReason + '（导航功能未验证，不可计为通过）';
  }
  } else {
    markDimSkipped(['D2_nav_click']);
  }

  // ===== D3: 弹窗关闭按钮运行时验证（v5.14 修正：消除定向修补动机）=====
  // 审计 §2.2 来源 A L6143：AI 仅给按钮添加 data-open-modal 属性即可过 D3
  // 修正：逐个遍历所有 [data-open-modal] 触发按钮 + 所有模态选择器
  //       必须验证完整闭环：点击触发 → 弹窗 visible → 找关闭按钮 → 点击关闭 → 弹窗 not visible
  //       触发按钮必须实际触发弹窗显示（防止添加属性但不绑定事件）
  if (shouldRunDim('D3')) { // v5.18 P1：--dimensions 未含 D3 时整块跳过
  log('\n--- D3: 弹窗关闭按钮运行时验证（v5.14 闭环验证：触发→显示→关闭→隐藏）---');
  const modalCloseSelectors = ['#modalClose', '.modal-close', '.close-btn', '[data-close]', '[aria-label="close"]', '[aria-label="Close"]', '.modal-close-btn', '.modal-cancel', 'button.btn-cancel'];
  // v5.14.2：扩展 modalSelectors，覆盖动态创建弹窗的常见命名（.modal-overlay / .pg-modal-mask / .modal-wrap / .modal-container / .modal-backdrop / .layui-layer / .ant-modal）
  const modalSelectors = ['#modalMask', '.modal-mask', '.modal', '#modal', '[role="dialog"]', '.dialog-mask', '.dialog',
    '.modal-overlay', '.pg-modal-mask', '.modal-wrap', '.modal-container', '.modal-backdrop', '.layui-layer', '.ant-modal'];
  // v5.14：触发按钮选择器按"语义优先级"排序，[data-open-modal] 优先（AI 最常滥用的属性）
  // v5.14.2：新增 onclick 内联触发检测（B 类 demo 常用 <button onclick="openModal(...)"> 模式）
  const openBtnSelectors = [
    '[data-open-modal]', '.btn-new', '.btn-add', '#btnNewOrder', '#btnNew',
    '.btn-primary[data-action="new"]', '.btn-create', '.btn-add-new',
    'button.btn-primary:not([data-annotation-toggle]):not([data-close])',
    '.action-btn-new', '.tool-btn-add',
    // v5.14.2 新增：onclick 内联触发（动态创建弹窗的常见模式）
    '[onclick*="openModal"]', '[onclick*="showModal"]', '[onclick*="openDialog"]',
    '.btn-action-new', '.btn-action-add', '.btn-operate-new',
    // v5.16 S-5 新增：动态行操作触发（data-action 触发 modal 的常见模式）
    '[data-action="edit"]', '[data-action="view"]', '[data-action="detail"]',
    '[data-action="newPledge"]', '[data-action="newRecord"]',
    '.btn-edit', '.btn-view', '.btn-detail', '.action-edit', '.action-view'
  ];

  // v2.3 启发式收紧（与 lib/audit-probes.mjs collectModalTriggers 同口径，单一事实源）：
  //   1. 显式 [data-open-modal]（契约触发器）永不排除
  //   2. 宽泛类启发式（button.btn-primary / .btn-new / .btn-add / onclick 内联等）命中且带
  //      data-route / data-action / data-nav 的按钮 = 业务导航/动作按钮，不判为弹窗触发器
  //      （v2.2 回归实证：p7 13 个工作流按钮"保存案件"等带 data-action、p4/p6 的 data-route
  //       按钮全被 btn-primary 误判，agent 被迫 3-4 轮改类名迎合检测器——22/30 失效为误判）
  //   3. 基于 data-action 值点名弹窗动作的选择器（valuePointed，如 [data-action="edit"]）保留：
  //      它们已按语义点名弹窗动作，若再按 hasAttribute('data-action') 排除会自我抵消（永远匹配不到）
  //   4. data-annotation-toggle / data-close 现有排除保留
  const d3ValuePointedSels = [
    '.btn-primary[data-action="new"]',
    '[data-action="edit"]', '[data-action="view"]', '[data-action="detail"]',
    '[data-action="newPledge"]', '[data-action="newRecord"]',
  ];

  // v2.3：D3 切页辅助（五重兜底，对齐 D10 四重兜底 + window.route()）：
  //   data-nav 点击 → a[href] 点击 → data-target-page 点击 → window.route(pid) → hidden 切换 + 路由事件
  const d3SwitchPage = async (pid) => {
    await page.evaluate((pid) => {
      // 方式1：点击 [data-nav="pageId"]（B 类 SPA 常用）
      const navEl = document.querySelector('[data-nav="' + pid + '"]');
      if (navEl) { navEl.click(); return; }
      // 方式2：点击 a[href*="pageId"]（传统 hash 导航）
      const aEl = document.querySelector('a[href*="' + pid + '"]');
      if (aEl) { aEl.click(); return; }
      // 方式3：点击 [data-target-page="pageId"]
      const targetPageEl = document.querySelector('[data-target-page="' + pid + '"]');
      if (targetPageEl) { targetPageEl.click(); return; }
      // 方式4：window.route(pid)（部分 demo 暴露全局路由函数）
      if (typeof window.route === 'function') {
        try { window.route(pid); return; } catch (e) { /* 回落到方式5 */ }
      }
      // 方式5：兜底直接切换 hidden + 派发路由事件（触发 demo 的 hashchange/popstate 监听）
      document.querySelectorAll('[data-page-id]').forEach(p => {
        p.hidden = (p.getAttribute('data-page-id') !== pid);
      });
      window.dispatchEvent(new PopStateEvent('popstate'));
      window.dispatchEvent(new HashChangeEvent('hashchange'));
    }, pid);
    await page.waitForTimeout(300);
  };

  // v2.3：页内收集可见触发按钮（收紧后规则；不设 5 上限，由调用方去重后统一截断）
  //   注意：page.evaluate 仅接受 1 个额外参数，多参数须包成对象（预验实证 bug 修复）
  const d3CollectBtnsOnCurrentView = async () => await page.evaluate((cfg) => {
    const sels = cfg.sels;
    const valuePointed = new Set(cfg.vpSels);
    const seen = new Set();  // 按 textContent + className 去重
    const result = [];
    for (const sel of sels) {
      const els = Array.from(document.querySelectorAll(sel));
      for (const el of els) {
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        const visible = r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
        if (!visible) continue;
        // 排除标注系统自身按钮
        if (el.closest('[data-annotation-toggle]') || el.closest('.annotation-panel') ||
            el.hasAttribute('data-annotation-toggle') || el.hasAttribute('data-close')) continue;
        // v2.3 启发式收紧：显式 data-open-modal / 值点名选择器永不排除；宽泛类启发式命中且带
        //   data-route / data-action / data-nav 的业务导航/动作按钮排除
        if (!el.hasAttribute('data-open-modal') && !valuePointed.has(sel) &&
            (el.hasAttribute('data-route') || el.hasAttribute('data-action') || el.hasAttribute('data-nav'))) continue;
        const key = (el.textContent || '').trim() + '|' + el.className;
        if (seen.has(key)) continue;
        seen.add(key);
        result.push({ selector: sel, text: (el.textContent || '').trim().substring(0, 30), modalId: el.getAttribute('data-open-modal') });
      }
    }
    return result;
  }, { sels: openBtnSelectors, vpSels: d3ValuePointedSels });

  // v2.3：逐页探测——D2 结束后停在最后一页，单屏探测会漏掉非当前页的触发按钮
  //   （v2.2 回归实证：p7 index.html:251 的 data-open-modal="newCaseModal" 在 P01，D2 后停在末页
  //    探 0 → 误走 v2.2 决策 A 的 n/a 豁免，"有真实弹窗却记 no modal in design" 属语义误用）
  //   实现：detectedPages >= 2 时逐页切换 → 每页收集可见触发按钮 → 合并去重（selector+text）
  //    → 复位回起始 active 页（关键：D4-D10 依赖页面状态，必须复位）；单页 demo 保持原单屏逻辑
  let allOpenBtns = [];
  let d3StartPageId = null;  // 起始 active 页（探测/测试后复位目标）
  if (detectedPages.length >= 2) {
    d3StartPageId = await page.evaluate(() => {
      const vis = document.querySelector('[data-page-id]:not([hidden])');
      return vis ? vis.getAttribute('data-page-id') : null;
    });
    const mergedSeen = new Set();  // 跨页合并去重：selector + text
    for (const pg of detectedPages) {
      await d3SwitchPage(pg.id);
      const pageBtns = await d3CollectBtnsOnCurrentView();
      for (const b of pageBtns) {
        const key = b.selector + '|' + b.text;
        if (mergedSeen.has(key)) continue;
        mergedSeen.add(key);
        allOpenBtns.push({ selector: b.selector, text: b.text, modalId: b.modalId, pageId: pg.id });
      }
    }
    // 去重后截断 5 个（保持原"限上限 5 个，避免过多消耗"预算）
    allOpenBtns = allOpenBtns.slice(0, 5);
    log('  [INFO] D3 逐页探测：' + detectedPages.length + ' 页，收集 ' + allOpenBtns.length + ' 个触发按钮');
    if (d3StartPageId) {
      await d3SwitchPage(d3StartPageId);
      log('  [INFO] D3 探测完成，复位回 ' + d3StartPageId);
    }
  } else {
    // 单页 demo（无 data-page-id 或仅 1 页）：原单屏收集逻辑
    allOpenBtns = (await d3CollectBtnsOnCurrentView()).slice(0, 5);
  }

  // v5.14：检测页面是否预设可见弹窗（无触发按钮时的兜底）
  const defaultVisibleModal = await page.evaluate((sels) => {
    for (const sel of sels) {
      const el = document.querySelector(sel);
      if (el && !el.hidden && el.offsetWidth > 0) return sel;
    }
    return null;
  }, modalSelectors);

  // v2.3：全文档 modal 候选容器计数（不限可见性，按元素去重——同一元素可能命中多个选择器）
  //   用途：豁免分支 b 判定——buttons==0 但存在弹窗容器 = "有弹窗设计但缺显式触发器"，不再 n/a
  const modalContainerCount = await page.evaluate((sels) => {
    const set = new Set();
    for (const sel of sels) document.querySelectorAll(sel).forEach((el) => set.add(el));
    return set.size;
  }, modalSelectors);

  // v2.3 豁免收紧三分支：
  //   a) buttons>0 → 正常逐页闭环测试（每按钮先切到其所在页再点击）
  //   b) buttons==0 且存在 modal 候选容器（不限可见性）→ 不再 n/a 豁免，warn + fix_command
  //   c) buttons==0 且零容器 → 维持 v2.2 决策 A 的 n/a 豁免（信息型应用无弹窗设计）
  if (allOpenBtns.length > 0) {
    log('  [INFO] 探测到 ' + allOpenBtns.length + ' 个触发按钮 + ' + (defaultVisibleModal ? '1 个默认可见弹窗' : '0 个默认可见弹窗'));
    let closedLoop = 0;       // 完整闭环通过数
    let openOnlyFail = 0;     // 仅打开失败数（点击触发按钮但弹窗未显示）
    let closeBtnMissingFail = 0; // 打开成功但找不到关闭按钮
    let closeNotHiddenFail = 0;  // 点击关闭但弹窗未隐藏
    const testedBtnTexts = [];

    // v5.14：逐个触发按钮验证闭环（旧版只验证第一个就 break）
    for (let i = 0; i < allOpenBtns.length; i++) {
      const btnInfo = allOpenBtns[i];
      log('  [INFO] [' + (i + 1) + '/' + allOpenBtns.length + '] 测试触发按钮: "' + btnInfo.text + '" (' + btnInfo.selector + (btnInfo.pageId ? ' @' + btnInfo.pageId : '') + ')');
      // v2.3：逐页来源的按钮先切到其所在页再点击（收集时按钮在该页可见，测试时页面状态可能已变；
      //   参考 v2.2 diagnose 的实现模式：为每个待测按钮切换到其所在页）
      if (btnInfo.pageId) await d3SwitchPage(btnInfo.pageId);

      // v5.17 Tier B2：D3 触发器闭环测试批量化（对齐 D6/D8 单页批量 evaluate 模式）
      //   原实现：每触发按钮 ~5-7 次 evaluate（find/click/waitForFunction/check/close-search/verify/force-hide）
      //   新实现：每触发按钮 2 次 evaluate（open+verify+flaky-retry / close+verify），force-hide 仅 close-fail 时附加
      //   不变：检测语义（触发→显示→关闭→隐藏闭环）、flaky 重试（500ms+重试 1 次）、
      //         screenshot 时机（open 后 / close-fail 后）、强制隐藏兜底
      //   保留：close-fail 时先截图再强制隐藏（截图反映真实失败状态，非 force-hide 后状态）
      //   注意：flaky 重试机制完整移入浏览器内（首次 poll 超时 → 500ms 等待 → 重新 click → 再次 poll）

      // Evaluate 1: 查找按钮 + 点击 + 等待显示 + flaky 重试
      const openResult = await page.evaluate(async ({ sel, text, modalSels, modalShowMs, modalId }) => {
        const els = Array.from(document.querySelectorAll(sel));
        const btn = els.find(e => (e.textContent || '').trim().substring(0, 30) === text);
        if (!btn) return { found: false };

        // v5.18 P0-A1：优先按 data-open-modal 值精确定位目标弹窗
        //   构建 preciseSels（#modalId + [data-modal-id="modalId"]），pollVisible 时前置检查
        //   找不到再回落到全量 modalSels 扫描，避免多弹窗场景下首匹配误报
        // v5.18 P0-A2：isVisible 的 querySelectorAll + 可见优先语义已同步到
        //   probes.isModalVisible（lib/audit-probes.mjs），run-audit 与 diagnose-runtime 共用同一判定逻辑
        const preciseSels = modalId ? ['#' + CSS.escape(modalId), '[data-modal-id="' + modalId + '"]'] : [];

        const isVisible = (sels) => {
          for (const s of sels) {
            const els = document.querySelectorAll(s);
            for (const el of els) {
              if (el && !el.hidden && el.offsetWidth > 0) return s;
            }
          }
          return null;
        };
        const pollVisible = async (sels, timeoutMs) => {
          const start = Date.now();
          while (Date.now() - start < timeoutMs) {
            const v = isVisible(sels);
            if (v) return v;
            await new Promise(r => setTimeout(r, 50));
          }
          return null;
        };

        // 先精确定位目标弹窗，找不到再回落到全量 modalSelectors 扫描
        const combinedSels = [...preciseSels, ...modalSels];

        try { btn.click(); } catch (e) { /* 点击失败视为未触发，pollVisible 返回 null */ }
        let modalVisible = await pollVisible(combinedSels, modalShowMs);

        // v5.15 P1-3 flaky modal 重试：首次失败后等待 500ms 重新点击并重新检测
        let retried = false;
        if (!modalVisible) {
          retried = true;
          await new Promise(r => setTimeout(r, 500));
          try { btn.click(); } catch (e) { /* 重试点击失败，pollVisible 返回 null */ }
          modalVisible = await pollVisible(combinedSels, 2000);
        }

        return { found: true, modalVisible, retried };
      }, { sel: btnInfo.selector, text: btnInfo.text, modalSels: modalSelectors, modalShowMs: WAIT_TIMES.MODAL_SHOW, modalId: btnInfo.modalId });

      if (!openResult.found) {
        log('  [WARN] 按钮已不在 DOM，跳过');
        continue;
      }

      if (openResult.retried) {
        log('  [INFO] 首次未检测到弹窗，等待 500ms 后重试 1 次');
      }

      if (!openResult.modalVisible) {
        log('  [FAIL] 点击触发按钮后弹窗未显示（可能 data-open-modal 属性未绑定实际事件）');
        openOnlyFail++;
        testedBtnTexts.push(btnInfo.text + ' [open-fail]');
        continue;
      }

      log('  [INFO] 弹窗已显示: ' + openResult.modalVisible);
      await screenshot('D3-modal-open-' + (i + 1));

      // Evaluate 2: 查找关闭按钮 + 点击 + 等待隐藏
      const closeResult = await page.evaluate(async ({ modalSel, closeSels, modalSels }) => {
        // 寻找关闭按钮（在弹窗容器内优先找，再全局找）
        let closeBtn = null;
        let closeSel = null;
        for (const sel of closeSels) {
          closeBtn = document.querySelector(`${modalSel} ${sel}`) || document.querySelector(sel);
          if (closeBtn) { closeSel = sel; break; }
        }
        if (!closeBtn) return { closeBtnFound: false };

        try { closeBtn.click(); } catch (e) { /* 点击失败视为未关闭，后续检测仍可见 */ }

        // 等待弹窗隐藏（对齐原 waitForFunction 2000ms 超时，谓词相同）
        const start = Date.now();
        while (Date.now() - start < 2000) {
          let anyVisible = null;
          for (const s of modalSels) {
            const els = document.querySelectorAll(s);
            for (const el of els) {
              if (el && !el.hidden && el.offsetWidth > 0) { anyVisible = s; break; }
            }
            if (anyVisible) break;
          }
          if (!anyVisible) return { closeBtnFound: true, closeSelector: closeSel, stillVisible: null };
          await new Promise(r => setTimeout(r, 50));
        }
        // 超时仍有可见弹窗
        let stillVisible = null;
        for (const s of modalSels) {
          const els = document.querySelectorAll(s);
          for (const el of els) {
            if (el && !el.hidden && el.offsetWidth > 0) { stillVisible = s; break; }
          }
          if (stillVisible) break;
        }
        return { closeBtnFound: true, closeSelector: closeSel, stillVisible };
      }, { modalSel: openResult.modalVisible, closeSels: modalCloseSelectors, modalSels: modalSelectors });

      if (!closeResult.closeBtnFound) {
        log('  [FAIL] 弹窗已打开但未找到关闭按钮');
        closeBtnMissingFail++;
        testedBtnTexts.push(btnInfo.text + ' [no-close-btn]');
        // 尝试 ESC 键关闭作为兜底
        await page.keyboard.press('Escape').catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }

      log('  [INFO] 找到关闭按钮: ' + closeResult.closeSelector);

      if (!closeResult.stillVisible) {
        log('  [OK] 闭环通过：触发 → 显示 → 关闭 → 隐藏');
        closedLoop++;
        testedBtnTexts.push(btnInfo.text + ' [ok]');
      } else {
        log('  [FAIL] 点击关闭按钮后弹窗仍未隐藏');
        closeNotHiddenFail++;
        testedBtnTexts.push(btnInfo.text + ' [close-fail]');
        await screenshot('D3-modal-still-visible-' + (i + 1));
        // 强制隐藏弹窗以继续测试下一个按钮
        // v5.14.2：同步扩展弹窗选择器，确保动态创建的 .modal-overlay 等也能被强制清理
        await page.evaluate(() => {
          document.querySelectorAll('.modal, [role="dialog"], .dialog-mask, #modalMask, .modal-overlay, .pg-modal-mask, .modal-wrap, .modal-container, .modal-backdrop').forEach(el => {
            el.hidden = true;
            el.style.display = 'none';
          });
        });
        await page.waitForTimeout(200);
      }
    }

    // 汇总评级
    const totalTested = closedLoop + openOnlyFail + closeBtnMissingFail + closeNotHiddenFail;
    if (totalTested === 0) {
      log('  [WARN] D3: 无可测试的弹窗触发按钮');
      warn++;
      results.dimensions.D3_modal_close = 'warn: no testable triggers';
    } else if (openOnlyFail > 0) {
      // v5.14：触发按钮未实际触发弹窗 = 定向修补特征（data-open-modal 属性但无事件）
      // 严格 FAIL，防止 AI 仅添加属性即过
      log('  [FAIL] D3: ' + openOnlyFail + '/' + totalTested + ' 个触发按钮点击后弹窗未显示（疑似定向修补：添加属性但未绑定事件）');
      log('         明细: ' + testedBtnTexts.join(', '));
      fail++;
      results.dimensions.D3_modal_close = 'fail: ' + openOnlyFail + ' triggers did not open modal';
      await screenshot('D3-final-fail');
    } else if (closeNotHiddenFail > 0 || closeBtnMissingFail > 0) {
      log('  [FAIL] D3: ' + (closeNotHiddenFail + closeBtnMissingFail) + '/' + totalTested + ' 个弹窗关闭闭环失败');
      log('         明细: ' + testedBtnTexts.join(', '));
      fail++;
      results.dimensions.D3_modal_close = 'fail: ' + (closeNotHiddenFail + closeBtnMissingFail) + ' close loops failed';
      await screenshot('D3-final-fail');
    } else {
      log('  [OK] D3: ' + closedLoop + '/' + totalTested + ' 个弹窗触发→关闭闭环通过');
      pass++;
      results.dimensions.D3_modal_close = 'pass: ' + closedLoop + '/' + totalTested;
    }
    // v2.3：闭环测试结束复位回起始页（测试过程按按钮所在页切换，须还原 D2 后页面状态供 D4-D10）
    if (d3StartPageId) await d3SwitchPage(d3StartPageId);
  } else if (modalContainerCount > 0) {
    // v2.3 豁免收紧分支 b：检测到弹窗容器但未找到触发按钮 → 不再 n/a 豁免
    //   根因：v2.2 决策 A 被语义误用——p4/p6/p7 demo 有真实弹窗（如 p7 P01 的
    //   data-open-modal="newCaseModal"），却因触发按钮未检出（display:none 页/启发式收紧）而记
    //   "no modal in design"，掩盖"触发器缺 data-open-modal 契约属性"的真实缺陷
    //   处置：warn + fix_command；有预设可见弹窗时仍先验证其关闭闭环（保留 v5.14 默认弹窗语义），
    //         闭环失败升 fail
    log('  [WARN] 检测到 ' + modalContainerCount + ' 个弹窗容器但未找到触发按钮——真实触发器应带 data-open-modal，见 v2.3 按钮契约');
    let defaultCloseLoopFail = 0;
    if (defaultVisibleModal) {
      log('  [INFO] 测试默认可见弹窗: ' + defaultVisibleModal);
      await screenshot('D3-modal-default-visible');
      // v5.17 Tier B2：默认弹窗关闭闭环批量化（原多次 page.$()+evaluate → 1 次 evaluate）
      const defaultCloseResult = await page.evaluate(async ({ modalSel, closeSels, modalSels }) => {
        let closeBtn = null;
        let closeSel = null;
        for (const sel of closeSels) {
          closeBtn = document.querySelector(`${modalSel} ${sel}`) || document.querySelector(sel);
          if (closeBtn) { closeSel = sel; break; }
        }
        if (!closeBtn) return { closeBtnFound: false };

        try { closeBtn.click(); } catch (e) { /* 点击失败视为未关闭 */ }
        await new Promise(r => setTimeout(r, 400));  // 对齐原 waitForTimeout(400)

        let stillVisible = null;
        for (const s of modalSels) {
          const els = document.querySelectorAll(s);
          for (const el of els) {
            if (el && !el.hidden && el.offsetWidth > 0) { stillVisible = s; break; }
          }
          if (stillVisible) break;
        }
        return { closeBtnFound: true, closeSelector: closeSel, stillVisible };
      }, { modalSel: defaultVisibleModal, closeSels: modalCloseSelectors, modalSels: modalSelectors });

      if (!defaultCloseResult.closeBtnFound) {
        log('  [FAIL] 默认弹窗未找到关闭按钮');
        defaultCloseLoopFail++;
      } else if (!defaultCloseResult.stillVisible) {
        log('  [OK] 默认弹窗关闭闭环通过');
      } else {
        log('  [FAIL] 默认弹窗点击关闭后仍未隐藏');
        defaultCloseLoopFail++;
      }
    }
    if (defaultCloseLoopFail > 0) {
      fail++;
      results.dimensions.D3_modal_close = 'fail: default modal close loop failed（检测到 ' + modalContainerCount + ' 个弹窗容器但未找到触发按钮——真实触发器应带 data-open-modal，见 v2.3 按钮契约）';
    } else {
      warn++;
      results.dimensions.D3_modal_close = 'warn: modal containers present but no trigger detected（检测到 ' + modalContainerCount + ' 个弹窗容器但未找到触发按钮——真实触发器应带 data-open-modal，见 v2.3 按钮契约）';
      log('  [FIX] fix_command: 给弹窗触发按钮添加 data-open-modal 属性（如 <button data-open-modal="newCaseModal">新建案件</button>）并绑定打开事件');
    }
  } else {
    // v2.3 豁免分支 c（维持 v2.2 决策 A）：无弹窗设计豁免——零触发按钮且零弹窗容器，
    //   需求未要求弹窗的信息型应用，闭环概念不适用，记 n/a 不计 warn
    //   依据：v2.1 验证 p6/p7/p8 需求 brief 零弹窗要求 + v1 同需求有弹窗设计为 A、v2/v2.1 无弹窗为 B 的实证
    //   v2.3 收紧：v2.2 此分支不查容器数，"有容器无触发器"场景误入此分支；现仅零容器才适用
    log('  [INFO] 未检测到弹窗与触发按钮，D3 记 n/a（无弹窗设计豁免，v2.2 决策A）');
    pass++;
    results.dimensions.D3_modal_close = 'pass: n/a — no modal in design（无弹窗设计豁免）';
  }
  } else {
    markDimSkipped(['D3_modal_close']);
  }

  // ===== D4: L2 marker 闪烁采样（v5.2.6 新增 — 视觉体验验证）=====
  if (shouldRunDim('D4')) { // v5.18 P1：--dimensions 未含 D4 时整块跳过（块首自导航回第一页+自启用标注，无前序状态依赖）
  log('\n--- D4: L2 marker 闪烁采样（5 次采样 transform 变化检测）---');
  // 切到第一个页面
  if (navLinks.length > 0) {
    await page.evaluate((href) => {
      const el = document.querySelector(`a[href="${href}"]`);
      if (el) el.click();
    }, navLinks[0].href);
    await page.waitForTimeout(500);
  }
  // 启用标注
  await page.evaluate(() => {
    const toggle = document.querySelector('[data-annotation-toggle]');
    if (toggle && !document.querySelector('[data-annotation-active]')) toggle.click();
  });
  await page.waitForTimeout(400);
  await screenshot('D4-L2-marker-before-click');

  // 点击第一个 L2 marker 激活
  const l2ClickResult = await page.evaluate(() => {
    const marker = document.querySelector('.l2-marker');
    if (!marker) return { error: 'no .l2-marker found' };
    marker.click();
    return { clicked: true };
  });
  await page.waitForTimeout(300); // D4 只需 transform 稳定，300ms 足够（CSS 动画默认 300ms）
  await screenshot('D4-L2-marker-active');

  // 5 次采样 transform 值（如果一直变化 → 闪烁；如果稳定 → 不闪烁）
  // v5.14.17 批次5 R-5（P2）— 增强：同步采样 ::before 伪元素 animation-name
  //   根因：L2 marker 闪烁通常通过 ::before 伪元素的 animation 属性实现（如脉冲效果）
  //         原 D4 仅检测 .l2-marker 自身 transform，无法归因闪烁来源
  //   实现：同步采样 ::before 的 animation-name + animation-duration
  //         若 animation-name !== 'none' → 闪烁来源为 ::before 动画（归因候选 1：CSS 动画）
  //         若 animation-name === 'none' 但 transform 变化 >2 → 归因候选 2/3（DOM 层级/CSS 优先级）
  const samples = [];
  const beforeSamples = [];
  for (let i = 0; i < 5; i++) {
    const result = await page.evaluate(() => {
      const marker = document.querySelector('.l2-marker');
      if (!marker) return null;
      // 查找激活态的 marker（is-highlighted 父元素）
      const highlighted = marker.closest('.is-highlighted') || marker.parentElement.closest('.is-highlighted');
      const target = highlighted ? highlighted.querySelector('.l2-marker') : marker;
      const cs = window.getComputedStyle(target);
      const before = window.getComputedStyle(target, '::before');
      return {
        transform: cs.transform,
        beforeAnimationName: before.animationName,
        beforeAnimationDuration: before.animationDuration,
      };
    });
    if (result) {
      samples.push(result.transform);
      beforeSamples.push({
        name: result.beforeAnimationName,
        duration: result.beforeAnimationDuration,
      });
    }
    await page.waitForTimeout(150);
  }
  const uniqueTransforms = new Set(samples.filter(Boolean));
  // R-5：::before animation-name 归因分析
  const beforeAnimationNames = new Set(beforeSamples.map(s => s.name).filter(n => n && n !== 'none'));
  const hasBeforeAnimation = beforeAnimationNames.size > 0;
  if (l2ClickResult.error) {
    log('  [WARN] ' + l2ClickResult.error);
    warn++;
    results.dimensions.D4_l2_flicker = 'warn: ' + l2ClickResult.error;
  } else if (uniqueTransforms.size <= 2) {
    // 允许 1-2 种状态（激活态稳定 + 可能一次过渡）
    log('  [OK] L2 marker 激活态 transform 稳定（' + uniqueTransforms.size + ' 种值，无闪烁）');
    if (hasBeforeAnimation) {
      log('  [INFO] R-5: ::before animation-name = ' + [...beforeAnimationNames].join(', ') + '（动画存在但 transform 稳定，属设计意图）');
    }
    pass++;
    results.dimensions.D4_l2_flicker = 'pass: ' + uniqueTransforms.size + ' unique transforms';
  } else {
    log('  [FAIL] L2 marker 激活态 transform 在 5 次采样中变化 ' + uniqueTransforms.size + ' 次（疑似闪烁）');
    // R-5 归因候选清单
    if (hasBeforeAnimation) {
      log('  [INFO] R-5 归因候选 1：::before animation-name = ' + [...beforeAnimationNames].join(', ') + '（闪烁来源疑似 ::before 动画）');
      log('         建议检查 CSS 中 .l2-marker::before 的 animation 属性是否为脉冲/闪烁效果');
    } else {
      log('  [INFO] R-5 归因候选 2/3：::before 无动画，闪烁来源疑似 DOM 层级不匹配或 CSS 优先级冲突');
      log('         候选 2：检查 .l2-marker 是否在 .is-highlighted 父元素内（DOM 层级匹配）');
      log('         候选 3：检查 [data-annotation-active] 属性是否设置（CSS 激活态依赖）');
      log('         候选 3：检查是否有更高优先级的 CSS 覆盖了 .l2-marker 的 transform');
    }
    fail++;
    results.dimensions.D4_l2_flicker = 'fail: ' + uniqueTransforms.size + ' unique transforms (flicker suspected)';
    await screenshot('D4-L2-marker-flicker-detected');
  }
  log('  [INFO] 采样值: ' + JSON.stringify([...uniqueTransforms]).substring(0, 200));
  if (hasBeforeAnimation) {
    log('  [INFO] R-5 ::before animation: ' + JSON.stringify([...beforeAnimationNames]));
  }
  } else {
    markDimSkipped(['D4_l2_flicker']);
  }

  // ===== D5: v5.2.5 三项修复验证 =====
  if (shouldRunDim('D5')) { // v5.18 P1：--dimensions 未含 D5 时整块跳过（D5.2 自遍历 navLinks，无前序状态依赖）
  log('\n--- D5: v5.2.5 三项修复验证 ---');
  // D5.1: L2 marker 序号规范
  const l2Texts = await page.evaluate(() => {
    return Array.from(document.querySelectorAll('.l2-marker')).map(m => (m.textContent || '').trim());
  });
  // v5.19 P1-1：兼容新编码 Pn-Ln-xxx（每页每级别从 001 起）与旧版纯数字序号
  const codeCount = l2Texts.filter(t => /^(?:\d+|P\d{2,}-L2-\d{3,})$/.test(t)).length;
  if (codeCount === l2Texts.length && l2Texts.length > 0) {
    log('  [OK] D5.1: L2 marker 编码规范（数字或 Pn-Ln-xxx）(' + codeCount + '/' + l2Texts.length + ')');
    pass++;
    results.dimensions.D5_l2_marker_seq = 'pass: ' + codeCount + '/' + l2Texts.length;
  } else {
    log('  [FAIL] D5.1: L2 marker 编码不规范（' + codeCount + '/' + l2Texts.length + '）');
    fail++;
    results.dimensions.D5_l2_marker_seq = 'fail: ' + codeCount + '/' + l2Texts.length;
  }
  // D5.2: 多页面 findVisibleElement（遍历每个页面统计 L2/L3）
  let d5Total = 0, d5Hit = 0;
  for (const link of navLinks.slice(0, detectedPages.length)) {
    await page.evaluate((href) => {
      const el = document.querySelector(`a[href="${href}"]`);
      if (el) el.click();
    }, link.href);
    // v5.16：navLink 切换等待改用 WAIT_TIMES.NAV_LINK_SETTLE（原 500ms）
    await page.waitForTimeout(WAIT_TIMES.NAV_LINK_SETTLE);
    const stats = await page.evaluate(() => {
      const visible = (el) => {
        if (!el) return false;
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        return r.width > 0 && r.height > 0 && s.display !== 'none';
      };
      // 查找当前可见页面
      const pages = Array.from(document.querySelectorAll('[data-page-id]'));
      const visiblePage = pages.find(p => visible(p));
      if (!visiblePage) return { l2: 0, l3: 0, visibleL2: 0, visibleL3: 0 };
      const l2 = visiblePage.querySelectorAll('.l2-marker');
      const l3 = visiblePage.querySelectorAll('[data-element-id] .l3-dot');
      return {
        l2: l2.length,
        l3: l3.length,
        visibleL2: Array.from(l2).filter(visible).length,
        visibleL3: Array.from(l3).filter(visible).length,
      };
    });
    d5Total += stats.l2 + stats.l3;
    d5Hit += stats.visibleL2 + stats.visibleL3;
  }
  if (d5Total === 0 || d5Hit === d5Total) {
    log('  [OK] D5.2: findVisibleElement 多页面锚定 ' + d5Hit + '/' + d5Total);
    pass++;
    results.dimensions.D5_multi_page_anchor = 'pass: ' + d5Hit + '/' + d5Total;
  } else {
    log('  [FAIL] D5.2: findVisibleElement 多页面锚定 ' + d5Hit + '/' + d5Total);
    fail++;
    results.dimensions.D5_multi_page_anchor = 'fail: ' + d5Hit + '/' + d5Total;
  }

  await screenshot('D5-final-state');
  } else {
    markDimSkipped(['D5_l2_marker_seq', 'D5_multi_page_anchor']);
  }

  // ===== D6: 按钮点击响应率（v5.14.16 修复 E：全量按钮覆盖 + 页面遍历 + 状态复位）=====
  // 审计 §2.2 来源 A L3319：AI 移除 disabled 属性即过 D6（原应保留 disabled 表示功能未实现）
  // v5.14：豁免 disabled 与 [aria-disabled="true"] 按钮，仅检查启用按钮的 click handler
  // v5.14.16 修复 E（批次1）：
  //   1. 全量页面遍历：原仅测首页（run-audit.mjs:970-977 切回首页），10 页 demo 的 9 页按钮逃逸
  //      修复：遍历所有 navLinks 指向的页面 + 首页，每页测按钮
  //   2. 状态复位：原无复位，前一个按钮打开 modal 会遮挡后续按钮产生系统性假 fail
  //      修复：每个按钮点击后关闭所有可见 modal + toast，恢复页面初始状态
  //   3. 多维状态检测：保留原有 DOM/hash/modal/toast/focus + MutationObserver
  if (shouldRunDim('D6')) { // v5.18 P1：--dimensions 未含 D6 时整块跳过（修复轮最耗时维度之一）
  log('\n--- D6: 按钮点击响应率（v5.14.16：全量页面遍历 + 状态复位）---');

  // 构建页面列表：首页 + navLinks 去重
  // v5.15 P2-5：navLinks 按路径模板归并（消除详情链接重复计页）
  //   根因：#/cases/PC2026-0001~0012 等详情链接被各计为一页，同一详情页遍历 8 次
  //   修复：仅归并含数字 ID 的最后一段（如 PC2026-0001 → :id），保留 #/dashboard 等独立路由
  //   rk3 P-2 修复：原正则 /\/[^/]+$/ 无 ID 特征限定，把 #/dashboard/#/cases/#/tasks 等
  //     6 个独立路由全并为 #/:id，导致真实页面按钮不再被 D6 遍历。现仅匹配含数字的段。
  function normalizeHref(href) {
    // 仅当最后一段含数字 ID（如 PC2026-0001、123）才归并为 :id，独立路由原样保留
    return href.replace(/\/[A-Za-z]*\d[^/]*$/, '/:id');
  }
  // v5.22.1 页面去重：初始页与导航项可能指向同一 data-page-id（负样本 P01：首页与"▦工作台"导航项同页），
  //   第二次遍历中按钮因状态已被首遍改变而幂等空转（"全部标为已读"变 toast-only、"标为已读"幂等无变化），
  //   虚增未响应数。按解析后的目标页 id 去重，保留首次出现（首页）。
  //   解析规则：data-nav/data-route 属性值即目标页 id；hash 链接取 href 去 # 前缀（#P01 → P01）；
  //   首页取当前可见 [data-page-id]（前序维度可能已导航离开初始页）。
  const d6HomePageId = await page.evaluate(() => {
    const visible = Array.from(document.querySelectorAll('[data-page-id]'))
      .find(p => !p.hidden && p.style.display !== 'none');
    return visible ? visible.getAttribute('data-page-id') : null;
  }).catch(() => null);
  function resolveD6NavPageId(link) {
    if (link.navId) return link.navId;
    if (link.routeId) return link.routeId;
    return link.href ? link.href.replace(/^#/, '') : null;
  }
  const d6PageList = [{ label: '首页(P01)', type: 'home', href: null }];
  const d6SeenHrefs = new Set();
  const d6SeenPageIds = new Set();
  if (d6HomePageId) d6SeenPageIds.add(d6HomePageId);
  for (const link of navLinks) {
    const normalizedHref = normalizeHref(link.href);
    if (d6SeenHrefs.has(normalizedHref)) continue;
    const targetPageId = resolveD6NavPageId(link);
    if (targetPageId && d6SeenPageIds.has(targetPageId)) {
      log('  [INFO] D6 页面去重: 移除重复页 ' + targetPageId + '（' + (link.text || link.href).substring(0, 20) + '）');
      continue;
    }
    d6SeenHrefs.add(normalizedHref);
    if (targetPageId) d6SeenPageIds.add(targetPageId);
    d6PageList.push({
      label: (link.text || link.href).substring(0, 20),
      type: link.type,
      href: link.href,
      navId: link.navId,
      routeId: link.routeId,
    });
  }
  log('  [INFO] D6 将遍历 ' + d6PageList.length + ' 个页面测试按钮');

  let totalResponsive = 0;
  let totalUnresponsive = 0;
  // v5.22：toast-only 空交互独立计数（同时计入 totalUnresponsive，供诊断报告区分假响应类型）
  let totalToastOnly = 0;
  const allUnresponsiveButtons = [];
  const pagesWithoutButtons = [];
  let pagesTested = 0;

  for (let pageIdx = 0; pageIdx < d6PageList.length; pageIdx++) {
    const pageInfo = d6PageList[pageIdx];

    // 导航到目标页面（首页跳过导航）
    if (pageInfo.type !== 'home') {
      let clickArg;
      if (pageInfo.type === 'data-nav') {
        clickArg = `[data-nav="${pageInfo.navId}"]`;
      } else if (pageInfo.type === 'data-route') {
        clickArg = `[data-route="${pageInfo.routeId}"]`;
      } else {
        clickArg = `a[href="${pageInfo.href}"]`;
      }
      const navClicked = await page.evaluate((sel) => {
        const el = document.querySelector(sel);
        if (el) { el.click(); return true; }
        return false;
      }, clickArg).catch(() => false);
      if (!navClicked) {
        log('  [WARN] D6 页面 ' + pageIdx + ' 导航失败: ' + clickArg + ' 未找到，跳过该页');
        continue;
      }
      // M3 修复：谓词改为目标页特定（原谓词恒真，退化为零等待）
      const d6TargetPageId = pageInfo.navId || pageInfo.routeId;
      if (d6TargetPageId) {
        await page.waitForFunction((pid) => {
          const el = document.querySelector(`[data-page-id="${pid}"]`);
          return el && !el.hidden && el.style.display !== 'none';
          // v5.17.2 修复：waitForFunction 签名为 (fn, arg, options) — 原 (fn, {timeout}, pid) 把 {timeout} 当 arg 传入谓词，
          //   导致 pid="[object Object]" → 谓词恒 false → 默认 30s 超时 → D6 每页白等 30s（7 页=210s 浪费）
        }, d6TargetPageId, { timeout: 2000 }).catch(() => page.waitForTimeout(300));
      } else {
        await page.waitForTimeout(300);
      }
    }

    // 收集该页面的启用控件（v5.14：排除标注系统 + disabled 按钮）
    // v5.24 变更3：控件收集扩展——select 与 input[type=text]（含无 type 属性的默认文本框）纳入；
    //   仅携带 data-action 的 select/input 做 responded 判定（运行时无法可靠判定"被 app.js
    //   引用 id"，简化为 data-action 分流），纯装饰控件只计数不判定，控制无监听控件误报
    const buttons = await page.evaluate(() => {
      const allBtns = Array.from(document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], select, input[type="text"], input:not([type])'));
      const enabledBtns = [];
      const skippedDisabled = [];
      const skippedDecorative = [];
      // select / 文本框的紧凑标签（textContent 会拼接全部 option，不适合做日志标签）
      const controlLabel = (b) => {
        const viaAria = (b.getAttribute('aria-label') || '').trim();
        if (viaAria) return viaAria;
        if (b.id) {
          const lbl = document.querySelector('label[for="' + b.id + '"]');
          if (lbl) return (lbl.textContent || '').trim();
        }
        return (b.id || b.placeholder || b.value || '').trim();
      };
      for (let i = 0; i < allBtns.length; i++) {
        const b = allBtns[i];
        const r = b.getBoundingClientRect();
        const s = window.getComputedStyle(b);
        const visible = r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
        // 排除标注系统自身的按钮
        const isAnnotation = b.closest('[data-annotation-toggle]') ||
          b.closest('[data-annotation-close]') ||
          b.closest('.annotation-panel') ||
          b.closest('#demora-annotation-host') ||
          b.hasAttribute('data-annotation-toggle') ||
          b.hasAttribute('data-annotation-close');
        if (!visible || isAnnotation) continue;

        // v5.24：控件类型识别（select 换项触发 change / 文本框填值触发 input / button 点击）
        const isSelect = b.tagName === 'SELECT';
        const isTextInput = b.tagName === 'INPUT' && (b.getAttribute('type') || 'text').toLowerCase() === 'text';
        // v5.24：无 data-action 的 select/input 视为纯装饰控件——只计数不判定（控制误报）
        if ((isSelect || isTextInput) && !b.hasAttribute('data-action')) {
          skippedDecorative.push({
            text: controlLabel(b).substring(0, 30),
            reason: 'no data-action (count only)',
          });
          continue;
        }

        // v5.14：豁免 disabled 按钮
        const isDisabled = b.disabled === true ||
          b.getAttribute('aria-disabled') === 'true' ||
          b.classList.contains('disabled') ||
          s.pointerEvents === 'none';
        if (isDisabled) {
          skippedDisabled.push({
            text: (isSelect || isTextInput) ? controlLabel(b).substring(0, 30) : (b.textContent || b.value || '').trim().substring(0, 30),
            reason: b.disabled ? 'disabled attr' :
                    b.getAttribute('aria-disabled') === 'true' ? 'aria-disabled' :
                    b.classList.contains('disabled') ? '.disabled class' : 'pointer-events:none'
          });
          continue;
        }

        enabledBtns.push({
          globalIndex: i,
          kind: isSelect ? 'select' : (isTextInput ? 'text' : 'button'),
          text: (isSelect || isTextInput) ? controlLabel(b).substring(0, 30) : (b.textContent || b.value || '').trim().substring(0, 30),
          hasOnclick: b.hasAttribute('onclick'),
          hasDataAction: b.hasAttribute('data-action') || b.hasAttribute('data-open-modal'),
          hasType: b.getAttribute('type') || null,
          tagName: b.tagName,
        });
      }
      return { enabled: enabledBtns, skippedDisabled, skippedDecorative, totalButtons: allBtns.length };
    });

    if (buttons.enabled.length === 0) {
      pagesWithoutButtons.push(pageInfo.label);
      log('  [INFO] ' + pageInfo.label + ': 0 个启用按钮（跳过）');
      continue;
    }
    pagesTested++;
    log('  [INFO] ' + pageInfo.label + ': 探测 ' + buttons.totalButtons + ' 按钮，启用 ' + buttons.enabled.length + ' 个');
    // v5.24：纯装饰 select/input 计数提示（不参与 responded 判定）
    if (buttons.skippedDecorative.length > 0) {
      log('  [INFO] ' + pageInfo.label + ': 另有 ' + buttons.skippedDecorative.length +
        ' 个无 data-action 的 select/input（纯装饰控件仅计数不判定）');
    }

    // v5.17 Tier A：D6 按钮点击批量化（对齐 D10 L2550 单页批量 evaluate 模式）
    //   原实现：N 次独立 evaluate（每次 IPC 往返 300-1500ms + 200ms setTimeout）= ~103s/147按钮
    //   新实现：每页 1 次 batched evaluate，click + setTimeout + 状态对比 + 复位 全在浏览器内
    //   收益：7 页 × 1 = 7 次 evaluate（原 147 + 35 复位 = 182 次），节省 ~87s
    //   不变：检测条件（mutated/consoleLogged/hash/modal/toast/focus/class/ariaPressed）、
    //         BUTTON_RESPONSE=200ms、状态复位选择器、日志格式
    let clickResults;
    try {
      // v5.17.1 修复：Playwright page.evaluate 仅接受单参数，多参数封装为对象（对齐 D3 L1098 模式）
      clickResults = await page.evaluate(async ({ btnList, settleMs }) => {
        // v5.24 变更3：选择器与收集侧保持一致（新增 select / input[type=text] / 无 type 文本框），
        //   globalIndex 对齐依赖两侧选择器完全相同
        const btns = Array.from(document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"], select, input[type="text"], input:not([type])'));
        const results = [];

        // v5.22 业务状态签名：临时隐藏 .toast（visibility 保持布局）后取 body.innerText
        //   + 全部 [data-action] 元素 className/aria-pressed 快照 + 内联 style 快照（进度条宽度等）。
        //   拦截两类假响应：toast-only 空交互、同值重渲染（mutation 为真但业务值未变）。
        const businessSignature = () => {
          const toasts = Array.from(document.querySelectorAll('.toast'));
          const saved = toasts.map(function (t) { return t.style.visibility; });
          toasts.forEach(function (t) { t.style.visibility = 'hidden'; });
          try {
            const text = (document.body.innerText || '');
            const controls = Array.from(document.querySelectorAll('[data-action]')).map(function (el) {
              return (el.className || '') + '/' + (el.getAttribute('aria-pressed') || '');
            }).join(',');
            const styles = Array.from(document.querySelectorAll('[style]')).map(function (el) {
              return el.tagName + ':' + (el.getAttribute('style') || '');
            }).join(';');
            return text + '\u0001' + controls + '\u0002' + styles;
          } finally {
            toasts.forEach(function (t, i) { t.style.visibility = saved[i]; });
          }
        };

        for (const btnInfo of btnList) {
          const globalIdx = btnInfo.globalIndex;
          try {
            const target = btns[globalIdx];
            if (!target) { results.push({ globalIdx, clicked: false, reason: 'not found' }); continue; }

            // v5.22.1 陈旧/不可见引用跳过：此前点击的重渲染会替换按钮（引用 detached）或将其隐藏，
            //   真实用户无法点击旧引用——不计入响应率分母（对齐 disabled 跳过先例与 D10 不可见伪影治理）
            if (!target.isConnected || target.getClientRects().length === 0) {
              results.push({ globalIdx, clicked: false, reason: 'stale or invisible (skipped)' });
              continue;
            }

            // 再次确认按钮启用状态
            if (target.disabled === true || target.getAttribute('aria-disabled') === 'true') {
              results.push({ globalIdx, clicked: false, reason: 'button became disabled' });
              continue;
            }

            // v5.24 变更3：按控件类型分流触发——button 走 click；select 选首个非当前项后派发
            //   change；input[text] 填入非空值后派发 input（responded 判定复用 v5.22 业务状态签名）
            const kind = btnInfo.kind || 'button';
            let altIndex = -1;
            if (kind === 'select') {
              const opts = Array.from(target.options || []);
              altIndex = opts.findIndex((o, idx) => idx !== target.selectedIndex);
              // 无第二项可选（单选项下拉无变更语义）→ 跳过，不计入响应率分母
              if (altIndex < 0) { results.push({ globalIdx, clicked: false, reason: 'no alternative option (skipped)' }); continue; }
            }
            // v5.24：select/input 触发前记录原值，测后恢复（避免筛选残留污染后续 D8/D9/D10 测试）
            const originalValue = (kind === 'select' || kind === 'text') ? target.value : null;

            // 记录点击前状态
            // v5.22 顺序约束：signature 必须在下方 observer.observe 之前计算（签名自身的 style 读写不能触发 observer）
            const beforeState = {
              domNodes: document.querySelectorAll('*').length,
              hash: location.hash,
              modalVisible: !!document.querySelector('.modal:not([hidden]), #modalMask:not([hidden]), [role="dialog"]:not([hidden]), .modal-overlay:not([hidden]), .pg-modal-mask:not([hidden]), .modal-wrap:not([hidden]), .modal-container:not([hidden])'),
              toastVisible: !!document.querySelector('.toast:not([hidden]), .toast.is-visible'),
              focused: document.activeElement,
              // v5.14.16 修复 E：多维状态检测（CSS 类切换 / 元素属性 / computed style）
              bodyClass: document.body.className,
              targetClass: target.className,
              targetAriaPressed: target.getAttribute('aria-pressed'),
              // v5.22：业务状态签名（before 快照，先于 MutationObserver 启动）
              signature: businessSignature(),
            };

            let mutated = false;
            const observer = new MutationObserver(() => { mutated = true; });
            observer.observe(document.body, { childList: true, subtree: true, attributes: true });

            let consoleLogged = false;
            const origLog = console.log;
            console.log = function() { consoleLogged = true; origLog.apply(console, arguments); };

            try {
              // v5.24 变更3：select 换项派发 change / input[text] 填值派发 input / button 点击
              if (kind === 'select') {
                target.selectedIndex = altIndex;
                target.dispatchEvent(new Event('change', { bubbles: true }));
              } else if (kind === 'text') {
                target.value = (target.value || '') + '1';
                target.dispatchEvent(new Event('input', { bubbles: true }));
              } else {
                target.click();
              }
              // v5.17：setTimeout 改为浏览器内 await Promise（消除 IPC 往返等待）
              await new Promise(r => setTimeout(r, settleMs));
            } finally {
              observer.disconnect();
              console.log = origLog;
            }

            const afterState = {
              domNodes: document.querySelectorAll('*').length,
              hash: location.hash,
              modalVisible: !!document.querySelector('.modal:not([hidden]), #modalMask:not([hidden]), [role="dialog"]:not([hidden]), .modal-overlay:not([hidden]), .pg-modal-mask:not([hidden]), .modal-wrap:not([hidden]), .modal-container:not([hidden])'),
              toastVisible: !!document.querySelector('.toast:not([hidden]), .toast.is-visible'),
              focused: document.activeElement,
              bodyClass: document.body.className,
              targetClass: target.className,
              targetAriaPressed: target.getAttribute('aria-pressed'),
              // v5.22：业务状态签名（after 快照，须在上方 observer.disconnect() 之后计算）
              signature: businessSignature(),
            };
            // v5.22：responded 以业务状态签名 + 结构信号为准；toast/console 降级为报告信号（toastOnly）
            //   从判定中移除 mutated/consoleLogged/toastVisible 三个假响应源：
            //   toast-only 空交互（仅弹 toast 无业务变化）、同值重渲染（重复赋相同文本仍触发 MutationObserver）
            const signatureChanged = beforeState.signature !== afterState.signature;
            const responded = signatureChanged ||
              beforeState.domNodes !== afterState.domNodes ||
              beforeState.hash !== afterState.hash ||
              beforeState.modalVisible !== afterState.modalVisible ||
              beforeState.focused !== afterState.focused ||
              beforeState.bodyClass !== afterState.bodyClass ||
              beforeState.targetClass !== afterState.targetClass ||
              beforeState.targetAriaPressed !== afterState.targetAriaPressed;
            const modalChanged = beforeState.modalVisible !== afterState.modalVisible;
            const toastChanged = beforeState.toastVisible !== afterState.toastVisible;
            const toastOnly = !responded && (toastChanged || consoleLogged);

            // v5.24 变更3：select/input 触发后恢复原值并派发对应事件——恢复页面初始状态，
            //   避免筛选残留污染后续 D8/D9/D10 维度测试；恢复派发发生在 responded 判定之后，
            //   不影响本次结果（observer 已 disconnect，签名快照已固定）
            if (originalValue !== null && target.isConnected) {
              try {
                target.value = originalValue;
                target.dispatchEvent(new Event(kind === 'select' ? 'change' : 'input', { bubbles: true }));
                await new Promise(r => setTimeout(r, 100));
              } catch (e) { /* 恢复失败不阻断 */ }
            }

            // v5.14.16 修复 E：状态复位（关闭可能打开的 modal/toast）— v5.17 移入浏览器内（消除复位 IPC 往返）
            if (modalChanged || toastChanged) {
              document.querySelectorAll('.modal:not([hidden]), #modalMask:not([hidden]), [role="dialog"]:not([hidden]), .modal-overlay:not([hidden]), .pg-modal-mask:not([hidden]), .modal-wrap:not([hidden]), .modal-container:not([hidden]), .modal-backdrop:not([hidden]), .layui-layer:not([hidden]), .ant-modal:not([hidden])').forEach(m => {
                m.setAttribute('hidden', '');
                m.style.display = 'none';
              });
              document.querySelectorAll('.toast:not([hidden]), .toast.is-visible').forEach(t => {
                t.setAttribute('hidden', '');
                t.classList.remove('is-visible');
              });
              document.querySelectorAll('.modal-close, .close-btn, .btn-close, [data-close-modal], [data-dismiss="modal"]').forEach(c => {
                try { c.click(); } catch (e) { /* 忽略 */ }
              });
              // v5.17.2：复位等待 200ms→100ms（已 setAttribute hidden + display:none，CSS 即时生效，100ms 足够）
              await new Promise(r => setTimeout(r, 100));
            }

            results.push({
              globalIdx,
              clicked: true,
              kind,
              // v5.24：select/文本框用紧凑标签（textContent 会拼接全部 option）
              text: (kind === 'select' || kind === 'text')
                ? ((target.getAttribute('aria-label') || target.id || target.value || '').trim().substring(0, 30))
                : (target.textContent || target.value || '').trim().substring(0, 30),
              responded,
              mutated,
              consoleLogged,
              // v5.22：业务签名/toast-only 报告信号（mutated/consoleLogged 保留仅供诊断，不再进入 responded）
              signatureChanged,
              toastOnly,
              hashChanged: beforeState.hash !== afterState.hash,
              modalChanged,
              toastChanged,
              focusChanged: beforeState.focused !== afterState.focused,
              classChanged: beforeState.targetClass !== afterState.targetClass || beforeState.bodyClass !== afterState.bodyClass,
            });
          } catch (e) {
            // 每按钮异常隔离：记录为未点击，不中断后续按钮（对齐原 outer catch 行为）
            results.push({ globalIdx, clicked: false, reason: 'exception: ' + e.message });
          }
        }
        return results;
      }, { btnList: buttons.enabled, settleMs: WAIT_TIMES.BUTTON_RESPONSE });
    } catch (e) {
      // 批量 evaluate 整体失败（页面导航/浏览器崩溃等灾难性场景）
      log('  [WARN] ' + pageInfo.label + ' D6 批量点击失败: ' + e.message);
      clickResults = buttons.enabled.map(b => ({ globalIdx: b.globalIndex, clicked: false, reason: 'batch evaluate failed' }));
    }

    // v5.17 Tier A2：按原格式逐行输出日志（AI 可解析，格式与 v1 完全一致）
    for (let i = 0; i < buttons.enabled.length; i++) {
      const btn = buttons.enabled[i];
      const result = clickResults[i];
      if (!result) continue;

      if (result.clicked && result.responded) {
        totalResponsive++;
        log('  [OK] ' + pageInfo.label + ' "' + result.text + '" 响应' +
          (result.signatureChanged ? ' [SIG]' : '') +
          (result.mutated ? ' [DOM]' : '') +
          (result.consoleLogged ? ' [LOG]' : '') +
          (result.hashChanged ? ' [HASH]' : '') +
          (result.modalChanged ? ' [MODAL]' : '') +
          (result.toastChanged ? ' [TOAST]' : '') +
          (result.focusChanged ? ' [FOCUS]' : '') +
          (result.classChanged ? ' [CLASS]' : ''));
      } else if (result.clicked && !result.responded) {
        totalUnresponsive++;
        allUnresponsiveButtons.push({ page: pageInfo.label, text: result.text });
        // v5.22：toast-only 空交互独立标注与计数（toast/console 有反应但业务签名与结构信号均无变化）
        if (result.toastOnly) {
          totalToastOnly++;
          log('  [WARN] ' + pageInfo.label + ' "' + result.text + '" 点击后无响应 [TOAST-ONLY]（onclick=' + btn.hasOnclick + ', data-action=' + btn.hasDataAction + '）');
        } else {
          // v5.24：select/input 控件触发方式与 button 不同（换项/填值派发事件），提示词区分
          const verb = (result.kind === 'select') ? '换项后' : (result.kind === 'text') ? '填值后' : '点击后';
          log('  [WARN] ' + pageInfo.label + ' "' + result.text + '" ' + verb + '无响应（onclick=' + btn.hasOnclick + ', data-action=' + btn.hasDataAction + '）');
        }
      } else if (!result.clicked && result.reason && result.reason.startsWith('exception')) {
        // 对齐原 outer catch 行为：记录异常，不计入 totalTested
        log('  [WARN] ' + pageInfo.label + ' 按钮 #' + btn.globalIndex + ' 测试异常: ' + result.reason.substring('exception: '.length));
      }
      // 其他 case（not found / became disabled / batch failed）→ 静默跳过（对齐原行为）
    }
  }

  const totalTested = totalResponsive + totalUnresponsive;
  // v5.22：汇总与值串统一追加 toast-only 计数（仅当 >0，报告信号不改变阈值判定）
  const toastOnlyNote = totalToastOnly > 0 ? ' (toast-only ' + totalToastOnly + ')' : '';
  log('  [INFO] D6 汇总: 遍历 ' + d6PageList.length + ' 页，测试 ' + pagesTested + ' 页，' + totalTested + ' 按钮' + toastOnlyNote);
  if (pagesWithoutButtons.length > 0) {
    log('  [INFO] 无启用按钮的页面: ' + pagesWithoutButtons.join(', '));
  }

  if (totalTested === 0) {
    // v5.14.7：D6 skip 改为 warn（原为 pass），堵塞"全 disabled demo 也能过 D6"反向漏洞
    log('  [WARN] D6: 所有页面均无可见启用业务按钮（企业级应用 0 启用按钮为异常信号）');
    warn++;
    results.dimensions.D6_button_responsiveness = 'warn: no enabled buttons across all pages';
  } else {
    const responsiveRatio = totalResponsive / totalTested;
    if (responsiveRatio >= 0.8) {
      // v5.16 S-7 修复：80-90% 增加"接近阈值"提示，辅助 AI 识别漏响应按钮
      const thresholdNote = responsiveRatio < 0.9 ? '（接近阈值，建议检查漏响应按钮）' : '';
      log('  [OK] D6: 启用按钮响应率 ' + totalResponsive + '/' + totalTested + ' (' + (responsiveRatio * 100).toFixed(0) + '%) — 跨 ' + pagesTested + ' 页' + thresholdNote);
      pass++;
      results.dimensions.D6_button_responsiveness = 'pass: ' + totalResponsive + '/' + totalTested + ' across ' + pagesTested + ' pages' + thresholdNote + toastOnlyNote;
    } else if (responsiveRatio >= 0.5) {
      log('  [WARN] D6: 启用按钮响应率 ' + totalResponsive + '/' + totalTested + ' (' + (responsiveRatio * 100).toFixed(0) + '%) — 部分按钮无响应');
      warn++;
      results.dimensions.D6_button_responsiveness = 'warn: ' + totalResponsive + '/' + totalTested + ' across ' + pagesTested + ' pages' + toastOnlyNote;
    } else {
      log('  [FAIL] D6: 启用按钮响应率 ' + totalResponsive + '/' + totalTested + ' (' + (responsiveRatio * 100).toFixed(0) + '%) — 大部分按钮无响应');
      log('         无响应按钮（按页）:');
      const grouped = {};
      for (const u of allUnresponsiveButtons) {
        if (!grouped[u.page]) grouped[u.page] = [];
        grouped[u.page].push(u.text);
      }
      for (const [p, btns] of Object.entries(grouped)) {
        log('           ' + p + ': ' + btns.slice(0, 5).join(', ') + (btns.length > 5 ? ' ...' : ''));
      }
      fail++;
      results.dimensions.D6_button_responsiveness = 'fail: ' + totalResponsive + '/' + totalTested + ' across ' + pagesTested + ' pages' + toastOnlyNote;
      await screenshot('D6-button-unresponsive');
    }
  }
  } else {
    markDimSkipped(['D6_button_responsiveness', 'D6_filter_consistency']); // v5.24：筛选往返一致性探针同属 D6 记账族，未选 D6 时一并 skip
  }

  // ===== v5.23 增强1/2 逐页收集器与浏览器内探针（D10 逐页导航循环中填充，循环后统一收口）=====
  //   背景：D7 视觉启发式只在初始页跑一次（表格坍塌漏检）、D8 覆盖率需逐页统计；
  //   D10 已有成熟的四重兜底逐页导航循环（a[href] click / data-nav click /
  //   data-target-page click / popstate+hashchange），此处挂载探针复用其导航/等待模式
  //   （优先复用而非自建循环，省时且导航语义与 D10 一致）
  const d7TableFails = [];             // D7 表格完整性 FAIL 项（含页码前缀字符串）
  const d7TableWarns = [];             // D7 表格完整性 WARN 项（行列数不一致）
  const d7CheckedPageIds = new Set();  // 已做表格检查的页（D7 初始检查与 D10 循环防重复计页）
  let d7VisualIssues = [];             // D7 初始页启发式结果（暂存，收口时并入最终判定）
  const d8CoverageSamples = [];        // D8 覆盖率逐页采样 { pageId, total, types[] }（v5.24：types 含逐类型规模分流数据）
  const d8CoverageCheckedPageIds = new Set();
  // v5.24 变更5：D10 导航后公共区域断言 FAIL 项（docScrollTop / topbar top，并入 D7 收口族定级）
  const d10NavFails = [];
  // v5.24 变更4：筛选往返一致性探针结果（d6FilterCheckedPages 区分"D10 未执行"与"已执行但无筛选控件"）
  const d6FilterResults = [];          // { pageId, control, verdict: 'FAIL'|'WARN'|'PASS', detail }
  let d6FilterCheckedPages = 0;
  const d6FilterCheckedPageIds = new Set(); // v5.24：探针已执行页去重（对齐 d8CoverageCheckedPageIds 模式，防御重复计页）

  // v5.23 增强1：表格完整性探针（page.evaluate 序列化到浏览器执行，D7 初始页 + D10 循环共用）
  //   ① tr 存在非 td/th/script/template/空白文本 直系子节点 → FAIL（非法表格结构；
  //     豁免 .l3-dot/.l2-marker——标注引擎注入的指示器非 demo 结构，对齐引擎自身排除规则）
  //   ② 可见 tr（getBoundingClientRect 面积>0）computed display ≠ table-row → FAIL
  //     （实证缺陷：demo style.css 写 [data-element-id]{display:inline-flex} 令 tr 布局坍塌）
  //   ③ 同一 tbody 内各行 td colspan 折算合计不一致 → WARN（rowspan/colspan 合法存在故降级）
  //   隐藏表格（折叠 details/隐藏弹窗内，rect 面积=0）整体跳过——视觉完整性只对可见内容负责
  const tableIntegrityProbe = () => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])') || document;
    const pageId = (visiblePage !== document) ? visiblePage.getAttribute('data-page-id') : 'INIT';
    const fails = [];
    const warns = [];
    const tables = visiblePage.querySelectorAll('table');
    tables.forEach((table, ti) => {
      const tableRect = table.getBoundingClientRect();
      if (tableRect.width * tableRect.height === 0) return; // 隐藏表格跳过
      const rows = table.querySelectorAll('tr');
      rows.forEach((tr, ri) => {
        // ① 非法直系子节点
        for (const child of tr.childNodes) {
          if (child.nodeType === 3) {
            if (!(child.textContent || '').trim()) continue; // 空白文本豁免
            fails.push('表' + (ti + 1) + ' 第' + (ri + 1) + '行 含非法文本子节点');
            continue;
          }
          if (child.nodeType !== 1) continue;
          const tag = child.tagName;
          if (tag === 'TD' || tag === 'TH' || tag === 'SCRIPT' || tag === 'TEMPLATE') continue;
          if (child.classList && (child.classList.contains('l3-dot') || child.classList.contains('l2-marker'))) continue;
          fails.push('表' + (ti + 1) + ' 第' + (ri + 1) + '行 含非法直系子节点 <' + tag + '>');
        }
        // ② 可见行 display 异常
        const trRect = tr.getBoundingClientRect();
        if (trRect.width > 0 && trRect.height > 0) {
          const disp = window.getComputedStyle(tr).display;
          if (disp !== 'table-row') {
            fails.push('表' + (ti + 1) + ' 第' + (ri + 1) + '行 display=' + disp);
          }
        }
      });
      // ③ 行列数一致性（colspan 折算：td.colSpan 累加，th 一并计入防表头行误报）
      const bodies = table.querySelectorAll('tbody');
      const bodyList = bodies.length > 0 ? bodies : [table];
      bodyList.forEach((tbody) => {
        const rowSpans = [];
        tbody.querySelectorAll(':scope > tr').forEach((tr) => {
          let spanSum = 0;
          tr.querySelectorAll(':scope > td, :scope > th').forEach((cell) => { spanSum += (cell.colSpan || 1); });
          rowSpans.push(spanSum);
        });
        if (rowSpans.length > 1 && rowSpans.some((c) => c !== rowSpans[0])) {
          warns.push('表' + (ti + 1) + ' 各行 td colspan 合计不一致（' + rowSpans.join('/') + '）');
        }
      });
    });
    return { pageId, fails, warns };
  };

  // v5.23 增强2-B / v5.24 变更1 重构：交互元件类型覆盖率探针（D10 逐页循环采样）
  //   v5.23 四层失效（UAT0826 实证）：①>=3 类型阈值静默（p4 P01 2/6、P03 2/8 整页不报）；
  //   ②类型键用 innerText 文本（功能同类文本不同被拆类型、select 用 option 拼接）；
  //   ③任一实例标注=整类型覆盖（无"首个"规范性）；④明细只存页码。
  //   v5.24 重构：
  //   - 类型键改语义键：tagName + 优先级取语义属性（aria-label > 关联 label 文本
  //     （label[for=id] 或父级 label）> data-action > innerText/value/placeholder 截断 30）
  //   - 选择器扩展：[role="button"] / [tabindex]:not([tabindex="-1"]) / 携带 data-action
  //     的任意元素（排除标注引擎注入的 .l3-dot/.l2-marker）
  //   - 逐类型输出实例数/标注数/首个实例（DOM 顺序）标注情况/首个实例卡片 element 名，
  //     规模分流校验（N<=4 全标 / N>4 首标+同类说明）在 Node 侧收口统一执行
  const coverageProbe = () => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])') || document;
    const pageId = (visiblePage !== document) ? visiblePage.getAttribute('data-page-id') : 'INIT';
    // 标注数据解包（N>4 组校验卡片 element 名是否含同类说明用，兼容 {version,pages} 包装与扁平结构）
    const annoData = window.__ANNOTATION_DATA__;
    const rawPages = (annoData && annoData.pages && typeof annoData.pages === 'object' && !Array.isArray(annoData.pages))
      ? annoData.pages
      : annoData;
    const pageCards = (rawPages && rawPages[pageId] && Array.isArray(rawPages[pageId].L3)) ? rawPages[pageId].L3 : [];
    // 首个未标注实例的定位提示：优先表格行号，其次 #id，再次同类内序号
    const locatorOf = (el, ordinal) => {
      const tr = el.closest('tr');
      if (tr) {
        const table = tr.closest('table');
        const rows = table ? Array.from(table.querySelectorAll('tr')) : [];
        return '行' + (rows.indexOf(tr) + 1);
      }
      if (el.id) return '#' + el.id;
      return '第' + ordinal + '个';
    };
    const typeMap = new Map();
    visiblePage.querySelectorAll('button, a[href], select, input, [role="button"], [tabindex]:not([tabindex="-1"]), [data-action]').forEach((el) => {
      if (el.classList.contains('l3-dot') || el.classList.contains('l2-marker')) return; // 标注引擎注入元件不参与统计
      const rect = el.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;
      const cs = window.getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden') return;
      if (el.tagName === 'INPUT' && (el.getAttribute('type') || 'text').toLowerCase() === 'hidden') return;
      // v5.24 语义键：优先语义属性，消除"功能同类文本不同被拆类型 / select 用 option 拼接"两类失真
      let sem = (el.getAttribute('aria-label') || '').trim();
      if (!sem && el.id) {
        const forLabel = visiblePage.querySelector('label[for="' + el.id + '"]') || document.querySelector('label[for="' + el.id + '"]');
        if (forLabel) sem = (forLabel.textContent || '').trim();
      }
      if (!sem) {
        const parentLabel = el.closest('label');
        if (parentLabel) sem = (parentLabel.textContent || '').trim();
      }
      if (!sem) sem = (el.getAttribute('data-action') || '').trim();
      if (!sem) sem = (el.innerText || el.value || el.placeholder || '').trim().replace(/\s+/g, ' ').substring(0, 30);
      const key = el.tagName + '|' + sem;
      const annotated = !!el.closest('[data-element-id]'); // closest 含自身，覆盖"自身或祖先带标注"两种情况
      let entry = typeMap.get(key);
      if (!entry) {
        entry = { count: 0, annotatedCount: 0, firstAnnotated: null, firstCardElement: null, unannotatedLocators: [] };
        typeMap.set(key, entry);
      }
      entry.count++;
      if (annotated) {
        entry.annotatedCount++;
      } else {
        entry.unannotatedLocators.push(locatorOf(el, entry.count));
      }
      if (entry.firstAnnotated === null) {
        // 首个可见实例（DOM 顺序）的标注规范性是 v5.24 规模分流契约的校验锚点
        entry.firstAnnotated = annotated;
        if (annotated) {
          const wrap = el.closest('[data-element-id]');
          const elementId = wrap ? wrap.getAttribute('data-element-id') : null;
          if (elementId) {
            const card = pageCards.find((c) => c && c.id === elementId);
            entry.firstCardElement = card ? String(card.element || '') : null;
          }
        }
      }
    });
    const types = [];
    for (const [key, v] of typeMap) {
      types.push({
        key,
        count: v.count,
        annotatedCount: v.annotatedCount,
        firstAnnotated: v.firstAnnotated === true,
        firstCardElement: v.firstCardElement || '',
        unannotatedLocators: v.unannotatedLocators.slice(0, 3), // 定位提示截 3 条防明细爆炸
      });
    }
    return { pageId, total: types.length, types };
  };

  // v5.24 变更4：筛选往返一致性探针（挂 D10 循环，导航 settle 后、L2/L3 点击前执行）
  //   目标（UAT0826 p6 实证）：筛选后计数文本"共 2 条"与表格可见 12 行不一致，现有维度全放过。
  //   触发对象：当前页可见 select[data-action] 与 select[id]（排除 multiple/不可见）；
  //            input[type=text] 且 data-action 或 id 命中 /search|filter|kw|关键词|搜索/i 者
  //            填入当前页首个表格行首格文本前 2 字。
  //   判定：计数文本与可见行数不一致 → FAIL；无计数文本且无任何可见状态变化（行显隐/文本/类名）
  //        → WARN；一致或仅行显隐变化 → 通过。测后恢复控件原值；每页每控件只测一次。
  //   幂等性：探针随 D10 循环每页执行一次，控件遍历单趟，天然幂等；异常由调用方 try/catch 兜底。
  //   可见行口径：rect 高>0 且含 td 的 tr（th-only 表头行不计入——"共 N 条"计数不含表头）；
  //   计数文本口径：distinct 计数值须与可见行总数或某单表行数匹配（多表多计数并存时不误判）
  const filterConsistencyProbe = async () => {
    const visiblePage = document.querySelector('[data-page-id]:not([hidden])') || document;
    const pageId = (visiblePage !== document) ? visiblePage.getAttribute('data-page-id') : 'INIT';
    const outcomes = [];
    const settle = (ms) => new Promise((r) => setTimeout(r, ms));
    // 同页计数文本：/共\s*(\d+)\s*(条|行|个|件|家|项)/（标注宿主在页容器外天然排除）
    const countMatches = () => {
      const text = visiblePage.innerText || '';
      const re = /共\s*(\d+)\s*(?:条|行|个|件|家|项)/g;
      const vals = [];
      let m;
      while ((m = re.exec(text)) !== null) vals.push(parseInt(m[1], 10));
      return vals;
    };
    // 可见数据行：所有可见 table 中 rect 高>0 且含 td 的 tr（表头行不计）
    const visibleTableRowInfo = () => {
      const perTable = [];
      visiblePage.querySelectorAll('table').forEach((table) => {
        const tr = table.getBoundingClientRect();
        if (tr.width * tr.height === 0) return; // 隐藏表格跳过
        let n = 0;
        table.querySelectorAll('tr').forEach((row) => {
          const r = row.getBoundingClientRect();
          if (r.height <= 0) return;
          if (!row.querySelector('td')) return; // th-only 表头行不计
          n++;
        });
        perTable.push(n);
      });
      return { perTable, total: perTable.reduce((s, n) => s + n, 0) };
    };
    // 可见状态签名（行显隐/文本/类名三信号，判定"触发后无任何可见状态变化"用）
    const stateSignature = () => {
      const rows = visibleTableRowInfo().total;
      const text = (visiblePage.innerText || '');
      const classes = Array.from(visiblePage.querySelectorAll('[class]'))
        .map((el) => el.tagName + '.' + el.className).join('|');
      return rows + '\u0001' + text + '\u0002' + classes;
    };
    // 触发对象收集
    const controls = [];
    visiblePage.querySelectorAll('select').forEach((sel) => {
      if (sel.multiple) return; // 排除多选
      if (!sel.hasAttribute('data-action') && !sel.id) return; // 仅 select[data-action] / select[id]
      const r = sel.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      const cs = window.getComputedStyle(sel);
      if (cs.display === 'none' || cs.visibility === 'hidden') return;
      controls.push({ el: sel, kind: 'select' });
    });
    visiblePage.querySelectorAll('input[type="text"], input:not([type])').forEach((inp) => {
      const ident = ((inp.getAttribute('data-action') || '') + ' ' + (inp.id || '')).toLowerCase();
      if (!/search|filter|kw|关键词|搜索/.test(ident)) return;
      const r = inp.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      controls.push({ el: inp, kind: 'text' });
    });
    // 触发 → 400ms 评估 → 恢复（每页每控件只测一次）
    for (const ctl of controls) {
      const el = ctl.el;
      const label = (el.getAttribute('aria-label') || el.id || el.getAttribute('data-action') || '').trim();
      try {
        let triggerDesc = '';
        let beforeValue = '';
        let beforeIndex = -1;
        if (ctl.kind === 'select') {
          const opts = Array.from(el.options || []);
          const alt = opts.findIndex((o, idx) => idx !== el.selectedIndex);
          if (alt < 0) continue; // 无第二项可选（非当前项），跳过
          beforeIndex = el.selectedIndex;
          beforeValue = el.value;
          const beforeSig = stateSignature();
          el.selectedIndex = alt;
          el.dispatchEvent(new Event('change', { bubbles: true }));
          await settle(400);
          const afterCounts = countMatches();
          const rowsInfo = visibleTableRowInfo();
          const afterSig = stateSignature();
          const distinct = Array.from(new Set(afterCounts));
          let verdict;
          let detail;
          if (distinct.length === 0) {
            // 无计数文本且触发后无任何可见状态变化（行显隐/文本/类名）→ WARN；有变化 → 通过
            verdict = (beforeSig !== afterSig) ? 'PASS' : 'WARN';
            detail = verdict === 'WARN'
              ? '筛选触发后无计数文本且无可见状态变化（控件 ' + label + '）'
              : '筛选触发后无计数文本但存在可见状态变化（控件 ' + label + '）';
          } else {
            // 计数文本与可见行一致性：distinct 值须与总行数或某单表行数匹配（多表多计数并存时不误判）
            const consistent = distinct.every((v) => v === rowsInfo.total || rowsInfo.perTable.indexOf(v) >= 0);
            verdict = consistent ? 'PASS' : 'FAIL';
            detail = verdict === 'FAIL'
              ? '筛选计数与可见行不一致（共 ' + distinct.join('/') + ' 条 vs 可见 ' + rowsInfo.total + ' 行，触发控件 ' + label + '）'
              : '筛选计数与可见行一致（共 ' + distinct.join('/') + ' 条 / 可见 ' + rowsInfo.total + ' 行，控件 ' + label + '）';
          }
          outcomes.push({ control: label, verdict, detail });
          triggerDesc = 'select 换项';
          // 测后恢复：select 重置原值 + dispatch change
          if (el.isConnected && beforeIndex >= 0) {
            el.selectedIndex = beforeIndex;
            el.dispatchEvent(new Event('change', { bubbles: true }));
            await settle(200);
          }
        } else {
          // input[text]：填入当前页首个表格行首格文本前 2 字（无表格时用占位词）
          const firstCell = visiblePage.querySelector('table tbody td, table td');
          const seed = firstCell ? (firstCell.textContent || '').trim().substring(0, 2) : '测试';
          beforeValue = el.value;
          const beforeSig = stateSignature();
          el.value = seed;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          await settle(400);
          const afterCounts = countMatches();
          const rowsInfo = visibleTableRowInfo();
          const afterSig = stateSignature();
          const distinct = Array.from(new Set(afterCounts));
          let verdict;
          let detail;
          if (distinct.length === 0) {
            verdict = (beforeSig !== afterSig) ? 'PASS' : 'WARN';
            detail = verdict === 'WARN'
              ? '搜索词触发后无计数文本且无可见状态变化（控件 ' + label + '）'
              : '搜索词触发后无计数文本但存在可见状态变化（控件 ' + label + '）';
          } else {
            const consistent = distinct.every((v) => v === rowsInfo.total || rowsInfo.perTable.indexOf(v) >= 0);
            verdict = consistent ? 'PASS' : 'FAIL';
            detail = verdict === 'FAIL'
              ? '筛选计数与可见行不一致（共 ' + distinct.join('/') + ' 条 vs 可见 ' + rowsInfo.total + ' 行，触发控件 ' + label + '）'
              : '筛选计数与可见行一致（共 ' + distinct.join('/') + ' 条 / 可见 ' + rowsInfo.total + ' 行，控件 ' + label + '）';
          }
          outcomes.push({ control: label, verdict, detail });
          triggerDesc = 'input 填词';
          // 测后恢复：input 重置原值 + dispatch input
          if (el.isConnected) {
            el.value = beforeValue;
            el.dispatchEvent(new Event('input', { bubbles: true }));
            await settle(200);
          }
        }
        void triggerDesc; // 触发方式仅用于注释语义，显式声明避免未使用告警
      } catch (e) {
        // 单控件异常隔离：记为 PASS 不中断（探针异常不阻塞主流程）
        outcomes.push({ control: label, verdict: 'PASS', detail: '探针异常（' + (e && e.message ? e.message : String(e)) + '）' });
      }
    }
    return { pageId, outcomes };
  };

  // ===== D7: 视觉启发式检查（v5.14 新增，采纳审计 final §5 P1-5；v5.23 拆为初始页启发式 + 逐页表格完整性）=====
  // 目的：捕获 B2 类视觉缺陷（侧栏遮挡 + 首屏空白卡片 + 表格布局坍塌）
  // 阈值（经 PM 决策调整）：D7-a 交叠 > 8%；D7-b 空白大块 ≥ 2；D7-c 首屏文本 < 30 字符（图表页面豁免）
  if (shouldRunDim('D7')) { // v5.18 P1：--dimensions 未含 D7 时整块跳过
    log('\n--- D7: 视觉启发式检查（v5.23：初始页启发式 + 逐页表格完整性）---');
    const visualIssues = await page.evaluate(() => {
      const viewportW = window.innerWidth;
      const viewportH = window.innerHeight;
      const issues = [];

      // D7-a: 固定/粘性定位元素与主内容容器交叠面积 > 主容器 8%
      // （阈值从 5% 调至 8%：正常 sticky header 高度约 60px，视口 800px 时占 7.5%，5% 会误报）
      const mainContainer = document.querySelector('main, .main, .content, #content, [role="main"]');
      const stickyElements = document.querySelectorAll('header, nav, aside, .sidebar, .header, .nav');
      if (mainContainer) {
        const mainRect = mainContainer.getBoundingClientRect();
        const mainArea = mainRect.width * mainRect.height;
        if (mainArea > 0) {
          for (const el of stickyElements) {
            const style = getComputedStyle(el);
            if (style.position === 'fixed' || style.position === 'sticky') {
              const r = el.getBoundingClientRect();
              const overlapW = Math.max(0, Math.min(r.right, mainRect.right) - Math.max(r.left, mainRect.left));
              const overlapH = Math.max(0, Math.min(r.bottom, mainRect.bottom) - Math.max(r.top, mainRect.top));
              const overlapArea = overlapW * overlapH;
              if (overlapArea / mainArea > 0.08) {
                issues.push(`D7-a: 固定元素 ${el.tagName}.${el.className} 与主容器交叠 ${(overlapArea/mainArea*100).toFixed(1)}% > 8%`);
              }
            }
          }
        }
      }

      // D7-b: 可见块级元素面积 > 视口 8% 且无文本/图形子节点者 ≥ 2 个
      const blockElements = document.querySelectorAll('div, section, main, article, aside');
      let emptyLargeBlocks = 0;
      for (const el of blockElements) {
        const r = el.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) continue;
        const area = r.width * r.height;
        if (area / (viewportW * viewportH) > 0.08) {
          const text = el.innerText?.trim() || '';
          const hasImg = el.querySelector('img, svg, canvas');
          if (text.length === 0 && !hasImg) {
            emptyLargeBlocks++;
          }
        }
      }
      if (emptyLargeBlocks >= 2) {
        issues.push(`D7-b: ${emptyLargeBlocks} 个大块级元素无文本/图形内容（≥ 2 触发 WARN）`);
      }

      // D7-c: 首屏可见文本密度低于阈值（阈值从 50 调至 30 + 图表页面白名单）
      // 图表页面白名单：页面含 <canvas>/<svg> 时豁免（库存仪表盘等以图表为主的页面文本少但非缺陷）
      const hasChart = document.querySelector('canvas, svg.graph, svg.chart, [data-chart]');
      if (!hasChart) {
        const firstScreenText = document.body.innerText.slice(0, viewportW * viewportH / 10);
        if (firstScreenText.length < 30) {
          issues.push(`D7-c: 首屏可见文本密度过低（${firstScreenText.length} 字符 < 30）`);
        }
      }

      // v5.15 P1-7：D7-d 表头与单元格 text-align 分布不一致（表头错位）
      //   rk3 P-7 修复：原仅比 ths[0] vs tds[0]，"表头居中/单元格左对齐"是合法常见设计 → 误报。
      //   改为分布判定：统计 th/td 的 text-align 分布，仅当某对齐在 th 中占比 >50% 但在 td 中 <20%（反之亦然）才告警。
      // v2.2：D7-d text-align 判定修正——依据 p2（ip-pledge-finance，0815-082200-GLM-5.2）实证 6 issues 全部误报：
      //   ① computed textAlign 对未显式设置的元素返回 'start'/'end'（CSS Text 3），与显式 'left'/'right' 语义相同但字符串不同，
      //      p2 的 th 显式 text-align:left（style.css .table th）vs td 默认 start → 制造 "th 100% left vs td 0% left" 假象；
      //   ② 数字/金额列右对齐（p2 的 .num { text-align:right }）是金融表格规范，
      //      v5.16 S-6 的 isTdAllCenter 豁免只覆盖 "td 全 center + th 全 left"，未覆盖数字列 right。
      //   修正：归一化 start→left / end→right 后再统计分布；数字单元格（纯数字/货币/百分比文本）不计入 td 分布；
      //         全数字列表格（tdDist 为空）跳过。真错位（th 全 center vs td 全 left 等）检出能力不变。
      const tables = document.querySelectorAll('table');
      for (const table of tables) {
        const ths = table.querySelectorAll('th');
        const tds = table.querySelectorAll('td');
        if (ths.length > 0 && tds.length > 0) {
          const normAlign = (a) => (a === 'start' ? 'left' : a === 'end' ? 'right' : a);
          const isNumericCell = (el) => /^[\s¥$€£-]*\d[\d,.，]*\s*%?$/.test((el.textContent || '').trim());
          const thDist = {};
          const tdDist = {};
          ths.forEach(t => { const a = normAlign(window.getComputedStyle(t).textAlign); thDist[a] = (thDist[a] || 0) + 1; });
          tds.forEach(t => { if (isNumericCell(t)) return; const a = normAlign(window.getComputedStyle(t).textAlign); tdDist[a] = (tdDist[a] || 0) + 1; });
          if (Object.keys(tdDist).length === 0) continue; // v2.2：全数字列表格无文本对齐可比，跳过
          for (const align of new Set([...Object.keys(thDist), ...Object.keys(tdDist)])) {
            const thRatio = thDist[align] ? thDist[align] / ths.length : 0;
            const tdRatio = tdDist[align] ? tdDist[align] / Object.values(tdDist).reduce((s, n) => s + n, 0) : 0;
            // v5.16 S-6 修复：阈值从严（>0.8 && <0.05），并增加 td 全 center 豁免
            //   根因：原阈值 >0.5 && <0.2 对"表头左对齐/数据列居中"合法设计过严（4/12 误报）
            //   修复：仅极端不对称（>0.8 && <0.05）才告警，td 全 center + th 全 left 豁免
            const isStrictAsymmetry = (thRatio > 0.8 && tdRatio < 0.05) || (tdRatio > 0.8 && thRatio < 0.05);
            const isTdAllCenter = (tdDist['center'] === Object.values(tdDist).reduce((s, n) => s + n, 0) && thDist['left'] === ths.length);
            if (isStrictAsymmetry && !isTdAllCenter) {
              issues.push(`D7-d: 表头/单元格 text-align 分布显著不一致（${align}: th ${(thRatio*100).toFixed(0)}% vs td ${(tdRatio*100).toFixed(0)}%）`);
              break;
            }
          }
        }
      }
      // v5.15 P1-7：D7-d2 输入框尺寸异常（width < 60px 或 > 100%）
      //   rk3 P-7 修复：排除 checkbox/radio/hidden（其 width 约 13-16px < 60 → 必报，误报炸弹）
      const inputs = document.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]):not([type="hidden"]), select, textarea');
      for (const inp of inputs) {
        const w = inp.getBoundingClientRect().width;
        if (w > 0 && w < 60) {
          issues.push(`D7-d: 输入框 ${inp.tagName}${inp.type ? '[type=' + inp.type + ']' : ''} 宽度 ${w.toFixed(0)}px < 60px（尺寸异常）`);
        }
      }

      // v5.24 变更5：D7-e 初始态 document 溢出检测（warn 维度记账，随 d7VisualIssues 走）
      //   根因（UAT0826 p3 实证）：骨架 footer 注入在 .app-shell 滚动容器之外，
      //   document 级溢出 149px 出现非预期整页滚动条；骨架 footer 应注入滚动容器内
      //   注意：document.scrollHeight 在 Chrome 为 undefined（Document 无该属性），
      //   须用 documentElement.scrollHeight（实测 p3：869-720=149px）
      if (document.querySelector('.app-shell')) {
        const docOverflow = document.documentElement.scrollHeight - document.documentElement.clientHeight;
        if (docOverflow > 4) {
          issues.push(`D7-e: document 溢出 ${Math.round(docOverflow)}px（app-shell 外存在 in-flow 块级元素；骨架 footer 应注入滚动容器内，旧版处理产物请重跑 enhance-prototype）`);
        }
      }

      return issues;
    });

    // v5.23 增强1：初始页启发式结果暂存（不立即定级）；逐页表格完整性数据在 D10
    //   逐页导航循环中收集（tableIntegrityProbe），循环结束后统一收口判定 D7 维度
    //   （warn 仍每维度计 1 次，对齐 v5.14.10 约定：不按 issue 数虚高）
    d7VisualIssues = visualIssues;
    if (visualIssues.length > 0) {
      visualIssues.forEach(i => log('  [WARN] ' + i));
      log('  [INFO] D7 初始页启发式发现 ' + visualIssues.length + ' 项（最终定级待逐页表格检查收口）');
    } else {
      log('  [INFO] D7 初始页启发式通过（0 项，最终定级待逐页表格检查收口）');
    }

    // v5.23 增强1：初始页表格完整性检测（当前可见页；D10 循环按 pageId 去重防重复计页，
    //   单页 demo 无 data-page-id 时 D10 循环不执行，由此获得表格覆盖）
    {
      const initTableReport = await page.evaluate(tableIntegrityProbe);
      if (initTableReport.pageId && !d7CheckedPageIds.has(initTableReport.pageId)) {
        d7CheckedPageIds.add(initTableReport.pageId);
        initTableReport.fails.forEach(f => d7TableFails.push(initTableReport.pageId + ' ' + f));
        initTableReport.warns.forEach(w => d7TableWarns.push(initTableReport.pageId + ' ' + w));
        log('  [INFO] D7 初始页表格完整性（' + initTableReport.pageId + '）：' +
          initTableReport.fails.length + ' FAIL / ' + initTableReport.warns.length + ' WARN');
      }
    }

    // 强制截图（强制交付物）
    const d7Screenshot = path.join(screenshotDir, `d7-visual-${Date.now()}.png`);
    await page.screenshot({ path: d7Screenshot, fullPage: true });
    log('  [INFO] D7 截图: ' + d7Screenshot);
  } else {
    markDimSkipped(['D7_visual_heuristics']);
  }

  // ===== D8: 运行时 L3 元件交互验证（v5.14 新增 — 消除 S-11 静态 HTML 定向修补）=====
  // 审计 §2.2 来源 A L1581：AI 在 tbody 中预先放一行静态 HTML 含 data-element-id
  //                       （DOMContentLoaded 时会被 renderRows 替换，运行时仍有动态锚点）
  // 修正：用 Playwright 在每个页面读取 DOM，对每个 data-element-id 元素验证：
  //   (a) 元素在运行时 DOM 中实际存在（不只是 HTML 文本）
  //   (b) 元素有交互行为：触发 click 检测响应（DOM 变化 / hash 变化 / 弹窗 / toast / focus 变化）
  //   (c) 或元素是 button/a/input 等天然可交互标签
  //   (d) 或元素有 tabindex 属性（开发者有意使其可交互）
  if (shouldRunDim('D8')) { // v5.18 P1：--dimensions 未含 D8 时整块跳过（自遍历 d8PageLinks，无前序状态依赖）
  log('\n--- D8: 运行时 L3 元件交互验证（v5.14：消除静态 HTML 定向修补）---');

  // 收集每个页面的 data-element-id 元素运行时状态
  // 限上限 8 个元件/页（避免过度消耗），最多遍历 3 个页面
  const d8PageLinks = navLinks.slice(0, 3);
  if (d8PageLinks.length === 0 && navLinks.length === 0) {
    // 单页 demo：直接在当前页验证
    d8PageLinks.push({ href: '' });
  }
  let d8TotalElements = 0;
  let d8InteractiveElements = 0;
  let d8StaticElements = 0;
  let d8MissingElements = 0;  // 标注数据中有 L3 id 但 DOM 中找不到
  const d8StaticDetails = [];

  for (const link of d8PageLinks) {
    if (link.href) {
      await page.evaluate((href) => {
        const el = document.querySelector(`a[href="${href}"]`);
        if (el) el.click();
      }, link.href);
      await page.waitForTimeout(500);
    }
    const pageId = link.href || 'home';
    log('  [INFO] 验证页面: ' + pageId);

    // 收集当前页面的 data-element-id 元件 + 启发式交互检测
    // v5.2.7：多页面 SPA 适配 — 仅收集当前可见页的元件，跳过 hidden 页面的隐藏元件
    //         原因：单轨制 hidden 切换下，其他页面的元件 offsetWidth=0，不应计入交互率分母
    const elementReport = await page.evaluate(() => {
      const els = Array.from(document.querySelectorAll('[data-element-id]'));
      const result = [];
      for (const el of els) {
        const r = el.getBoundingClientRect();
        const s = window.getComputedStyle(el);
        const visible = r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
        // v5.2.7：跳过不可见元件（多页面 SPA 中隐藏页面的元件不计入统计）
        if (!visible) continue;
        const id = el.getAttribute('data-element-id');

        // 启发式 1：天然可交互标签
        const isNativeInteractive = ['BUTTON', 'A', 'INPUT', 'SELECT', 'TEXTAREA'].includes(el.tagName) ||
                                     el.isContentEditable;
        // 启发式 2：tabindex 属性
        const hasTabindex = el.hasAttribute('tabindex') && parseInt(el.getAttribute('tabindex'), 10) >= 0;
        // 启发式 3：onclick 属性
        const hasOnclick = el.hasAttribute('onclick');
        // 启发式 4：data-action / data-open-modal 等行为属性
        const hasDataAction = el.hasAttribute('data-action') || el.hasAttribute('data-open-modal') ||
                              el.hasAttribute('data-toggle') || el.hasAttribute('data-target');
        // 启发式 5：cursor:pointer
        const cursorPointer = s.cursor === 'pointer';
        // v5.2.7 启发式 6：内部包含可交互元件（如 span 包装 button/input/select）
        // 标注体系允许 data-element-id 放在包装器上，包装器内有可交互子元件即视为可交互
        const hasInteractiveChild = !!el.querySelector('button, a, input, select, textarea, [tabindex]');

        const staticFlags = {
          isNativeInteractive, hasTabindex, hasOnclick, hasDataAction, cursorPointer, visible,
          hasInteractiveChild,
        };
        // 元件"具备交互意图"的判断（满足任一即视为可交互）
        const hasInteractionIntent = isNativeInteractive || hasTabindex || hasOnclick ||
                                     hasDataAction || cursorPointer || hasInteractiveChild;

        result.push({
          id,
          tagName: el.tagName,
          visible,
          hasInteractionIntent,
          staticFlags,
          // 父元素是否可交互（如 span 套在 button 内）
          parentInteractive: el.parentElement ? (
            ['BUTTON', 'A', 'INPUT'].includes(el.parentElement.tagName) ||
            el.parentElement.hasAttribute('onclick') ||
            el.parentElement.hasAttribute('data-action')
          ) : false,
        });
      }
      return result;
    });

    // 对未显示交互意图的元件，进一步用触发 click + MutationObserver 验证
    // v5.17 Tier B3：D8 click 测试批量化（对齐 D6/D10 单页批量 evaluate 模式）
    //   原实现：N 次独立 evaluate（每次 IPC 往返 + 400ms setTimeout）= 最多 8 次/页
    //   新实现：每页 1 次 batched evaluate，click + setTimeout + 状态对比 全在浏览器内
    //   收益：3 页 × 最多 8 元件 = 24 次 → 3 次 evaluate
    //   不变：检测条件（mutated/domNodes/hash/modal/toast/focused）、400ms 等待、8 元件/页上限
    //   保留：visible/hasInteractionIntent/parentInteractive 预判（避免不必要的 click 测试）
    const clickTestTargets = [];
    for (const elem of elementReport.slice(0, 8)) {
      d8TotalElements++;
      if (!elem.visible) {
        // 不可见元件跳过交互验证（仍计为静态）
        d8StaticElements++;
        d8StaticDetails.push(`${pageId}/${elem.id} [不可见]`);
        continue;
      }
      if (elem.hasInteractionIntent || elem.parentInteractive) {
        d8InteractiveElements++;
        continue;
      }
      clickTestTargets.push({ id: elem.id, tagName: elem.tagName });
    }

    // 批量 click + MutationObserver 检测响应（防止遗漏无属性但已绑定事件的情况）
    if (clickTestTargets.length > 0) {
      let clickResults;
      try {
        // v5.17.1 修复：Playwright page.evaluate 仅接受单参数，多参数封装为对象（对齐 D3 L1098 模式）
        clickResults = await page.evaluate(async ({ targets, settleMs }) => {
          const results = [];
          for (const t of targets) {
            try {
              const el = document.querySelector(`[data-element-id="${t.id}"]`);
              if (!el) { results.push({ id: t.id, found: false, responded: false }); continue; }

              const beforeState = {
                domNodes: document.querySelectorAll('*').length,
                hash: location.hash,
                modalVisible: !!document.querySelector('.modal:not([hidden]), #modalMask:not([hidden]), [role="dialog"]:not([hidden]), .modal-overlay:not([hidden]), .pg-modal-mask:not([hidden]), .modal-wrap:not([hidden]), .modal-container:not([hidden])'),
                toastVisible: !!document.querySelector('.toast:not([hidden]), .toast.is-visible'),
                focused: document.activeElement,
              };

              let mutated = false;
              const observer = new MutationObserver(() => { mutated = true; });
              observer.observe(document.body, { childList: true, subtree: true, attributes: true });

              try {
                el.click();
                await new Promise(r => setTimeout(r, settleMs));
              } finally {
                observer.disconnect();
              }

              const afterState = {
                domNodes: document.querySelectorAll('*').length,
                hash: location.hash,
                modalVisible: !!document.querySelector('.modal:not([hidden]), #modalMask:not([hidden]), [role="dialog"]:not([hidden]), .modal-overlay:not([hidden]), .pg-modal-mask:not([hidden]), .modal-wrap:not([hidden]), .modal-container:not([hidden])'),
                toastVisible: !!document.querySelector('.toast:not([hidden]), .toast.is-visible'),
                focused: document.activeElement,
              };
              const responded = mutated ||
                beforeState.domNodes !== afterState.domNodes ||
                beforeState.hash !== afterState.hash ||
                beforeState.modalVisible !== afterState.modalVisible ||
                beforeState.toastVisible !== afterState.toastVisible ||
                beforeState.focused !== afterState.focused;
              results.push({ id: t.id, found: true, responded });
            } catch (e) {
              // 每元件异常隔离：记录为未响应，不中断后续元件（对齐原单次 evaluate 行为）
              results.push({ id: t.id, found: false, responded: false, reason: 'exception: ' + e.message });
            }
          }
          return results;
        // v5.17.2：D8 settle 400ms→200ms（D8 元件为同步交互，200ms 足够；与 D6 BUTTON_RESPONSE 对齐）
        }, { targets: clickTestTargets, settleMs: 200 });
      } catch (e) {
        // 批量 evaluate 整体失败（页面导航/浏览器崩溃等灾难性场景）
        log('  [WARN] D8 批量 click 测试失败: ' + e.message);
        clickResults = clickTestTargets.map(t => ({ id: t.id, found: false, responded: false, reason: 'batch evaluate failed' }));
      }

      // 按原格式处理结果（found+responded → 可交互，否则 → 静态）
      for (let i = 0; i < clickTestTargets.length; i++) {
        const target = clickTestTargets[i];
        const result = clickResults[i];
        if (!result) continue;
        if (result.found && result.responded) {
          d8InteractiveElements++;
        } else {
          d8StaticElements++;
          d8StaticDetails.push(`${pageId}/${target.id} [${target.tagName} 静态]`);
        }
      }
    }
  }

  // D8 评级
  if (d8TotalElements === 0) {
    log('  [WARN] D8: 未检测到任何 data-element-id 元件，跳过');
    warn++;
    results.dimensions.D8_l3_interactive = 'warn: no data-element-id found';
  } else {
    const interactiveRatio = d8InteractiveElements / d8TotalElements;
    log('  [INFO] D8: 共检查 ' + d8TotalElements + ' 个 L3 元件，可交互 ' + d8InteractiveElements + ' 个，静态 ' + d8StaticElements + ' 个');
    if (d8StaticElements > 0) {
      log('  [INFO] 静态元件明细: ' + d8StaticDetails.slice(0, 5).join(', ') + (d8StaticDetails.length > 5 ? ' ...' : ''));
    }
    if (interactiveRatio >= 0.8) {
      log('  [OK] D8: L3 元件交互率 ' + (interactiveRatio * 100).toFixed(0) + '% (' + d8InteractiveElements + '/' + d8TotalElements + ')');
      pass++;
      results.dimensions.D8_l3_interactive = 'pass: ' + d8InteractiveElements + '/' + d8TotalElements;
    } else if (interactiveRatio >= 0.5) {
      log('  [WARN] D8: L3 元件交互率 ' + (interactiveRatio * 100).toFixed(0) + '% — 部分元件无交互行为');
      warn++;
      results.dimensions.D8_l3_interactive = 'warn: ' + d8InteractiveElements + '/' + d8TotalElements;
    } else {
      log('  [FAIL] D8: L3 元件交互率 ' + (interactiveRatio * 100).toFixed(0) + '% — 大部分元件为静态 HTML（疑似定向修补）');
      fail++;
      results.dimensions.D8_l3_interactive = 'fail: ' + d8InteractiveElements + '/' + d8TotalElements + ' interactive';
      await screenshot('D8-l3-static');
    }
  }

  // v5.14.17 批次5 R-6（P2）— D8 L3 数据冗余检测（三元组判重）
  //   根因：AI 生成 demo 时可能复制粘贴产生 (element, function, response) 完全相同的 L3 卡片
  //   实现：从 __ANNOTATION_DATA__ 读取所有 L3 卡片，按 (element, function, response) 三元组分组
  //         同组 >1 个 → 输出 warn（不自动去重，agent 人工确认是否为合法重复如表格多行同功能按钮）
  //   判重键：(element, function, response) 三元组完全相同
  //   不一刀切去重的理由：合法的多卡片场景（如表格多行同功能按钮）可能被误判，需 agent 人工确认
  // v5.14.18 修复 3：包装结构兼容（{version, pages: {P01:...}} vs 扁平 {P01:...}）
  // v5.14.18 修复 7：新增同页内 id 重复检测（收窄为同页，跨页 id 复用是引擎设计支持）
  {
    const d8DupReport = await page.evaluate(() => {
      const data = window.__ANNOTATION_DATA__;
      if (!data || typeof data !== 'object') return { hasData: false, duplicates: [], samePageIdDups: [] };
      // v5.14.18 修复 3：包装结构兼容（对齐引擎 annotation-engine.js L102-103 的解包逻辑）
      const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
        ? data.pages
        : data;
      const metaKeys = ['version', 'metadata', 'config', 'pages'];
      const pages = {};
      for (const pageId of Object.keys(rawData)) {
        if (metaKeys.includes(pageId)) continue;
        const pageObj = rawData[pageId];
        if (pageObj && typeof pageObj === 'object' && Array.isArray(pageObj.L3)) {
          pages[pageId] = pageObj;
        }
      }
      const tripleMap = new Map();  // key = "element|function|response" → [cardId, ...]
      for (const pageKey of Object.keys(pages)) {
        const pageObj = pages[pageKey];
        for (const card of pageObj.L3) {
          const element = (card.element || '').trim();
          const func = (card.function || '').trim();
          const response = (card.response || '').trim();
          // 跳过空三元组（无 element 的卡片不参与判重）
          if (!element && !func && !response) continue;
          const key = `${element}|${func}|${response}`;
          if (!tripleMap.has(key)) tripleMap.set(key, []);
          tripleMap.get(key).push(card.id || `${pageKey}-?`);
        }
      }
      const duplicates = [];
      for (const [key, ids] of tripleMap) {
        if (ids.length > 1) {
          const [element, func, response] = key.split('|');
          duplicates.push({ element, function: func, response, ids });
        }
      }
      // v5.14.18 修复 7：同页内 id 重复检测（收窄为同页）
      const samePageIdDups = [];
      for (const pageKey of Object.keys(pages)) {
        const l3 = pages[pageKey].L3;
        const seenInPage = {};
        for (const card of l3) {
          if (!card.id) continue; // 无 id 不参与 id 判重（避免 undefined 误判）
          // v5.14.18 修复 P-3：累加计数（原 seenInPage[card.id] + 1 在 ≥3 次时仍报 2）
          seenInPage[card.id] = (seenInPage[card.id] || 0) + 1;
          if (seenInPage[card.id] > 1) {
            samePageIdDups.push({ pageKey, id: card.id, count: seenInPage[card.id] });
          }
        }
      }
      return { hasData: true, duplicates, samePageIdDups };
    });

    if (d8DupReport.hasData && d8DupReport.duplicates.length > 0) {
      const totalDupCards = d8DupReport.duplicates.reduce((sum, d) => sum + d.ids.length, 0);
      log(`  [WARN] D8: 检测到 L3 数据冗余（${d8DupReport.duplicates.length} 组三元组重复，共 ${totalDupCards} 张卡片）`);
      log('         判重键 = (element, function, response) 三元组完全相同');
      log('         请 agent 人工确认是否为合法重复（如表格多行同功能按钮）');
      d8DupReport.duplicates.slice(0, 5).forEach(d => {
        log(`         - 卡片 ${d.ids.join(', ')} (element='${d.element}', function='${d.function}', response='${d.response}')`);
      });
      if (d8DupReport.duplicates.length > 5) {
        log(`         ... 还有 ${d8DupReport.duplicates.length - 5} 组重复`);
      }
      // R-6 warn 不影响 D8 主评级（D8_l3_interactive 已定级），仅作为附加告警
      // warn++ 累加到全局 warn 计数，影响 overall 评级（A→B）
      warn++;
      results.dimensions.D8_l3_duplication = `warn: ${d8DupReport.duplicates.length} groups, ${totalDupCards} cards`;
    } else if (d8DupReport.hasData && d8DupReport.duplicates.length === 0) {
      // v5.14.18 修复 P-2：else-if 改为仅判 duplicates.length === 0（原条件含 samePageIdDups.length === 0
      //   导致 Case B 走错误兜底 + 误导性 INFO + pass-- 无对应 pass++）
      // 现在 Case B（三元组 0 重复 + 同页 id 重复）走此分支：三元组判重通过 → 后续 id 块正确回退 pass--
      log('  [OK] D8: L3 数据三元组判重通过（无冗余卡片）');
      pass++;
      results.dimensions.D8_l3_duplication = 'pass: no duplication';
    } else if (!d8DupReport.hasData) {
      log('  [INFO] D8: __ANNOTATION_DATA__ 不存在或无 L3 数据，跳过三元组判重');
      // 不计入 pass/fail/warn，仅 INFO
    }

    // v5.14.18 修复 7：同页内 id 重复告警（独立于三元组判重）
    if (d8DupReport.hasData && d8DupReport.samePageIdDups.length > 0) {
      const totalIdDups = d8DupReport.samePageIdDups.length;
      log(`  [WARN] D8: 检测到 L3 卡片同页内 id 重复（${totalIdDups} 个 id 在同页内重复）`);
      log('         同页内 id 重复会导致 querySelector 只命中第一张卡片，与 P-A2(不闪烁)/P-A3(重复展示) 联动');
      d8DupReport.samePageIdDups.slice(0, 5).forEach(d => {
        log(`         - 页面 ${d.pageKey} id [${d.id}] 出现 ${d.count} 次`);
      });
      warn++;
      // v5.14.18 修复 P-2 + R-1：三场景分支正确处理 pass 回退和 dimension 字段
      // Case B（三元组 0 重复 + id 重复）：dimension='pass...' → 改 warn + pass--
      // Case C（三元组重复 + id 重复）：dimension='warn: X groups...' → 追加 id 信息（R-1）
      // Case D（无三元组数据 + id 重复）：dimension=undefined → 设 warn
      if (results.dimensions.D8_l3_duplication && results.dimensions.D8_l3_duplication.startsWith('pass')) {
        // Case B：三元组判重 pass → 回退 pass，改 warn
        results.dimensions.D8_l3_duplication = `warn: same-page id dup (${totalIdDups} ids)`;
        pass--;
      } else if (results.dimensions.D8_l3_duplication && results.dimensions.D8_l3_duplication.startsWith('warn')) {
        // Case C：三元组已有 warn → 追加 id 重复信息（R-1）
        results.dimensions.D8_l3_duplication += ` + same-page id dup (${totalIdDups} ids)`;
      } else if (!results.dimensions.D8_l3_duplication) {
        // Case D：dimension 未设置 → 设 warn
        results.dimensions.D8_l3_duplication = `warn: same-page id dup (${totalIdDups} ids)`;
      }
    }

    // v5.23 增强2-A：D8 序号型重复检测（三元组精确判重的补盲）
    //   背景：仅按 (element,function,response) 三元组精确判重会漏检序号型重复——
    //         "待办任务行1/行2/行3" 仅 element 尾部序号不同、语义字段相同，属复制粘贴式冗余
    //   实现：归一化 function/trigger/response（常见 ID 模式 [A-Z]{1,3}-?\d+ → #ID#，
    //         其余纯数字 → #N#），归一化后语义相同 + 组内 element 去尾部数字后相同 +
    //         组内数量 > 1 → 序号型重复组（按页分组；纯精确重复已由上方三元组判重
    //         覆盖，distinct element 数 =1 的组跳过，避免双重计数）
    {
      const d8SeqReport = await page.evaluate(() => {
        const data = window.__ANNOTATION_DATA__;
        if (!data || typeof data !== 'object') return { hasData: false, groups: [] };
        // v5.14.18 修复 3 同款解包：兼容 {version, pages} 包装与扁平两种结构
        const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
          ? data.pages
          : data;
        const metaKeys = ['version', 'metadata', 'config', 'pages'];
        const norm = (s) => String(s || '')
          .replace(/[A-Z]{1,3}-?\d+/g, '#ID#')  // 常见 ID 模式（CASE-1001 / AB12）
          .replace(/\d+/g, '#N#')               // 其余纯数字（行号/序号）
          .trim();
        const stripTrailingNum = (s) => String(s || '').trim().replace(/[\d\s]+$/, '').trim();
        const seqMap = new Map();  // key = pageId|norm(func)|norm(response)|strippedElement → 卡片列表
        for (const pageId of Object.keys(rawData)) {
          if (metaKeys.includes(pageId)) continue;
          const pageObj = rawData[pageId];
          if (!pageObj || typeof pageObj !== 'object' || !Array.isArray(pageObj.L3)) continue;
          for (const card of pageObj.L3) {
            const element = (card.element || '').trim();
            const func = (card.function || card.trigger || '').trim();
            const response = (card.response || '').trim();
            if (!element && !func && !response) continue;
            const key = pageId + '|' + norm(func) + '|' + norm(response) + '|' + stripTrailingNum(element);
            if (!seqMap.has(key)) seqMap.set(key, []);
            seqMap.get(key).push({ pageId, element, id: card.id || '?' });
          }
        }
        const groups = [];
        for (const cards of seqMap.values()) {
          if (cards.length < 2) continue;
          const distinctElements = new Set(cards.map((c) => c.element));
          if (distinctElements.size < 2) continue; // 纯精确重复，已由三元组判重覆盖
          groups.push({
            pageId: cards[0].pageId,
            baseName: stripTrailingNum(cards[0].element),
            count: cards.length,
            ids: cards.map((c) => c.id),
          });
        }
        return { hasData: true, groups };
      });

      if (d8SeqReport.hasData && d8SeqReport.groups.length > 0) {
        const totalSeqCards = d8SeqReport.groups.reduce((sum, g) => sum + g.ids.length, 0);
        d8SeqReport.groups.forEach((g) => {
          log('  [WARN] D8: ' + g.pageId + ' 存在同类重复标注（' + (g.baseName || '(空)') + '×' + g.count + '，建议同类元件仅标注首个）');
        });
        log('         序号型重复 = 归一化语义相同 + element 仅尾部序号差异（' +
          d8SeqReport.groups.length + ' 组 / ' + totalSeqCards + ' 张卡片）');
        // 每页每组记 1 次 warn（组已按页分组，warn 数 = 组数）
        warn += d8SeqReport.groups.length;
        results.dimensions.D8_l3_sequence_dup = 'warn: ' + d8SeqReport.groups.length + ' 组序号型重复 - ' +
          d8SeqReport.groups.slice(0, 3).map((g) => g.pageId + ' ' + (g.baseName || '(空)') + 'x' + g.count).join(' | ');
      } else if (d8SeqReport.hasData) {
        log('  [OK] D8: 序号型重复检测通过（无同类冗余标注）');
        pass++;
        results.dimensions.D8_l3_sequence_dup = 'pass: no sequence duplication';
      } else {
        log('  [INFO] D8: __ANNOTATION_DATA__ 不存在或无 L3 数据，跳过序号型重复检测');
      }
    }
  }
  } else {
    markDimSkipped(['D8_l3_interactive', 'D8_l3_duplication', 'D8_l3_sequence_dup', 'D8_element_coverage']);
  }

  // ===== D9: 标注面板交互链路验证（v5.14 新增 — 修复 D4 仅检查 transform 未验证面板显隐的缺陷）=====
  // 背景：A/B 跑发现 D4 仅点击 .l2-marker 采样 transform，未验证：
  //   1. 点击 .l2-marker 后标注面板是否真正显示（panel.style.display === 'flex'）
  //   2. contentRoot 是否设置 [data-annotation-active] 属性（CSS 激活态依赖）
  //   3. 标注开关 [data-annotation-toggle] 点击能否切换面板显隐
  //   4. 关闭按钮 [data-annotation-close] 能否关闭面板
  //   5. 面板激活后左侧页面内容是否被异常遮挡（padding-right 是否生效或内容被覆盖）
  // v5.14 修正：标注面板封装在 Shadow DOM 中（#demora-annotation-host），必须使用
  //   host.shadowRoot.querySelector 穿透 Shadow DOM，与 D0.2 实现对齐
  if (shouldRunDim('D9')) { // v5.18 P1：--dimensions 未含 D9 时整块跳过（D9.1 自重置面板状态，无前序状态依赖）
  log('\n--- D9: 标注面板交互链路验证（v5.14 新增 — 面板显隐 + 页面协同）---');

  // v5.17 Tier B4：D9 子测试合并（对齐 D6/D8/D3 单页批量 evaluate 模式）
  //   原实现：D9.1-D9.5 每子测试 2-3 次 evaluate（click / waitForFunction / state check 分离）= ~10 次
  //   新实现：D9.1+D9.2 合并为 1 次，D9.3/D9.4/D9.5 各 1 次 = 4 次
  //   不变：检测语义（面板显隐 / L2-L3 协同激活 / 关闭闭环）、pass/fail/warn 累积、
  //         screenshot 时机（每子测试后 + 失败时附加）、waitForFunction 谓词、waitForTimeout 时长
  //   注意：screenshot 在 evaluate 返回后拍摄（页面状态为该子测试的动作后状态，与原逻辑一致）

  // D9.1 + D9.2 合并：重置（若已激活先关闭）+ 点击开关激活 + 等待 500ms + 状态检查
  const d9ToggleResult = await page.evaluate(async () => {
    const toggle = document.querySelector('[data-annotation-toggle]');
    if (!toggle) return { error: 'no [data-annotation-toggle] found' };
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    // 穿透 Shadow DOM 获取面板（与 D0.2 对齐）
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const panel = sr ? sr.querySelector('.annotation-panel') : null;

    // D9.1: 若已激活，先关闭（对齐原 waitForTimeout(300) 等待关闭动画）
    if (contentRoot.hasAttribute('data-annotation-active') && toggle) {
      toggle.click();
      await new Promise(r => setTimeout(r, 300));
    }

    // D9.2: 点击开关激活
    const beforeActive = contentRoot.hasAttribute('data-annotation-active');
    const beforeDisplay = panel ? window.getComputedStyle(panel).display : 'no-panel';
    toggle.click();
    await new Promise(r => setTimeout(r, 500));  // 对齐原 waitForTimeout(500)

    // 检查激活后状态
    return {
      beforeActive, beforeDisplay, clicked: true,
      activeAttr: contentRoot.hasAttribute('data-annotation-active'),
      panelDisplay: panel ? window.getComputedStyle(panel).display : 'no-panel',
      panelVisible: panel ? (panel.offsetWidth > 0 && panel.offsetHeight > 0) : false,
    };
  });

  if (d9ToggleResult.error) {
    log('  [WARN] D9.2: ' + d9ToggleResult.error);
    warn++;
    results.dimensions.D9_panel_interaction = 'warn: ' + d9ToggleResult.error;
  } else {
    if (d9ToggleResult.activeAttr && d9ToggleResult.panelDisplay !== 'none' && d9ToggleResult.panelVisible) {
      log('  [OK] D9.2: 标注开关点击后面板显示正常（display=' + d9ToggleResult.panelDisplay + ', activeAttr=true）');
      pass++;
      results.dimensions.D9_toggle_show = 'pass: panel shown after toggle';
    } else {
      log('  [FAIL] D9.2: 标注开关点击后面板未显示（activeAttr=' + d9ToggleResult.activeAttr + ', display=' + d9ToggleResult.panelDisplay + ', visible=' + d9ToggleResult.panelVisible + '）');
      fail++;
      results.dimensions.D9_toggle_show = 'fail: toggle click does not show panel';
      await screenshot('D9-toggle-failed');
    }
  }
  await screenshot('D9-panel-toggle-active');

  // D9.3: 点击 L2 marker，验证面板内容切换 + 左侧页面协同激活 + 未被遮挡
  // v5.14 修正：原 D9.3 仅检查 panelHasContent + paddingRight，遗漏"左侧页面协同激活"。
  //   用户反馈："L2、L3 标注，标准面板激活，但左侧页面并没激活" — 即面板显示了卡片内容，
  //   但左侧页面对应的 .anno-zone 没有 is-highlighted class，或 .anno-card 没有 is-active class。
  //   修复：新增 zoneHighlighted + panelCardActive 双向协同检查，覆盖完整交互链路。
  // v5.17 Tier B4：click + waitForFunction + state check 合并为单 evaluate
  // v5.18 P0-A2：targetZoneHighlighted 身份校验逻辑已同步到 probes.clickFirstMarkerAndObserve
  //   （lib/audit-probes.mjs），diagnose-runtime 通过 import probes 共用同一判定逻辑。
  //   本 evaluate 额外检查 overlap/paddingRight（run-audit 专属，probes 简化版未含），
  //   核心 pass 条件（targetZoneHighlighted && activeCardCount && highlightedZoneCount）与 probes 一致。
  const d9L2Result = await page.evaluate(async () => {
    const markers = document.querySelectorAll('.l2-marker');
    if (markers.length === 0) return { error: 'no .l2-marker found' };
    // v5.14.8：点击第一个"可见的" L2 marker（与 D9.4 L3 dot 逻辑对齐）
    // 原缺陷：盲目点击 markers[1]，不检查可见性。若 markers[1] 在隐藏页面，
    //   findVisibleElement 找不到对应 zone → is-highlighted 不生效 → D9.3 必然 FAIL。
    //   AI 被迫在 demo 中加捕获阶段监听器定向 hack（反向工程审计逻辑）。
    // 修复：遍历 markers 找第一个 getBoundingClientRect 可见的 marker 点击。
    let target = null;
    for (const m of markers) {
      const r = m.getBoundingClientRect();
      const s = window.getComputedStyle(m);
      if (r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden') {
        target = m; break;
      }
    }
    if (!target) return { error: 'no visible .l2-marker' };
    // 记录点击前状态，便于协同验证
    const zoneId = target.closest('[data-zone-id]')
      ? target.closest('[data-zone-id]').getAttribute('data-zone-id')
      : null;
    target.click();

    // 等待面板 .anno-card 出现（对齐原 waitForFunction 2000ms 超时 + 300ms fallback）
    const cardHost = document.getElementById('demora-annotation-host');
    const cardSr = cardHost ? cardHost.shadowRoot : null;
    const start = Date.now();
    let cardFound = false;
    while (Date.now() - start < 2000) {
      if (cardSr && cardSr.querySelector('.anno-card')) { cardFound = true; break; }
      await new Promise(r => setTimeout(r, 50));
    }
    if (!cardFound) {
      await new Promise(r => setTimeout(r, 300));  // fallback 对齐原 .catch(() => waitForTimeout(300))
    }

    // 验证面板内容已更新 + 左侧页面协同激活 + 内容可见性
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const panel = sr ? sr.querySelector('.annotation-panel') : null;
    const panelBody = panel ? panel.querySelector('.panel-body') : null;
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    // 检查左侧页面是否有内容被面板遮挡
    const cs = window.getComputedStyle(contentRoot);
    const paddingRight = parseInt(cs.paddingRight || '0', 10);
    const visibleInteractive = Array.from(document.querySelectorAll('button, a[href], input, select, [role="button"]'))
      .filter(el => {
        if (el.closest('.annotation-panel')) return false; // 排除面板内元素
        if (el.id === 'demora-annotation-host') return false; // 排除标注宿主
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && r.top >= 0 && r.top < window.innerHeight;
      })[0];
    const interactiveRect = visibleInteractive ? visibleInteractive.getBoundingClientRect() : null;
    const panelRect = panel ? panel.getBoundingClientRect() : null;
    const overlapDetected = interactiveRect && panelRect
      ? (interactiveRect.right > panelRect.left && interactiveRect.left < panelRect.right)
      : false;

    // v5.14 新增：左侧页面协同激活检查
    const highlightedZones = document.querySelectorAll('.anno-zone.is-highlighted');
    const activeL2Cards = panelBody ? panelBody.querySelectorAll('.anno-card.is-active') : null;
    const l2TabBtn = panel ? panel.querySelector('[data-tab="L2"].active') : null;
    // v5.14.18 修复 5：限定查询到可见页面，避免跨页 id 复用时 querySelector 命中隐藏页面的 zone
    let targetZoneHighlighted = false;
    if (zoneId) {
      const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
      const scope = visiblePage || document;
      const zoneEl = scope.querySelector('[data-zone-id="' + zoneId + '"]');
      targetZoneHighlighted = zoneEl ? zoneEl.classList.contains('is-highlighted') : false;
    }
    return {
      clicked: true, targetZoneId: zoneId,
      panelHasContent: panelBody ? panelBody.children.length > 0 : false,
      paddingRight,
      pageInteractiveExists: !!visibleInteractive,
      overlapDetected,
      highlightedZoneCount: highlightedZones.length,
      activeCardCount: activeL2Cards ? activeL2Cards.length : 0,
      l2TabActive: !!l2TabBtn,
      targetZoneHighlighted,
    };
  });

  if (d9L2Result.error) {
    log('  [WARN] D9.3: ' + d9L2Result.error);
    warn++;
  } else {
    // v5.14 修正判定逻辑：优先判定页面协同激活缺失（用户报告的核心问题）
    if (d9L2Result.overlapDetected) {
      log('  [FAIL] D9.3: 面板激活后左侧页面交互元素被遮挡（paddingRight=' + d9L2Result.paddingRight + 'px，存在重叠）');
      fail++;
      results.dimensions.D9_l2_coop = 'fail: page content overlapped by panel';
      await screenshot('D9-overlap-detected');
    } else if (!d9L2Result.highlightedZoneCount || !d9L2Result.activeCardCount || !d9L2Result.targetZoneHighlighted) {
      // v5.14.18 修复 5：增加 targetZoneHighlighted 身份校验
      log('  [FAIL] D9.3: L2 点击后面板与左侧页面协同缺失（highlightedZones=' + d9L2Result.highlightedZoneCount + ', activeCards=' + d9L2Result.activeCardCount + ', targetZoneHighlighted=' + d9L2Result.targetZoneHighlighted + '）— 标注面板激活但左侧页面未激活或身份不匹配');
      fail++;
      results.dimensions.D9_l2_coop = 'fail: panel active but page not highlighted (L2)';
      await screenshot('D9-L2-no-coop');
    } else if (d9L2Result.panelHasContent && d9L2Result.paddingRight > 0) {
      log('  [OK] D9.3: L2 marker 点击后协同正常（zone高亮=' + d9L2Result.highlightedZoneCount + ', 卡片激活=' + d9L2Result.activeCardCount + ', padding-right=' + d9L2Result.paddingRight + 'px）');
      pass++;
      results.dimensions.D9_l2_coop = 'pass: L2 coop ok (zones=' + d9L2Result.highlightedZoneCount + ', cards=' + d9L2Result.activeCardCount + ')';
    } else if (d9L2Result.panelHasContent) {
      log('  [WARN] D9.3: 协同正常但 padding-right=0（可能面板覆盖页面内容）');
      warn++;
      results.dimensions.D9_l2_coop = 'warn: panel content updated but no padding-right';
      await screenshot('D9-no-padding');
    } else {
      log('  [WARN] D9.3: L2 marker 点击后面板内容为空');
      warn++;
      results.dimensions.D9_l2_coop = 'warn: panel body empty after L2 click';
    }
  }
  await screenshot('D9-L2-marker-panel');

  // D9.4: 点击 L3 dot，验证面板切换 L3 tab + 左侧页面协同激活
  // v5.14 新增：用户报告"L3 标注，标准面板激活，但左侧页面并没激活"，原 D9 完全未检查 L3 dot
  // v5.17 Tier B4：click + waitForFunction + state check 合并为单 evaluate
  // v5.18 P0-A2：targetDotActive 身份校验逻辑已同步到 probes.clickFirstDotAndObserve
  //   （lib/audit-probes.mjs 新增），diagnose-runtime 现已对称检测 D9.4（原仅检测 D9.3）。
  //   核心 pass 条件（targetDotActive && activeCardCount && activeDotCount）与 probes 一致。
  const d9L3Result = await page.evaluate(async () => {
    const dots = document.querySelectorAll('.l3-dot');
    if (dots.length === 0) return { error: 'no .l3-dot found' };
    // 点击第一个可见的 L3 dot
    let target = null;
    for (const d of dots) {
      const r = d.getBoundingClientRect();
      // v5.14.18 修复 5：增加 computed style 检查（与 D9.3 L2 marker 视觉可见性检查对齐）
      const s = window.getComputedStyle(d);
      if (r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0') {
        target = d; break;
      }
    }
    if (!target) return { error: 'no visible .l3-dot' };
    // 记录 L3 element id，便于协同验证
    const elemId = target.closest('[data-element-id]')
      ? target.closest('[data-element-id]').getAttribute('data-element-id')
      : null;
    target.click();

    // 等待面板 .anno-card 出现（对齐原 waitForFunction 2000ms 超时 + 300ms fallback）
    const cardHost = document.getElementById('demora-annotation-host');
    const cardSr = cardHost ? cardHost.shadowRoot : null;
    const start = Date.now();
    let cardFound = false;
    while (Date.now() - start < 2000) {
      if (cardSr && cardSr.querySelector('.anno-card')) { cardFound = true; break; }
      await new Promise(r => setTimeout(r, 50));
    }
    if (!cardFound) {
      await new Promise(r => setTimeout(r, 300));
    }

    // 验证面板切换 L3 tab + 左侧页面协同激活
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const panel = sr ? sr.querySelector('.annotation-panel') : null;
    const panelBody = panel ? panel.querySelector('.panel-body') : null;
    const activeDots = document.querySelectorAll('.l3-dot.is-active');
    const activeL3Cards = panelBody ? panelBody.querySelectorAll('.anno-card.is-active') : null;
    const l3TabBtn = panel ? panel.querySelector('[data-tab="L3"].active') : null;
    // v5.14.18 修复 5：限定查询到可见页面，避免跨页 id 复用时 querySelector 命中隐藏页面的 element
    let targetDotActive = false;
    if (elemId) {
      const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
      const scope = visiblePage || document;
      const elemWrap = scope.querySelector('[data-element-id="' + elemId + '"]');
      const dot = elemWrap ? elemWrap.querySelector('.l3-dot') : null;
      targetDotActive = dot ? dot.classList.contains('is-active') : false;
    }
    return {
      clicked: true, targetElementId: elemId,
      activeDotCount: activeDots.length,
      activeCardCount: activeL3Cards ? activeL3Cards.length : 0,
      l3TabActive: !!l3TabBtn,
      targetDotActive,
    };
  });

  if (d9L3Result.error) {
    log('  [WARN] D9.4: ' + d9L3Result.error);
    warn++;
    results.dimensions.D9_l3_coop = 'warn: ' + d9L3Result.error;
  } else {
    if (!d9L3Result.activeDotCount || !d9L3Result.activeCardCount || !d9L3Result.targetDotActive) {
      // v5.14.18 修复 5：增加 targetDotActive 身份校验
      log('  [FAIL] D9.4: L3 dot 点击后面板与左侧页面协同缺失（activeDots=' + d9L3Result.activeDotCount + ', activeCards=' + d9L3Result.activeCardCount + ', targetDotActive=' + d9L3Result.targetDotActive + '）— 标注面板激活但左侧页面未激活或身份不匹配');
      fail++;
      results.dimensions.D9_l3_coop = 'fail: panel active but page not highlighted (L3)';
      await screenshot('D9-L3-no-coop');
    } else {
      log('  [OK] D9.4: L3 dot 点击后协同正常（dot激活=' + d9L3Result.activeDotCount + ', 卡片激活=' + d9L3Result.activeCardCount + ', L3 tab=' + (d9L3Result.l3TabActive ? 'active' : 'inactive') + '）');
      pass++;
      results.dimensions.D9_l3_coop = 'pass: L3 coop ok (dots=' + d9L3Result.activeDotCount + ', cards=' + d9L3Result.activeCardCount + ')';
    }
  }
  await screenshot('D9-L3-dot-panel');

  // D9.5: 点击关闭按钮，验证面板隐藏
  // v5.17 Tier B4：click + waitForTimeout + state check 合并为单 evaluate
  const d9CloseResult = await page.evaluate(async () => {
    // 穿透 Shadow DOM 获取关闭按钮（与 D0.2 对齐）
    const host = document.getElementById('demora-annotation-host');
    const sr = host ? host.shadowRoot : null;
    const closeBtn = sr ? sr.querySelector('[data-annotation-close]') : null;
    if (!closeBtn) return { error: 'no [data-annotation-close] found' };
    closeBtn.click();
    await new Promise(r => setTimeout(r, 400));  // 对齐原 waitForTimeout(400)

    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    const panel = sr ? sr.querySelector('.annotation-panel') : null;
    return {
      activeAttr: contentRoot.hasAttribute('data-annotation-active'),
      panelDisplay: panel ? window.getComputedStyle(panel).display : 'no-panel',
    };
  });

  if (d9CloseResult.error) {
    log('  [WARN] D9.5: ' + d9CloseResult.error);
    warn++;
    results.dimensions.D9_panel_close = 'warn: ' + d9CloseResult.error;
  } else {
    if (!d9CloseResult.activeAttr && d9CloseResult.panelDisplay === 'none') {
      log('  [OK] D9.5: 关闭按钮点击后面板隐藏正常');
      pass++;
      results.dimensions.D9_panel_close = 'pass: panel hidden after close';
    } else {
      log('  [FAIL] D9.5: 关闭按钮点击后面板未隐藏（activeAttr=' + d9CloseResult.activeAttr + ', display=' + d9CloseResult.panelDisplay + '）');
      fail++;
      results.dimensions.D9_panel_close = 'fail: close button does not hide panel';
      await screenshot('D9-close-failed');
    }
  }
  } else {
    markDimSkipped(['D9_toggle_show', 'D9_l2_coop', 'D9_l3_coop', 'D9_panel_close']);
  }

  // ===== D10: 逐页 L2/L3 全量激活验证（v5.14.2 新增）=====
  // 背景：D8 只遍历前 3 页 × 8 个元件，D9 只点击 1 个 L2 + 1 个 L3，无法覆盖全量激活。
  //   用户报告："b 跑打开标注面板，左侧页面无显示 L3 标注，更不用讨论点击 L3 标注进行激活验证了"
  //   用户要求：每个页面均执行 L2 全部标注激活、L3 全部标注激活 + 截图确认，通过才放行。
  // 实现：
  //   1. 遍历所有 detectedPages（通过 [data-nav] 点击 / a[href] 点击 / hidden 切换三重兜底导航）
  //   2. 每页：浏览器内 async for 循环点击所有 .l2-marker，验证 zone is-highlighted + panel card is-active
  //   3. 每页：浏览器内 async for 循环点击所有 .l3-dot，验证 dot is-active + panel card is-active
  //   4. 每页 2 张截图（L2 全量验证后 + L3 全量验证后）
  //   5. 任一标注激活失败 → D10 FAIL（通过才放行）
  // 性能：浏览器内批量验证（150ms/个），8 页 52 标注 ≈ 75s（无性能瓶颈）
  if (shouldRunDim('D10')) { // v5.18 P1：--dimensions 未含 D10 时整块跳过（D10.0 自激活标注模式，无前序状态依赖）
  log('\n--- D10: 逐页 L2/L3 全量激活验证（v5.14.2 新增）---');

  // D10.0：确保标注面板已打开（D9.5 可能已关闭）
  // v5.14.5 强化：点击 toggle 后验证 data-annotation-active 属性已设置
  //   原盲区：只点击 toggle 不验证结果，若标注引擎未正确激活，后续测试全部无效
  //   修复：验证 contentRoot 有 data-annotation-active 属性，否则 FAIL
  let d10TotalL2 = 0, d10PassL2 = 0, d10FailL2 = 0;
  let d10TotalL3 = 0, d10PassL3 = 0, d10FailL3 = 0;
  const d10FailDetails = [];
  let d10ModeActive = true;

  await page.evaluate(() => {
    const toggle = document.querySelector('[data-annotation-toggle]');
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    if (!contentRoot.hasAttribute('data-annotation-active') && toggle) {
      toggle.click();
    }
  });
  await page.waitForFunction(() => {
    const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
    return contentRoot.hasAttribute('data-annotation-active');
  }, { timeout: 2000 }).catch(() => page.waitForTimeout(300));
  {
    const activeOk = await page.evaluate(() => {
      const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
      return contentRoot.hasAttribute('data-annotation-active');
    });
    if (!activeOk) {
      log('  [FAIL] D10.0: 标注模式激活失败（data-annotation-active 属性未设置）');
      log('         标注引擎可能未正确初始化，或 toggle 按钮无响应');
      fail++;
      results.dimensions.D10_full_activation = 'fail: annotation mode not activated (data-annotation-active missing)';
      await screenshot('D10-activation-mode-failed');
      log('  [INFO] D10 跳过后续逐页验证（标注模式未激活）');
      d10ModeActive = false;
    }
  }

  // D10.1：遍历所有 detectedPages
  // v5.14.5：用 d10ModeActive flag 控制是否执行（标注模式未激活时跳过）
  for (let pageIdx = 0; pageIdx < detectedPages.length && d10ModeActive; pageIdx++) {
    const pageId = detectedPages[pageIdx].id;
    log('  [INFO] D10 页面 [' + (pageIdx + 1) + '/' + detectedPages.length + ']: ' + pageId);

    // 导航到目标页面（四重兜底：[data-nav] 点击 → a[href] 点击 → [data-target-page] 点击 → hidden 切换+路由事件）
    // v5.14.3：新增方式3 [data-target-page] 点击 + 方式4 派发 popstate/hashchange 事件
    //   背景：B 跑 D10 首轮因方式3 hidden 切换绕过 route() → injectAnnotationMarkers()，导致 127 个标注未激活
    await page.evaluate((pid) => {
      // 方式1：点击 [data-nav="pageId"] 元素（B 类 SPA 常用）
      const navEl = document.querySelector('[data-nav="' + pid + '"]');
      if (navEl) { navEl.click(); return; }
      // 方式2：点击 a[href*="pageId"] 元素（传统 hash 导航）
      const aEl = document.querySelector('a[href*="' + pid + '"]');
      if (aEl) { aEl.click(); return; }
      // 方式3：点击 [data-target-page="pageId"] 元素（部分 demo 使用此属性）
      const targetPageEl = document.querySelector('[data-target-page="' + pid + '"]');
      if (targetPageEl) { targetPageEl.click(); return; }
      // 方式4：兜底直接切换 hidden + 派发路由事件（触发 demo 的 hashchange/popstate 监听）
      document.querySelectorAll('[data-page-id]').forEach(p => {
        p.hidden = (p.getAttribute('data-page-id') !== pid);
      });
      // 派发 popstate 事件，触发 demo 路由逻辑（如 injectAnnotationMarkers）
      window.dispatchEvent(new PopStateEvent('popstate'));
      // 派发 hashchange 事件（部分 demo 监听 hashchange）
      window.dispatchEvent(new HashChangeEvent('hashchange'));
    }, pageId);
    // M3 修复 + OD-A fallback 统一：谓词改为目标页特定（原谓词恒真，退化为零等待）
    //   原缺陷：谓词 "任一页可见即 true" 在导航前就恒为 true，waitForFunction 立即返回，等待≈0ms
    //   修复：检查目标页 data-page-id 可见，与 D2/D6 谓词语义对齐
    //   fallback 统一为 400ms（原 600ms 与 D2/D6 300ms 不一致，OD-A 校准）
    // v5.17.2：超时 2000ms→1000ms + fallback 400ms→200ms（D2/D6 谓词一致且导航常 <100ms 成功，
    //   1000ms 超时仍充裕；fallback 200ms 对齐 D6 的 300ms 量级，减少无谓等待）
    await page.waitForFunction((pid) => {
      const el = document.querySelector(`[data-page-id="${pid}"]`);
      return el && !el.hidden && el.style.display !== 'none';
      // v5.17.2 修复：waitForFunction 签名为 (fn, arg, options) — 原 (fn, {timeout}, pid) 把 {timeout} 当 arg 传入谓词，
      //   导致 pid="[object Object]" → 谓词恒 false → 默认 30s 超时 → D10 每页白等 30s（6 页=180s 浪费）
    }, pageId, { timeout: 1000 }).catch(() => page.waitForTimeout(200));

    // v5.14.5：导航后验证标注模式仍激活 + 数量一致性校验（v5.17.3 合并为单 evaluate，省 7 次 IPC）
    //   背景：部分 demo 的 app.js 路由逻辑会重置 body 属性，导致标注模式被关闭
    //   修复：导航后检查 data-annotation-active，若丢失则重新激活；同时校验 DOM marker 数量 vs 声明数量
    //   v5.17.3：原为 2 次 evaluate（mode check + count check），合并为 1 次以削减 evaluate 调用数
    {
      const navReport = await page.evaluate((targetPageId) => {
        // 1. 标注模式检查
        const contentRoot = document.querySelector('[data-annotation-root]') || document.body;
        let stillActive = contentRoot.hasAttribute('data-annotation-active');
        if (!stillActive) {
          const toggle = document.querySelector('[data-annotation-toggle]');
          if (toggle) toggle.click();
          stillActive = contentRoot.hasAttribute('data-annotation-active');
        }
        // 2. 数量一致性校验
        const data = window.__ANNOTATION_DATA__;
        if (!data || typeof data !== 'object') return { stillActive, hasData: false };
        const rawData = (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages))
          ? data.pages
          : data;
        const pageObj = rawData[targetPageId] && Array.isArray(rawData[targetPageId].L2) ? rawData[targetPageId] : null;
        if (!pageObj) return { stillActive, hasData: false };
        const declaredL2 = Array.isArray(pageObj.L2) ? pageObj.L2.length : 0;
        const declaredL3 = Array.isArray(pageObj.L3) ? pageObj.L3.length : 0;
        const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
        if (!visiblePage) return { stillActive, hasData: true, declaredL2, declaredL3, domL2: 0, domL3: 0 };
        const domL2 = visiblePage.querySelectorAll('.l2-marker').length;
        const domL3 = visiblePage.querySelectorAll('.l3-dot').length;
        return { stillActive, hasData: true, declaredL2, declaredL3, domL2, domL3 };
      }, pageId);

      if (!navReport.stillActive) {
        log('    [WARN] 标注模式在导航后丢失且无法重新激活，跳过该页');
        await screenshot('D10-page-' + pageId + '-mode-lost');
        continue;
      }

      if (navReport.hasData) {
        if (navReport.declaredL2 !== navReport.domL2) {
          log(`    [WARN] D10: 页面 ${pageId} L2 数量不一致：声明 ${navReport.declaredL2}，DOM ${navReport.domL2}（P-A1 数量对不上信号）`);
        }
        if (navReport.declaredL3 !== navReport.domL3) {
          log(`    [WARN] D10: 页面 ${pageId} L3 数量不一致：声明 ${navReport.declaredL3}，DOM ${navReport.domL3}（P-A1 数量对不上信号）`);
        }
        // v5.17.3 注入等待已移除：200ms settle（下方）已足够让标注引擎完成注入+事件绑定，
        //   waitForFunction 方式虽更精确但增加 evaluate 调用（V2/B5 目标 <100），settled 200ms 零 evaluate 开销
        await page.waitForTimeout(200);
      }
    }

    // v5.17.3 修复：导航后等待标注引擎注入+事件绑定完成
    //   背景：v5.17.2 修复导航超时后，导航 <100ms 完成，但标注引擎 injectAnnotationMarkers() 后
    //         的事件绑定（click handler）可能仍在 rAF/setTimeout 队列中未执行 → marker 点击无响应 → 假失败
    //   修复：无条件等待 200ms 让注入+事件绑定完成（原 30s 破损等待意外提供此时间，7 页 × 200ms = 1.4s 可接受）
    await page.waitForTimeout(200);

    // v5.23 增强1：D7 表格完整性检测（挂载于 D10 逐页导航，复用四重兜底导航后的稳定 DOM；
    //   按 pageId 去重防与 D7 初始页检查重复计页；结果在 D10 循环后统一并入 D7 维度定级）
    if (shouldRunDim('D7')) {
      const tableReport = await page.evaluate(tableIntegrityProbe);
      if (tableReport.pageId && !d7CheckedPageIds.has(tableReport.pageId)) {
        d7CheckedPageIds.add(tableReport.pageId);
        tableReport.fails.forEach(f => d7TableFails.push(tableReport.pageId + ' ' + f));
        tableReport.warns.forEach(w => d7TableWarns.push(tableReport.pageId + ' ' + w));
        log('    [D7] 表格完整性: ' + tableReport.fails.length + ' FAIL / ' + tableReport.warns.length + ' WARN');
      }
    }
    // v5.23 增强2-B：D8 交互元件类型覆盖率采样（与 D7 表格检测同点执行，省一次导航等待）
    if (shouldRunDim('D8')) {
      const covReport = await page.evaluate(coverageProbe);
      if (covReport.pageId && !d8CoverageCheckedPageIds.has(covReport.pageId)) {
        d8CoverageCheckedPageIds.add(covReport.pageId);
        d8CoverageSamples.push(covReport);
      }
    }

    // v5.24 变更5：D10 导航后公共区域断言（导航 settle 后、L2/L3 点击前；与探针同挂载点）
    //   断言：① document.scrollingElement.scrollTop === 0（导航后页面应置顶）；
    //         ② 首个可见 header/nav（header, nav, .topbar, .header 中 rect 高>0 的第一个）
    //            rect.top >= -1（公共区域不应被顶出视口）
    //   违例去向：D7 选中 → d10NavFails 并入 D7 收口族判 FAIL（结果串标注来源）；
    //             D7 未选中 → 降级 [WARN] 输出（log 收集进 WARN_DETAILS 块，不计数不阻塞）
    {
      const navIssues = await page.evaluate(() => {
        const issues = [];
        const docScrollTop = document.scrollingElement ? document.scrollingElement.scrollTop : 0;
        if (docScrollTop !== 0) issues.push({ kind: 'scroll', value: Math.round(docScrollTop) });
        const candidates = document.querySelectorAll('header, nav, .topbar, .header');
        for (const el of candidates) {
          const r = el.getBoundingClientRect();
          if (r.height <= 0) continue;
          if (r.top < -1) issues.push({ kind: 'topbar', value: Math.round(r.top) });
          break; // 仅首个可见 header/nav 参与断言
        }
        return issues;
      });
      for (const item of navIssues) {
        const msg = item.kind === 'scroll'
          ? pageId + ' 导航后页面未置顶（docScrollTop=' + item.value + '）'
          : pageId + ' 导航后公共区域被顶出视口（topbar top=' + item.value + 'px）';
        if (shouldRunDim('D7')) {
          d10NavFails.push(msg);
        } else {
          log('    [WARN] D10 ' + msg + '（D7 未选中，仅记入 WARN_DETAILS 不计数）');
        }
      }
    }

    // v5.24 变更4：筛选往返一致性探针（导航 settle 后、L2/L3 点击前触发；结果循环后统一收口）
    //   仅 D6 选中时执行（D6_filter_consistency 记账族），页去重防重复计页
    if (shouldRunDim('D6')) {
      try {
        const filterReport = await page.evaluate(filterConsistencyProbe);
        if (filterReport.pageId && !d6FilterCheckedPageIds.has(filterReport.pageId)) {
          d6FilterCheckedPageIds.add(filterReport.pageId);
          d6FilterCheckedPages++;
          for (const o of filterReport.outcomes) {
            d6FilterResults.push({ pageId: filterReport.pageId, control: o.control, verdict: o.verdict, detail: o.detail });
          }
          log('    [D6] 筛选一致性探针 ' + filterReport.pageId + '：' + filterReport.outcomes.length +
            ' 个控件（FAIL ' + filterReport.outcomes.filter(o => o.verdict === 'FAIL').length +
            ' / WARN ' + filterReport.outcomes.filter(o => o.verdict === 'WARN').length + '）');
        }
      } catch (e) {
        // 探针异常不阻塞主流程（对齐 v5.24 变更4 契约）
        log('    [WARN] D6: 筛选一致性探针异常（' + e.message + '），不阻塞主流程');
      }
    }

    // v5.16：settleMs 通过 evaluate 参数注入浏览器上下文（原硬编码 150ms）
    const l2Result = await page.evaluate(async (settleMs) => {
      const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
      if (!visiblePage) return { total: 0, passed: 0, failed: 0, details: [] };
      const currentPageId = visiblePage.getAttribute('data-page-id');
      // v5.14.4：限定查询范围到当前可见页面
      // v5.15 S-9：computed style 二次校验（与 L3 dot 逻辑对齐）
      const markers = Array.from(visiblePage.querySelectorAll('.l2-marker')).filter(m => {
        const cs = window.getComputedStyle(m);
        return cs.display !== 'none' && parseFloat(cs.opacity) > 0;
      });
      if (markers.length === 0) return { total: 0, passed: 0, failed: 0, details: [] };

      const host = document.getElementById('demora-annotation-host');
      const sr = host ? host.shadowRoot : null;
      const panel = sr ? sr.querySelector('.annotation-panel') : null;
      const panelBody = panel ? panel.querySelector('.panel-body') : null;

      let passed = 0, failed = 0;
      const details = [];

      for (let i = 0; i < markers.length; i++) {
        const marker = markers[i];
        const zoneWrap = marker.closest('[data-zone-id]');
        const zoneId = zoneWrap ? zoneWrap.getAttribute('data-zone-id') : null;

        // v5.14.5：视觉可见性检查（computed style）
        //   原盲区：只检查 getBoundingClientRect() 尺寸，不检查 display/opacity/visibility
        //   修复：检查 computed style 确保标注图标真正视觉可见
        const cs = getComputedStyle(marker);
        const r = marker.getBoundingClientRect();
        const visuallyVisible = cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0' && r.width > 0 && r.height > 0;

        if (!visuallyVisible) {
          // 标注图标不可见 → FAIL（不跳过，记录为失败）
          failed++;
          details.push({
            type: 'L2',
            pageId: currentPageId,
            markerIndex: i,
            zoneId: zoneId,
            reason: 'marker not visible',
            display: cs.display,
            visibility: cs.visibility,
            opacity: cs.opacity,
            rectW: r.width,
            rectH: r.height,
          });
          continue;
        }

        // 点击 L2 marker
        marker.click();
        // 等待 settleMs 让 class 切换 + 面板内容更新完成（v5.16：原 150ms → WAIT_TIMES.ANNOTATION_SETTLE）
        await new Promise(r => setTimeout(r, settleMs));

        // 验证激活态：zone is-highlighted + panel anno-card is-active
        const zoneHighlighted = zoneWrap ? zoneWrap.classList.contains('is-highlighted') : false;
        const activeCards = panelBody ? panelBody.querySelectorAll('.anno-card.is-active') : [];
        const cardActive = activeCards.length > 0;

        if (zoneHighlighted && cardActive) {
          passed++;
        } else {
          failed++;
          details.push({
            type: 'L2',
            pageId: currentPageId,
            markerIndex: i,
            zoneId: zoneId,
            zoneHighlighted: zoneHighlighted,
            cardActive: cardActive,
          });
        }
      }

      return { total: markers.length, passed, failed, details };
    }, WAIT_TIMES.ANNOTATION_SETTLE);

    d10TotalL2 += l2Result.total;
    d10PassL2 += l2Result.passed;
    d10FailL2 += l2Result.failed;
    if (l2Result.details.length > 0) {
      d10FailDetails.push(...l2Result.details);
    }

    log('    [L2] ' + l2Result.passed + '/' + l2Result.total + ' 激活通过' + (l2Result.failed > 0 ? '，失败 ' + l2Result.failed + ' 个' : ''));
    await screenshot('D10-page-' + pageId + '-L2-verified');

    // D10.3：该页 L3 全量激活验证（浏览器内 async for 循环）
    // v5.14.4 修复：限定查询范围到当前可见页面，避免全局查询导致 N×M 跨页测试
    //   原缺陷：document.querySelectorAll('.l3-dot') 返回所有页面的 dot（如 65 个），
    //          每页都测试全部 65 个 → 65×10=650 次测试，隐藏页面的 dot 必然失败
    //   修复：在可见页面 [data-page-id]:not([hidden]) 范围内查询 .l3-dot
    // v5.16：settleMs 通过 evaluate 参数注入浏览器上下文（原硬编码 150ms）
    const l3Result = await page.evaluate(async (settleMs) => {
      const visiblePage = document.querySelector('[data-page-id]:not([hidden])');
      if (!visiblePage) return { total: 0, passed: 0, failed: 0, details: [] };
      const currentPageId = visiblePage.getAttribute('data-page-id');
      // v5.14.4：限定查询范围到当前可见页面
      const dots = Array.from(visiblePage.querySelectorAll('.l3-dot'));
      if (dots.length === 0) return { total: 0, passed: 0, failed: 0, details: [] };

      const host = document.getElementById('demora-annotation-host');
      const sr = host ? host.shadowRoot : null;
      const panel = sr ? sr.querySelector('.annotation-panel') : null;
      const panelBody = panel ? panel.querySelector('.panel-body') : null;

      let passed = 0, failed = 0;
      const details = [];
      let testedCount = 0;

      for (let i = 0; i < dots.length; i++) {
        const dot = dots[i];
        const elemWrap = dot.closest('[data-element-id]');
        const elemId = elemWrap ? elemWrap.getAttribute('data-element-id') : null;

        // v5.14.5：视觉可见性检查（computed style），与 L2 逻辑一致
        const cs = getComputedStyle(dot);
        const r = dot.getBoundingClientRect();
        const visuallyVisible = cs.display !== 'none' && cs.visibility !== 'hidden' && cs.opacity !== '0' && r.width > 0 && r.height > 0;

        if (!visuallyVisible) {
          failed++;
          details.push({
            type: 'L3',
            pageId: currentPageId,
            dotIndex: i,
            elementId: elemId,
            reason: 'dot not visible',
            display: cs.display,
            visibility: cs.visibility,
            opacity: cs.opacity,
            rectW: r.width,
            rectH: r.height,
          });
          continue;
        }
        testedCount++;

        // 点击 L3 dot
        dot.click();
        // 等待 settleMs 让 class 切换 + 面板内容更新完成（v5.16：原 150ms → WAIT_TIMES.ANNOTATION_SETTLE）
        await new Promise(r => setTimeout(r, settleMs));

        // 验证激活态：dot is-active + panel anno-card is-active
        const dotActive = dot.classList.contains('is-active');
        const activeCards = panelBody ? panelBody.querySelectorAll('.anno-card.is-active') : [];
        const cardActive = activeCards.length > 0;

        if (dotActive && cardActive) {
          passed++;
        } else {
          failed++;
          details.push({
            type: 'L3',
            pageId: currentPageId,
            dotIndex: i,
            elementId: elemId,
            dotActive: dotActive,
            cardActive: cardActive,
          });
        }
      }

      return { total: dots.length, passed, failed, details };
    }, WAIT_TIMES.ANNOTATION_SETTLE);

    d10TotalL3 += l3Result.total;
    d10PassL3 += l3Result.passed;
    d10FailL3 += l3Result.failed;
    if (l3Result.details.length > 0) {
      d10FailDetails.push(...l3Result.details);
    }

    log('    [L3] ' + l3Result.passed + '/' + l3Result.total + ' 激活通过' + (l3Result.failed > 0 ? '，失败 ' + l3Result.failed + ' 个' : ''));
    await screenshot('D10-page-' + pageId + '-L3-verified');
  }

  // D10 评级
  // v5.14.6：L3 存在性断言 — 有 data-element-id 但 0 个 .l3-dot → FAIL（标注引擎未正确创建 dot）
  //   背景：B 跑 D10 假阳性报告 L3 19/19，但 demo 实际无 .l3-dot（AI 忘记写）
  //   修复：检测 data-element-id 数量 > 0 但 .l3-dot 总数 = 0 → FAIL
  // v5.18 P0-A2：改用 probes.collectAnnotationState（单一事实源，与 diagnose-runtime 一致）
  //   原 inline evaluate 仅查 [data-element-id] 数量；probes 一次性返回 elementCount/dotCount 等
  if (d10ModeActive && d10TotalL3 === 0 && d10FailDetails.length === 0) {
    const annoState = await page.evaluate(probes.collectAnnotationState);
    const elemCount = annoState.elementCount;
    if (elemCount > 0) {
      log('  [FAIL] D10: L3 存在性断言失败（检测到 ' + elemCount + ' 个 [data-element-id] 但 0 个 .l3-dot）');
      log('         标注引擎未正确创建 .l3-dot 元素，或 AI 未写入 data-element-id 属性');
      fail++;
      results.dimensions.D10_full_activation = 'fail: L3 existence assertion failed (' + elemCount + ' data-element-id but 0 .l3-dot)';
      await screenshot('D10-L3-existence-failed');
    }
  }

  log('  [INFO] D10 汇总: L2 ' + d10PassL2 + '/' + d10TotalL2 + '，L3 ' + d10PassL3 + '/' + d10TotalL3 + '，失败 ' + d10FailDetails.length + ' 个');
  if (d10FailDetails.length > 0) {
    log('  [FAIL] D10: 逐页 L2/L3 全量激活验证失败（' + d10FailDetails.length + ' 个标注未激活）');
    log('         失败明细（前 10 个）:');
    d10FailDetails.slice(0, 10).forEach(d => {
      const ident = d.zoneId || d.elementId || ('index#' + (d.markerIndex !== undefined ? d.markerIndex : d.dotIndex));
      // v5.14.5：支持"标注不可见"失败原因
      if (d.reason === 'marker not visible' || d.reason === 'dot not visible') {
        log('           - [' + d.type + '] 页面=' + d.pageId + ', ' + ident + ', 不可见: display=' + d.display + ', visibility=' + d.visibility + ', opacity=' + d.opacity + ', rect=' + d.rectW + 'x' + d.rectH);
      } else {
        const coopFlag = d.type === 'L2'
          ? 'zoneHigh=' + d.zoneHighlighted + ',cardActive=' + d.cardActive
          : 'dotActive=' + d.dotActive + ',cardActive=' + d.cardActive;
        log('           - [' + d.type + '] 页面=' + d.pageId + ', ' + ident + ', ' + coopFlag);
      }
    });
    fail++;
    results.dimensions.D10_full_activation = 'fail: ' + d10FailDetails.length + ' annotations not activated (L2:' + d10FailL2 + ', L3:' + d10FailL3 + ')';
    await screenshot('D10-activation-failed');
  } else if (d10TotalL2 + d10TotalL3 === 0) {
    log('  [WARN] D10: 未检测到任何 L2/L3 标注，跳过');
    warn++;
    results.dimensions.D10_full_activation = 'warn: no annotations found';
  } else {
    log('  [OK] D10: 逐页 L2/L3 全量激活验证通过（L2 ' + d10PassL2 + '/' + d10TotalL2 + '，L3 ' + d10PassL3 + '/' + d10TotalL3 + '）');
    pass++;
    results.dimensions.D10_full_activation = 'pass: L2 ' + d10PassL2 + '/' + d10TotalL2 + ', L3 ' + d10PassL3 + '/' + d10TotalL3;
  }
  } else {
    markDimSkipped(['D10_full_activation']);
  }

  // ===== v5.23 增强1 收口：D7 逐页表格完整性汇总定级（v5.24：并入 D10 导航断言违例）=====
  //   判定：任一表格 FAIL 或 d10NavFails 非空 → D7 fail；仅 WARN（表格 WARN 或初始页启发式 issue）
  //   → warn；否则 pass。warn 只计 1 次（对齐 v5.14.10 约定：Visual issues in D7 increment warn once per dimension）
  if (shouldRunDim('D7')) {
    if (!shouldRunDim('D10')) {
      log('  [INFO] D7: D10 未选中，逐页表格完整性检测未执行（仅以初始页启发式定级）');
    }
    // v5.24 变更5：d10NavFails（D10 导航后公共区域断言违例）并入 FAIL 定级族，结果串标注来源
    if (d7TableFails.length > 0 || d10NavFails.length > 0) {
      d7TableFails.forEach(f => log('  [FAIL] D7: 表格完整性 ' + f));
      d10NavFails.forEach(f => log('  [FAIL] D7: [D10 导航断言] ' + f));
      const d7FailSamples = d7TableFails
        .concat(d10NavFails.map(f => f + ' [D10导航断言]'))
        .slice(0, 3).map(i => i.substring(0, 80)).join(' | ');
      fail++;
      results.dimensions.D7_visual_heuristics = 'fail: ' + (d7TableFails.length + d10NavFails.length) +
        ' 项缺陷（表格完整性 ' + d7TableFails.length + ' + 导航断言 ' + d10NavFails.length + '） - ' +
        d7FailSamples +
        (d7VisualIssues.length > 0 ? '（另有初始页启发式 ' + d7VisualIssues.length + ' 项）' : '');
      log('  [FAIL] D7: 视觉启发式检查失败（表格完整性 ' + d7TableFails.length + ' 项 + D10 导航断言 ' + d10NavFails.length + ' 项 FAIL）');
    } else if (d7VisualIssues.length > 0 || d7TableWarns.length > 0) {
      // v5.14.10：warn 只计 1 次（原每个 issue warn++ 导致 total 虚高，与 D2 同模式 bug）
      d7TableWarns.forEach(w => log('  [WARN] D7: 表格完整性 ' + w));
      warn++;
      const d7Parts = [];
      if (d7VisualIssues.length > 0) d7Parts.push(d7VisualIssues.length + ' 项初始页启发式');
      if (d7TableWarns.length > 0) d7Parts.push(d7TableWarns.length + ' 项表格 WARN');
      results.dimensions.D7_visual_heuristics = 'warn: ' + d7Parts.join(' + ') + ' - ' +
        d7VisualIssues.concat(d7TableWarns).slice(0, 2).map(i => i.substring(0, 80)).join(' | ');
      log('  [WARN] D7: 视觉启发式检查告警（' + d7Parts.join(' + ') + '）');
    } else {
      log('  [OK] D7: 视觉启发式检查通过（含逐页表格完整性）');
      pass++;
      results.dimensions.D7_visual_heuristics = 'pass';
    }
  }

  // ===== v5.24 变更1 收口：D8 交互元件类型覆盖率汇总定级（消费新 probe 逐类型规模分流数据）=====
  //   逐类型判定（规模分流契约）：
  //     count<=4 → annotatedCount < count 即该类型缺标（小规模组须全部实例标注）；
  //     count>4  → 首个可见实例（DOM 顺序）未标注即缺标；已标注但关联卡片 element 名不含
  //                同类说明（/同类|首(行|个).*实例|共用/）→ missingNote（仅明细，不并入缺标）
  //   页级判定：missing>=1 且 missing/total>10% → WARN；missing>=3 或页覆盖率
  //   (annotatedTypes/total)<90% → FAIL；每页最多计 1 次 warn/fail（保持 v5.23 约定）
  //   明细落盘：results.d8_coverage_details（JSON.stringify(results) 全量序列化自动包含）
  if (shouldRunDim('D8')) {
    if (d8CoverageSamples.length === 0) {
      log('  [INFO] D8: 逐页导航未执行（D10 未选中或循环体未运行），交互元件类型覆盖率检测跳过');
      results.dimensions.D8_element_coverage = 'skip: 逐页导航未执行（覆盖率依赖 D10 逐页循环采样）';
    } else {
      const NOTE_PATTERN = /同类|首(行|个).*实例|共用/;
      let coverageFailCount = 0;
      let coverageWarnCount = 0;
      const failPages = [];
      const warnPages = [];
      const resultSamples = []; // 结果串样本：页码+缺标类型（上限 20 条）
      results.d8_coverage_details = {};
      for (const s of d8CoverageSamples) {
        if (!s.types || s.types.length === 0) continue; // 无交互类型页不参与判定
        const missing = [];
        const missingNote = [];
        for (const t of s.types) {
          // 规模分流：<=4 组全标校验 / >4 组首实例校验（firstAnnotated 为首实例标注态）
          const isMissing = (t.count <= 4)
            ? (t.annotatedCount < t.count)
            : (t.firstAnnotated !== true);
          if (isMissing) {
            missing.push({ type: t.key, count: t.count, annotated: t.annotatedCount, locators: t.unannotatedLocators });
          } else if (t.count > 4 && !NOTE_PATTERN.test(t.firstCardElement || '')) {
            missingNote.push({ type: t.key, count: t.count, cardElement: t.firstCardElement || '' });
          }
        }
        const total = s.types.length;
        const annotatedTypes = total - missing.length;
        const coveragePct = Math.round((annotatedTypes / total) * 100) + '%';
        results.d8_coverage_details[s.pageId] = { coverage: coveragePct, missing, missingNote };
        if (missing.length >= 3 || annotatedTypes / total < 0.90) {
          coverageFailCount++;
          failPages.push(s.pageId);
          log('  [FAIL] D8: ' + s.pageId + ' 交互元件类型覆盖率 ' + coveragePct + '（' + annotatedTypes + '/' + total +
            '），缺标类型 ' + missing.length + ' 个：' + missing.map(m => m.type + '×' + m.count).slice(0, 5).join('、'));
          missing.forEach(m => resultSamples.push(s.pageId + ' ' + m.type + '×' + m.count));
        } else if (missing.length >= 1 && missing.length / total > 0.10) {
          coverageWarnCount++;
          warnPages.push(s.pageId);
          log('  [WARN] D8: ' + s.pageId + ' 交互元件类型覆盖率 ' + coveragePct + '（' + annotatedTypes + '/' + total +
            '），缺标类型 ' + missing.length + ' 个：' + missing.map(m => m.type + '×' + m.count).slice(0, 5).join('、'));
          missing.forEach(m => resultSamples.push(s.pageId + ' ' + m.type + '×' + m.count));
        }
        if (missingNote.length > 0) {
          log('  [INFO] D8: ' + s.pageId + ' 有 ' + missingNote.length + ' 个类型首实例已标注但卡片 element 名缺同类说明（仅明细，不并入缺标）：' +
            missingNote.map(n => n.type + '（card="' + n.cardElement + '"）').slice(0, 3).join('、'));
        }
      }
      if (coverageFailCount > 0) {
        fail += coverageFailCount;
        results.dimensions.D8_element_coverage = 'fail: ' + coverageFailCount + ' 页覆盖率不达标（' + failPages.join(',') + '） - ' +
          resultSamples.slice(0, 20).join(' | ');
      } else if (coverageWarnCount > 0) {
        warn += coverageWarnCount;
        results.dimensions.D8_element_coverage = 'warn: ' + coverageWarnCount + ' 页覆盖率不足（' + warnPages.join(',') + '） - ' +
          resultSamples.slice(0, 20).join(' | ');
      } else {
        log('  [OK] D8: 交互元件类型覆盖率检测通过（' + d8CoverageSamples.length + ' 页采样无覆盖率缺口）');
        pass++;
        results.dimensions.D8_element_coverage = 'pass: ' + d8CoverageSamples.length + ' 页采样无覆盖率缺口';
      }
    }
  }

  // ===== v5.24 变更4 收口：D6_filter_consistency 筛选往返一致性汇总定级 =====
  //   任一 FAIL → 维度 fail（fail++ 记 1 次，结果串含样本）；仅 WARN → warn 记 1 次；
  //   探针已执行且无违例 → pass（全量跑无筛选控件 → pass: n/a，与 D3/D11 豁免同模式）；
  //   探针未执行（D10 未选中或循环体未运行）→ skip（对齐 D8_element_coverage skip 语义）
  if (shouldRunDim('D6')) {
    const filterFails = d6FilterResults.filter(r => r.verdict === 'FAIL');
    const filterWarns = d6FilterResults.filter(r => r.verdict === 'WARN');
    if (filterFails.length > 0) {
      filterFails.forEach(f => log('  [FAIL] D6: [' + f.pageId + '] ' + f.detail));
      fail++;
      results.dimensions.D6_filter_consistency = 'fail: ' + filterFails.length + ' 处筛选计数与可见行不一致 - ' +
        filterFails.map(f => f.pageId + ' ' + f.detail).slice(0, 5).map(i => i.substring(0, 80)).join(' | ');
      log('  [FAIL] D6: 筛选往返一致性检测失败（' + filterFails.length + ' 处计数不一致 / ' + d6FilterCheckedPages + ' 页探测）');
    } else if (filterWarns.length > 0) {
      filterWarns.forEach(w => log('  [WARN] D6: [' + w.pageId + '] ' + w.detail));
      warn++;
      results.dimensions.D6_filter_consistency = 'warn: ' + filterWarns.length + ' 处筛选触发后无可见状态变化 - ' +
        filterWarns.map(w => w.pageId + ' ' + w.detail).slice(0, 5).map(i => i.substring(0, 80)).join(' | ');
    } else if (d6FilterCheckedPages > 0) {
      if (d6FilterResults.length > 0) {
        log('  [OK] D6: 筛选往返一致性通过（' + d6FilterCheckedPages + ' 页 / ' + d6FilterResults.length + ' 个筛选控件计数一致）');
        pass++;
        results.dimensions.D6_filter_consistency = 'pass: ' + d6FilterResults.length + ' controls across ' + d6FilterCheckedPages + ' pages';
      } else {
        log('  [OK] D6: 筛选往返一致性 n/a（' + d6FilterCheckedPages + ' 页无筛选控件，不计 fail）');
        pass++;
        results.dimensions.D6_filter_consistency = 'pass: n/a — 无筛选控件（' + d6FilterCheckedPages + ' 页探测 0 控件）';
      }
    } else {
      log('  [INFO] D6: D10 逐页导航未执行，筛选往返一致性探针跳过');
      results.dimensions.D6_filter_consistency = 'skip: 逐页导航未执行（筛选探针依赖 D10 逐页循环）';
    }
  }

  // ===== D11: docs/index.html mermaid 浏览器渲染校验（v5.23 新增维度）=====
  // 背景：PRD mermaid 源码引号 typo（如 P04 -->|"生成报告| 缺右引号）静态检查不报错，
  //       交付后浏览器打开 docs 才报 Syntax error；D11 用真实浏览器渲染全部 .mermaid 块做交付前拦截。
  // 加载方式：复用现有 browser/context 新开 page，以 file:// 直载项目根 docs/index.html——
  //   docs 与 demo 为兄弟目录，现有静态服务根固定在 demoDir（startHttpServer spawn cwd），
  //   无法覆盖 docs/；file:// 下 assets/mermaid/*.js 相对路径按 docs/ 目录解析，
  //   Chromium 允许同目录树子资源加载，与 D0 http 加载 demo 的渲染行为一致。
  if (shouldRunDim('D11')) { // v5.18 P1 同款：--dimensions 未含 D11 时整块跳过
    log('\n--- D11: docs/index.html mermaid 渲染校验（v5.23 新增）---');
    const docsProjectRoot = path.dirname(demoDir);
    const docsIndexPath = path.join(docsProjectRoot, 'docs', 'index.html');
    if (!fs.existsSync(docsIndexPath)) {
      // docs 未生成豁免（与 D3 无弹窗豁免同模式）：不计 fail，记 pass: n/a
      log('  [INFO] docs/index.html 不存在，D11 记 n/a（docs 未生成豁免，不计 fail）');
      pass++;
      results.dimensions.D11_docs_mermaid = 'pass: n/a — docs 未生成（docs/index.html 不存在）';
    } else {
      const docsPage = await context.newPage();
      try {
        await docsPage.goto(pathToFileURL(docsIndexPath).href, { timeout: 15000, waitUntil: 'domcontentloaded' });
        // v5.17.2 同款签名注意：waitForFunction 为 (fn, arg, options) 三参形式，
        //   options 必须放第 3 参（第 2 参传对象会被当作 arg，timeout 失效退化为默认 30s）
        await docsPage.waitForFunction(() => document.readyState === 'complete', null, { timeout: 5000 })
          .catch(() => {}); // 容错：readyState 慢不阻断，mermaid 渲染等待兜底
        // 展开全部 <details>：mermaid-init.js v5.20 P1-1 折叠惰性渲染——折叠块初始
        // 文本测量失败保持原始文本，须触发 toggle 事件驱动按需渲染，否则误报"未渲染"
        await docsPage.evaluate(() => {
          document.querySelectorAll('details').forEach((d) => { if (!d.open) d.open = true; });
        });
        // 等待渲染完成：每个 .mermaid 块产出 svg（成功/语法错误均产 svg）或
        // mermaid.min.js 加载失败时整体替换为 .mermaid-fallback；15s 容错超时
        await docsPage.waitForFunction(() => {
          const total = document.querySelectorAll('.mermaid').length;
          const done = document.querySelectorAll('.mermaid svg, .mermaid .mermaid-error, .mermaid-fallback').length;
          return total === 0 || done >= total;
        }, null, { timeout: 15000 }).catch(() => {
          log('  [WARN] D11: mermaid 渲染等待超时（15s），按现状评估未完成块');
        });
        // mermaid.run 为异步批处理，再等一拍降低 svg 替换竞态
        await docsPage.waitForTimeout(500);

        // 逐块评估：innerText 含 Syntax error/Error 或无 svg 子节点 → FAIL
        const mermaidReport = await docsPage.evaluate(() => {
          const blocks = Array.from(document.querySelectorAll('.mermaid'));
          const fallbackCount = document.querySelectorAll('.mermaid-fallback').length;
          const failures = [];
          blocks.forEach((el, idx) => {
            const text = (el.innerText || '').trim();
            const firstLine = (text.split('\n').find((l) => l.trim()) || '').substring(0, 40);
            const hasSvg = !!el.querySelector('svg');
            const isErr = /syntax\s*error/i.test(text) || /(^|\s)error(\s|$|:)/i.test(text);
            if (isErr || !hasSvg) {
              failures.push({
                index: idx + 1,
                reason: isErr ? 'Syntax error 文案' : '无 svg 子节点（未渲染完成）',
                firstLine,
              });
            }
          });
          return { total: blocks.length, fallbackCount, failures };
        });

        if (mermaidReport.fallbackCount > 0) {
          // mermaid.min.js 加载失败：全部块降级为源码显示，docs 资源损坏属交付缺陷
          log('  [FAIL] D11: mermaid.min.js 加载失败，' + mermaidReport.fallbackCount + ' 块降级为源码显示（.mermaid-fallback）');
          fail++;
          results.dimensions.D11_docs_mermaid = 'fail: mermaid.min.js 加载失败（' + mermaidReport.fallbackCount + ' 块 fallback）';
        } else if (mermaidReport.failures.length > 0) {
          log('  [FAIL] D11: ' + mermaidReport.failures.length + '/' + mermaidReport.total + ' 块 mermaid 渲染失败');
          mermaidReport.failures.slice(0, 8).forEach((f) => {
            log('    - 第 ' + f.index + ' 块 ' + f.reason + '："' + f.firstLine + '"');
          });
          if (mermaidReport.failures.length > 8) {
            log('    ... 还有 ' + (mermaidReport.failures.length - 8) + ' 块失败');
          }
          fail++;
          results.dimensions.D11_docs_mermaid = 'fail: ' + mermaidReport.failures.length + '/' +
            mermaidReport.total + ' 块渲染失败（第 ' + mermaidReport.failures[0].index + ' 块 "' +
            mermaidReport.failures[0].firstLine + '"）';
          // v5.18 P0-A5 同款：--retry 模式跳过截图
          if (!args.retry) {
            try {
              const d11Shot = path.join(screenshotDir, `${label}-D11-docs-mermaid-fail.jpeg`);
              await docsPage.screenshot({ path: d11Shot, fullPage: false, type: 'jpeg', quality: 80 });
              log('  [INFO] D11 截图: ' + d11Shot);
            } catch (e) {
              log('  [WARN] D11 截图失败: ' + e.message);
            }
          }
        } else if (mermaidReport.total === 0) {
          log('  [WARN] D11: docs/index.html 无 mermaid 块');
          warn++;
          results.dimensions.D11_docs_mermaid = 'warn: no mermaid blocks found';
        } else {
          log('  [OK] D11: docs mermaid 渲染校验通过（' + mermaidReport.total + '/' + mermaidReport.total + ' 块渲染正常）');
          pass++;
          results.dimensions.D11_docs_mermaid = 'pass: ' + mermaidReport.total + '/' + mermaidReport.total + ' 块渲染正常';
        }
      } catch (e) {
        log('  [FAIL] D11: docs 页面加载/评估失败: ' + e.message);
        fail++;
        results.dimensions.D11_docs_mermaid = 'fail: ' + e.message;
      } finally {
        await docsPage.close();
      }
    }
  } else {
    markDimSkipped(['D11_docs_mermaid']);
  }

  // v5.15 P0-1：审计对象身份验证（审计后比对，防御端口冲突加载错误 demo）
  //   比对预读取的 demoIdentity 与审计实际探测的 detectedPages
  //   若不匹配 → FAIL 退出，禁止写入 audit-result.json
  if (demoIdentity.pageCount > 0 && results.detectedPages) {
    const actualPageCount = results.detectedPages.length;
    if (actualPageCount !== demoIdentity.pageCount) {
      log('[FAIL] 审计对象身份不匹配：预期 ' + demoIdentity.pageCount + ' 页（demo/index.html），实际审计 ' + actualPageCount + ' 页');
      log('       疑似端口冲突加载了错误 demo，禁止写入审计结果');
      log('       预期 title="' + demoIdentity.title + '"，请检查端口 ' + args.port + ' 是否被其他 demo 占用');
      stopHttpServer();
      process.exit(1);
    }
    log('[OK] 审计对象身份验证通过：' + actualPageCount + ' 页一致');
  }

  // ===== 写入 audit-result.json =====
  results.summary = { pass, fail, warn, total: pass + fail + warn };
  results.overall = fail === 0 ? (warn === 0 ? 'A' : 'B') : (fail <= 2 ? 'C' : 'D');
  const resultPath = path.join(demoDir, 'audit-result.json');
  fs.writeFileSync(resultPath, JSON.stringify(results, null, 2), 'utf-8');
  log('\n[INFO] 审计结果写入: ' + resultPath);

  // v5.18 P0-A1：与 verify-delivery V-4 对齐的不可接受 warn 门禁前置
  //   根因：run-audit 对 B 级（含任意 warn）即写 runtime_audit_passed:true，
  //         但 verify-delivery V-4 对 B+D0_console/D6 warn 打回 → 同一质量 bar 在打包后才执行，
  //         每次返工浪费 1 轮审计（4-16m）+ 打包 + verify（15-30m），aigc/college/green 三案中招
  //   修复：overall=B 时若含不可接受 warn（D0_console/D6_button_responsiveness），不写 runtime_audit_passed
  //   注意：overall 评级本身不变（不影响评级语义与质量 bar），仅把 V-4 标准从"打包后"前移到"审计后立刻"
  const UNACCEPTABLE_WARN_GATE = {
    D0_console: 'console 含 error/404（功能缺陷）',
    D6_button_responsiveness: '按钮无响应或全 disabled（功能缺陷）',
  };
  let unacceptableWarnHits = [];
  if (results.overall === 'B') {
    for (const [dim, reason] of Object.entries(UNACCEPTABLE_WARN_GATE)) {
      const val = results.dimensions[dim];
      if (typeof val === 'string' && /^warn:/i.test(val)) {
        unacceptableWarnHits.push({ dim, value: val, reason });
      }
    }
  }
  const gatePassed = (results.overall === 'A') || (results.overall === 'B' && unacceptableWarnHits.length === 0);

  // v5.6 状态机：A/B 评级时标记 AI 阶段 5 已完成
  // package-delivery.mjs 必须看到 runtime_audit_passed: true 才允许打包
  // v5.18 P1：--dimensions 部分维度模式不写 runtime_audit_passed（防止用维度子集绕过全量质量门禁）
  if (gatePassed && !selectedDims) {
    const simProjectDir = path.dirname(demoDir); // demoDir = sim-project/demo → sim-project
    const stateFile = path.join(simProjectDir, '.demora', 'state.yaml');
    if (fs.existsSync(stateFile)) {
      // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
      let text = readStateYaml(simProjectDir);
      const regex = /^(\s*runtime_audit_passed:\s*).*$/m;
      if (regex.test(text)) {
        text = text.replace(regex, '$1true');
      } else {
        text = text.trimEnd() + '\nruntime_audit_passed: true\n';
      }
      fs.writeFileSync(stateFile, text, 'utf-8');
      // v5.16 Task 8.2：写入 state.yaml 后主动失效缓存（同进程内后续读取需拿到新值）
      invalidate(simProjectDir);
      log('[OK] state.yaml: runtime_audit_passed = true (评级 ' + results.overall + ')');
    }
  } else if (gatePassed && selectedDims) {
    // v5.18 P1：部分维度通过 ≠ 全量通过，禁止写 runtime_audit_passed（最终验收必须全量审计）
    //   logAlways 直出：--dimensions 常与 --retry 组合使用，此 [WARN] 属关键流程控制信息，不可被过滤器吞掉
    logAlways('[WARN] --dimensions 部分维度模式：选中维度虽通过，但不写 runtime_audit_passed（最终验收必须不带 --dimensions 全量审计）');
  } else if (results.overall === 'B' && unacceptableWarnHits.length > 0) {
    log('[FAIL] 不可接受 warn 清单命中（与 verify-delivery V-4 对齐），不写 runtime_audit_passed：');
    unacceptableWarnHits.forEach(w => {
      log('       - ' + w.dim + ': ' + String(w.value).substring(0, 80) + ' — ' + w.reason);
    });
    log('       须修复至 A 级（或仅剩可接受 warn：D4 / D7 / D8 / D9 / D10）后方可进入 Phase 3 打包');
  } else {
    log('[WARN] 评级 ' + results.overall + ' < B，不写 runtime_audit_passed');
  }

  // v5.16 Tier 3 Task 5：收集失败维度 self-diagnostics（D10/D3/D5/D9 失败时附 DOM 断言结果）
  //   在 browser.close 前收集，消除 AI 读源码定位失败的需求
  //   策略：扫描 results.dimensions 中所有 fail 项，按维度调用对应 diagnostics 收集器
  //   v5.18 P0-A5：--retry 模式跳过浏览器内 diagnostics 收集（降低上下文消耗）
  //     failedDimensions 仍构造（无 diagnostics），用于写 fix-suggestions.json + [FIX_SUGGESTIONS] 块
  const failedDimensions = [];
  const _dimToCollector = {
    'D3_modal_close': 'D3',
    'D5_l2_marker_seq': 'D5',
    'D5_multi_page_anchor': 'D5',
    'D9_toggle_show': 'D9',
    'D9_l2_coop': 'D9',
    'D9_l3_coop': 'D9',
    'D9_panel_close': 'D9',
    'D10_full_activation': 'D10',
    'D6_button_responsiveness': 'D6',
    'D6_filter_consistency': 'D6', // v5.24：筛选往返一致性失败时纳入 failedDimensions（挂 D6 修复建议模板族）
    'D11_docs_mermaid': 'D11', // v5.23：D11 失败时纳入 failedDimensions（无浏览器内 diagnostics，reason 已含块明细）
  };
  for (const [key, val] of Object.entries(results.dimensions)) {
    if (typeof val !== 'string') continue;
    // v5.18：D6 warn 也收集（按钮无响应是首轮 D 评级主因，warn 时仍需给修复建议）
    const isFail = val.startsWith('fail');
    const isD6Warn = key === 'D6_button_responsiveness' && val.startsWith('warn');
    if (!isFail && !isD6Warn) continue;
    const dim = _dimToCollector[key];
    if (dim) {
      let diagnostics = null;
      // v5.18 P0-A5：--retry 模式跳过浏览器内 diagnostics 收集（输出 < 2KB）
      if (!args.retry) {
        try {
          if (dim === 'D10') diagnostics = await collectD10Diagnostics(page);
          else if (dim === 'D3') diagnostics = await collectD3Diagnostics(page);
          else if (dim === 'D5') diagnostics = await collectD5Diagnostics(page);
          else if (dim === 'D9') diagnostics = await collectD9Diagnostics(page);
        } catch (e) { diagnostics = { error: e.message }; }
      }
      failedDimensions.push({ dim, reason: val, diagnostics });
    }
  }

  // v5.18 P0-A5：失败时写 demo/fix-suggestions.json（含失败维度 + 修复命令 + diagnostics）
  //   用途：AI 修复时一次性读取，无需解析 [FIX_SUGGESTIONS] 块或重读审计输出
  //   触发条件：fail > 0 或 overall < B（即 C/D 评级，含不可接受 warn 命中场景）
  if (fail > 0 || (results.overall !== 'A' && results.overall !== 'B')) {
    const fixSuggestions = {
      timestamp: new Date().toISOString(),
      overall: results.overall,
      failed_dimensions: failedDimensions.map(f => {
        const templates = matchFixSuggestion(f);
        return {
          dimension: f.dim,
          reason: f.reason,
          fix_patterns: templates.map(t => ({
            root_cause: t.root_cause,
            fix_pattern: t.fix_pattern,
            evidence_selector: t.evidence_selector,
          })),
          diagnostics: f.diagnostics || null,
        };
      }),
    };
    fs.writeFileSync(path.join(demoDir, 'fix-suggestions.json'), JSON.stringify(fixSuggestions, null, 2), 'utf-8');
    log('[INFO] 修复建议已写入: demo/fix-suggestions.json');
  }

  // ===== 汇总 =====
  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
  log('======================================================================');
  log(`>>> 综合评级: ${results.overall}`);
  log(`>>> 截图保存: ${screenshotDir}`);

  // v5.16 Tier 3 Task 4：维度结果摘要表（--dimensions-only 模式核心输出）
  //   列出所有维度的 pass/fail/warn 状态，便于 AI 快速定位失败维度
  //   使用 console.log 直接输出（绕过 log() 过滤器，确保 --dimensions-only 模式也输出）
  {
    const _allDimensions = Object.entries(results.dimensions);
    const _dimLines = ['[DIMENSION_SUMMARY] 维度结果摘要（共 ' + _allDimensions.length + ' 项）'];
    _allDimensions.forEach(([k, v]) => {
      _dimLines.push('  - ' + k + ': ' + v);
    });
    _dimLines.push('[DIMENSION_SUMMARY_END]');
    console.log(_dimLines.join('\n'));
  }

  // v5.14.16 修复 F（批次1）：[WARN] 详情块（强制输出，防御 grep 过滤丢失 [WARN]）
  //   根因：G-1 agent 用 grep 过滤输出时丢失 [WARN] 行，导致 B 级 warn 被忽略
  //   修复：[SUMMARY] 后强制输出 [WARN_DETAILS] 块，agent 即使 grep 也难以整体排除
  //         块格式：[WARN_DETAILS_BEGIN] ... [WARN_DETAILS_END]（成对标记，便于解析）
  if (warnDetails.length > 0) {
    log('');
    log('[WARN_DETAILS_BEGIN] 警告详情（共 ' + warnDetails.length + ' 条，不可被 grep 过滤）');
    warnDetails.forEach((w, i) => {
      log('  ' + (i + 1) + '. ' + w);
    });
    log('[WARN_DETAILS_END]');
    log('[INFO] agent 禁止用 grep 过滤审计输出，必须完整读取 [WARN_DETAILS_BEGIN]~[WARN_DETAILS_END] 块');
  }

  // v5.14.18 修复 10：WARN 维度摘要块（按 dimension 维度汇总，强制 agent 关注）
  //   原现状：v5.14.16 修复 F 已加 WARN_DETAILS 块，但仅按行收集 warnDetails
  //   强化：追加按 results.dimensions 维度的 WARN 摘要，让 agent 一目了然哪些维度告警
  //         特别是 v5.14.18 新增的 D8 same-page id dup / D10 数量不一致 / P010 body flex 等
  const warnDimensions = Object.entries(results.dimensions)
    .filter(([_, v]) => String(v).startsWith('warn'));
  if (warnDimensions.length > 0) {
    log('');
    log('[WARN_DIMENSION_SUMMARY] 维度告警摘要（共 ' + warnDimensions.length + ' 个维度告警，必须逐条确认）');
    warnDimensions.forEach(([k, v]) => {
      log('  - ' + k + ': ' + v);
    });
    log('[WARN_DIMENSION_SUMMARY_END]');
  }

  // v5.16 Tier 3 Task 3：输出 [FIX_SUGGESTIONS] 块（引导 AI 按维度修复，避免读源码）
  //   含 dimension/root_cause/fix_pattern/evidence_selector 四字段 + diagnostics DOM 断言结果
  //   使用 console.log 直接输出（绕过 log() 过滤器，确保 --dimensions-only 模式也输出）
  outputFixSuggestions(failedDimensions);

  await browser.close();
  stopHttpServer(args.port);

  // v5.17 Tier B5：opt-in 性能指标输出（仅 --debug-eval-count 时）
  if (args.debugEvalCount) {
    const __wall = ((Date.now() - __perfStart) / 1000).toFixed(1);
    console.log(`>>> [PERF] Wall time: ${__wall}s, evaluate calls: ${__evalCount}`);
  }

  process.exit(fail > 0 ? 1 : 0);
}

main().catch(e => {
  console.error('[FAIL] 审计异常: ' + e.message);
  console.error(e.stack);
  try { stopHttpServer(); } catch (_) {}
  process.exit(1);
});
