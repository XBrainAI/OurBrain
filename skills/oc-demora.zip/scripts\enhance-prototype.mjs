// enhance-prototype.mjs
// Phase 2 Demo 增强：注入标注三件套（v5.1 Shadow DOM 隔离版）+ 版权 Footer（v5.10）
// v5.18 P0-A3：新增 C13 标注引擎未加载检测（[demora-annotation-js] 标记 + annotation-engine.js 引用），原 C13 顺移为 C15
// v2.3：P031 触发器语义预检 + C18 modal hidden 归一 + P032 role=dialog 位置 + P013 契约修正
// v2.4：P033 显隐状态反模式检测 + C19 P018 自动对齐
// v5.23：新增 C20 表格结构标注迁移（tr/td/th/tbody/thead 上的 data-element-id 迁移至行内安全位置，UAT0824 codex-dsf-p3 P06 表格坍塌根因）
// v5.24：① Footer 注入位置从 <body> 末尾改为 .content 滚动容器闭合前（消除 document 溢出结构性隐患，UAT0826 p3 根因①）
//        ② 新增 C21 导航锚点防护（capture 阶段拦截 data-nav 锚点默认跳转，防 topbar 被顶出视口，UAT0826 p3 根因③）
//
// 设计理念：
//   标注系统作为"独立叠加层"，通过 data-* 属性约定与 AI 生成的 HTML 对接。
//   面板用 Shadow DOM 封装，避免 .anno-card / .l2-tag 等通用类名污染主页面。
//
// 注入方式（v5.1 Shadow DOM 隔离）：
//   1. annotation-styles.css 主页面部分 → demo/index.html <head> 末尾
//   2. Shadow DOM 宿主 <div id="demora-annotation-host"> → <body> 末尾
//   3. annotation-styles.css 面板部分 + annotation-panel.html → Shadow DOM 内
//   4. annotation-engine.js → <body> 末尾（通过 host.shadowRoot 访问面板）
//   5. v5.10 新增：Ourchem × Demora 联合版权 Footer → .content 滚动容器闭合前
//      （v5.24 前为 <body> 末尾；HTML 无 .content 容器时回退 <body> 末尾，项目级统一标识）
//   6. v5.24 新增：C21 导航锚点防护脚本 → <body> 末尾（capture 拦截 data-nav 锚点默认跳转）
//
// 幂等：使用标记注释包裹注入内容，重复运行不会重复注入。
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';
import { appendConversationEntry } from './lib/conversation-log.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findReferencesDir() {
  const candidates = [
    path.join(__dirname, '..', 'references'),
    path.join(__dirname, '..', '..', '..', 'src', 'reference'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// v5.10 新增：查找 Ourchem 白色 logo SVG 文件
// 搜索路径（按优先级）：
//   1. dist/oc-demora/assets/logo/logo-ourchem/奥凯logo-长-白.svg（dist 运行时）
//   2. src/assets/IP/logo/logo-ourchem/奥凯logo-长-白.svg（dev 运行时）
function findOurchemWhiteLogo() {
  const candidates = [
    path.join(__dirname, '..', 'assets', 'logo', 'logo-ourchem', '奥凯logo-长-白.svg'),
    path.join(__dirname, '..', '..', '..', '..', 'src', 'assets', 'IP', 'logo', 'logo-ourchem', '奥凯logo-长-白.svg'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/**
 * v5.10 新增：从 SVG 文件提取内部内容（<svg>...</svg> 之间的部分）
 * 用于将完整 SVG 文件内联到 HTML 中，并设置正确的 viewBox
 */
function extractSvgInner(svgContent) {
  const match = svgContent.match(/<svg[^>]*>([\s\S]*)<\/svg>/);
  if (!match) return null;
  return match[1].trim();
}

/**
 * v5.10 新增：构建 Ourchem × Demora 联合版权 Footer HTML
 * 含 Ourchem 白色 logo（inline SVG）+ Demora logo + 版权声明
 * 使用 demora-footer-* 前缀 CSS 类，避免与 AI 生成 CSS 冲突
 */
function buildCopyrightFooter(whiteLogoSvgPath) {
  let ourchemInlineSvg = '';
  if (whiteLogoSvgPath) {
    const svgContent = fs.readFileSync(whiteLogoSvgPath, 'utf-8');
    const inner = extractSvgInner(svgContent);
    if (inner) {
      ourchemInlineSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 133.24 25.6">\n${inner}\n      </svg>`;
    }
  }

  return `
<!-- [demora-copyright-footer] start -->
<style>
  /* v5.10: Ourchem × Demora 联合版权 Footer（项目级统一标识） */
  .demora-footer {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    padding: 24px 20px;
    margin-top: 40px;
    background: #0a0e14;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    color: rgba(255, 255, 255, 0.6);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    /* v5.14.18 防御性 CSS：防止 body 被设为 flex/grid 容器时 footer 漂移到右侧 */
    width: 100%;
    box-sizing: border-box;
    flex-basis: 100%;
    flex-shrink: 0;
    align-self: stretch;
  }
  .demora-footer-coop {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
  }
  .demora-footer-brand-logo {
    display: flex;
    align-items: center;
    height: 28px;
  }
  .demora-footer-brand-ourchem svg {
    height: 28px;
    width: auto;
    opacity: 0.95;
  }
  .demora-footer-brand-demora svg {
    height: 24px;
    width: auto;
  }
  .demora-footer-coop-x {
    font-size: 18px;
    font-weight: 300;
    color: rgba(255, 255, 255, 0.4);
  }
  .demora-footer-copyright {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.5);
    line-height: 1.7;
    text-align: center;
    margin: 0;
  }
  @media (max-width: 640px) {
    .demora-footer { padding: 20px 16px; }
    .demora-footer-coop { gap: 12px; }
    .demora-footer-brand-ourchem svg, .demora-footer-brand-demora svg { height: 22px; }
    .demora-footer-coop-x { font-size: 16px; }
  }
</style>
<footer class="demora-footer">
  <div class="demora-footer-coop">
    <div class="demora-footer-brand-logo demora-footer-brand-ourchem" aria-label="Ourchem">
      ${ourchemInlineSvg}
    </div>
    <span class="demora-footer-coop-x" aria-hidden="true">×</span>
    <div class="demora-footer-brand-logo demora-footer-brand-demora" aria-label="Demora">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 32" fill="none">
        <g transform="translate(0, 2)">
          <rect x="4" y="0" width="12" height="6" rx="3" fill="#14B8A6" opacity="0.4"/>
          <rect x="6" y="11" width="20" height="6" rx="3" fill="#14B8A6" opacity="0.7"/>
          <rect x="0" y="22" width="36" height="6" rx="3" fill="#14B8A6"/>
        </g>
        <text x="48" y="23" font-family="Inter, -apple-system, sans-serif" font-weight="700" font-size="20" fill="#F5F5F7">Demora</text>
      </svg>
    </div>
  </div>
  <p class="demora-footer-copyright">
    © 2026 Ourchem × Demora · 保留所有权利
  </p>
</footer>
<!-- [demora-copyright-footer] end -->
`;
}

/**
 * v5.24 新增：定位 .content 滚动容器的闭合标签插入位置（HTML 字符串模式）
 *
 * 变更原因（UAT0826 p3 根因①）：P1-4 布局契约为 .app-shell（100vh flex）+ .topbar
 * （公共区常驻）+ .content（overflow-y:auto 业务滚动容器）——业务滚动收敛 .content、
 * document 不滚。footer 原注入 body 末尾（app-shell 之外 in-flow）→ document 高度 =
 * app-shell 全高 + footer 高（实证 1049 > 视口 900，溢出 149px），击穿"document 不滚"
 * 契约前提，所有经本脚本处理的 demo 共有此结构性溢出隐患。footer 移入 .content 内
 * 随业务内容滚动后，document 恢复不溢出。
 *
 * 实现说明：本脚本操作 HTML 字符串，无法探测 computed overflow-y（次选滚动区判定
 * 不可行），退化为定位第一个 class 列表含独立 "content" 词的元素（骨架契约为
 * <main class="content">，兼容 AI 写的 <div class="content">），以同名闭标签平衡
 * 计数求容器闭合处。找不到 .content 或平衡计数失败返回 -1（调用方回退 body 末尾）。
 *
 * @param {string} html 完整 HTML 字符串
 * @returns {number} 插入位置索引（.content 闭合标签前）；无 .content 或定位失败返回 -1
 */
function findContentCloseInsertPos(html) {
  // 扫描开标签，按 class 空白分词精确匹配 "content"（不误伤 content-header/page-content 等）
  const openTagRe = /<([a-zA-Z][\w-]*)\b[^>]*>/g;
  let openMatch = null;
  let m;
  while ((m = openTagRe.exec(html)) !== null) {
    const classMatch = m[0].match(/\bclass\s*=\s*(["'])([^"']*)\1/i);
    if (!classMatch) continue;
    if (classMatch[2].trim().split(/\s+/).includes('content')) {
      openMatch = m;
      break;
    }
  }
  if (!openMatch) return -1;
  // 同名标签平衡计数（开标签 +1 / 闭标签 -1），深度归零处即 .content 闭合标签位置
  const tagName = openMatch[1];
  const tokenRe = new RegExp('</?' + tagName + '\\b[^>]*>', 'gi');
  tokenRe.lastIndex = openMatch.index + openMatch[0].length;
  let depth = 1;
  let tm;
  while ((tm = tokenRe.exec(html)) !== null) {
    depth += tm[0].startsWith('</') ? -1 : 1;
    if (depth === 0) return tm.index;
  }
  return -1; // 闭合标签失衡（截断 HTML 等），调用方回退 body 末尾
}

// v5.6 状态机字段写入：annotation_injected: true
// 表示 AI 阶段 3（标注系统注入）已完成
// v5.25 P1-3：同时写入 phase2_enhance_completed_at（设计生成段终点，与 lock-model 的 phase2_started_at 配对）
function markAnnotationInjected(root) {
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) return false;
  let text = fs.readFileSync(stateFile, 'utf-8');
  const updates = {
    annotation_injected: 'true',
    phase2_enhance_completed_at: new Date().toISOString(),
  };
  for (const [key, value] of Object.entries(updates)) {
    const regex = new RegExp('^(\\s*' + key + ':\\s*).*$', 'm');
    if (regex.test(text)) {
      text = text.replace(regex, '$1' + value);
    } else {
      text = text.trimEnd() + '\n' + key + ': ' + value + '\n';
    }
  }
  fs.writeFileSync(stateFile, text, 'utf-8');
  return true;
}

/**
 * 从 CSS 内容中按标记提取区段
 * 标记格式：/* >>> [section-name:begin] <<< *​/ ... /* >>> [section-name:end] <<< *​/
 * @param {string} css 完整 CSS 内容
 * @param {string} sectionName 区段名（如 'demora-main-page-styles'）
 * @returns {string} 区段内容（不含标记行），未找到则返回空字符串
 */
function extractCssSection(css, sectionName) {
  const beginMarker = `>>> [${sectionName}:begin]`;
  const endMarker = `>>> [${sectionName}:end]`;
  const beginIdx = css.indexOf(beginMarker);
  const endIdx = css.indexOf(endMarker);
  if (beginIdx === -1 || endIdx === -1 || endIdx < beginIdx) {
    return '';
  }
  // 截取 begin 行结束位置到 end 标记开始位置之间的内容
  const beginLineEnd = css.indexOf('\n', beginIdx);
  const content = css.slice(beginLineEnd + 1, endIdx).trim();
  return content;
}

const INJECT_CSS_START = '<!-- [demora-annotation-css] start -->';
const INJECT_CSS_END = '<!-- [demora-annotation-css] end -->';
const INJECT_PANEL_START = '<!-- [demora-annotation-panel] start -->';
const INJECT_PANEL_END = '<!-- [demora-annotation-panel] end -->';
const INJECT_JS_START = '<!-- [demora-annotation-js] start -->';
const INJECT_JS_END = '<!-- [demora-annotation-js] end -->';
// v5.24 新增：C21 导航锚点防护脚本注入标记
const INJECT_NAV_GUARD_START = '<!-- [demora-nav-guard] start -->';
const INJECT_NAV_GUARD_END = '<!-- [demora-nav-guard] end -->';

// v5.2.7：CSS 内部标记（用于 check-structure.mjs S-6 排除正则匹配）
// 原因：HTML 注释标记位于 <style> 标签外，readAllCss() 仅提取 <style> 内的 CSS 文本，
//       导致 injectedBlockRegex 无法匹配，注入的保留类名规则被误判为 AI 重复定义。
// 修复：在 <style> 标签内额外添加 CSS 注释包裹标记，使 S-6 能正确识别注入块。
const INJECT_CSS_INNER_START = '/* [demora-injected-css] start */';
const INJECT_CSS_INNER_END = '/* [demora-injected-css] end */';
const INJECT_PANEL_CSS_INNER_START = '/* [demora-injected-panel-css] start */';
const INJECT_PANEL_CSS_INNER_END = '/* [demora-injected-panel-css] end */';

/**
 * v5.18 Tier C：标注基础设施自动修正（spec first-round-bplus-guarantee）
 *
 * 设计理念：
 *   - frontend-design 完整自由度保留（布局/视觉/交互由 AI 设计）
 *   - 标注基础设施（nav href/hidden/anno-zone/data-annotation-root 等）由引擎自动修正
 *   - 9 项修正覆盖 P019-P027 + P017 强化的根因，将首轮 B+ 率从 17% 提升到 >80%（v2 增强）
 *
 * 修正清单（按执行顺序）：
 *   C2: [data-page-id] 的 style="display:none" → hidden 属性 + 注入 [hidden]{display:none!important} CSS
 *   C6: 第一个 [data-page-id] 的 hidden 属性移除（首屏必须可见，须在 C2 之后执行）
 *   C5: 无 data-annotation-root → 为 <main> 或 <body> 添加
 *   C1: data-nav 元素 href 重复或 # → 改为唯一值 #${navId}
 *   C3: [data-zone-id] 无 anno-zone 类 → 添加
 *   C4: [data-element-id] 在内联元素（input/a/span/i/label/select/textarea）→ 用 <div> 包裹
 *       注意（first-round-bplus-guarantee-v2）：BUTTON 移出 inlineTags
 *         根因：codex-dsf 38 个 data-element-id on BUTTON 实测 D8/D10 全 pass
 *   C9: display:none 元素的 data-element-id 剥离（first-round-bplus-guarantee-v2 新增）
 *       根因：tw-dsf2 首轮 D10 L3 dots 8 个未激活，隐藏 placeholder 含 data-element-id
 *   C7（WARN 不修正）: 标注元素在 [data-page-id] 外 → 输出 WARN
 *   C8（WARN 不修正）: 有 modal 容器但无 [data-open-modal] → 输出 WARN
 *   C10: 移除空 .l2-marker（让标注引擎自动创建带数字序号的 marker）
 *   C11（WARN 不修正）: 重复 data-element-id 警告
 *   C12: modal 触发器从 onclick/data-action 反解补写 data-open-modal（v5.18 P0-C3，升级 C8）
 *   C13（WARN，v5.18 P0-A3 新增）: 标注引擎未加载检测——[demora-annotation-js] 标记或
 *        annotation-engine.js 脚本引用缺失，由后续 step 3 自动补注入
 *   C15（WARN，v5.18 P0-C3）: modal 容器无关闭控件（原 C13，A3 让渡编号）
 *   C14（WARN 不修正）: __ANNOTATION_DATA__ id 去重校验
 *   C16: 手写 .l3-dot 全删（v2.1 新增，D10 根因 C 类前置）
 *        根因：静态手写 dot 与引擎运行时注入冲突（p8 l3DotCount 54 vs dataElementIdCount 40）；
 *              p5 删 35 个手写 dot 后 1 轮 pass。引擎为每个 data-element-id 自动创建 dot，
 *              静态出现的 .l3-dot 均为手写冗余
 *   C17: 重复 .l2-marker 去重（v2.1 新增，D10 根因 C 类前置）
 *        根因：同一 data-zone-id 容器内手写多个 marker（p1 每 zone 2 个：声明 3 DOM 6），
 *              引擎 ensureMarkers 检测到已存在 marker 则跳过 → 重复 marker 不被引擎去重
 *   C18: modal 容器 hidden 属性归一为 style="display:none"（v2.3 新增）
 *        根因：v2.2 p6 实证——4 个 modal 用 hidden 属性，骨架 openModal 只清 display
 *              （el.style.display = ''）打不开 hidden 的 modal → D3 close fail + 级联失败
 *   C19: P018 自动对齐（v2.4 新增）——__ANNOTATION_DATA__ 声明集与静态锚点集双向对齐
 *        依据：v2.3 p10 修复链实证——P018 FAIL（声明 L3 44 vs DOM 27）后 agent 人肉 3 分钟
 *              双向对齐（补 4 个静态锚点 + Node 脚本删动态行锚点 + 裁声明 44→31）。
 *              P018 的 fix_command 已写"enhance 自动处理"，本轮起名实相符
 *   C20: 表格结构元素（tr/td/th/tbody/thead）上的 data-element-id 自动迁移至行内安全位置
 *        （v5.23 新增，UAT0824 codex-dsf-p3 P06：注入样式 [data-element-id]{display:inline-flex}
 *          覆盖 tr 原生 table-row 致整行坍塌 + 引擎 dot 直插 tr 形成非法表格子节点；
 *          迁移目标：行内第一个交互子元素 button/a/select/input，无则包裹首格内容为 span）
 *   C21: 导航锚点防护脚本注入（v5.24 新增，UAT0826 p3 根因③——运行时脚本注入，非静态修正）
 *        根因三元组：① 版权 Footer 位于 body 末尾 in-flow（app-shell 之外）→ document 高
 *          1049 > 视口 900 溢出 149px（由本次 footer 注入位置修改①根治）；② demo（AI 写）
 *          page 元素挂 id（如 <section id="P03">）→ <a href="#P03"> 成为真锚点；
 *          ③ demo 的 click 委托处理 data-nav 后无 e.preventDefault() → 浏览器默认锚点跳转
 *          发生在 route() 复位之后，document 滚动 20px，58px topbar 被裁 20px
 *          （p6 因 page 无 id 幸免——对照实验已证明）。
 *        方案：主流程注入 capture 阶段全局 click 拦截器——preventDefault 阻断默认锚点跳转，
 *          pushState 同步 hash（不触发滚动），setTimeout(0) 滚动复位兜底；
 *          仅拦 a[data-nav][href^="#"]（data-nav 路由型导航），纯 hash 路由 demo 不受影响。
 *
 * 幂等：所有修正均为幂等，重复执行不会产生副作用
 * 返回：{ html, fixCount }
 */
function applyAnnotationInfrastructureFixes(html, appJsContent = '') {
  let fixCount = 0;
  // 注意：BUTTON 已移出 inlineTags（first-round-bplus-guarantee-v2）
  //   根因：codex-dsf 38 个 BUTTON 上 data-element-id 实测 D8/D10 全 pass，标注引擎对 BUTTON 用绝对定位创建 .l3-dot
  //   保留：input/a/span/i/label/select/textarea（这些元素 .l3-dot 确实 rect=0x0）
  const inlineTags = ['input', 'a', 'span', 'i', 'label', 'select', 'textarea'];

  // ===== C2: 页面隐藏机制统一（覆盖 P021）=====
  // 扫描 [data-page-id] 元素的 style="display:none"，改为 hidden 属性
  const pageTagRegex = /<[^>]*\bdata-page-id\s*=\s*["'][^"']*["'][^>]*>/gi;
  let c2Count = 0;
  html = html.replace(pageTagRegex, (tag) => {
    const styleMatch = tag.match(/\sstyle\s*=\s*["']([^"']*)["']/i);
    if (!styleMatch || !/display\s*:\s*none/i.test(styleMatch[1])) return tag;
    const oldStyle = styleMatch[1];
    const newStyle = oldStyle.replace(/display\s*:\s*none;?\s*/gi, '').trim();
    const hasHidden = /\shidden(?:\s*=\s*["'][^"']*["'])?(?=\s|>|\/)/i.test(tag);
    // 移除原 style 属性
    let newTag = tag.replace(/\s+style\s*=\s*["'][^"']*["']/i, '');
    if (newStyle) {
      newTag = newTag.replace(/(\s*\/?>)$/, ` style="${newStyle}"$1`);
    }
    if (!hasHidden) {
      newTag = newTag.replace(/(\s*\/?>)$/, ' hidden$1');
    }
    c2Count++;
    return newTag;
  });
  // 注入 [hidden]{display:none!important} 防御性 CSS（若不存在）
  const hiddenCssRegex = /\[hidden\]\s*\{[^}]*display\s*:\s*none\s*!important[^}]*\}/i;
  if (!hiddenCssRegex.test(html) && html.includes('</head>')) {
    html = html.replace('</head>', '\n<style>/* [demora-auto-fix-hidden] */\n[hidden] { display: none !important; }\n</style>\n</head>');
    log('  [OK] C2 P021 auto-fix: 注入 [hidden]{display:none!important} 防御性 CSS');
    fixCount++;
  }
  if (c2Count > 0) {
    log(`  [OK] C2 P021 auto-fix: ${c2Count} 个 [data-page-id] 隐藏机制统一为 hidden 属性`);
    fixCount += c2Count;
  }

  // ===== C6: 移除首屏 P01 hidden 残留（覆盖 P026）=====
  // 注意：必须在 C2 之后执行，C2 可能为非首屏页面添加 hidden，C6 仅移除第一个 [data-page-id] 的 hidden
  const firstPageMatch = html.match(/<[^>]*\bdata-page-id\s*=\s*["'][^"']*["'][^>]*>/i);
  if (firstPageMatch) {
    const firstPageTag = firstPageMatch[0];
    if (/\shidden(?:\s*=\s*["'][^"']*["'])?(?=\s|>|\/)/i.test(firstPageTag)) {
      const newTag = firstPageTag.replace(/\s+hidden(?:\s*=\s*["'][^"']*["'])?/i, '');
      html = html.replace(firstPageTag, newTag);
      log('  [OK] C6 P026 auto-fix: 移除首屏页面 P01 的 hidden 属性');
      fixCount++;
    }
  }

  // ===== C5: 自动添加 data-annotation-root（覆盖 P025）=====
  // 注意：需剥离 HTML 注释后再检测，避免注释中的 "data-annotation-root" 文字导致假阳性
  // （与 pre-audit-check.mjs checkP025 的注释剥离逻辑保持一致）
  const htmlNoCommentsC5 = html.replace(/<!--[\s\S]*?-->/g, '');
  if (!/data-annotation-root/i.test(htmlNoCommentsC5)) {
    const mainMatch = html.match(/<main\b([^>]*)>/i);
    if (mainMatch && !/data-annotation-root/i.test(mainMatch[1])) {
      html = html.replace(/<main\b([^>]*)>/i, '<main$1 data-annotation-root>');
      log('  [OK] C5 P025 auto-fix: 为 <main> 注入 data-annotation-root 属性');
      fixCount++;
    } else {
      const bodyMatch = html.match(/<body\b([^>]*)>/i);
      if (bodyMatch && !/data-annotation-root/i.test(bodyMatch[1])) {
        html = html.replace(/<body\b([^>]*)>/i, '<body$1 data-annotation-root>');
        log('  [OK] C5 P025 auto-fix: 为 <body> 注入 data-annotation-root 属性');
        fixCount++;
      }
    }
  }

  // ===== C1: Nav link href 唯一化（覆盖 P019/P022）=====
  // 收集所有带 data-nav 属性的元素（含其 href）
  const navLinkRegex = /<[^>]*\bdata-nav\s*=\s*["']([^"']+)["'][^>]*>/gi;
  const navLinks = [];
  let navMatch;
  while ((navMatch = navLinkRegex.exec(html)) !== null) {
    const fullTag = navMatch[0];
    const navId = navMatch[1];
    const hrefMatch = fullTag.match(/\shref\s*=\s*["']([^"']*)["']/i);
    const href = hrefMatch ? hrefMatch[1] : '';
    navLinks.push({ index: navMatch.index, fullTag, navId, href });
  }
  const hrefCount = {};
  for (const link of navLinks) {
    hrefCount[link.href] = (hrefCount[link.href] || 0) + 1;
  }
  const usedHrefs = new Set();
  for (const link of navLinks) {
    if (hrefCount[link.href] === 1 && link.href !== '#' && link.href !== '') {
      usedHrefs.add(link.href);
    }
  }
  // 从后向前替换（保持索引稳定）
  let c1Count = 0;
  for (let i = navLinks.length - 1; i >= 0; i--) {
    const link = navLinks[i];
    if (hrefCount[link.href] > 1 || link.href === '#' || link.href === '') {
      const baseId = link.navId || 'nav';
      let newHref = `#${baseId}`;
      let suffix = 1;
      while (usedHrefs.has(newHref)) {
        suffix++;
        newHref = `#${baseId}${suffix}`;
      }
      usedHrefs.add(newHref);
      let newTag;
      if (/\shref\s*=/i.test(link.fullTag)) {
        newTag = link.fullTag.replace(/\shref\s*=\s*["'][^"']*["']/i, ` href="${newHref}"`);
      } else {
        newTag = link.fullTag.replace(/(\s*\/?>)$/, ` href="${newHref}"$1`);
      }
      html = html.slice(0, link.index) + newTag + html.slice(link.index + link.fullTag.length);
      c1Count++;
    }
  }
  if (c1Count > 0) {
    log(`  [OK] C1 P019/P022 auto-fix: 修正 ${c1Count} 个 nav link href 为唯一值`);
    fixCount += c1Count;
  }

  // ===== C3: data-zone-id 添加 anno-zone 类（覆盖 P024）=====
  const zoneTagRegex = /<[^>]*\bdata-zone-id\s*=\s*["'][^"']*["'][^>]*>/gi;
  let c3Count = 0;
  html = html.replace(zoneTagRegex, (tag) => {
    if (/class\s*=\s*["'][^"']*\banno-zone\b[^"']*["']/i.test(tag)) return tag;
    c3Count++;
    if (/class\s*=\s*["']/i.test(tag)) {
      return tag.replace(/(class\s*=\s*["'])([^"']*)(["'])/i, (m, pre, val, post) => {
        const newVal = val + (val === '' || val.endsWith(' ') ? '' : ' ') + 'anno-zone';
        return pre + newVal + post;
      });
    }
    return tag.replace(/(\s*\/?>)$/, ' class="anno-zone"$1');
  });
  if (c3Count > 0) {
    log(`  [OK] C3 P024 auto-fix: 为 ${c3Count} 个 data-zone-id 容器添加 anno-zone 类`);
    fixCount += c3Count;
  }

  // ===== C20: 表格结构元素上的 data-element-id 自动迁移（v5.23 新增）=====
  // 根因（UAT0824 codex-dsf-p3 P06 表格前两行所有字段挤入第一列）：
  //   ① data-element-id 落在 tr 上时，注入样式 [data-element-id]{display:inline-flex}
  //     覆盖 tr 原生 display:table-row → 整行坍塌；
  //   ② 标注引擎把 <span class="l3-dot"> 直插 tr 内部 → 非法表格子节点，进一步破坏结构。
  // 方案：把 data-element-id（及关联的 data-action 交互属性，若有）迁移到行内第一个
  //   交互子元素（button/a/select/input，且自身无 data-element-id，防属性重复）；
  //   行内无交互子元素时包裹该行第一个 td/th 的内容为 <span data-element-id="...">
  //   （保持表格结构合法），迁移后原表格元素移除该属性。
  // 配套（双保险）：annotation-styles.css v5.23 表格结构 display 豁免 + annotation-engine.js
  //   v5.23 dot 安全注入——动态渲染的表格行无法被本静态规则覆盖，由 CSS/引擎运行时兜底。
  // 幂等：迁移后表格元素不再含 data-element-id，重复运行不再命中。
  // 注意：须在 C4 之前执行——迁移目标落在 a/input/span 等内联元素上时，需随即被 C4
  //   包裹 div（与原生内联标注同形态），保证重复运行输出稳定（幂等）。
  let c20Count = 0;
  const tableStructRegex = /<(tr|td|th|tbody|thead)\b([^>]*?)>/gi;
  const c20Matches = [];
  let c20M;
  while ((c20M = tableStructRegex.exec(html)) !== null) {
    const attrs = c20M[2] || '';
    if (!/\sdata-element-id\s*=\s*["'][^"']*["']/i.test(attrs)) continue;
    const idMatch = attrs.match(/\sdata-element-id\s*=\s*["']([^"']*)["']/i);
    c20Matches.push({
      index: c20M.index,
      fullTag: c20M[0],
      tagName: c20M[1].toLowerCase(),
      elementId: idMatch ? idMatch[1] : '',
    });
  }
  // 从后向前替换（保持索引稳定，与 C4 同款策略）
  for (let i = c20Matches.length - 1; i >= 0; i--) {
    const match = c20Matches[i];
    const openEnd = match.index + match.fullTag.length;
    // 定位元素区间（开标签 → 同名闭标签；与 C7 同款简化假设：同标签不嵌套，
    // 区间截断最坏情况是漏迁移，不会误迁移）
    const closeRe = new RegExp(`</${match.tagName}\\s*>`, 'i');
    const closeM = html.slice(openEnd).match(closeRe);
    if (!closeM) continue;
    const regionStart = openEnd;
    const regionEnd = openEnd + closeM.index;
    const region = html.slice(regionStart, regionEnd);
    // 收集要迁移的属性：data-element-id + 关联 data-action（若有）
    const actionMatch = match.fullTag.match(/\sdata-action\s*=\s*(["'])([^"']*)\1/i);
    let attrText = ` data-element-id="${match.elementId}"`;
    if (actionMatch) attrText += ` data-action="${actionMatch[2]}"`;
    // 目标1：行内第一个交互子元素（button/a/select/input，跳过已有 data-element-id 的，防属性重复）
    const interactiveRe = /<(button|a|select|input)\b[^>]*>/gi;
    let target = null;
    let im;
    while ((im = interactiveRe.exec(region)) !== null) {
      if (/\sdata-element-id\s*=\s*["'][^"']*["']/i.test(im[0])) continue;
      target = { start: regionStart + im.index, tag: im[0] };
      break;
    }
    if (target) {
      // 属性注入到交互元素开标签尾部（与 C12 补写 data-open-modal 同款手法）
      const newTargetTag = target.tag.replace(/(\s*\/?>)$/, attrText + '$1');
      html = html.slice(0, target.start) + newTargetTag + html.slice(target.start + target.tag.length);
    } else {
      // 目标2：包裹第一个 td/th 的内容为 <span data-element-id="...">
      //   tr/tbody/thead → 行内第一个单元格的内容；td/th → 自身内容
      let cellStart = null;
      let cellInner = '';
      if (match.tagName === 'td' || match.tagName === 'th') {
        cellStart = regionStart;
        cellInner = region;
      } else {
        const cellM = region.match(/<(td|th)\b[^>]*>/i);
        if (cellM) {
          const cellTag = cellM[1].toLowerCase();
          const cellOpenStart = regionStart + cellM.index;
          const cellOpenEnd = cellOpenStart + cellM[0].length;
          const cellCloseM = html.slice(cellOpenEnd).match(new RegExp(`</${cellTag}\\s*>`, 'i'));
          if (cellCloseM) {
            cellStart = cellOpenEnd;
            cellInner = html.slice(cellOpenEnd, cellOpenEnd + cellCloseM.index);
          }
        }
      }
      if (cellStart === null) {
        log(`  [WARN] C20: 表格元素 ${match.tagName} 上的 data-element-id="${match.elementId}" 行内无交互子元素且无单元格，跳过迁移`);
        continue;
      }
      const wrapped = `<span${attrText}>${cellInner}</span>`;
      html = html.slice(0, cellStart) + wrapped + html.slice(cellStart + cellInner.length);
    }
    // 原表格元素移除已迁移属性（data-element-id 必删；data-action 已迁则同删）
    let cleanedTag = match.fullTag.replace(/\s+data-element-id\s*=\s*["'][^"']*["']/i, '');
    if (actionMatch) cleanedTag = cleanedTag.replace(/\s+data-action\s*=\s*["'][^"']*["']/i, '');
    html = html.slice(0, match.index) + cleanedTag + html.slice(match.index + match.fullTag.length);
    c20Count++;
  }
  if (c20Count > 0) {
    log(`  [OK] C20 表格结构标注迁移: 为 ${c20Count} 个表格元素上的 data-element-id 迁移至行内安全位置`);
    fixCount += c20Count;
  }

  // ===== C4: data-element-id 内联元素包裹 div（覆盖 P023）=====
  const inlinePattern = inlineTags.join('|');
  const inlineElemRegex = new RegExp(
    `<(${inlinePattern})\\b([^>]*?\\sdata-element-id\\s*=\\s*["']([^"']+)["'][^>]*?)(\\s*\\/?)>`,
    'gi'
  );
  const inlineMatches = [];
  let inlineM;
  while ((inlineM = inlineElemRegex.exec(html)) !== null) {
    inlineMatches.push({
      index: inlineM.index,
      fullMatch: inlineM[0],
      tag: inlineM[1].toLowerCase(),
      elementId: inlineM[3],
      selfClose: inlineM[4] && inlineM[4].includes('/')
    });
  }
  // 从后向前替换（保持索引稳定）
  let c4Count = 0;
  for (let i = inlineMatches.length - 1; i >= 0; i--) {
    const match = inlineMatches[i];
    const blockEnd = match.index + match.fullMatch.length;
    if (match.selfClose) {
      const cleanedOpen = match.fullMatch.replace(/\s+data-element-id\s*=\s*["'][^"']*["']/i, '');
      const newBlock = `<div data-element-id="${match.elementId}">${cleanedOpen}</div>`;
      html = html.slice(0, match.index) + newBlock + html.slice(blockEnd);
      c4Count++;
    } else {
      const closeRegex = new RegExp(`</${match.tag}\\s*>`, 'i');
      const subHtml = html.slice(blockEnd);
      const closeMatch = subHtml.match(closeRegex);
      if (!closeMatch) continue; // 找不到结束标签，跳过
      const fullBlockEnd = blockEnd + closeMatch.index + closeMatch[0].length;
      const innerContent = html.slice(blockEnd, fullBlockEnd);
      const cleanedOpen = match.fullMatch.replace(/\s+data-element-id\s*=\s*["'][^"']*["']/i, '');
      const newBlock = `<div data-element-id="${match.elementId}">${cleanedOpen}${innerContent}</div>`;
      html = html.slice(0, match.index) + newBlock + html.slice(fullBlockEnd);
      c4Count++;
    }
  }
  if (c4Count > 0) {
    log(`  [OK] C4 P023 auto-fix: 为 ${c4Count} 个内联元素上的 data-element-id 包裹 div`);
    fixCount += c4Count;
  }

  // ===== C9: 剥离 display:none / hidden 元素的 data-element-id（first-round-bplus-guarantee-v2 新增）=====
  // 根因：tw-dsf2 首轮 D10 L3 dots 8 个未激活，隐藏 placeholder 元素（style="display:none" 或 hidden 属性）
  //       含 data-element-id → 标注引擎为这些元素创建 .l3-dot，但因父元素 display:none 导致 .l3-dot 也不可见
  // 方案：扫描同时含"display:none"或"hidden 属性"且带 data-element-id 的開标签，剥离其 data-element-id 属性
  // 排除：[data-page-id] 元素（页面切换机制，由 C2 统一为 hidden 属性 + C6 处理首屏）
  //   → 仅剥离非 [data-page-id] 元素的 data-element-id
  // 注意：C9 须在 C2 之后执行（C2 将 display:none 改为 hidden，C9 需同时识别两种形式）
  // 幂等：剥离是幂等的（已剥离的不会再匹配 data-element-id）
  let c9Count = 0;
  // 匹配同时含 display:none/hidden 且含 data-element-id 的開标签
  //   情况 A：style="...display:none..." + data-element-id（任意顺序）
  //   情况 B：hidden 属性 + data-element-id（任意顺序）
  const hiddenAnnoRegex = /<(\w+)(\s[^>]*?)>/gi;
  let c9M;
  const c9Matches = [];
  while ((c9M = hiddenAnnoRegex.exec(html)) !== null) {
    const tagName = c9M[1];
    const attrs = c9M[2] || '';
    const fullTag = c9M[0];
    // 必须含 data-element-id
    if (!/\sdata-element-id\s*=\s*["'][^"']*["']/i.test(attrs)) continue;
    // 排除 [data-page-id]（页面切换机制）
    if (/\sdata-page-id\s*=\s*["'][^"']*["']/i.test(attrs)) continue;
    // 必须含 display:none 或 hidden 属性
    const hasDisplayStyle = /\sstyle\s*=\s*["'][^"']*display\s*:\s*none[^"']*["']/i.test(attrs);
    const hasHiddenAttr = /(?:^|\s)hidden(?:\s*=\s*["'][^"']*["'])?(?=\s|>|\/)/i.test(attrs);
    if (!hasDisplayStyle && !hasHiddenAttr) continue;
    // 提取 data-element-id 值（用于日志）
    const idMatch = attrs.match(/\sdata-element-id\s*=\s*["']([^"']*)["']/i);
    c9Matches.push({
      index: c9M.index,
      fullTag: fullTag,
      elementId: idMatch ? idMatch[1] : '',
    });
  }
  // 从后向前替换（保持索引稳定）
  for (let i = c9Matches.length - 1; i >= 0; i--) {
    const match = c9Matches[i];
    const cleanedTag = match.fullTag.replace(/\s+data-element-id\s*=\s*["'][^"']*["']/i, '');
    html = html.slice(0, match.index) + cleanedTag + html.slice(match.index + match.fullTag.length);
    c9Count++;
  }
  if (c9Count > 0) {
    log(`  [OK] C9 P023-hidden auto-fix: 剥离 ${c9Count} 个 display:none/hidden 元素的 data-element-id 属性（避免 D10 L3 dots 不可见）`);
    fixCount += c9Count;
  }

  // ===== C10: 移除空 .l2-marker（first-round-bplus-guarantee-v2 新增）=====
  // 根因：AI 写 HTML 时插入空 <span class="l2-marker"></span>（textContent 为空），
  //       标注引擎 ensureMarkers 检测到已存在 .l2-marker 则跳过不填充数字序号
  //       → D5_l2_marker_seq 检测到 marker 无序号 → 1/20 fail
  // 方案：扫描 class 含 l2-marker 且 textContent 为空（<span ...></span>）的元素，
  //       移除整个 span，让标注引擎 ensureMarkers 自动创建带数字序号的 marker
  // 正则：匹配 <span class="...l2-marker..."></span>（开闭标签紧邻或仅含空白）
  // 幂等：移除是幂等的（已移除的不会再匹配）
  const emptyL2MarkerRegex = /<span\s+[^>]*\bclass\s*=\s*["'][^"']*\bl2-marker\b[^"']*["'][^>]*>\s*<\/span>/gi;
  let c10Count = 0;
  html = html.replace(emptyL2MarkerRegex, () => {
    c10Count++;
    return '';
  });
  if (c10Count > 0) {
    log(`  [OK] C10 auto-fix: 移除 ${c10Count} 个空 .l2-marker，让引擎自动创建带数字序号的 marker`);
    fixCount += c10Count;
  }

  // ===== C11: 重复 data-element-id 警告（first-round-bplus-guarantee-v2 新增，不自动修正）=====
  // 根因：动态表格行模板复用同一 data-element-id，renderReport/renderCaseList 生成 N 行时 id 重复
  //       → 标注引擎 querySelector('[data-element-id="xxx"]') 只返回第一个匹配
  //       → D10 L3 dots 只激活第一个匹配的行，其余行无标注
  // 方案：静态扫描 HTML 中所有 data-element-id 值，统计重复，WARN 提示
  // 注意：不自动修正（动态表格行模板的 id 重复在静态 HTML 中可能表现为模板字符串占位符，
  //       如 data-element-id="case-row-{{id}}"，静态扫描不会判重复；只有真重复才 WARN）
  //       AI 需手动检查动态渲染逻辑，确保每行用唯一 id
  // 实现：去除 script/style/comment 后扫描，避免 JS 模板字符串中的占位符导致假阳性
  const cleanHtmlC11 = html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const elementIdRegexC11 = /\bdata-element-id\s*=\s*["']([^"']+)["']/gi;
  const elementIdCounts = {};
  let c11M;
  while ((c11M = elementIdRegexC11.exec(cleanHtmlC11)) !== null) {
    const id = c11M[1];
    elementIdCounts[id] = (elementIdCounts[id] || 0) + 1;
  }
  const duplicateIds = Object.keys(elementIdCounts).filter(id => elementIdCounts[id] > 1);
  if (duplicateIds.length > 0) {
    const totalDup = duplicateIds.reduce((s, id) => s + elementIdCounts[id], 0);
    log(`  [WARN] C11: 发现 ${duplicateIds.length} 个重复的 data-element-id（共 ${totalDup} 次出现：${duplicateIds.slice(0, 3).map(id => '"' + id + '" x' + elementIdCounts[id]).join(', ')}${duplicateIds.length > 3 ? '...' : ''}），D10 L3 dots 只激活第一个匹配。修复：动态表格行模板用唯一 id`);
  }

  // ===== C7: 标注元素在页面外 WARN（覆盖 P020，不自动修正）=====
  // 去除 script/style/comment 后扫描，避免模板字符串导致假阳性
  const cleanHtml = html
    .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  // 提取 [data-page-id] 元素的范围（简化：匹配 open tag 到 close tag，假设不嵌套）
  const pageRanges = [];
  const pageOpenRe = /<(\w+)[^>]*\bdata-page-id\s*=\s*["']([^"']+)["'][^>]*>/gi;
  let pageM;
  while ((pageM = pageOpenRe.exec(cleanHtml)) !== null) {
    const tagName = pageM[1].toLowerCase();
    const openEnd = pageM.index + pageM[0].length;
    const closeRe = new RegExp(`</${tagName}\\s*>`, 'i');
    const subHtml = cleanHtml.slice(openEnd);
    const closeM = subHtml.match(closeRe);
    if (closeM) {
      pageRanges.push({
        start: pageM.index,
        end: openEnd + closeM.index + closeM[0].length
      });
    }
  }
  const orphanElements = [];
  const annoRe = /<\w+[^>]*\bdata-(?:zone|element)-id\s*=\s*["']([^"']+)["'][^>]*>/gi;
  let annoM;
  while ((annoM = annoRe.exec(cleanHtml)) !== null) {
    const inPage = pageRanges.some(r => annoM.index >= r.start && annoM.index < r.end);
    if (!inPage) {
      orphanElements.push(annoM[1]);
    }
  }
  if (orphanElements.length > 0) {
    log(`  [WARN] P020: ${orphanElements.length} 个标注元素不在 [data-page-id] 内（AI 需手动移入页面）：${orphanElements.slice(0, 3).join(', ')}${orphanElements.length > 3 ? '...' : ''}`);
  }

  // ===== C12: modal 触发器契约归一（v5.18 P0-C3，升级 C8 为自动修正）=====
  // 根因：modal 容器存在但触发按钮只有 onclick="openModal('x')" 或 data-action="openModal:x"，
  //       骨架委托只认 data-open-modal 属性 → 弹窗打不开 → D3 弹窗闭环 fail（college 单维度 10+ 轮主因）
  // 方案：从 onclick/data-action 反解 modal id，自动补写 data-open-modal="x"
  // 幂等：已有 data-open-modal 则跳过；仅补属性不改行为，误判时 diagnose 仍确诊，不引入新失败模式
  const modalClassRegex = /class\s*=\s*["'](?:[^"']*\s)?modal(?:\s[^"']*)?["']/gi;
  const modalAttrRegex = /\bdata-modal\b/i;
  const modalCount = (html.match(modalClassRegex) || []).length + (modalAttrRegex.test(html) ? 1 : 0);
  let c12Count = 0;
  if (modalCount > 0) {
    // 情形1：onclick="...openModal('xxx')..." 但无 data-open-modal
    html = html.replace(/<\w+\b[^>]*\bonclick\s*=\s*["'][^"']*?\bopenModal\(\s*['"]([^'"]+)['"]\s*\)[^>]*>/gi, (m, modalId) => {
      if (/\bdata-open-modal\s*=/i.test(m)) return m;
      c12Count++;
      return m.replace(/\s*\/?>$/, ` data-open-modal="${modalId}">`);
    });
    // 情形2：data-action="openModal:xxx" / data-action="openModal('xxx')" 但无 data-open-modal
    html = html.replace(/<\w+\b[^>]*\bdata-action\s*=\s*["']\s*openModal\s*[:(]\s*['"]?([^'"):>\s"']+)['"]?\s*\)?\s*["'][^>]*>/gi, (m, modalId) => {
      if (/\bdata-open-modal\s*=/i.test(m)) return m;
      c12Count++;
      return m.replace(/\s*\/?>$/, ` data-open-modal="${modalId}">`);
    });
  }
  if (c12Count > 0) {
    log(`  [OK] C12 auto-fix: ${c12Count} 个 modal 触发器从 onclick/data-action 反解补写 data-open-modal（升级 C8）`);
    fixCount += c12Count;
  }

  // ===== C13: 标注引擎未加载检测（v5.18 P0-A3 新增）=====
  // 根因：P013 升级为 FAIL 后，data-zone-id 存在但 .l2-marker 缺失 = 标注引擎未加载
  //       → enhance-prototype 应在注入前检测 [demora-annotation-js] 标记 + 脚本引用
  //       → 若缺失则由后续 step 3（INJECT_JS_START 标记检查）自动补注入
  // 方案：检测注入标记和脚本引用是否缺失，WARN 提示
  //       实际注入由主流程 step 3（INJECT_JS_START 幂等检查）自动完成，此处仅检测告警
  // 幂等：检测是幂等的；注入由 step 3 的 INJECT_JS_START 标记保证幂等
  // 注意：C13 在 applyAnnotationInfrastructureFixes 内运行（注入前），此时标记应不存在
  //       若标记已存在（enhance-prototype 重复运行）则跳过；若不存在则 step 3 将自动注入
  const c13HasMarker = html.includes(INJECT_JS_START);
  const c13HasScriptRef = html.includes('annotation-engine.js') || html.includes('annotation-engine');
  if (!c13HasMarker || !c13HasScriptRef) {
    const missingParts = [];
    if (!c13HasMarker) missingParts.push('[demora-annotation-js] 注入标记');
    if (!c13HasScriptRef) missingParts.push('annotation-engine.js 脚本引用');
    log(`  [WARN] C13: 标注引擎未加载检测——${missingParts.join(' + ')}缺失，将由后续 step 3 自动补注入`);
  }

  // ===== C8: 缺 data-open-modal 触发器 WARN（C12 归一后仍缺失的兜底）=====
  const triggerCount = (html.match(/\bdata-open-modal\s*=/gi) || []).length;
  if (modalCount > 0 && triggerCount === 0) {
    log(`  [WARN] P017: 存在 ${modalCount} 个 modal 容器但无 [data-open-modal] 触发器（AI 需手动添加 data-open-modal 属性到触发按钮）`);
  }

  // ===== C15: modal 容器无关闭控件 WARN（v5.18 P0-C3，保持 WARN 不注入 UI）=====
  // 关闭按钮的样式/位置属设计决策，交给 diagnose-runtime 确诊后由 AI 修复（不自动注入 UI 元素）
  // v5.18 P0-A3：原 C13 编号让渡给"标注引擎未加载检测"（A3 优先级更高），此检测项顺移为 C15
  if (modalCount > 0) {
    const hasCloseControl = /\bdata-close\b|\bdata-close-modal\b|class\s*=\s*["'][^"']*\bclose\b/i.test(html);
    if (!hasCloseControl) {
      log('  [WARN] C15: 存在 modal 容器但未检测到关闭控件（[data-close]/[data-close-modal]/.close），D3 弹窗闭环可能失败。请为弹窗添加关闭按钮（样式/位置由你设计）');
    }
  }

  // ===== C14: __ANNOTATION_DATA__ id 去重校验（v5.18 P0-C3，对齐 R-9 契约，静态确定可判）=====
  // 根因：__ANNOTATION_DATA__ 中 L2/L3 id 重复 → 标注面板-页面协同错位（D9）/ 激活失败（D10）
  // 仅 WARN 不修正（id 命名属数据设计，交给 AI）；静态 JSON 可判，确定性
  const annoDataM = html.match(/__ANNOTATION_DATA__\s*=\s*(\{[\s\S]*?\})\s*;/);
  if (annoDataM) {
    try {
      const annoData = JSON.parse(annoDataM[1]);
      const annoIds = [];
      const collectIds = (obj) => {
        if (!obj) return;
        if (Array.isArray(obj)) { obj.forEach(collectIds); return; }
        if (typeof obj === 'object') {
          if (obj.zoneId) annoIds.push(String(obj.zoneId));
          if (obj.elementId) annoIds.push(String(obj.elementId));
          if (obj.id) annoIds.push(String(obj.id));
          Object.values(obj).forEach(collectIds);
        }
      };
      collectIds(annoData);
      const annoIdCounts = {};
      annoIds.forEach(id => { annoIdCounts[id] = (annoIdCounts[id] || 0) + 1; });
      const dupAnnoIds = Object.keys(annoIdCounts).filter(id => annoIdCounts[id] > 1);
      if (dupAnnoIds.length > 0) {
        log(`  [WARN] C14: __ANNOTATION_DATA__ 中 ${dupAnnoIds.length} 个 id 重复（${dupAnnoIds.slice(0, 3).join(', ')}${dupAnnoIds.length > 3 ? '...' : ''}），标注面板-页面协同可能错位（D9/D10）。请确保 L2/L3 id 全局唯一`);
      }
    } catch (e) { /* 含模板占位符导致 JSON 解析失败，跳过（运行时再确诊） */ }
  }

  // ===== C16: 手写 .l3-dot 全删（v2.1 新增，D10 根因 C 类前置）=====
  // 根因：AI 手写静态 .l3-dot 与引擎运行时注入冲突（p8 l3DotCount 54 vs dataElementIdCount 40；
  //       p5 删 35 个手写 dot 后 1 轮 pass）。引擎为每个 data-element-id 自动创建 dot
  //       （ensureMarkers 的 :scope > .l3-dot 检查），静态出现的 .l3-dot 均为手写冗余
  // 方案：匹配 class 含 l3-dot 的 <span>...</span>（非自闭合，含任意内容），整标签删除
  // 安全性：引擎用 createElement 动态创建 dot，面板模板字符串仅含 l1-tag/l2-tag/l3-tag class，
  //         本正则不会误伤已注入的引擎代码（重复运行幂等安全）
  // 幂等：删除是幂等的（已删除的不会再匹配）
  const handwrittenL3DotRegex = /<span\s+[^>]*\bclass\s*=\s*["'][^"']*\bl3-dot\b[^"']*["'][^>]*>[\s\S]*?<\/span>/gi;
  let c16Count = 0;
  html = html.replace(handwrittenL3DotRegex, () => {
    c16Count++;
    return '';
  });
  if (c16Count > 0) {
    log(`  [OK] C16 auto-fix: 移除 ${c16Count} 个手写 .l3-dot（引擎将自动创建）`);
    fixCount += c16Count;
  }

  // ===== C17: 重复 .l2-marker 去重（v2.1 新增，D10 根因 C 类前置）=====
  // 根因：AI 在同一 data-zone-id 容器内手写多个 .l2-marker（p1 每 zone 2 个：声明 3 DOM 6），
  //       引擎 ensureMarkers 检测到已存在 marker 则跳过 → 重复 marker 不被引擎去重
  // 方案：每个 data-zone-id 容器内保留第一个手写 .l2-marker，删除其余
  // 实现：定位含 data-zone-id 的开标签 → 用同名闭标签确定容器区间（简化假设：同标签不嵌套，
  //       与 C7 pageRanges 同等强度；区间截断最坏情况是漏删，不会误删），
  //       区间内第 2+ 个 marker 收集后从后向前删除
  // 注意：须在 C10 之后执行（空 marker 已被移除，剩余均为有内容的手写 marker）
  // 幂等：去重后每 zone 仅 1 个 marker，重复执行不再命中
  const c17MarkerRegex = /<span\s+[^>]*\bclass\s*=\s*["'][^"']*\bl2-marker\b[^"']*["'][^>]*>[\s\S]*?<\/span>/gi;
  let c17Count = 0;
  {
    // Step 1: 定位所有 zone 容器区间（开标签 → 同名闭标签，与 C7 相同的简化假设）
    const zoneRanges = [];
    const zoneOpenRe = /<(\w+)[^>]*\bdata-zone-id\s*=\s*["'][^"']*["'][^>]*>/gi;
    let zoneM;
    while ((zoneM = zoneOpenRe.exec(html)) !== null) {
      const tagName = zoneM[1].toLowerCase();
      const openEnd = zoneM.index + zoneM[0].length;
      const closeRe = new RegExp(`</${tagName}\\s*>`, 'i');
      const closeM = html.slice(openEnd).match(closeRe);
      if (closeM) {
        zoneRanges.push({ start: zoneM.index, end: openEnd + closeM.index + closeM[0].length });
      }
    }
    // Step 2: 收集每个 zone 内第 2+ 个 marker 的删除区间（按起始位置去重，防嵌套 zone 重复收集）
    const removeByKey = new Map();
    for (const range of zoneRanges) {
      c17MarkerRegex.lastIndex = 0;
      let c17M;
      let seenInZone = 0;
      while ((c17M = c17MarkerRegex.exec(html)) !== null) {
        if (c17M.index <= range.start || c17M.index >= range.end) continue;
        seenInZone++;
        if (seenInZone > 1) {
          removeByKey.set(c17M.index, { start: c17M.index, end: c17M.index + c17M[0].length });
        }
      }
    }
    // Step 3: 从后向前删除（保持索引稳定）
    const removeRanges = Array.from(removeByKey.values()).sort((a, b) => b.start - a.start);
    for (const r of removeRanges) {
      html = html.slice(0, r.start) + html.slice(r.end);
      c17Count++;
    }
  }
  if (c17Count > 0) {
    log(`  [OK] C17 auto-fix: 移除 ${c17Count} 个重复 .l2-marker（每 zone 保留第一个，引擎自动补序号）`);
    fixCount += c17Count;
  }

  // ===== C18: modal 容器 hidden 归一为 style="display:none"（v2.3 新增，建议 2①）=====
  // 根因：v2.2 p6 实证——4 个 modal 用 hidden 属性，骨架 openModal 只清 display
  //       （el.style.display = ''）打不开 hidden 的 modal → D3 close fail + 级联失败
  // 方案：匹配 modal 容器开标签（class 含 modal 的 div/section）含独立 hidden 属性 →
  //       移除 hidden 并确保 style 含 display:none（已有 style 则追加/替换 display 值，
  //       无则加 style="display:none"）
  // 幂等：归一后 modal 开标签不再含独立 hidden 属性，重复运行 0 次
  let c18Count = 0;
  const modalHiddenRegex = /<(div|section)\b[^>]*\bclass\s*=\s*["'](?:[^"']*\s)?modal(?:\s[^"']*)?["'][^>]*>/gi;
  html = html.replace(modalHiddenRegex, (tag) => {
    // 独立 hidden 属性判定（与 C9 同款正则，不匹配 class="...hidden..." / data-hidden）
    const hasHiddenAttr = /(?:^|\s)hidden(?:\s*=\s*["'][^"']*["'])?(?=\s|>|\/)/i.test(tag);
    if (!hasHiddenAttr) return tag;
    c18Count++;
    // 移除 hidden 属性（与 C6 同款替换）
    let newTag = tag.replace(/\s+hidden(?:\s*=\s*["'][^"']*["'])?/i, '');
    // 确保 style 含 display:none（已有 style 则追加，无则新增 style="display:none"）
    const styleMatch = newTag.match(/\sstyle\s*=\s*(["'])([^"']*)\1/i);
    if (styleMatch) {
      const styleVal = styleMatch[2];
      if (!/display\s*:\s*none/i.test(styleVal)) {
        const trimmed = styleVal.trim().replace(/;?\s*$/, '');
        const newVal = trimmed ? trimmed + '; display:none' : 'display:none';
        newTag = newTag.replace(styleMatch[0], ' style="' + newVal + '"');
      }
    } else {
      newTag = newTag.replace(/(\s*\/?>)$/, ' style="display:none"$1');
    }
    return newTag;
  });
  if (c18Count > 0) {
    log(`  [OK] C18 auto-fix: ${c18Count} 个 modal 容器 hidden 属性归一为 style="display:none"（骨架 openModal 只清 display）`);
    fixCount += c18Count;
  }

  // ===== C19: P018 自动对齐——声明集与静态锚点集双向对齐（v2.4 新增，建议 3）=====
  // 依据：v2.3 p10 修复链实证——P018 FAIL（声明 L3 44 vs DOM 27）后 agent 人肉 3 分钟双向对齐
  //       （补 4 个静态锚点 + Node 脚本删动态行锚点残留 + 裁 __ANNOTATION_DATA__ 声明 44→31）。
  //       P018 的 fix_command 已写"enhance 自动处理"，本轮起名实相符。
  // 原则：静态锚点集为基准——剥离 script/style/comment 后的 data-zone-id（L2）/data-element-id（L3）
  //       全集为 S；__ANNOTATION_DATA__ 各页 L2/L3 数组条目的 id 全集为 D
  //       （schema 见 SKILL.md：{ P01: { name, L1, L2: [{id, zone, description}], L3: [{id, element, function, response}] } }）
  // 双向对齐（幂等：对齐后 D==S，重复运行 0 修正）：
  //   D−S（声明冗余）：声明有但静态 DOM 无，且 id 字符串在 index.html 全文与 app.js 中均仅出现于
  //        __ANNOTATION_DATA__ 块内（近似判断：动态行锚点已删的残留）→ 从声明裁剪该条目
  //   S−D（漏声明）：静态 DOM 有但声明无 → 在锚点所处页（[data-page-id]）的 L2/L3 数组
  //        生成骨架条目（id + zone/element 取元素文本前 20 字符，其余字段留空由 AI 补）
  // 保守边界（避免误删）：id 出现在 __ANNOTATION_DATA__ 块外（JS 模板字符串等，可能为动态注入）
  //        → 保留声明并 WARN（需人工确认 P018）
  // 写回：字符串级局部编辑（平衡括号定位条目对象后删除 / 在数组闭合 ] 前插入），
  //        不整体重序列化，最大限度保持原格式；应用后做语法校验，失败则整体回滚本轮编辑
  // 注意：C19 在 C9 之后执行——C9 已剥离隐藏元素的 data-element-id，其声明将被同步裁剪（保持一致性）
  // C19 与 P018 的关系：C19 在 enhance 阶段自动消化对齐，pre-audit P018 作为门禁兜底
  {
    const escRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // 平衡括号匹配：从 openIdx 的 { 或 [ 起，找配对的 } 或 ]（处理嵌套与字符串字面量）
    const matchBracket = (str, openIdx) => {
      let depth = 0, inS = false, sCh = '';
      for (let i = openIdx; i < str.length; i++) {
        const c = str[i];
        if (inS) {
          if (c === '\\') { i++; continue; }
          if (c === sCh) inS = false;
        } else {
          if (c === '"' || c === "'" || c === '`') { inS = true; sCh = c; }
          else if (c === '{' || c === '[') depth++;
          else if (c === '}' || c === ']') { depth--; if (depth === 0) return i; }
        }
      }
      return -1;
    };
    const c19Marker = 'window.__ANNOTATION_DATA__';
    const c19MarkerIdx = html.indexOf(c19Marker);
    if (c19MarkerIdx !== -1) {
      // Step 1: 平衡括号定位对象字面量块区间 [dataStart, dataEnd)（与 pre-audit P009/P018 同款扫描）
      let c19I = c19MarkerIdx + c19Marker.length;
      while (c19I < html.length && /[=\s]/.test(html[c19I])) c19I++;
      if (html[c19I] === '{') {
        const dataStart = c19I;
        const dataEndRaw = matchBracket(html, c19I);
        if (dataEndRaw !== -1) {
          const dataEnd = dataEndRaw + 1;
          let dataStr = html.slice(dataStart, dataEnd);
          // Step 2: 解析声明集 D（JS 对象字面量 key 无引号 → 受限 Function 解析，与 P009/P018 同款）
          let c19Data = null;
          try { c19Data = new Function('"use strict"; return (' + dataStr + ')')(); } catch (e) { c19Data = null; }
          if (c19Data && typeof c19Data === 'object') {
            const c19Raw = (c19Data.pages && typeof c19Data.pages === 'object' && !Array.isArray(c19Data.pages))
              ? c19Data.pages
              : c19Data;
            const c19MetaKeys = ['version', 'metadata', 'config', 'pages'];
            // Step 3: 静态锚点集 S（剥离 script/style/comment 后扫描 + 页面归属，C7 同款区间假设）
            const c19Clean = html
              .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '')
              .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
              .replace(/<!--[\s\S]*?-->/g, '');
            const c19PageRanges = [];
            const c19PageRe = /<(\w+)[^>]*\bdata-page-id\s*=\s*["']([^"']+)["'][^>]*>/gi;
            let c19PM;
            while ((c19PM = c19PageRe.exec(c19Clean)) !== null) {
              const tagName = c19PM[1].toLowerCase();
              const openEnd = c19PM.index + c19PM[0].length;
              const closeM = c19Clean.slice(openEnd).match(new RegExp('</' + tagName + '\\s*>', 'i'));
              if (closeM) c19PageRanges.push({ pageId: c19PM[2], start: c19PM.index, end: openEnd + closeM.index + closeM[0].length });
            }
            const c19StaticAnchors = new Map(); // id → { level, pageId }
            const c19AnchorRe = /\bdata-(zone|element)-id\s*=\s*["']([^"']+)["']/gi;
            let c19AM;
            while ((c19AM = c19AnchorRe.exec(c19Clean)) !== null) {
              const range = c19PageRanges.find(r => c19AM.index >= r.start && c19AM.index < r.end);
              c19StaticAnchors.set(c19AM[2], {
                level: c19AM[1] === 'zone' ? 'L2' : 'L3',
                // 页外锚点兜底归第一页（C7/P020 会另行告警孤儿锚点）
                pageId: range ? range.pageId : (c19PageRanges[0] ? c19PageRanges[0].pageId : null),
              });
            }
            // 声明集 D：id 全集（存在性对齐）
            const c19Declared = new Set();
            for (const pageKey of Object.keys(c19Raw)) {
              if (c19MetaKeys.includes(pageKey)) continue;
              const pageObj = c19Raw[pageKey];
              if (!pageObj || typeof pageObj !== 'object') continue;
              for (const lvl of ['L2', 'L3']) {
                if (!Array.isArray(pageObj[lvl])) continue;
                for (const card of pageObj[lvl]) {
                  if (card && card.id !== undefined) c19Declared.add(String(card.id));
                }
              }
            }
            // 文本编辑列表（位置均基于原始 dataStr，从后往前应用保索引稳定）
            const edits = []; // { start, end, text }（start==end 为纯插入，text=='' 为删除）
            const delRanges = []; // 已收集删除区间（嵌套同名 id 去重用）
            let c19Trimmed = 0;
            const c19Kept = [];
            // Step 4: D−S 裁剪（保守边界：id 仅在 __ANNOTATION_DATA__ 块内出现才裁）
            for (const id of c19Declared) {
              if (c19StaticAnchors.has(id)) continue; // 静态可见，无需处理
              // 保守检查：id 字符串在 html 全文（含 script 模板字符串）的出现位置必须全部落在块内
              let onlyInData = true;
              let pos = html.indexOf(id);
              while (pos !== -1) {
                if (pos < dataStart || pos >= dataEnd) { onlyInData = false; break; }
                pos = html.indexOf(id, pos + 1);
              }
              // app.js 模板字符串可能动态注入该锚点 → 同样保留
              if (onlyInData && appJsContent.includes(id)) onlyInData = false;
              if (!onlyInData) { c19Kept.push(id); continue; }
              // 定位块内所有 id: 'X' 字段 → 平衡括号扩展到条目对象 {…} → 收集删除区间
              const idFieldRe = new RegExp("\\bid\\s*:\\s*(['\"])(" + escRe(id) + ")\\1", 'g');
              let idm;
              while ((idm = idFieldRe.exec(dataStr)) !== null) {
                const objStart = dataStr.lastIndexOf('{', idm.index);
                if (objStart === -1) continue;
                const objEnd = matchBracket(dataStr, objStart);
                if (objEnd === -1 || objEnd < idm.index) continue;
                // 边界验证：条目须为数组内元素（后跟 , 或 ]，或前跟 , 或 [），否则定位可疑 → 安全降级保留
                const afterComma = dataStr.slice(objEnd + 1).match(/^\s*,/);
                const afterBracket = dataStr.slice(objEnd + 1).match(/^\s*\]/);
                const beforeComma = dataStr.slice(0, objStart).match(/,\s*$/);
                const beforeBracket = dataStr.slice(0, objStart).match(/\[\s*$/);
                if (!afterComma && !afterBracket && !beforeComma && !beforeBracket) { c19Kept.push(id); continue; }
                // 删除区间（优先删后置逗号 {…},；末元素则删前置逗号 ,{…}）
                let delStart = objStart, delEnd = objEnd + 1;
                if (afterComma) {
                  delEnd = objEnd + 1 + afterComma[0].length;
                  // 吞掉条目行自身的换行+缩进（避免删除后残留空行）
                  const preWs = dataStr.slice(0, delStart).match(/\n[ \t]*$/);
                  if (preWs) delStart -= preWs[0].length;
                } else {
                  const cIdx = dataStr.slice(0, objStart).lastIndexOf(',');
                  if (cIdx !== -1 && /^\s*$/.test(dataStr.slice(cIdx + 1, objStart))) delStart = cIdx;
                }
                // 嵌套同名 id 去重：新区间覆盖已有区间 → 移除旧区间；已被覆盖 → 跳过
                for (let k = delRanges.length - 1; k >= 0; k--) {
                  if (delRanges[k].start >= delStart && delRanges[k].end <= delEnd) {
                    const eo = edits.findIndex(e => e.start === delRanges[k].start && e.end === delRanges[k].end);
                    if (eo !== -1) { edits.splice(eo, 1); c19Trimmed--; }
                    delRanges.splice(k, 1);
                  }
                }
                if (delRanges.some(r => delStart >= r.start && delEnd <= r.end)) continue;
                delRanges.push({ start: delStart, end: delEnd });
                edits.push({ start: delStart, end: delEnd, text: '' });
                c19Trimmed++;
              }
            }
            // Step 5: S−D 补声明（按页分组，同页同 level 的多条目一次插入，避免重复键）
            const c19MissingByPage = new Map(); // pageId → [{ id, level, name }]
            for (const [id, anchor] of c19StaticAnchors) {
              if (c19Declared.has(id)) continue;
              if (!anchor.pageId) continue; // 无页面结构，跳过（C7/P020 兜底告警孤儿锚点）
              if (!c19MissingByPage.has(anchor.pageId)) c19MissingByPage.set(anchor.pageId, []);
              // name 取锚点元素文本（strip 嵌套标签）前 20 字符；空文本兜底 id（"就近标题"不做，近似）
              let name = '';
              const tagRe = new RegExp('<(\\w+)[^>]*\\bdata-(?:zone|element)-id\\s*=\\s*["\']' + escRe(id) + '["\'][^>]*>', 'i');
              const tm = c19Clean.match(tagRe);
              if (tm) {
                const openEnd = tm.index + tm[0].length;
                const closeM = c19Clean.slice(openEnd).match(new RegExp('</' + tm[1] + '\\s*>', 'i'));
                if (closeM) {
                  name = c19Clean.slice(openEnd, openEnd + closeM.index)
                    .replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 20);
                }
              }
              c19MissingByPage.get(anchor.pageId).push({ id, level: anchor.level, name: name || id });
            }
            const buildEntryText = (level, id, name) => {
              const safeId = id.replace(/'/g, "\\'");
              const safeName = name.replace(/'/g, "\\'");
              return level === 'L2'
                ? "{ id: '" + safeId + "', zone: '" + safeName + "', description: '' }"
                : "{ id: '" + safeId + "', element: '" + safeName + "', function: '', response: '' }";
            };
            let c19Added = 0;
            for (const [pageId, missing] of c19MissingByPage) {
              // 页对象文本定位（key 边界匹配，P01 不误匹配 P010）
              const pageRe = new RegExp('(^|[{,\\s])' + escRe(pageId) + '\\s*:\\s*\\{');
              const pmatch = dataStr.match(pageRe);
              if (!pmatch) {
                // 页对象缺失 → 顶层闭合 } 前新建页（含缺失 level 的数组，缩进近似）
                const l2Items = missing.filter(m => m.level === 'L2');
                const l3Items = missing.filter(m => m.level === 'L3');
                let pageText = ',\n  ' + pageId + ": {\n    name: '" + pageId + "'";
                if (l2Items.length) pageText += ',\n    L2: [\n      ' + l2Items.map(m => buildEntryText('L2', m.id, m.name)).join(',\n      ') + '\n    ]';
                if (l3Items.length) pageText += ',\n    L3: [\n      ' + l3Items.map(m => buildEntryText('L3', m.id, m.name)).join(',\n      ') + '\n    ]';
                pageText += '\n  }';
                edits.push({ start: dataStr.length - 1, end: dataStr.length - 1, text: pageText });
                c19Added += missing.length;
                continue;
              }
              const pBrace = pmatch.index + pmatch[0].length - 1; // 页对象 {（pmatch[0] 以 { 结尾）
              const pEnd = matchBracket(dataStr, pBrace);
              if (pEnd === -1) continue;
              for (const lvl of ['L2', 'L3']) {
                const items = missing.filter(m => m.level === lvl);
                if (items.length === 0) continue;
                const seg = dataStr.slice(pBrace, pEnd + 1);
                const arrM = seg.match(new RegExp('\\b' + lvl + '\\s*:\\s*\\['));
                if (arrM) {
                  const arrOpen = pBrace + arrM.index + arrM[0].length - 1; // [ 的绝对位置
                  const arrClose = matchBracket(dataStr, arrOpen);
                  if (arrClose === -1) continue;
                  const inner = dataStr.slice(arrOpen + 1, arrClose);
                  const entriesText = items.map(m => buildEntryText(lvl, m.id, m.name)).join(',\n');
                  if (inner.trim() === '') {
                    edits.push({ start: arrOpen + 1, end: arrClose, text: '\n      ' + entriesText + '\n    ' });
                  } else {
                    // 缩进对齐数组内已有条目（取首个条目的行首缩进，近似）
                    const indentM = inner.match(/\n([ \t]*)\S/);
                    const indent = indentM ? indentM[1] : '      ';
                    // 在最后一个条目 } 之后追加（保持逗号在行尾、闭合 ] 独立行的原格式；
                    // 无 } 时（非对象数组，防御）回退到 ] 前插入）
                    const lastBraceRel = inner.lastIndexOf('}');
                    if (lastBraceRel !== -1) {
                      const insertPos = arrOpen + 1 + lastBraceRel + 1;
                      edits.push({ start: insertPos, end: insertPos, text: ',' + '\n' + indent + entriesText });
                    } else {
                      edits.push({ start: arrClose, end: arrClose, text: ',' + '\n' + indent + entriesText });
                    }
                  }
                } else {
                  // 页对象无该数组 → 页对象闭合 } 前新建
                  const arrText = ',\n    ' + lvl + ': [\n      ' + items.map(m => buildEntryText(lvl, m.id, m.name)).join(',\n      ') + '\n    ]';
                  edits.push({ start: pEnd, end: pEnd, text: arrText });
                }
                c19Added += items.length;
              }
            }
            // Step 6: 从后往前应用编辑 + 语法校验（防文本编辑错位破坏 demo）+ 写回
            let c19Applied = false;
            if (edits.length > 0) {
              edits.sort((a, b) => b.start - a.start);
              let editedStr = dataStr;
              for (const e of edits) {
                editedStr = editedStr.slice(0, e.start) + e.text + editedStr.slice(e.end);
              }
              try {
                new Function('"use strict"; return (' + editedStr + ')')();
                dataStr = editedStr;
                c19Applied = true;
              } catch (e) {
                log('  [WARN] C19: __ANNOTATION_DATA__ 对齐后语法校验失败，已回滚本轮编辑（需人工确认 P018）：' + e.message);
                c19Trimmed = 0;
                c19Added = 0;
              }
            }
            if (c19Applied) {
              html = html.slice(0, dataStart) + dataStr + html.slice(dataEnd);
            }
            if (c19Trimmed > 0 || c19Added > 0) {
              log('  [OK] C19 auto-fix: P018 对齐——裁剪声明 ' + c19Trimmed + ' 条（动态锚点残留），补声明 ' + c19Added + ' 条（静态锚点缺声明）');
              fixCount += c19Trimmed + c19Added;
            } else if (c19Kept.length === 0) {
              log('  [OK] C19: 声明与静态锚点已一致');
            }
            c19Kept.slice(0, 5).forEach(id => {
              log("  [WARN] C19: 声明条目 '" + id + "' 在 DOM 静态不可见但可能为动态注入（保留，需人工确认 P018）");
            });
            if (c19Kept.length > 5) {
              log('  [WARN] C19: 其余 ' + (c19Kept.length - 5) + ' 条动态注入声明同样保留（需人工确认 P018）');
            }
          }
        }
      }
    }
  }

  return { html, fixCount };
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');
  const refsDir = findReferencesDir();

  log('======================================================================');
  log('enhance-prototype.mjs — 注入标注三件套 (v5.1 Shadow DOM 隔离)');
  log('======================================================================');

  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在，请先运行 generate-demo.mjs 并让 AI 填充内容');
    return { ok: false, error: 'demo/index.html not found' };
  }

  // v5.16 S-4 修复：APP_JS_SKELETON 防覆盖哨兵
  //   根因：generate-demo 写入事件委托骨架后，AI 在 Edit/Write app.js 时整体覆盖，骨架痕迹丢失
  //   修复：enhance-prototype 检测 app.js 是否保留骨架关键标记，缺失则 WARN + 记录到 conversation-log
  {
    const appJsPath = path.join(demoDir, 'assets', 'app.js');
    if (fs.existsSync(appJsPath)) {
      const content = fs.readFileSync(appJsPath, 'utf-8');
      const skeletonMarkers = [
        '事件委托',           // 骨架注释标记
        'closest(',           // 事件委托核心方法
        'data-page-id',       // route() 函数引用
        'style.display',      // display 切换（非 hidden）
        'demoraApplyFilter',  // v5.25 P1-1 正确样板：筛选全量重算原语（整体覆盖告警信号）
        'demoraSyncAnnotations' // v5.25 P1-1 正确样板：动态行标注同步原语
      ];
      const missingMarkers = skeletonMarkers.filter(m => !content.includes(m));
      if (missingMarkers.length > 0) {
        log(`[WARN] app.js 骨架痕迹缺失: ${missingMarkers.join(', ')}（AI 可能整体覆盖了骨架，建议保留事件委托 + display 切换模式）`);
        // 追加到 conversation-log.yaml
        // v5.25 P1-2：改走 lib/conversation-log.mjs 唯一写入通道（文件为只读，直接 appendFileSync 会 EPERM）
        try {
          appendConversationEntry(projectRoot, {
            actor: 'enhance-prototype',
            phase: 2,
            message: `app.js 骨架痕迹缺失 ${missingMarkers.join(', ')}（skeleton-integrity-warn）`,
          });
        } catch (e) { /* 忽略日志写入失败 */ }
      }
    }
  }

  // v5.14.19 C4 short-circuit：若 state.yaml 标记 annotation_injected=true 且 index.html 未变，跳过注入
  //   收益：AI 阶段 3-4 多次运行 enhance-prototype 时，若 index.html 未改则跳过读 CSS/Panel/JS + 注入逻辑
  //   失效条件：index.html mtime 或 size 变化（AI Edit 会更新 mtime → 自动失效）
  //   回退：args.force=true 强制重注入
  if (!args.force) {
    try {
      const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
      if (fs.existsSync(stateFile)) {
        const stateText = fs.readFileSync(stateFile, 'utf-8');
        const injectedMatch = stateText.match(/^\s*annotation_injected:\s*(\S+)/m);
        if (injectedMatch && injectedMatch[1] === 'true') {
          // annotation_injected=true，检查 index.html 是否变化
          const cacheFile = path.join(projectRoot, '.demora', '.enhance-cache.json');
          const stat = fs.statSync(indexPath);
          const cacheKey = `${stat.mtimeMs}|${stat.size}`;
          if (fs.existsSync(cacheFile)) {
            const cached = JSON.parse(fs.readFileSync(cacheFile, 'utf-8'));
            if (cached.key === cacheKey) {
              log('  [INFO] C4 short-circuit: annotation_injected=true 且 index.html 未变，跳过注入');
              log('  [INFO] 如需强制重注入，请传 --force 参数');
              return { ok: true, skipped: true, reason: 'index.html unchanged since last injection' };
            }
          }
        }
      }
    } catch (e) {
      // 短路检查失败（state.yaml 读取失败/stat 失败等），继续执行注入
    }
  }

  if (!refsDir) {
    log('[FAIL] 未找到 references 目录');
    return { ok: false, error: 'references dir not found' };
  }

  const annotationDir = path.join(refsDir, 'annotation');
  const cssPath = path.join(annotationDir, 'annotation-styles.css');
  const panelPath = path.join(annotationDir, 'annotation-panel.html');
  const jsPath = path.join(annotationDir, 'annotation-engine.js');

  for (const [label, fp] of [['CSS', cssPath], ['Panel', panelPath], ['JS', jsPath]]) {
    if (!fs.existsSync(fp)) {
      log(`[FAIL] 标注 ${label} 文件不存在: ${fp}`);
      return { ok: false, error: `annotation ${label} not found` };
    }
  }

  // 读取并分割 CSS（v5.1：主页面样式 + 面板样式）
  const fullCss = fs.readFileSync(cssPath, 'utf-8');
  const mainPageCss = extractCssSection(fullCss, 'demora-main-page-styles');
  const panelCss = extractCssSection(fullCss, 'demora-panel-styles');

  if (!mainPageCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-main-page-styles] 区段');
    return { ok: false, error: 'CSS section demora-main-page-styles not found' };
  }
  if (!panelCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-panel-styles] 区段');
    return { ok: false, error: 'CSS section demora-panel-styles not found' };
  }
  log('  [OK] CSS 分割完成: 主页面 ' + mainPageCss.length + ' 字符, 面板 ' + panelCss.length + ' 字符');

  const panelHtml = fs.readFileSync(panelPath, 'utf-8').trim();

  let html = fs.readFileSync(indexPath, 'utf-8');
  let injectCount = 0;

  // v5.18 Tier C: 标注基础设施自动修正（spec first-round-bplus-guarantee）
  //   在标注注入前自动修正 8 类基础设施问题（nav href/hidden/anno-zone/data-annotation-root 等）
  //   将首轮 B+ 率从 17% 提升到 >80%，不限制 AI 的设计自由度
  // v2.4：读取 app.js 内容传入 C19（P018 自动对齐的保守边界——动态注入 id 检测）
  let appJsContentForC19 = '';
  const appJsPathForC19 = path.join(demoDir, 'assets', 'app.js');
  if (fs.existsSync(appJsPathForC19)) {
    appJsContentForC19 = fs.readFileSync(appJsPathForC19, 'utf-8');
  }
  const autoFixResult = applyAnnotationInfrastructureFixes(html, appJsContentForC19);
  html = autoFixResult.html;
  const autoFixCount = autoFixResult.fixCount;

  // 1. 注入主页面 CSS 到 <head> 末尾（标记样式 + 激活态 padding）
  // v5.2.7：在 <style> 内额外添加 CSS 注释包裹标记，配合 check-structure.mjs S-6 排除正则
  if (!html.includes(INJECT_CSS_START)) {
    const cssBlock = `\n${INJECT_CSS_START}\n<style>\n${INJECT_CSS_INNER_START}\n${mainPageCss}\n${INJECT_CSS_INNER_END}\n</style>\n${INJECT_CSS_END}\n`;
    if (html.includes('</head>')) {
      html = html.replace('</head>', cssBlock + '</head>');
      injectCount++;
      log('  [OK] 注入主页面标记样式 -> <head>（含 S-6 内部标记）');
    } else {
      log('  [WARN] 未找到 </head>，跳过主页面 CSS 注入');
    }
  } else {
    log('  [INFO] 主页面 CSS 已注入（幂等跳过）');
  }

  // 2. 注入 Shadow DOM 宿主 + 面板内容到 </body> 前
  //    使用 <template> 元素承载面板 CSS+HTML，避免 </script> 字符串转义问题
  // v5.2.7：在面板 <style> 内额外添加 CSS 注释包裹标记
  if (!html.includes(INJECT_PANEL_START)) {
    const panelBlock = `\n${INJECT_PANEL_START}\n<template id="demora-annotation-panel-tpl"><style>\n${INJECT_PANEL_CSS_INNER_START}\n${panelCss}\n${INJECT_PANEL_CSS_INNER_END}\n</style>\n${panelHtml}\n</template>\n<div id="demora-annotation-host"></div>\n<script>(function(){var h=document.getElementById('demora-annotation-host');var t=document.getElementById('demora-annotation-panel-tpl');if(!h||!t){return;}var s=h.attachShadow({mode:'open'});s.appendChild(t.content.cloneNode(true));})();</script>\n${INJECT_PANEL_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', panelBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板（template + 宿主 + bootstrap，含 S-6 内部标记）');
    } else {
      html += panelBlock;
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板 -> 末尾（含 S-6 内部标记）');
    }
  } else {
    log('  [INFO] Shadow DOM 面板已注入（幂等跳过）');
  }

  // 3. 注入标注引擎 JS 到 </body> 前
  if (!html.includes(INJECT_JS_START)) {
    const jsContent = fs.readFileSync(jsPath, 'utf-8');
    const jsBlock = `\n${INJECT_JS_START}\n<script>\n${jsContent}\n</script>\n${INJECT_JS_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', jsBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> <body>');
    } else {
      html += jsBlock;
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> 末尾');
    }
  } else {
    log('  [INFO] JS 已注入（幂等跳过）');
  }

  // v5.15 L-1 事件委托骨架注入已迁移至 generate-demo.mjs（rk3 P-5 修复）
  //   根因：enhance-prototype 在 AI 填充 app.js 之后运行，isPlaceholder(length<200) 恒 false
  //         → 注入永不命中。骨架现由 generate-demo 在创建空 app.js 时写入。
  //   详见 generate-demo.mjs APP_JS_SKELETON（route 用 display:none，禁止 hidden）。

  // 4. v5.10 新增：注入 Ourchem × Demora 联合版权 Footer
  //    项目级统一标识，所有 demo HTML 均需带上
  //    幂等：使用 [demora-copyright-footer] 标记包裹
  //    v5.24 变更：注入位置从 <body> 末尾改为 .content 滚动容器闭合前（根因①修复）
  //      原位置 footer 处于 app-shell 之外 in-flow → document 高于视口（UAT0826 p3 实证
  //      溢出 149px），击穿 P1-4"业务滚动收敛 .content、document 不滚"契约前提；
  //      移入 .content 后 footer 随业务内容滚动，document 不再溢出。
  //      回退：HTML 无 .content 或闭合定位失败 → 保持 v5.10 行为（body 末尾），兼容旧布局
  const FOOTER_MARKER = '[demora-copyright-footer] start';
  if (!html.includes(FOOTER_MARKER)) {
    const whiteLogoPath = findOurchemWhiteLogo();
    if (whiteLogoPath) {
      const footerBlock = buildCopyrightFooter(whiteLogoPath);
      // v5.24：优先插入 .content 滚动容器闭合标签前（消除 document 溢出）
      const contentClosePos = findContentCloseInsertPos(html);
      if (contentClosePos !== -1) {
        html = html.slice(0, contentClosePos) + footerBlock + '\n' + html.slice(contentClosePos);
        injectCount++;
        log('  [OK] 注入 Ourchem × Demora 联合版权 Footer -> .content 滚动容器内（v5.24 消除 document 溢出）');
      } else if (html.includes('</body>')) {
        html = html.replace('</body>', footerBlock + '\n</body>');
        injectCount++;
        log('  [OK] 注入 Ourchem × Demora 联合版权 Footer -> <body>（v5.10 兼容回退：未找到 .content 滚动容器）');
      } else {
        html += footerBlock;
        injectCount++;
        log('  [OK] 注入 Ourchem × Demora 联合版权 Footer -> 末尾（v5.10 兼容回退）');
      }
    } else {
      log('  [WARN] 未找到 Ourchem 白色 logo SVG，跳过版权 Footer 注入（路径搜索失败）');
    }
  } else {
    log('  [INFO] 版权 Footer 已注入（幂等跳过）');
  }

  // 5. v5.24 新增：C21 导航锚点防护脚本注入（UAT0826 p3 根因③修复）
  //    根因：demo（AI 写）page 元素挂 id（<section id="P03">）→ <a href="#P03"> 成为真锚点；
  //          click 委托处理 data-nav 后无 preventDefault → 浏览器默认锚点跳转发生在
  //          route() 复位之后，document 滚动 20px、58px topbar 被裁 20px。
  //    方案：capture 阶段全局 click 拦截（先于任何 bubble 委托），preventDefault 阻断
  //          默认锚点跳转；pushState 同步 hash（与 location.hash 赋值不同，pushState
  //          不触发任何滚动）；setTimeout(0) 滚动复位兜底（防其他监听器残留滚动）。
  //    幂等：检测 __DEMORA_C21_NAV_GUARD__ 运行时标记（字符串 contains）+ 注释标记双保险
  if (!html.includes('__DEMORA_C21_NAV_GUARD__') && !html.includes(INJECT_NAV_GUARD_START)) {
    const navGuardBlock = `
${INJECT_NAV_GUARD_START}
<script>
/* demora C21（v5.24）：导航锚点防护 — capture 阶段拦截 data-nav 锚点默认跳转，
 * 防止 hash 锚点滚动覆盖 route() 复位导致 topbar 被顶出视口（UAT0826 p3 实证）。
 * 仅拦截 a[data-nav][href^="#"]（data-nav 路由型导航）；纯 hash 路由 demo 不受影响。
 * pushState 不触发滚动（不同于 location.hash 赋值）；setTimeout(0) 滚动复位兜底。 */
(function () {
  if (window.__DEMORA_C21_NAV_GUARD__) return;
  window.__DEMORA_C21_NAV_GUARD__ = true;
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[data-nav][href^="#"]') : null;
    if (!a) return;
    e.preventDefault();
    try { history.pushState(null, '', a.getAttribute('href')); } catch (err) {}
    setTimeout(function () {
      if (document.scrollingElement) document.scrollingElement.scrollTop = 0;
    }, 0);
  }, true);
})();
</script>
${INJECT_NAV_GUARD_END}
`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', navGuardBlock + '</body>');
      injectCount++;
      log('  [OK] C21 导航锚点防护: 注入 capture 阶段 data-nav 锚点拦截脚本 -> <body>（v5.24 防 topbar 被顶出视口）');
    } else {
      html += navGuardBlock;
      injectCount++;
      log('  [OK] C21 导航锚点防护: 注入 capture 阶段 data-nav 锚点拦截脚本 -> 末尾（v5.24）');
    }
  } else {
    log('  [INFO] C21 导航锚点防护已注入（幂等跳过）');
  }

  if (injectCount > 0 || autoFixCount > 0) {
    fs.writeFileSync(indexPath, html, 'utf-8');
    log(`\n  [OK] demo/index.html 已更新（${injectCount} 项注入${autoFixCount > 0 ? ' + ' + autoFixCount + ' 项自动修正' : ''}）`);
  }

  log('\n======================================================================');
  log('[SUMMARY] 标注三件套 + 版权 Footer + C21 导航防护注入完成（v5.24）');
  log('======================================================================');
  log('  主页面样式（标记 + 激活态 padding）-> <head>');
  log('  面板样式 + 面板 HTML -> Shadow DOM');
  log('  标注引擎 JS -> <body>（通过 host.shadowRoot 访问面板）');
  log('  Ourchem × Demora 联合版权 Footer -> .content 滚动容器内（v5.24；无 .content 回退 <body> 末尾）');
  log('  C21 导航锚点防护 -> <body>（v5.24 capture 拦截 data-nav 锚点默认跳转）');
  log('  AI 代码零侵入 — 标注系统通过 data-* 属性约定工作');

  // v5.6 状态机：标记 AI 阶段 3 已完成
  markAnnotationInjected(projectRoot);
  log('  [OK] state.yaml: annotation_injected = true');

  // v5.14.19 C4：写入缓存 key（mtime+size），供下次运行 short-circuit 判断
  try {
    const stat = fs.statSync(indexPath);
    const cacheKey = `${stat.mtimeMs}|${stat.size}`;
    const cacheFile = path.join(projectRoot, '.demora', '.enhance-cache.json');
    fs.writeFileSync(cacheFile, JSON.stringify({ key: cacheKey, ts: Date.now() }), 'utf-8');
  } catch (e) {
    // 缓存写入失败不影响主流程
  }

  // v5.11 新增：同步注入 Ourchem × Demora 联合版权 Footer 到 website HTML 文件
  // 决策 2-B：自动注入（替代手工嵌入），保证后续流水线及 skill 运行同步更新
  injectFooterToWebsite(projectRoot);

  return { ok: true, injected: injectCount };
}

/**
 * v5.11 新增：将 Ourchem × Demora 联合版权 Footer 注入到 website HTML 文件
 *
 * 决策 2-B：自动注入（替代手工嵌入），保证 website footer 与 demo/docs footer 一致
 *
 * 处理目标：
 *   - src/assets/website/index.html
 *   - src/assets/website/getting-started.html
 *   - src/assets/website/docs.html（若存在）
 *
 * 注入策略：
 *   1. 优先替换旧的 <footer class="footer">...</footer> 块（仅 Demora logo 的旧 footer）
 *   2. 兜底注入到 </body> 前（无 </body> 时追加到文件末尾）
 *   3. 幂等：检测 [demora-copyright-footer] start 标记，已注入则跳过
 */
export function injectFooterToWebsite(projectRoot) {
  log('\n----------------------------------------------------------------------');
  log('[v5.11] 同步注入 Ourchem × Demora 联合版权 Footer 到 website HTML');
  log('----------------------------------------------------------------------');

  // 查找 website 目录（dev 路径优先，dist 路径兜底）
  const candidates = [
    path.join(__dirname, '..', '..', '..', '..', 'src', 'assets', 'website'),
    path.join(__dirname, '..', 'assets', 'website'),
  ];
  let websiteDir = null;
  for (const p of candidates) {
    if (fs.existsSync(p)) { websiteDir = p; break; }
  }
  if (!websiteDir) {
    log('  [INFO] 未找到 website 目录，跳过 website footer 注入');
    return { ok: false, reason: 'website dir not found' };
  }
  log(`  [OK] website 目录: ${websiteDir}`);

  // 查找 Ourchem 白色 logo
  const whiteLogoPath = findOurchemWhiteLogo();
  if (!whiteLogoPath) {
    log('  [WARN] 未找到 Ourchem 白色 logo SVG，跳过 website footer 注入');
    return { ok: false, reason: 'logo not found' };
  }

  const footerBlock = buildCopyrightFooter(whiteLogoPath);
  const targetFiles = ['index.html', 'getting-started.html', 'docs.html'];
  let injectCount = 0;
  let skipCount = 0;

  for (const fname of targetFiles) {
    const fp = path.join(websiteDir, fname);
    if (!fs.existsSync(fp)) {
      log(`  [INFO] ${fname} 不存在，跳过`);
      continue;
    }

    let html = fs.readFileSync(fp, 'utf-8');
    const FOOTER_MARKER = '[demora-copyright-footer] start';

    // 幂等检测
    if (html.includes(FOOTER_MARKER)) {
      log(`  [INFO] ${fname} 已注入联合版权 Footer（幂等跳过）`);
      skipCount++;
      continue;
    }

    let updated = false;

    // 策略 1：替换旧 footer 块（class="footer" 或类似）
    // 匹配 <footer class="footer">...</footer>（含可能的属性变体）
    const oldFooterRegex = /<footer[^>]*class=["'][^"']*\bfooter\b[^"']*["'][^>]*>[\s\S]*?<\/footer>/i;
    if (oldFooterRegex.test(html)) {
      html = html.replace(oldFooterRegex, footerBlock.trim());
      updated = true;
      log(`  [OK] ${fname} 替换旧 footer 为联合版权 Footer`);
    }

    // 策略 2：兜底注入到 </body> 前
    if (!updated && html.includes('</body>')) {
      html = html.replace('</body>', footerBlock + '\n</body>');
      updated = true;
      log(`  [OK] ${fname} 注入联合版权 Footer -> </body> 前`);
    }

    // 策略 3：追加到文件末尾
    if (!updated) {
      html += footerBlock;
      updated = true;
      log(`  [OK] ${fname} 追加联合版权 Footer -> 末尾`);
    }

    if (updated) {
      fs.writeFileSync(fp, html, 'utf-8');
      injectCount++;
    }
  }

  log(`\n  [SUMMARY] website footer 注入完成: ${injectCount} 个文件已更新, ${skipCount} 个文件已跳过`);
  return { ok: true, injected: injectCount, skipped: skipCount };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('enhance-prototype.mjs') || process.argv[1].endsWith('enhance-prototype'));
if (isDirectRun) {
  // v5.14.19 C4：CLI 参数解析（--project-root / --force）
  //   原因：原 main() 无参调用，导致 args.projectRoot/args.force 永远 undefined，
  //         C4 short-circuit 的 --force 回退通道失效，且无法显式指定项目根目录
  const cliArgs = {};
  for (let i = 2; i < process.argv.length; i++) {
    const a = process.argv[i];
    if (a === '--force') {
      cliArgs.force = true;
    } else if (a === '--project-root' || a === '--projectRoot') {
      cliArgs.projectRoot = process.argv[++i];
    }
  }
  const result = main(cliArgs);
  process.exit(result.ok ? 0 : 1);
}
