# 审计输出读取契约（详版）

> SKILL.md「审计输出读取契约」的详版参考。背景：A/B 测试暴露 G-1（grep 盲区）——agent 用 `grep -v '[WARN]'` 过滤审计输出丢失警告行，导致 B 级 warn 被忽略，含 warn 的交付物被打包。run-audit 现已强制输出 `[WARN_DETAILS_BEGIN]~[WARN_DETAILS_END]` 块防御过滤。

## 1. Agent 读取审计输出铁律

1. **禁止用 grep 过滤审计输出**：`grep -v '\[WARN\]'`、`grep '\[OK\]'`、`grep -E '\[FAIL\]|\[SUMMARY\]'` 等过滤行为**全部禁止**
   - 原因：grep 过滤会丢失 `[WARN]` 行，导致 B 级 warn 被忽略
   - 修复：run-audit 在 `[SUMMARY]` 后强制输出 `[WARN_DETAILS_BEGIN]~[WARN_DETAILS_END]` 块，agent 必须完整读取
2. **必须完整读取审计输出**：agent 应读取 run-audit 的完整 stdout，不得截断或过滤
   - 实现建议：`const output = execSync('node scripts/run-audit.mjs ...', { encoding: 'utf-8', maxBuffer: 10 * 1024 * 1024 })`
   - 禁止：`execSync(...).split('\n').filter(l => !l.includes('[WARN]'))`
3. **[WARN] 行必须处理**：审计输出中的每条 `[WARN]` 都必须被 agent 评估：
   - 不可接受 warn（`D0_console` 的 error/404、`D6` 的 fail、`D8_element_coverage` 的 fail（v5.24 升级））→ 必须修复至 A 级才放行
   - 可接受 warn（`D4` / `D7` / `D8` / `D9` / `D10` 非功能缺陷类；v5.24 起 D8 中仅 `D8_element_coverage` 的 fail 不可放行，其 WARN 仍可放行）→ 记录但可放行
   - D3 无弹窗设计不再产生 warn（v2.2 决策A 豁免：探测不到弹窗与触发按钮时记 `pass: n/a`）
4. **[WARN_DETAILS] 块解析**：`[WARN_DETAILS_BEGIN]` 到 `[WARN_DETAILS_END]` 之间的每一行是一条 warn 详情，agent 必须逐条评估

## 2. 结构化产物优先

- `demo/audit-result.json`：run-audit 全量结果（dimensions / summary / overall / d8_coverage_details）——修复推理的首选输入
- `demo/diagnose-result.json`：diagnose-runtime 结构化确诊结果（逐元素失败清单 + 根因分类）
- `demo/fix-suggestions.json`：run-audit 失败时自动写入（失败维度 + root_cause + fix_pattern + evidence_selector），体积比全量审计输出小一个量级

## 3. 上下文治理

- Phase 3 审计轮次 > 3 轮时，每轮开始前必须读取 state.yaml 而非依赖对话历史
- audit-result.json 载入后提取 dimensions 中 fail/warn 项；修复后重跑审计再读 1 次新结果，禁止反复全文重读
