# [VAND generated] src/reference/AGENTS.md — 项目 AI 规则入口（VAND 接管治理）

> 本文件已由 VAND 全面接管并原位续存：原规则全文见 .vand-workspace/project-context.md（§吸收的既有规则：src/reference/AGENTS.md）；后续迭代由 VAND 接管管理（经 .vand-workspace/specs/ 规格）。
> AI 工具加载本文件时，请同时读取范式入口 .vand/AGENTS.md 与上述 project-context 对应节。

## 范式入口

- 范式：.vand/AGENTS.md
- 项目工作区：.vand-workspace/

## 项目规则

- 全文：.vand-workspace/project-context.md（§吸收的既有规则：src/reference/AGENTS.md）
