// append-conversation-log.mjs
// 会话日志追加 CLI（v5.25 P1-2）——conversation-log.yaml 的唯一 AI 写入入口
//
// 根因：0828 轮 ≥4 案例批量补记相同时间戳（v5.23"即时追加"纪律失守），
//       耗时归因出现 81~98 分钟黑洞；文件被 AI 整体重写导致三种条目格式并存。
// 机制：lib/conversation-log.mjs 唯一写入通道（追加前临时解除只读 → 追加 → 恢复只读）。
//       文件为只读（0o444），AI 直接编辑/重写 → EPERM，必须走本脚本。
//       时间戳一律取机器当前时间（追加即发生），禁止补记历史时间。
//
// 调用：
//   node scripts/append-conversation-log.mjs --message "AI 完成 8 页面 Demo 设计"
//   node scripts/append-conversation-log.mjs --message "..." --actor ai --phase 2
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { appendConversationEntry } from './lib/conversation-log.mjs';

export function main(args = {}) {
  const root = args.root || process.cwd();
  if (!args.message || !String(args.message).trim()) {
    process.stderr.write('[FAIL] 缺少 --message（要记录的事件描述）\n');
    process.exit(1);
  }
  const r = appendConversationEntry(root, {
    message: String(args.message),
    actor: args.actor || 'AI',
    phase: args.phase,
  });
  if (!r.ok) {
    process.stderr.write(`[FAIL] 追加失败: ${r.reason}\n`);
    process.exit(1);
  }
  process.stdout.write(`[OK] conversation-log 已追加（timestamp: ${r.timestamp}，actor: ${r.actor || 'AI'}）\n`);
  process.stdout.write('     时间戳为机器当前时间——事件发生时即时调用本脚本，禁止事后批量补记（Q-8 检出）\n');
  return r;
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const argv = process.argv.slice(2);
  const args = {};
  const readVal = (flag) => {
    const i = argv.indexOf(flag);
    return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : undefined;
  };
  args.message = readVal('--message');
  args.actor = readVal('--actor');
  const phase = readVal('--phase');
  if (phase !== undefined) args.phase = /^\d+$/.test(phase) ? parseInt(phase, 10) : phase;
  const rootIdx = argv.indexOf('--root');
  if (rootIdx >= 0 && argv[rootIdx + 1]) args.root = path.resolve(argv[rootIdx + 1]);
  main(args);
}
