---
name: oc-demora
version: 0723-095011-GLM-5.2
description: >-
  Demora 需求澄清与原型生成 Skill。通过"想清楚 - 做精致 - 改到位"三阶段流程，
  帮助 AI 与 PM 协作产出可运行的高保真原型、完整 PRD 文档与测试验收清单。
  核心能力：结构化需求模型驱动、三层标注体系（L1/L2/L3）、
  frontend-design skill 主导设计判断、全链路追溯。
created: 2026-07-23
updated: 2026-07-23
author: Demora Skill Generator
---

# Demora Skill - 需求澄清与原型生成

## 核心定位

Demora 是**面向任意产品形态**的需求澄清工具，通过三阶段流程产出**可运行原型 + PRD 文档 + 验收清单**。

- 不绑定前端框架（Vue/React/Svelte/纯 HTML 均可）
- 不绑定需求类型（CRM/ERP/OA/聊天/大屏均可）
- Demo 的技术选型由 AI 基于 frontend-design skill 方法论决定

## 三阶段流程

### Phase 1 - 想清楚

AI 读取 inbox/ 资料，与 PM 对话澄清需求，填充 `.demora/requirement-model.yaml`。

```bash
# v5.13 规范化：PM 输入归档（必执行）
# 1. AI 接收 PM 输入（一段话 或 上传文档）
#    - 若 PM 上传文档 → AI 复制到 inbox/documents/
#    - AI 生成 inbox/text/requirement-scenario-brief.md（PM 输入原始归档）
# 2. AI 与 PM 对话澄清需求
#    - AI 生成 inbox/text/requirement-input.md（AI 详版需求文档，6 章节结构）

# v5.12 新增：项目名提炼（AI 自动分析 inbox/text/ 资料，输出候选项目名）
# PM 先将需求文档放入 inbox/text/ 后执行：
node scripts/derive-project-name.mjs     # 输出候选项目名（中英文）
# PM 从候选中选择一个，执行 scaffold（自动创建 <slug>/ 子目录）
node scripts/scaffold-project.mjs --project-slug <slug> --project-name "<中文名>"
# AI 与 PM 对话填充需求模型其他字段
node scripts/validate-model.mjs          # 校验完成度 100%
node scripts/lock-model.mjs --lock       # 锁定需求模型
```

**Phase 顺序铁律**：必须从 Phase 1 开始，禁止跳过。转换条件：validate-model 100% + PM 确认锁定。

**行为铁律**：
1. `requirement-model.yaml` 锁定后只读
2. `demo/` 在 `demo_protected: true` 时禁止覆盖
3. `decisions.yaml` 为 append-only
4. `final_approved: true` 后所有产出物锁定

**Schema**：详见 `references/schemas/requirement-model-schema.yaml`

### PM 输入归档规范（v5.13 新增）

**两份文件用途**：

- `inbox/text/requirement-scenario-brief.md`：PM 输入的原始归档，AI 不得修改，仅作为后续 `derive-project-name` 和 `generate-product-docs` 的输入源
- `inbox/text/requirement-input.md`：AI 详版需求文档，基于 brief + 与 PM 对话扩展

**两种 PM 输入形式的处理流程**：

**形式 A：PM 在对话中说一段话**

1. AI 将 PM 的话原样保存为 `inbox/text/requirement-scenario-brief.md`（顶部加 `# PM 需求场景简述` 标题，正文为 PM 原话）
2. AI 与 PM 对话澄清，扩展为 `inbox/text/requirement-input.md`（结构化 markdown，含 6 个章节：业务背景/用户角色/核心功能/页面列表/业务规则/验收标准）

**形式 B：PM 上传文档**

1. AI 将文档复制到 `inbox/documents/`（保留原文件名）
2. AI 提取文档摘要，保存为 `inbox/text/requirement-scenario-brief.md`（顶部加 `# PM 需求场景简述` 标题 + `> 来源：inbox/documents/<原文件名>` 引用 + 摘要正文）
3. AI 与 PM 对话澄清，扩展为 `inbox/text/requirement-input.md`（结构化 markdown，6 个章节）

**requirement-input.md 6 章节模板**：

```markdown
# PM 需求详版

## 1. 业务背景
<项目背景、行业痛点、价值主张>

## 2. 用户角色
<角色列表，每个角色含职责说明>

## 3. 核心功能
<功能模块列表，每个模块含功能点描述>

## 4. 页面列表
<页面清单，每个页面含 ID/名称/类型/路由/主要功能>

## 5. 业务规则
<业务约束、状态流转、权限规则>

## 6. 验收标准
<可测试的验收条件，每个条件可被 check-structure/run-audit 验证>
```

### 项目名规范（v5.12 新增）

- **项目中文名**：用于展示，如「旅游行程预订系统」
- **项目英文 slug**：用于公网发布路径 `https://demora.ipsunlight.com/<slug>/`，格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符
- **目录结构**：scaffold 时自动创建 `<slug>/` 子目录作为项目根（如 `travel-booking/`），所有 demora 文件（.demora/、inbox/、demo/ 等）在该子目录内
- **AI 提炼流程**：
  1. PM 将需求文档放入 `inbox/text/`
  2. AI 执行 `derive-project-name.mjs`，基于 inbox/ 资料自动提炼 3-5 个候选项目名（中英文）
  3. PM 从候选中选择一个（或自定义）
  4. AI 执行 `scaffold-project.mjs --project-slug <slug> --project-name "<中文名>"`
  5. requirement-model.yaml 已预填 project.name + project.slug，后续 Phase 1 对话填充其他字段

### Phase 1 -> Phase 2 转换

```bash
node scripts/generate-demo.mjs           # 创建空 demo/ 目录结构
```

`generate-demo.mjs` 仅创建目录和空文件，不生成任何 HTML/JS/CSS 内容：

```
demo/
├── index.html        # 空文件（AI 填充）
├── assets/
│   ├── app.js        # 空文件（AI 填充）
│   └── style.css     # 空文件（AI 填充）
├── start.bat         # 启动脚本
└── README.txt        # 说明文件
```

### Phase 2 - 做精致

**设计方法论（frontend-design skill 唯一主导）**：

AI 直接读取 `skills/frontend-design/SKILL.md` 方法论原文，从零设计完整 Demo。
不经过任何翻译层、适配层、字段化中转。

frontend-design skill 方法论要点：
- **Ground in subject**：基于产品世界做视觉个性判断
- **Hero as thesis**：每个页面 hero 是论点
- **Typography carries personality**：刻意配对字体
- **Signature element**：每产品 1 个标志性视觉元素
- **反 AI 默认审美自检**：规避三种 AI 默认风格
- **Writing in design**：业务文案要具体、主动

**业务填充（强制）**：

AI 从零设计完整 Demo 后，必须完成：
1. Mock 数据业务化（每实体 >= 10 条，覆盖正常/边界/异常态）
2. 标注数据完整化（每页 L1 + L2 区域覆盖可视范围内所有主要区域 + L3 元件覆盖可视范围内所有可交互元件）
3. 所有可交互元素有实际功能实现

```bash
node scripts/check-business-fill.mjs     # 校验业务填充完整性
```

**文档生成**：

```bash
node scripts/generate-prd.mjs            # 24 个 Markdown 文档
node scripts/generate-product-docs.mjs   # HTML 产品文档
node scripts/generate-traceability.mjs   # 追溯矩阵
```

### Phase 3 - 改到位

评审后处理决策：

```bash
node scripts/sync-docs.mjs               # 同步 accept 决策到文档
node scripts/quality-check.mjs           # 质量检查
node scripts/package-delivery.mjs        # 打包交付
```

## 标注系统

### 三层标注体系

| 层级 | 回答 | 视觉标记 |
|------|------|---------|
| L1 页面说明 | "这个页面是干什么的" | 面板中的摘要卡片 |
| L2 区域标注 | "这块区域是什么逻辑" | 绿色水滴形编号 |
| L3 元件标注 | "这个控件怎么交互" | 蓝色圆点指示器 |

### 标注数据约定

标注系统是独立叠加层，AI 的 JS 逻辑零侵入（无需引入 mixin/插件/全局状态）。但 AI 必须在 HTML 结构中完成以下 4 项：

1. 在区域容器上添加 `data-zone-id="R-001"` 属性
2. 在元件包裹层上添加 `data-element-id="C-001"` 属性
3. 在 L2 区域内添加 `<span class="l2-marker">` 标记元素（绿色水滴形编号，由标注引擎绑定点击事件）
4. 在 `<script>` 中定义 `window.__ANNOTATION_DATA__` 对象（含 L1/L2/L3 数据）

`enhance-prototype.mjs` 自动注入标注三件套（CSS + HTML + JS），不侵入 AI 的代码。

详见 `references/annotation/annotation-guide.md`。

### L2/L3 覆盖率要求（v5.13.3 新增 — 强制）

**L2 区域覆盖率**：每个页面的可视范围内所有主要区域都必须有 `data-zone-id` 标注。

主要区域定义（必须标注）：
- 页面 hero/标题区
- 列表/表格区
- 表单区
- 详情/卡片区
- 操作按钮区
- 筛选/搜索区
- 统计/概览区
- 弹窗/抽屉内容区

**L3 元件覆盖率**：每个页面的可视范围内所有可交互元件都必须有 `data-element-id` 标注。

可交互元件定义（必须标注）：
- `<button>` 按钮
- `<input>` 输入框（含 text/number/date/email/password/search）
- `<select>` 下拉选择
- `<textarea>` 文本域
- `<a href>` 链接（导航/操作类，纯展示链接除外）
- `[role="button"]` ARIA 按钮
- `[contenteditable]` 可编辑区域
- `[tabindex]` 可聚焦元素

**L3 元件一致性**：标注数据中定义的每个 L3 id 必须在 HTML 中有对应的 `data-element-id` 元素，且该元素内有实际的可交互元件（不能只有 `.l3-dot` 指示器而无实际元件）。

**按状态显隐的元件处理**：
- 当元件按状态条件显隐（如 `style.display = 'none'`）时，标注引擎 v5.2.3 会自动过滤"容器可见但内部实际元件全隐藏"的 L3 标注，不在面板显示卡片
- AI 应确保 `data-element-id` 包裹的是完整的元件组（含显隐逻辑），而不是仅包裹 `.l3-dot`

### 标注数据结构（v5.13.3 新增 page.name）

`window.__ANNOTATION_DATA__` 的每个页面对象必须包含 `name` 字段（页面中文名称），用于标注面板头部显示：

```javascript
window.__ANNOTATION_DATA__ = {
  P01: {
    name: '专利清单',  // 页面中文名称（必填，显示在标注面板头部 "P01 - 专利清单"）
    L1: { summary: '...', entry: '...', ... },
    L2: [{ id: 'R-001', zone: '搜索筛选区', description: '...' }, ...],
    L3: [{ id: 'P01-C-001', element: '搜索按钮', ... }, ...]
  },
  P02: {
    name: '转化详情',
    ...
  }
}
```

`name` 字段也兼容 `title` 别名（`ann.name || ann.title`）。

### 标注注入流程

```bash
node scripts/enhance-prototype.mjs       # 注入标注三件套到 demo/
```

脚本仅做三件事：
1. 注入 `annotation-styles.css` 到 `<head>`
2. 注入 `annotation-panel.html` 到 `<body>` 末尾
3. 注入 `annotation-engine.js` 到 `<body>` 末尾

## 运行时契约

AI 生成 Demo 时必须遵守以下运行时约定，避免与标注引擎冲突或导致功能失效。

### 4 个运行时陷阱

| # | 陷阱 | 后果 | 规避方式 |
|---|------|------|---------|
| 1 | 全局作用域 `const` 冲突 | 标注引擎 IIFE 内部变量与 AI 全局变量同名时，AI 代码可能覆盖标注引擎行为 | AI 避免在全局作用域使用 `const app =`、`const state =` 等常见变量名，改用模块作用域或命名空间（如 `const myApp = {}`） |
| 2 | `focusZoneCard` 副作用 | 点击 `.l2-marker` 会自动打开标注面板并切换到 L2 Tab，AI 不应假设面板始终隐藏 | AI 的交互逻辑不应依赖标注面板的显隐状态；面板由标注引擎独立管理 |
| 3 | L2 marker 元素缺失 | 标注引擎通过 `closest('.l2-marker')` 查找标记，若 AI 未添加则 L2 点击高亮失效 | AI 必须在每个 `data-zone-id` 区域内添加至少一个 `<span class="l2-marker">` 元素 |
| 4 | Vue Router 4 同路径导航 | `router.push('/current-path')` 会抛出 NavigationDuplicated 警告 | AI 在导航前应检查目标路径是否与当前路径相同，或使用 `router.replace()` |
| 5 | `display:flex/grid` 覆盖 `hidden` 属性 | CSS `display:flex` 会覆盖 HTML `hidden` 属性的默认 `display:none`，导致弹窗/元素无法隐藏 | AI 在使用 `hidden` 属性时，CSS 必须用 `.xxx:not([hidden]) { display: flex }` 而非 `.xxx { display: flex }`；或依赖全局 `[hidden] { display: none !important }` 防御（v5.13.4 已注入） |

### AI 必须添加的 4 项 HTML 元素

标注引擎不自动创建以下元素，AI 必须在 HTML 中手动添加：

1. `data-zone-id` 属性 — 标注 L2 区域的容器
2. `data-element-id` 属性 — 标注 L3 元件的包裹层
3. `.l2-marker` 类 — L2 区域的可点击标记（绿色水滴形编号）
4. `window.__ANNOTATION_DATA__` — 标注数据对象（含 L1/L2/L3 结构）

### 标注开关与面板

- 标注开关 `[data-annotation-toggle]` 由 AI 在页面顶部工具栏放置
- 标注面板 `.annotation-panel` 由 `enhance-prototype.mjs` 自动注入，AI 无需创建
- 标注引擎在 `DOMContentLoaded` 后自动初始化，AI 无需手动调用

**运行时契约（v5.13.1 新增 — 禁止重复绑定）：**

- **禁止**在 app.js / components.js 中为 `[data-annotation-toggle]` 或 `#annotationToggle` 添加 `addEventListener('click', ...)`
- 标注引擎已自动绑定 click → `togglePanel()`，AI 重复绑定会导致 togglePanel 被调用两次（状态相互抵消，面板永远无法显示）
- AI 仅可通过 `window.__ANNOTATION_ENGINE__.refresh()` 通知引擎数据变化，**不要**调用 `window.__ANNOTATION_ENGINE__.togglePanel()`

## 脚本清单

| 脚本 | 说明 |
|------|------|
| `main.py` | CLI 入口 |
| `derive-project-name.mjs` | v5.12 AI 提炼项目名候选 |
| `scaffold-project.mjs` | 初始化项目目录（v5.12 支持 `--project-slug` 创建子目录） |
| `validate-model.mjs` | 校验需求模型完成度 |
| `lock-model.mjs` | 锁定/解锁需求模型 |
| `render-card.mjs` | 渲染交互卡片 |
| `generate-demo.mjs` | 创建空 demo/ 目录结构 |
| `enhance-prototype.mjs` | 注入标注三件套 |
| `generate-prd.mjs` | 生成 24 个 Markdown 文档 |
| `generate-product-docs.mjs` | 生成 HTML 产品文档 |
| `generate-traceability.mjs` | 生成追溯矩阵 |
| `check-structure.mjs` | 结构完整性校验 |
| `check-business-fill.mjs` | 业务填充完整性校验 |
| `quality-check.mjs` | 质量检查 |
| `sync-docs.mjs` | 同步决策到文档 |
| `package-delivery.mjs` | 打包交付 |
| `verify-demo-runtime.mjs` | Demo 运行时验证 |

## 交互契约

所有 .mjs 脚本遵循统一契约：
- 调用：`node <script>.mjs`，cwd 为用户项目根目录
- 导出：`export function main(args = {})`
- 编码：文件读写 `encoding: 'utf-8'`
- 输出：`[OK]` / `[FAIL]` / `[WARN]` / `[INFO]` / `[SUMMARY]`，禁止 emoji

## 文件结构

```
oc-demora/
├── SKILL.md                       # 本文件
├── README.md                      # 使用说明
├── package.json                   # 配置
├── scripts/                       # 脚本（16 个）
├── assets/                        # 静态资源
├── examples/                      # 使用示例
├── tests/                         # 基础测试
└── references/                    # 运行时依赖
    ├── annotation/                # 标注系统三件套
    ├── methodology/               # 产品需求方法论
    │   ├── annotation-spec.md     # L1/L2/L3 标注规范
    │   ├── doc-templates/         # 24 个文档模板
    │   ├── interaction-templates/ # 6 个交互卡片
    │   ├── schemas/               # 需求模型 Schema
    │   └── guides/                # 方法论指南
    └── scripts/                   # 共享脚本
```
