---
name: oc-demora
version: 0831-135516-GLM-5.3
description: Demora 需求澄清与原型生成 Skill。通过"想清楚 - 做精致 - 改到位"三阶段流程，帮助 AI 与 PM 协作产出可运行的高保真原型、完整 PRD 文档与测试验收清单。核心能力：结构化需求模型驱动、三层标注体系（L1/L2/L3）、frontend-design skill 主导设计判断、全链路追溯。
created: 2026-08-31
updated: 2026-08-31
author: Demora Skill Generator
---

<!-- 版本注释必须位于 frontmatter 之后：YAML frontmatter 必须从文件第 1 行开始，前置任何内容（含 HTML 注释）会导致 Codex 等 agent harness 解析不到 name/description 而静默跳过整个 skill（v5.21 安装兼容性修复）。description 必须保持单行标量，禁止 >- / | 块标量。 -->
<!-- v5.18 P0-B4：渐进披露 + 瘦身 -->
<!-- v5.19：P1-1 标注 id 编码统一 Pn-Ln-xxx / P1-5 导航 label 契约 / P1-6 交互操作性定义 / P2-1 说明详尽度契约 / P0-3 目录子目录强调 / D-2 导航折叠体系指引 -->
<!-- v5.20：P1-3 标注圆内去零序号（U3）/ P1-4 置顶保持公共区域 app-shell 契约（U6）/ P1-5 顶栏 SVG 折叠图标（U5）/ P2-3 scaffold 自动迁移 inbox（U9/U10）-->
<!-- v2.3：按钮类契约（btn-accent/btn-primary 保留类 + P008 data-action 硬规则）+ 检查器通过条件速查表（P008/P013/P018/P027/S-3/S-11，替代读检查器源码）+ 自写截图 channel:'msedge' 模板（p1 实证超时 124s 教训） -->
<!-- v5.23：UAT0824 盲区修复——mermaid 三层防线（引号平衡+stub+D11）、表格结构标注保护（CSS 豁免+C20+P040）、L3 密度契约修订（同类只标首个+双向检测）、htmlhint 内置、findProjectRoot cwd 优先+隐式根防护、D7 逐页化 -->
<!-- v5.24：UAT0826 盲区修复——platform-check 非破坏化+P042 层级修正（根污染根治）、L3 规模分流契约（≤4 全标/>4 首标+说明）+D8 FAIL 升级、P043+筛选往返探针（筛选显示同步防线）、骨架 footer 容器内注入+C21 导航锚点防护+D10 公共区域断言（导航滚动根治） -->
<!-- v5.25：0828 轮耗时根因修复——P0-1 demo 打包后冻结（package-delivery 成功后 demo/ 全只读 + delivery_packaged_at 落盘 + verify-delivery V-16 mtime 校验，--unfreeze-demo 显式解冻逃生口）+ P0-2 解锁计数看门狗（model_unlock_count，第 2 次解锁 ESCALATION、第 3 次硬阻断 --force 放行）+ P0-2b 隐藏容器 L3 锁定前硬拦截（validate-model，弹窗/抽屉内部控件锚点判 FAIL）+ P1-1 骨架正确样板（generate-demo 预置 demoraApplyFilter/demoraBindFilter/demoraResetPageState/demoraSyncAnnotations 四原语 + route() 切页状态复位，语义对齐 D6/D8/D10 探针，S-15 静态提醒）+ P1-2 会话日志唯一追加入口（append-conversation-log.mjs，conversation-log.yaml 只读化 + Q-8 批量补记检出）+ P1-3 计时埋点（state.yaml: phase2_started_at / phase2_enhance_completed_at / phase2_check_completed_at / audit_started_at，summarize-state 展示 Timeline） -->

# Demora Skill - 需求澄清与原型生成

> **v5.18 P0-B4：渐进披露** — 本文件聚焦三阶段流程 + 硬门禁 + data-* 契约表 + 脚本清单 + diagnose 先行要求。详细参考材料已下沉至 `references/` 目录按需读取。

## 核心定位

Demora 是**面向任意产品形态**的需求澄清工具，通过三阶段流程产出**可运行原型 + PRD 文档 + 验收清单**。

- 不绑定前端框架（Vue/React/Svelte/纯 HTML 均可）
- 不绑定需求类型（CRM/ERP/OA/聊天/大屏均可）
- Demo 的技术选型由 AI 基于 frontend-design skill 方法论决定

## 环境前置（一次性准备）

> Playwright 用于 Phase 3 的 run-audit.mjs（D0~D11 浏览器审计）与 verify-demo-runtime.mjs（R-1~R-5 运行时验证）。dist 包已预装 playwright JS（node_modules/playwright + playwright-core），无需 `npm install`。

**Windows 用户（开箱即用）**：
- 确保系统有 Microsoft Edge（Win10+ 默认自带）——run-audit/verify 自动用 Edge，免下载 chromium 二进制（~170MB）
- 若 Edge 不可用：运行 `npx playwright install chromium`（仅一次）

**macOS / Linux 用户**：
- 运行 `npx playwright install chromium`（约 170MB，仅一次）
- 或运行 `node scripts/install-deps.mjs`（一键检测 + 安装）

**验证环境就绪**：
```bash
node scripts/install-deps.mjs    # 检测 playwright 是否可用，缺失则提示安装命令
```

## 平台兼容性契约（v5.14.16 批次1 新增 — 强制）

> **详细内容已下沉至 `references/platform-compatibility.md`，本节仅保留摘要**

> **背景**：A/B 测试在 WorkBuddy 平台暴露三类跨平台缺陷：W-7（safe-delete shim 拦截 fs.rmSync FAIL_CLOSED）、C-1（PowerShell 默认 CP936 解码 UTF-8 致乱码）、G-4（shim 拦截截图清理致历史截图堆积）。本契约规范 agent 平台错误应对，禁止绕过脚本逻辑。

### 平台预检（scaffold 前必执行）

```bash
node scripts/lib/platform-check.mjs    # 跨平台兼容性预检（shim/编码/路径/权限）
```

预检输出 `[SUMMARY]` 行含 `overall: OK/WARN/FAIL`：
- `OK`：无平台风险，继续 scaffold
- `WARN`：存在风险但可继续（如 shim 激活，agent 应使用 platform-utils 工具）
- `FAIL`：致命风险（如关键目录不可写），**禁止继续 scaffold**，先修复环境

### Agent 平台错误应对规范（铁律）

1. **使用 platform-utils 工具**：涉及目录/文件删除时**必须**使用 `scripts/lib/platform-utils.mjs` 的 `safeRemoveDir` / `safeRemoveFile`（同步版 `safeRemoveDirSync` / `safeRemoveFileSync`），禁止直接调用 `fs.rmSync`
   - 原因：platform-utils 多策略降级（重命名轮转 → rmSync → 逐个 unlink），shim 拦截时自动降级
   - 示例：`import { safeRemoveDirSync } from './lib/platform-utils.mjs';`
   
2. **禁止 Python shutil.rmtree 绕过 shim**：shim 是平台层强制策略，Python 绕过属于规避行为，且会导致路径格式不一致（/c/ vs C:\）引发后续问题

3. **禁止跳过脚本逻辑**：任何脚本失败应**报告并停止**，而非跳过继续。例如：
   - 清理失败 → 报告 `[WARN]` 但继续流程（清理非阻塞）
   - 状态机校验失败 → 报告 `[FAIL]` 并停止（必阻塞）

4. **PowerShell 编码处理**：Windows 平台读取 UTF-8 文件（SKILL.md / requirement-model.yaml）**必须**用 Node.js `fs.readFileSync(file, 'utf-8')`，禁止用 PowerShell `Get-Content`（默认 CP936 致中文乱码）

5. **路径含特殊字符**：项目路径含空格/中文时，PowerShell 命令必须用单引号包裹路径参数；建议优先使用纯英文路径避免编码问题

### 失败处理原则

- **可恢复失败**（清理失败、临时文件残留）：`[WARN]` + 继续流程
- **不可恢复失败**（状态机不一致、门禁未通过、关键目录不可写）：`[FAIL]` + 停止流程 + 报告根因
- **禁止**：吞掉异常静默继续、跳过校验、伪造状态字段

### 审计输出读取契约（v5.14.16 批次1 新增 — 强制）

> **详细内容已下沉至 `references/audit-output-contract.md`，本节仅保留摘要**

> **背景**：A/B 测试暴露 G-1（grep 盲区）— agent 用 `grep -v '\[WARN\]'` 过滤审计输出丢失警告行，导致 B 级 warn 被忽略，含 warn 的交付物被打包。run-audit 现已强制输出 `[WARN_DETAILS_BEGIN]~[WARN_DETAILS_END]` 块防御过滤。

**Agent 读取审计输出铁律**：

1. **禁止用 grep 过滤审计输出**：`grep -v '\[WARN\]'`、`grep '\[OK\]'`、`grep -E '\[FAIL\]|\[SUMMARY\]'` 等过滤行为**全部禁止**
   - 原因：grep 过滤会丢失 `[WARN]` 行，导致 B 级 warn 被忽略
   - 修复：run-audit 在 `[SUMMARY]` 后强制输出 `[WARN_DETAILS_BEGIN]~[WARN_DETAILS_END]` 块，agent 必须完整读取

2. **必须完整读取审计输出**：agent 应读取 run-audit 的完整 stdout，不得截断或过滤
   - 实现建议：`const output = execSync('node scripts/run-audit.mjs ...', { encoding: 'utf-8', maxBuffer: 10 * 1024 * 1024 })`
   - 禁止：`execSync(...).split('\n').filter(l => !l.includes('[WARN]'))`

3. **[WARN] 行必须处理**：审计输出中的每条 `[WARN]` 都必须被 agent 评估：
   - 不可接受 warn（`D0_console` 的 error/404、`D6` 的 fail、`D8_element_coverage` 的 fail（v5.24 升级））→ 必须修复至 A 级才放行
   - 可接受 warn（`D4` / `D7` / `D8` / `D9` / `D10` 非功能缺陷类；v5.24 起 D8 中仅 `D8_element_coverage` 的 fail 不可放行，其 WARN 仍可放行）→ 记录但可放行
   - D3 无弹窗设计不再产生 warn（v2.2 决策A 豁免：探测不到弹窗与触发按钮时记 `pass: n/a`）

4. **[WARN_DETAILS] 块解析**：`[WARN_DETAILS_BEGIN]` 到 `[WARN_DETAILS_END]` 之间的每一行是一条 warn 详情，agent 必须逐条评估

## 三阶段流程

### Phase 1 - 想清楚

AI 读取 inbox/ 资料，与 PM 对话澄清需求，填充 `.demora/requirement-model.yaml`。

```bash
# v5.13 规范化：PM 输入归档（必执行）
# 1. AI 接收 PM 输入（一段话 或 上传文档）
#    - 若 PM 上传文档 → AI 复制到 inbox/documents/
#    - AI 生成 inbox/text/requirement-scenario-brief.md（PM 输入原始归档）
# 2. AI 与 PM 对话澄清需求
#    - AI 生成 inbox/text/requirement-input.md（AI 详版需求文档，6 章节结构）

# v5.12 新增：项目名提炼（AI 自动分析 inbox/text/ 资料，输出候选项目名）
# PM 先将需求文档放入 inbox/text/ 后执行：
node scripts/derive-project-name.mjs     # 输出候选项目名（中英文）
# PM 从候选中选择一个，执行 scaffold（自动创建 <slug>/ 子目录）
node scripts/scaffold-project.mjs --project-slug <slug> --project-name "<中文名>"
# AI 与 PM 对话填充需求模型其他字段
node scripts/validate-model.mjs          # 校验完成度 100%
node scripts/lock-model.mjs --lock       # 渲染确认卡片（不锁定，写入 lock_card_shown=true）
# PM 确认卡片内容后：
node scripts/lock-model.mjs --lock --confirm  # PM 确认后执行锁定（校验 lock_card_shown=true）
```

**Phase 顺序铁律**：必须从 Phase 1 开始，禁止跳过。转换条件：validate-model 100% + PM 确认锁定。

> **v5.25 P0-2 解锁看门狗**：每次 `--unlock --confirm` 计数 +1（state.yaml `model_unlock_count`）。第 2 次解锁输出 `[ESCALATION]` 并写 `escalation_required: true`——必须把"锁定时为何未发现"的根因写入 conversation-log，并在单次解锁内完成全部修订；第 3 次起硬阻断（exit 1），确需解锁由 PM 人工裁决后 `--unlock --confirm --force`。禁止把 lock/unlock 循环当作迭代手段（0828 轮实证：cb-glm53f/p6 三轮循环空转 70m 未出 Phase 1）。

> **v5.25 P0-2b 隐藏容器 L3 契约（锁定前拦截）**：`validate-model.mjs` 扫描各页 L3——`element` 描述为弹窗/对话框/抽屉/模态内部控件即 FAIL（exit 1）。原因：enhance C9 会剥离隐藏元素的 data-element-id，此类锚点注入后 S-11 必然不一致。修复：弹窗内交互改由**弹窗触发器**承担标注（response 描述弹窗行为），或锚定弹窗外可见控件。禁止"先锁定、注入失败后解锁修订"。

> **v5.25 P1-2 会话日志契约**：conversation-log.yaml 由 scaffold 创建即只读（0o444），AI 直接编辑/重写会 EPERM——这是技术阻断不是环境故障。唯一追加入口：`node scripts/append-conversation-log.mjs --message "<事件描述>" [--actor ai|pm] [--phase N]`，**事件发生时即时调用**，时间戳一律取机器当前时间。事后批量补记会被 quality-check Q-8 检出（≥3 条相同时间戳 → WARN），0828 轮因此出现 81~98 分钟不可归因黑洞。

> **v5.25 P1-1 骨架正确样板（必须复用，禁止整体重写骨架）**：generate-demo 预置的 app.js 骨架包含四个与审计探针逐字对齐的原语——`demoraBindFilter`/`demoraApplyFilter`（筛选全量重算：状态位与 display 同一行集写入、计数=可见行数，对齐 D6_filter_consistency）、`demoraResetPageState`（route() 切页自动复位筛选/分页，对齐 D10 分页往返）、`demoraSyncAnnotations`（动态行后调用，向 `__ANNOTATION_DATA__` 幂等补条目 + engine.refresh()，对齐 D8 全实例标注）。业务规则：①筛选一律 `demoraBindFilter(控件, {table, counterEl, match})`；②动态新增带 `data-element-id` 的行后调用 `demoraSyncAnnotations(容器)`；③行级同类按钮共用同一 `data-action`（动词），实体标识放 `data-id` 等自有属性；④会改变行数的操作必须两步弹窗确认，禁止单击直接改表。违反项由 D6/D8/D10 运行时 FAIL 兜底，check-structure S-15 静态提醒（WARN）。0828/0829 轮实证：此缺陷族修复循环 ~90m/案。

> **v5.25 P1-3 计时埋点（脚本自动写入，AI 无需操作）**：state.yaml 时间线字段 `phase2_started_at`（锁定）→ `phase2_enhance_completed_at`（注入完成）→ `phase2_check_completed_at`（结构校验通过）→ `audit_started_at`（审计开始）→ `delivery_packaged_at`（打包完成）。`summarize-state.mjs` 的 [Timeline] 区块直接输出各段耗时，供回归轮耗时归因。

**行为铁律**：
1. `requirement-model.yaml` 锁定后只读
2. `demo/` 在 `demo_protected: true` 时禁止覆盖
3. `decisions.yaml` 为 append-only
4. `final_approved: true` 后所有产出物锁定

**Schema**：详见 `references/schemas/requirement-model-schema.yaml`

### PM 输入归档规范（v5.13 新增）

**两份文件**：
- `inbox/text/requirement-scenario-brief.md`：PM 输入原始归档，AI 不得修改（作为 `derive-project-name` / `generate-product-docs` 输入源）
- `inbox/text/requirement-input.md`：AI 详版需求文档（基于 brief + 对话扩展）

**两种 PM 输入形式**：
- **形式 A（对话一段话）**：AI 将 PM 原话保存为 brief.md（顶部加 `# PM 需求场景简述` 标题，正文为 PM 原话）
- **形式 B（上传文档）**：AI 将文档复制到 `inbox/documents/`（保留原文件名），再提取摘要保存为 brief.md（顶部加标题 + `> 来源：inbox/documents/<原文件名>` 引用 + 摘要正文）

两种形式后续均：AI 与 PM 对话澄清，扩展为 requirement-input.md（结构化 markdown，6 章节）。

**requirement-input.md 6 章节模板**（每章节一段）：
1. 业务背景（项目背景/行业痛点/价值主张）
2. 用户角色（角色列表 + 职责说明）
3. 核心功能（功能模块 + 功能点描述）
4. 页面列表（ID/名称/类型/路由/主要功能）
5. 业务规则（业务约束/状态流转/权限规则）
6. 验收标准（可测试条件，须可被 check-structure.mjs S-1~S-14 或 run-audit.mjs D0~D11 验证）

> **v5.18 P0-B2：PM 需求输入写入命令（去 BOM）**
> - **推荐**：用 Node.js 写入（无 BOM）：
>   ```bash
>   node -e "const fs=require('fs'); fs.writeFileSync('inbox/text/requirement-input.md', fs.readFileSync('源文件路径','utf8').replace(/^\uFEFF/,''), 'utf8')"
>   ```
> - **替代**：用 PowerShell `Copy-Item`（字节复制，保留原编码）：
>   ```powershell
>   Copy-Item -LiteralPath "源文件路径" -Destination "inbox/text/requirement-input.md"
>   ```
> - **禁止**：PowerShell `Set-Content` 直写（Windows PowerShell 5.1 默认 UTF-8 BOM，会导致 generate-product-docs 死循环）

### 项目名规范（v5.12 新增）

- **项目中文名**：用于展示，如「旅游行程预订系统」
- **项目英文 slug**：用于公网发布路径 `https://demora.ipsunlight.com/<slug>/`，格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符
- **目录结构**：scaffold 时自动创建 `<slug>/` 子目录作为项目根（如 `travel-booking/`），所有 demora 文件（.demora/、inbox/、demo/ 等）在该子目录内
  - **v5.19 P0-3 强调**：项目**必须位于独立子目录，禁止在当前目录平铺项目文件**——scaffold 现已无条件创建项目子目录；未传 `--project-slug` 时，scaffold 会从 requirement-input.md 文件名自动推导 slug
  - **v5.20 P2-3**：Phase 1 在 cwd 级归档的 `inbox/`（derive-project-name 提炼所需）由 scaffold 自动迁移至项目子目录并清理——scaffold 后需求文件归属 `<slug>/inbox/`，cwd 不残留杂散 inbox（U9/U10）
- **AI 提炼流程**：
  1. PM 将需求文档放入 `inbox/text/`
  2. AI 执行 `derive-project-name.mjs`，基于 inbox/ 资料自动提炼 3-5 个候选项目名（中英文）
  3. PM 从候选中选择一个（或自定义）
  4. AI 执行 `scaffold-project.mjs --project-slug <slug> --project-name "<中文名>"`（自动迁移 cwd 级 inbox 至项目目录）
  5. requirement-model.yaml 已预填 project.name + project.slug，后续 Phase 1 对话填充其他字段

### Phase 1 -> Phase 2 转换

```bash
node scripts/generate-demo.mjs           # 创建空 demo/ 目录结构
```

`generate-demo.mjs` 仅创建目录和空文件，不生成任何 HTML/JS/CSS 内容：

```
demo/
├── index.html        # 空文件（AI 填充）
├── assets/
│   ├── app.js        # 空文件（AI 填充）
│   └── style.css     # 空文件（AI 填充）
├── start.bat         # 启动脚本
└── README.txt        # 说明文件
```

### Phase 2 - 做精致

**设计方法论（frontend-design skill 唯一主导）**：

AI 直接读取 `skills/frontend-design/SKILL.md` 方法论原文，从零设计完整 Demo。
不经过任何翻译层、适配层、字段化中转。

frontend-design skill 方法论要点：
- **Ground in subject**：基于产品世界做视觉个性判断
- **Hero as thesis**：每个页面 hero 是论点
- **Typography carries personality**：刻意配对字体
- **Signature element**：每产品 1 个标志性视觉元素
- **反 AI 默认审美自检**：规避三种 AI 默认风格
- **Writing in design**：业务文案要具体、主动

> **v5.18 P0-C2'：禁止跨案例读取（严格顺序依赖）**
> - 不得读取其它案例（req-case-*/codex-dsf-req-case-* 等）的产物作为参考
> - 设计参考以 `skills/frontend-design` 与 `references/` 为准
> - **此项仅在 A6/A7/C4/B4 全部落地后生效**——先固化先验（骨架默认能力 + 校验器修正），再禁止运行时借鉴
> - 违反此条款的 agent 行为将被视为流程违规

**业务填充（强制）**：

AI 从零设计完整 Demo 后，必须完成：
1. Mock 数据业务化（每实体 >= 10 条，覆盖正常/边界/异常态）
2. 标注数据完整化（每页 L1 + L2 区域覆盖可视范围内所有主要区域 + L3 元件覆盖按同类组规模分流——≤4 全标 / >4 首标+同类说明，v5.24 契约见"L2/L3 覆盖率要求"节）
3. 所有可交互元素有实际功能实现
   - **操作性定义（v5.19 P1-6）**："实际功能" = 点击/提交后至少产生一项**业务状态变化**——数据增删改（列表/表单/状态位更新）、视图切换（页面/Tab/筛选切换）、表单校验反馈（错误提示 + 阻断提交）或界面状态更新（按钮态/徽标/进度变化）
   - toast 消息**仅可作辅助反馈，不可单独成立**为功能实现——仅有 toast 提示而无任何业务状态变化的按钮视为空交互（pre-audit-check P036 静态检测 WARN）；该契约由 P036（语法级）+ P038（数据流级）静态检测与 D6 业务状态签名（运行时，v5.22）三层执行，完整契约见 R-11

**列表行操作区结构一致性（v5.23 新增）**：
- 动态列表每行的操作按钮区应保持结构一致：已读/已完成/已归档等终态行以禁用态（disabled 样式）呈现对应按钮，而非条件性移除按钮
- 理由：条件性增删按钮导致行间操作区错位（UAT0824 opencode-ox- 案例实证），且破坏视觉对齐预期

**指标卡/KPI 卡可交互要求（v5.24 新增 — 设计约束）**：
- 指标卡/KPI 卡应实现为可交互元素：用 `button`/`role="button"` 或挂 `data-action`（点击查看明细/跳转），从而纳入 L3 标注契约与 D8 覆盖检测
- 纯展示 div 卡片不在 L3 契约范围（UAT 期望与契约通过设计要求对齐）

```bash
node scripts/check-business-fill.mjs     # 校验业务填充完整性
```

**文档生成**：

```bash
node scripts/generate-prd.mjs            # 24 个 Markdown 文档
node scripts/generate-product-docs.mjs   # HTML 产品文档
node scripts/generate-traceability.mjs   # 追溯矩阵
```

> generate-prd 与 generate-product-docs 的 mermaid 黑名单自检已含引号平衡检查（v5.23）；run-audit D11 提供浏览器真实渲染兜底校验

**上下文治理（v5.16 强化 — P0-4 修复）**：
- **[硬指令]** 审计轮次 > 3 轮时，每轮开始前必须读取 state.yaml 而非依赖对话历史

### 上下文 token 管理（参考）

AI 无需手动估算 token 或维护 context-token-count.txt。run-audit.mjs 内部已实现：
- 自动检测上下文 token 用量（基于内容长度估算）
- 超过 200K 时输出非阻断 WARN（建议触发 Context Compaction）
- AI 可忽略此 WARN，按正常流程继续审计

**[硬指令] app.js 编辑规则（v5.16 强化 — P-5 修复）**：
- generate-demo.mjs 会在 app.js 写入事件委托骨架（含 route()/openModal()/closeModal() 函数）
- AI 编辑 app.js 时**必须增量填充**，禁止整体覆盖
- 具体规则：
  1. 保留骨架中的 `document.addEventListener('click', ...)` 事件委托结构
  2. 保留骨架中的 `route(pageId)` 函数（使用 `style.display` 切换，禁止用 `hidden` 属性）
  3. 在 `// TODO: AI 实现` 注释处填充业务逻辑
  4. 可新增函数，但不得删除骨架函数
- **[自检]** enhance-prototype.mjs 会检测骨架痕迹缺失（事件委托/closest/data-page-id/style.display）
- **[禁止]** 用 `hidden` 属性切换页面可见性（会导致 D10 标注未激活）

**[硬指令] modal 触发约定（v5.16 强化；v2.2 决策A 补充）**：
- **D3 语义（v2.2 决策A）**：有弹窗时验证 open→close 闭环（触发→显示→关闭→隐藏）；**无弹窗设计记 n/a**（`pass: n/a — no modal in design`），不计 warn、不影响评级——需求未要求弹窗的信息型应用，闭环概念不适用
- 弹窗触发按钮**必须使用 `data-open-modal="modalId"` 属性**，不得用 `data-action` 替代
- 若需用 data-action 触发弹窗，必须同时添加 `data-open-modal` 属性
- D3 审计的 openBtnSelectors 已扩展覆盖 data-action="edit"/"view"/"detail" 等模式，但 data-open-modal 是首选
- **[示例]** 正确：`<button data-open-modal="pledgeModal">新建质押</button>`
- **[示例]** 错误：`<button data-action="newPledge">新建质押</button>`（未加 data-open-modal 时 D3 探测不到触发按钮，可能记 n/a 豁免但弹窗闭环未被验证）

**[硬指令] 导航折叠体系（v5.20 P1-5 重构 — 顶栏最左图标；v5.20.1 UAT 三轮 U5 修正：图标透明底 + 折叠完全收起 + 顶栏左组合）**：
- 导航采用**侧栏布局**时**必须**使用骨架预置的折叠体系：侧栏容器加 `.sidebar` 类，顶栏（topbar）**最左**放图标按钮 `.nav-toggle` + `[data-nav-toggle]` 属性（骨架已内置 CSS/JS：点击切换 `body.nav-collapsed`，折叠态**完全收起**（零残留），悬停屏幕左缘热区自动唤出完整导航）
- 折叠图标**使用用户给定的 SVG**（24×24 分栏图标，**透明底**——与任何顶栏底色协调，原样内联不得改动/简化）：
  ```html
  <button type="button" class="nav-toggle" data-nav-toggle aria-expanded="false"
          aria-label="折叠导航" title="折叠/展开导航">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
      <rect x="3" y="6" width="18" height="12" rx="2" ry="2"
            stroke="#9b9b9b" stroke-width="1.4" fill="none"/>
      <rect x="5.5" y="9" width="1.6" height="6" fill="#9b9b9b"/>
      <rect x="8" y="9" width="1.6" height="6" fill="#9b9b9b"/>
      <rect x="11" y="9" width="8.5" height="6" stroke="#9b9b9b" stroke-width="1.2" fill="none"/>
    </svg>
  </button>
  ```
- 交互形态（codex 风格）：打开态点击图标 → 导航**完全收起**（translateX 移出，无窄条残留）；折叠态悬停屏幕左缘（约 14px 热区）→ 导航唤出；折叠态点击图标 → 打开导航
- 顶栏布局提示（v5.20.1 U5）：`.nav-toggle` 与品牌区（logo/标题）组成**左侧相邻组合**——如给 `.topbar-brand` 加 `margin-right: auto`（操作区自然靠右），或包一层左组容器；**禁止** space-between 三段布局把品牌推离图标
- 布局对齐建议（v5.20 P1-4 契约）：`.app-shell`（100vh 纵向 flex）+ `.topbar`（公共区常驻）+ `.layout` + `.sidebar` + `.content`（`overflow-y:auto` 业务滚动容器）——切页置顶由 route() 自动复位滚动容器，**公共 topbar 保持常驻视口不被顶走**（U6 置顶定义：保持公共区域，仅业务页面区域置顶）
- app-shell 布局下，`.app-shell` 之外不得出现 in-flow 块级元素（v5.24）：骨架注入的版权 footer 已改为注入滚动容器内（不再造成 document 溢出）；AI 自建元素同样遵守，保证 `document.scrollHeight === clientHeight`
- 顶栏布局（无侧栏）可不采用折叠体系

**[硬指令] 按钮类契约（v2.3 新增 — btn-primary 误判教训）**：
- `btn-primary` 为**弹窗触发器保留类**（会被 D3 启发式探测为弹窗触发候选）
- 业务主按钮（导航/提交/筛选等）使用 `btn-accent`（骨架已预置与 .btn-primary 相同视觉样式，见 `demo/assets/style.css`），或带 `data-route`/`data-action` 属性的按钮
- 弹窗触发按钮必须带 `data-open-modal` 属性（v2.3 契约）
- **P008 硬规则**：所有 `data-open-modal` 按钮必须同时带 `data-action` 属性（P008 静态线索要求：onclick / data-action / app.js 引用其 id/class 三线索至少其一，骨架的事件委托不计入线索）。`data-action` 此处仅作静态线索，骨架委托命中 `data-open-modal` 分支即 return，不会触发 handleDemoAction，无行为冲突
- 背景：p6/p7/p4 实证——业务主按钮误用 `.btn-primary`，D3 启发式点击后无弹窗弹出即判闭环断裂 FAIL

**[硬指令] 显隐状态位契约（v2.4 新增 — 分页状态污染教训）**：
- 元素显隐（`style.display`）**仅作输出**，禁止读取 `style.display !== 'none'` 反推业务状态（筛选/分页/tab 态）
- 分页/筛选/切换等显隐控制必须用**独立 `data-*` 状态位**记录（如 `row.dataset.filtered = ok ? '1' : '0'`），每次由全部状态位**全量重算** display：
  ```js
  // 正确：display 由独立状态位全量重算（可逆）
  const filteredOut = row.dataset.filtered === '0';
  const onPage = /* 分页计算 */;
  row.style.display = (filteredOut || !onPage) ? 'none' : '';
  // 错误：读取 display 反推筛选态（状态污染不可逆）
  // const visible = row.style.display !== 'none';  // ← P033 检测命中
  ```
- 背景：v2.3 p6 实证——分页函数以 display 反推筛选态，行被翻页隐藏后永久误判为已筛掉，5 个标注 rect=0x0、audit 三轮才修复。**P033 静态检测该反模式（WARN），diagnose 序列探针（翻页往返后复查）运行时兜底**
- 反例（UAT0826 p6 实证，v5.24 追加）：仅对 `filter(r => r.dataset.filtered === '1')` 的匹配行设置 display、遗漏 `filtered='0'` 行 → 筛选后计数文本变化但表格行全部照旧可见（"半吊子筛选"）。全量重算必须覆盖所有状态分支：`row.style.display = (filteredOut || !onPage) ? 'none' : ''`。
  检测：pre-audit P043 静态检测状态位/display 行集不对称；run-audit 筛选往返探针断言计数文本与可见行数一致。

**v2.3 检查器通过条件速查表（替代读检查器源码）**

> 背景：v2.2 调研 6/6 案例首次 pre-audit FAIL、agent 为搞清判定读检查器源码 4-6 个/案。以下为各检查项一行判定摘要（判定细节详见对应脚本 `--help` 或 `references/audit-fix-guide.md`，**禁止读脚本源码**）：

| 检查项 | 通过条件（一行判定） |
|--------|---------------------|
| P008 | 弹窗触发按钮（`data-open-modal`/`btn-new`/`btn-add`）带静态事件线索：HTML `onclick` 属性 / `data-action` 属性 / app.js 中引用其 id/class，三选一即可 |
| P013 | HTML 内引擎注入标记在即可：有 `data-zone-id` 则页面须有 `l2-marker` 类引用、有 `data-element-id` 须有 `l3-dot` 类引用（marker/dot 元素由标注引擎运行时自动创建，AI 无需手写；标记全缺 = 引擎未加载，FAIL） |
| P018 | `__ANNOTATION_DATA__` 声明的 L2/L3 数量 = HTML 中 `data-zone-id`/`data-element-id` 数量（逐页比对，v2.1 起 FAIL 阻断；diagnose-runtime v2.3 起同步运行时校验） |
| P027 | nav link 的 `href` 与 `data-nav` 一致（如 `href="#P02"` 对应 `data-nav="P02"`），或 href 目标 `[id=...]`/`[data-page-id=...]` 存在；typo 即 FAIL |
| S-3 | 面板容器三件套 `.annotation-panel` + `.panel-body` + `.panel-header` 存在于 HTML（enhance-prototype 自动注入，勿在重写 HTML 时删除） |
| S-11 | `__ANNOTATION_DATA__` 中每个 L3 id 在 HTML 有对应 `data-element-id`（静态初筛；运行时动态生成的锚点豁免为 WARN，由 D10 兜底） |

**P027 补充警示（v5.24 新增）**：page-view 元素禁止同时挂 `id` 与 `data-page-id`——`href="#Pxx"` 在 page 挂 id 时成为真锚点，浏览器默认跳转会与切页滚动复位时序冲突（UAT0826 p3 实证 topbar 被顶出视口）。路由语义一律由 `data-nav`/`data-route` 承载；骨架 C21 已对 data-nav 锚点做 preventDefault 兜底。

<!-- v5.19 P1-5：导航 label 契约 -->
**[硬指令] 导航 label 契约（v5.19 P1-5 新增）**：
- 导航菜单项**只显示业务名称**（如「培育工作台」「学员管理」），**禁止显示 P01/01 等研发编码**——研发编码属于内部追溯用信息，对 PM 是噪音
- 页面编码仅存于 `data-page-id` 属性（nav link 的 `data-nav`/`href` 承载路由语义），不得出现在任何可见文本中
- 违反将被 pre-audit-check **P035** 预检 WARN（导航研发编码检测）

**自写截图模板（v2.3 新增 — Windows channel 强制）**

> Windows 下自写 Playwright 截图脚本**必须指定 `channel: 'msedge'`**（p1 实证：缺省时 Playwright 尝试下载 chromium 二进制，超时 124s 白耗）。最小模板：

```js
// demo/shot.mjs — 自写截图最小模板（调试文件，用后必须删除并重跑 quality-check）
import { chromium } from 'playwright';
const browser = await chromium.launch({ channel: 'msedge' });  // Windows 必须指定，免下载
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.goto('http://127.0.0.1:8802/', { waitUntil: 'networkidle' });
await page.screenshot({ path: 'shot.png', fullPage: true });
await browser.close();
```

## 标注基础设施契约（enhance-prototype.mjs 自动修正）

> Demo 的页面布局、视觉风格、交互方式由 frontend-design skill 自由设计，本章节不约束设计自由度。
> 以下标注基础设施由 `enhance-prototype.mjs` 在标注注入阶段（AI 完成 demo 后）自动修正，AI 无需手动处理：
>
> 1. **nav link href 重复**（覆盖 P019）→ 自动修正：引擎改为唯一值（基于 data-nav 属性值）
> 2. **`style="display:none"` 页面隐藏**（覆盖 P021）→ 自动修正：引擎改为 `hidden` 属性 + 注入 `[hidden]{display:none!important}` 防御 CSS
> 3. **data-zone-id 缺 anno-zone 类**（覆盖 P024）→ 自动修正：引擎添加 `anno-zone` 类
> 4. **data-element-id 在内联元素上**（覆盖 P023）→ 自动修正：引擎用 `<div>` 包裹（保留原元素，移除其 data-element-id）
>    - 注意（v5.18 调整）：BUTTON 已移出 inlineTags — codex-dsf 实测 38 个 BUTTON 上 data-element-id 运行时 D8/D10 全 pass（标注引擎对 BUTTON 用绝对定位创建 .l3-dot），C4 不再包裹 BUTTON
> 5. **缺 data-annotation-root**（覆盖 P025）→ 自动修正：引擎为 `<main>` 或 `<body>` 添加 `data-annotation-root` 属性
> 6. **首屏页面 P01 hidden 残留**（覆盖 P026）→ 自动修正：引擎移除首屏 `[data-page-id]` 的 hidden 属性
> 7. **隐藏元素含 data-element-id**（覆盖 P023-hidden，v5.18 新增 C9）→ 自动修正：引擎剥离 `display:none` / `hidden` 元素的 `data-element-id` 属性（避免 .l3-dot 不可见导致 D10 L3 失活）
>    - 实测根因：tw-dsf2 首轮 D10 L3 dots 8 个未激活，隐藏 placeholder 元素含 data-element-id → 标注引擎为这些元素创建 .l3-dot，但因父元素 display:none 导致 .l3-dot 也不可见
>    - 排除：`[data-page-id]` 元素的 hidden（页面切换机制，由 C2/C6 处理）
>
> AI 需注意（引擎无法自动修正，需 AI 手动处理）：
>
> 8. **标注元素应放在 `[data-page-id]` 内**（P020）→ 需注意：引擎会 WARN 提示，AI 需手动将全局 sidebar/topbar 中的标注元素移入对应页面
> 9. **弹窗触发按钮应加 `data-open-modal`**（P017 强化）→ 需注意：引擎会 WARN 提示，AI 需手动为 modal 触发按钮添加 `data-open-modal="modalId"` 属性
> 10. **禁止手写 `.l2-marker`**→ 需注意：引擎自动创建并编号，手动写会导致 ensureMarkers 重复创建嵌套 marker，D5 失败
> 11. **nav link 数量须 ≥ 页面数**（P022）→ 需注意：引擎仅修正 href 唯一性，不自动添加 nav link，AI 须为每个 `[data-page-id]` 提供对应 nav link
> 12. **nav link href 须与 data-nav 一致或目标存在**（P027，v5.18 新增）→ 需注意：引擎仅检测不修正（typo 需 AI 判断正确目标），AI 须确保 `href="#P02"` 与 `data-nav="P02"` 一致，或 href 目标 `[id=...]` / `[data-page-id=...]` 存在

### Phase 3 - 改到位

评审后处理决策：

```bash
node scripts/sync-docs.mjs               # 同步 accept 决策到文档
node scripts/pre-audit-check.mjs --demo demo  # v5.14.11 新增：audit 前静态契约预检（P001-P005，<1s）
node scripts/run-audit.mjs --demo demo --label <scenario>  # 浏览器运行时审计（D0~D11）
node scripts/quality-check.mjs           # 质量检查
node scripts/package-delivery.mjs        # 打包交付（v5.14.16 硬门禁：runtime_audit_passed/final_approved 非 true 硬 FAIL）
node scripts/verify-delivery.mjs         # 交付物完整性校验（v5.14.16 必执行：V-1~V-12，含哈希终检 V-11 + 状态机一致性 V-12）
```

> **v5.25 P0-1 demo 冻结**：package-delivery.mjs 成功后自动将 demo/ 全部文件置只读并写入 `delivery_packaged_at`；verify-delivery **V-16** 检测打包后改写（任一 demo 文件 mtime > packaged_at 即 FAIL）。修复已打包 demo 的唯一合法路径：`node scripts/package-delivery.mjs --unfreeze-demo` → 修复 → 重跑 run-audit.mjs → package-delivery.mjs → verify-delivery.mjs。打包后直接改 demo 会 EPERM 失败，这不是环境故障，禁止绕过（0828 轮实证：tw-glm53f 两案打包后 7~51m 继续改写，交付物为旧版 demo）。

> **v5.23 审计维度更新（D0~D11，18 个维度）**：
> - D11 docs mermaid 渲染校验：浏览器加载 docs/index.html 验证全部 mermaid 块真实渲染（v5.23 新增，拦截 PRD 源码语法错误流入交付物）
> - D7 视觉启发式检查（v5.23 起为逐页执行，含表格完整性：tr 布局坍塌/非法子节点检测）
> - D8 另含同类重复标注检测（序号型冗余 WARN）与交互元件类型覆盖率检测（漏标 WARN）
>
> **v5.24 审计维度更新（UAT0826 盲区修复）**：
> - D8 覆盖检测 FAIL 升级（v5.24）：页覆盖率 <90% 或缺标类型 ≥3 时 D8_element_coverage 判 FAIL（不可接受 warn，B 级不可放行）；缺标类型 ≥1 且占比 >10% 判 WARN；明细落盘 audit-result.json 的 d8_coverage_details
> - D8 覆盖检测按同类组规模差异化校验（≤4 组任一未标即缺标；>4 组校验首实例+同类说明），序号型重复仅对 >4 组告警
> - D6 控件收集含 `input[type=text]`/`select`（v5.24）
> - 筛选往返一致性探针（v5.24，挂 D10 循环）：对可见筛选控件触发变更，断言计数文本与表格可见行数一致，不一致 FAIL
> - D10 每次导航后断言 document scrollTop=0 且 header/nav 完整在视口内（v5.24，公共区域完整性）

**[硬指令] 调试文件清理后重跑规则（v5.16 新增）**：
- AI 在调试过程中创建的临时文件（debug-*.mjs, diag-*.mjs, srv.mjs, audit-run*.log 等）必须在调试完成后清理
- **清理后必须重跑 `node scripts/quality-check.mjs`** 刷新 quality-report.yaml
- 否则 quality-report 会保留原检出记录，造成"幽灵文件"陈旧现象
- **[自检]** verify-delivery 通过后也会刷新 Q-4 状态，但 Q-7 的调试文件检出需 AI 主动重跑 quality-check

> **v5.14.11 新增：audit 前静态预检**（降低重试次数，基于真实根因可拦截 30-50% 重试）
> - `pre-audit-check.mjs` 必须在 `run-audit.mjs` 前执行，预检失败时按错误清单修复 demo 后再次预检
> - 检测项：P001 手动 marker 误带属性 / P002 [hidden] 防御规则 / P003 导航完备性 / P004 __ANNOTATION_DATA__ 内联位置 / P005 端口占用
> - 预检不替代运行时审计（D9 协同/D10 激活仍需 run-audit 验证）

> **v5.17 新增：审计硬超时 + 进程治理**（Tier C，根治孤儿进程 + 轮询浪费）
> - run-audit.mjs 内置 `HARD_TIMEOUT_MS=900000`（15 min），触发时 `browser.close()` + `process.exit(2)`
> - AI 调用 run-audit.mjs 时 `timeout_ms` 必须设为 `960000`（16 min > 硬超时 15 min，让硬超时先触发）
> - **exit code 2 = 硬超时**：视为审计失败需修复，**禁止轮询等待**（A/B 测试 codex-dsf 因轮询浪费 16 min）
> - exit code 124 = shell 超时（不应出现，硬超时先触发；若出现说明硬超时失效，需排查）
> - exit code 0/1 = 审计正常完成（0=全通过，1=有 FAIL）

> **v5.15 新增：审计对象身份验证**（P0-1 修复，防御端口冲突导致审计错误 demo）
> - run-audit.mjs 启动前读取 demo/index.html 的 title + data-page-id 数量（预读取身份）
> - 审计完成后比对 detectedPages 与预读取值，不匹配 → FAIL 退出（exit 1）
> - 防御场景：并发审计时端口 8800 被前一轮残留进程占用，加载了错误 demo 的内容

### Phase 3 门禁（v5.14.16 根治：软门禁升级为硬门禁）

> **硬指令**：run-audit.mjs 评级为 A，或 B 且无不可接受 warn 才可进入 Phase 3（v5.18 P0-A1 对齐）。
> 若评级为 C/D，或 B 但含不可接受 warn（`D0_console` console error/404、`D6_button_responsiveness` 按钮无响应/全 disabled），
> 必须返回 Phase 2 修复后重跑 run-audit，直至达标。
> 可接受 warn（B 级可放行）：D4 / D7 / D8 / D9 / D10（非功能缺陷类；v5.24 例外：`D8_element_coverage` 的 FAIL 不可放行——页覆盖率 <90% 或缺标类型 ≥3 时判 FAIL）。D3 无弹窗设计记 n/a 不产生 warn（v2.2 决策A 豁免）。
> runtime_audit_passed 写入门禁与 verify-delivery V-4 完全对齐——审计通过即代表可交付，
> 不会在打包后被 V-4 二次打回（消除"B 到底能不能过 V-4"的返工困惑）。
> 评级结果写入 state.yaml 的 runtime_audit_passed 字段（达标=true，否则不写）。
> 无 Playwright 环境时 run-audit 显式 FAIL 退出，禁止静默通过。

> **v5.14.16 根治硬门禁**（A/B 测试 wb-dsf-0731-2 暴露的漏洞修复）：
> - **package-delivery.mjs 软门禁升级为硬门禁**：删除 demo_protected 软分支 + UNVERIFIED-LABEL 软警告。
>   state.yaml 无 `runtime_audit_passed: true` 也无 `final_approved: true` 时**硬 FAIL 退出码 1**。
>   AI 无法再通过"标注未审计"绕过门禁，必须返回 Phase 2 修复 demo 重跑 run-audit 至 A/B 级。
> - **截图黑名单**：失败证据截图（含 `failed`/`no-coop`/`error` 关键词）不进入客户交付包。
> - **.tmp-full 位置迁移**：临时目录从 `delivery/.tmp-full` 迁移到 `.demora/.tmp-full-package/`，
>   即使清理失败也不会污染 delivery/ 目录。
> - **设计原则**：任何门禁都不能停留在"AI 应该遵守 SKILL.md 文字"层面，必须脚本硬阻断。
>   AI 时间压力下会自行合理化违规，软警告无法约束，只有硬 FAIL 退出码 1 才能强制阻断。

> **v5.14 硬指令**：package-delivery.mjs 完成后**必须执行 verify-delivery.mjs**，完成 V-1~V-13 完整性校验。
> - V-1~V-11：交付物完整性 + 哈希终检（防御验收后产物漂移）
> - V-12（v5.14.16 批次1 新增）：state.yaml 状态机一致性校验，认可 `delivery_packaged=true + final_approved=false + current_phase=2` 中间态（消除设计死锁），防御手动编辑绕过
> - V-13（v5.14.16 批次1 新增）：交付物洁净度 + 哈希绑定校验（防御调试文件/失败截图/delivery-stash 残留 + delivery_demo_hash 不一致）
> - V-4（v5.14.16 批次2 修复 G 增强）：B 级门禁区分 warn 严重性。overall=B 时扫描 dimensions，`D0_console` warn（console error/404）、`D6_button_responsiveness` warn（按钮无响应/全 disabled）和 `D8_element_coverage` FAIL（v5.24 新增：页覆盖率 <90% 或缺标类型 ≥3）判为不可接受 warn 降级 FAIL；清单外 warn（D4 / D7 / D8 / D9 / D10）可放行。需修复至 A 级才可放行。D3 无弹窗设计记 n/a 不产生 warn（v2.2 决策A 豁免）。
> verify-delivery.mjs 通过后，state.yaml 的 delivery_consistency_verified 自动设为 true。
> 跳过 verify-delivery.mjs 视为 Phase 3 未完成。

> **v5.14.16 批次2 修复 J — run-audit 截图清理 shim 适配**：
> - 审计前截图清理改用 `platform-utils.safeCleanFilesSync` 批量删除，shim 拦截时自动降级（unlinkSync → rmSync）
> - 清理失败时输出 `[shim active]` / `[shim inactive]` 标记，辅助诊断是否 shim 拦截
> - 批次1 A/B 测试验证：safeRemoveFileSync 在 WorkBuddy shim 环境下有效

> **v5.14.16 批次2 修复 K — dist 发布前 WorkBuddy 兼容性检查**：
> - build-test-dist.mjs DIST 阶段自动生成 `dist/WorkBuddy-compatibility-checklist.md`
> - 自动检测项：运行 platform-check.mjs 收集 shim/编码/路径/权限预检结果
> - 人工执行项：21 项 WorkBuddy 环境冒烟测试清单（脚手架→审计→打包→校验全流程）
> - 归档流程：PM 人工执行勾选 → 重命名为 `WorkBuddy-compatibility-report-<skill>.md` → 归档到 `docs/audit-reports/`

## audit 失败一次性修复指引

> **详细内容已下沉至 `references/audit-fix-guide.md`，本节仅保留摘要**

> **核心原则**：audit 失败时，AI 必须一次性读取 [FIX_SUGGESTIONS] 块并按指引修复，禁止读源码、禁止反复重试。

### 修复流程

1. **读取 [FIX_SUGGESTIONS] 块**
   - run-audit 输出末尾会包含 `[FIX_SUGGESTIONS_BEGIN]` ... `[FIX_SUGGESTIONS_END]` 块
   - 块内是 JSON 数组，每项含 4 字段：
     - `dimension`：失败维度（D10/D3/D5/D9）
     - `root_cause`：可能根因（多个）
     - `fix_pattern`：修复模式描述
     - `evidence_selector`：可执行的证据收集命令（grep/node -e）
     - `diagnostics`：run-audit 收集的浏览器 DOM 状态快照

2. **按 evidence_selector 收集证据**
   - 执行 `evidence_selector` 字段的命令（如 `grep -n "display:\\s*none" demo/assets/style.css`）
   - 根据输出判断哪个 `root_cause` 命中

3. **按 fix_pattern 修复**
   - **修复前先读 `demo/fix-suggestions.json`**（v2.1 新增）：run-audit 失败时自动写入的结构化修复建议（失败维度 + root_cause + fix_pattern + 证据选择器），体积比全量审计输出小一个量级，是修复推理的首选输入
   - 根据命中的 `root_cause` 应用对应的 `fix_pattern`
   - 修复后重新运行 audit

4. **重试时使用 --retry 模式（v5.18 P0-A5 更新）**
   - 重试命令：`node scripts/run-audit.mjs --demo <demo-dir> --retry`
   - --retry 等价 --dimensions-only + 跳过截图 + 跳过 self-diagnostics（输出 < 2KB，轻量化的是上下文体积而非耗时——维度检测仍全量执行，约与全量审计同耗时）
   - 失败时自动写 demo/fix-suggestions.json（含失败维度 + 修复命令）
   - **修改 demo 任何文件后必须先重跑 `diagnose-runtime` 再 --retry**（A4 新鲜度门禁会拒绝过期诊断，秒退且退出码 1 即此原因）
   - **仅最终验收跑全量审计**（不带 --retry）

### 禁止行为

- **严禁读取 run-audit.mjs 源码**定位失败原因（违反将导致审计失败判定无效）。
  - 失败原因必须使用审计输出的 [FIX_SUGGESTIONS] 块，其中 `detection_logic` 字段描述了该维度的检测逻辑摘要，`evidence_selector` 提供 grep 命令用于定位问题代码。
  - 审计前自检：确认本次会话未读取 run-audit.mjs 源码（若已误读，应停止并重新开始）。
- **禁止盲目重试**（重试前必须按 fix_pattern 修复）
- **禁止超过 2 次重试**（如 2 次仍失败，应人工介入或回退到上一稳定版本）

## 标注系统

### 三层标注体系

| 层级 | 回答 | 视觉标记 |
|------|------|---------|
| L1 页面说明 | "这个页面是干什么的" | 面板中的摘要卡片 |
| L2 区域标注 | "这块区域是什么逻辑" | 绿色水滴形编号 |
| L3 元件标注 | "这个控件怎么交互" | 蓝色圆点指示器 |

### 标注数据约定

标注系统是独立叠加层，AI 的 JS 逻辑零侵入（无需引入 mixin/插件/全局状态）。但 AI 必须在 HTML 结构中完成以下 4 项：

1. 在区域容器上添加 `data-zone-id="P01-L2-001"` 属性 <!-- v5.19 P1-1：id 编码统一 Pn-Ln-xxx，与 __ANNOTATION_DATA__ 的 id 一致 -->
2. 在元件包裹层上添加 `data-element-id="P01-L3-001"` 属性
3. 在 L2 区域内添加 `<span class="l2-marker">` 标记元素（绿色水滴形编号，由标注引擎绑定点击事件）
4. 在 `<script>` 中定义 `window.__ANNOTATION_DATA__` 对象（含 L1/L2/L3 数据）

`enhance-prototype.mjs` 自动注入标注三件套（CSS + HTML + JS），不侵入 AI 的代码。

详见 `references/annotation/annotation-guide.md`。

### L2/L3 覆盖率要求（v5.13.3 新增 — 强制）

**L2 区域覆盖率**：每个页面的可视范围内所有主要区域都必须有 `data-zone-id` 标注。

主要区域定义（必须标注）：
- 页面 hero/标题区
- 列表/表格区
- 表单区
- 详情/卡片区
- 操作按钮区
- 筛选/搜索区
- 统计/概览区
- 弹窗/抽屉内容区

**L3 元件覆盖率**：每个页面的可视范围内所有**去重后的可交互元件类型**（按元素类型+功能归并）必须至少有 1 个 `data-element-id` 标注。

**同类元件 L3 标注规模分流（v5.24 裁决，替换 v5.23"同类只标首个"）**：
- 同类组 ≤ 4 个可见实例（指标卡组、固定小列表行等）：全部实例必须标注，卡片描述须为同属性（禁止把同属性元件描述成不同属性）
- 同类组 > 4 个实例（数据表多行操作按钮等）：只标注首个可见实例（DOM 顺序第一），且 `__ANNOTATION_DATA__` 卡片 element 名必须含同类说明，模板："xxx（同类首个，其余 N 个实例共用本说明）"
- 检测：D8_element_coverage 按类型实例规模差异化校验（≤4 组任一未标即缺标；>4 组校验首实例+说明）；P041/D8 序号型重复仅对 >4 组告警

可交互元件定义（去重后每类型必须至少标注 1 个）：
- `<button>` 按钮
- `<input>` 输入框（含 text/number/date/email/password/search）
- `<select>` 下拉选择
- `<textarea>` 文本域
- `<a href>` 链接（导航/操作类，纯展示链接除外）
- `[role="button"]` ARIA 按钮
- `[contenteditable]` 可编辑区域
- `[tabindex]` 可聚焦元素

**L3 元件一致性**：标注数据中定义的每个 L3 id 必须在 HTML 中有对应的 `data-element-id` 元素，且该元素内有实际的可交互元件（不能只有 `.l3-dot` 指示器而无实际元件）。

**按状态显隐的元件处理**：
- 当元件按状态条件显隐（如 `style.display = 'none'`）时，标注引擎 v5.2.3 会自动过滤"容器可见但内部实际元件全隐藏"的 L3 标注，不在面板显示卡片
- AI 应确保 `data-element-id` 包裹的是完整的元件组（含显隐逻辑），而不是仅包裹 `.l3-dot`

**表格结构标注禁令（v5.23 新增）**：
- 禁止在 tr/td/th/tbody/thead 等表格结构元素上直接放置 `data-element-id`
  （标注系统的 `[data-element-id]` 布局契约会覆盖原生 table-row 显示，导致整行布局坍塌——UAT0824 实证缺陷）
- 行级标注的正确做法：放在行内第一个交互元素（button/a/select）上；无交互元素时用行内 `<span data-element-id>` 包裹首个单元格内容
- enhance-prototype C20 会自动迁移存量违规标注；pre-audit P040 静态检测违规即 FAIL

<!-- v5.19 P2-1：标注说明详尽度契约 -->
**标注说明详尽度要求（v5.19 P2-1 新增 — 强制）**：
- L2 `description` 须含两要素：**功能**（这块区域做什么）+ **数据来源/业务规则**（数据从哪来 / 按什么规则处理），参考长度 ≥ 30 字
- L3 条目五字段 `id` / `element` / `function` / `trigger` / `response` 必须齐全，建议补充 `condition`（触发条件）/ `exception`（异常分支）

### 标注数据结构（v5.13.3 新增 page.name）

`window.__ANNOTATION_DATA__` 的每个页面对象必须包含 `name` 字段（页面中文名称），用于标注面板头部显示：

```javascript
window.__ANNOTATION_DATA__ = {
  P01: {
    name: '专利清单',  // 页面中文名称（必填，显示在标注面板头部 "P01 - 专利清单"）
    L1: { summary: '...', entry: '...', ... },
    L2: [{ id: 'P01-L2-001', zone: '搜索筛选区', description: '...' }, ...],   // v5.19 P1-1：id 用 Pn-Ln-xxx（页面-级别-页内序号，每页每级别从 001 起）
    L3: [{ id: 'P01-L3-001', element: '搜索按钮', ... }, ...]
  },
  P02: {
    name: '转化详情',
    ...
  }
}
```

`name` 字段也兼容 `title` 别名（`ann.name || ann.title`）。

<!-- v5.19 P1-1：标注 id 编码契约统一 -->
**id 编码契约（v5.19 P1-1 统一）**：L2/L3 的 `id` 统一采用 `Pn-Ln-xxx` 编码（页面-级别-页内序号，如 `P01-L2-001` / `P01-L3-001`，每页每级别从 001 起），与标注引擎 marker 的编码保持一致；标注面板会以引擎编码为主标签显示。HTML 中 `data-zone-id` / `data-element-id` 的属性值须与对应 L2/L3 `id` 一致（P018 数量比对 / S-11 id 对应均按此口径）。

### 标注注入流程

```bash
node scripts/enhance-prototype.mjs       # 注入标注三件套到 demo/
node scripts/diagnose-runtime.mjs --demo demo  # v5.18 P0-B2：运行时快速确诊（D3/D6/D9/D10，<90s，须 0 失效才进 run-audit）
```

脚本仅做三件事：
1. 注入 `annotation-styles.css` 到 `<head>`
2. 注入 `annotation-panel.html` 到 `<body>` 末尾
3. 注入 `annotation-engine.js` 到 `<body>` 末尾

> **v5.18 P0-B2：运行时快速确诊（diagnose-runtime.mjs，supersede diagnose-button-failure）**
> - `enhance-prototype.mjs` 完成后必须执行 `diagnose-runtime.mjs`，**须 0 失效**才进 pre-audit-check / run-audit
> - 定位：把"猜根因 → 修 → 跑 4-16m 全量审计试错"的盲修循环，替换为 <90 秒确定性确诊
> - 检测维度（谓词来自 `scripts/lib/audit-probes.mjs` 单一事实源（v5.18 P0-A2 迁移完成），保证"诊断过 = 审计过"）：
>   - D0 console：404/error 资源（favicon 已由 generate-demo 注入 `<link rel="icon" href="data:,">`）
>   - D3 弹窗闭环：触发→显示→关闭→隐藏 全链路（逐 trigger 输出选择器 + 断裂点）
>   - D6 按钮响应：可见可交互按钮点击响应 + init 异常关联（取代 diagnose-button-failure 的 D6 检测）
>   - D9/D10 标注协同/激活：`__ANNOTATION_DATA__` + marker/dot + 面板激活反馈
> - 输出：控制台逐元素失败清单（选择器 + 根因分类 + fix_pattern）+ `demo/diagnose-result.json` 结构化结果
> - 退出码：0=0 失效（可进 run-audit 验收），1=有失效（须修复），2=Playwright 不可用
> - 流程：AI 按 fix_pattern 修复 demo → 重跑 diagnose-runtime 至 0 失效 → pre-audit-check → run-audit（此时应一次通过）
> - 关系：diagnose-runtime 检测的是真实功能缺陷（按钮真没绑定、弹窗真关不掉、标注真没激活），修复即真实质量提升，非定向骗过审计

## 运行时契约

> **详细内容已下沉至 `references/runtime-contract.md`，本节仅保留摘要**

AI 生成 Demo 时必须遵守以下运行时约定，避免与标注引擎冲突或导致功能失效。

### 10 个运行时陷阱

| # | 陷阱 | 后果 | 规避方式 |
|---|------|------|---------|
| 1 | 全局作用域 `const` 冲突 | 标注引擎 IIFE 内部变量与 AI 全局变量同名时，AI 代码可能覆盖标注引擎行为 | AI 避免在全局作用域使用 `const app =`、`const state =` 等常见变量名，改用模块作用域或命名空间（如 `const myApp = {}`） |
| 2 | `focusZoneCard` 副作用 | 点击 `.l2-marker` 会自动打开标注面板并切换到 L2 Tab，AI 不应假设面板始终隐藏 | AI 的交互逻辑不应依赖标注面板的显隐状态；面板由标注引擎独立管理 |
| 3 | L2 marker 元素缺失 | 标注引擎通过 `closest('.l2-marker')` 查找标记，若 AI 未添加则 L2 点击高亮失效 | AI 必须在每个 `data-zone-id` 区域内添加至少一个 `<span class="l2-marker">` 元素 |
| 4 | Vue Router 4 同路径导航 | `router.push('/current-path')` 会抛出 NavigationDuplicated 警告 | AI 在导航前应检查目标路径是否与当前路径相同，或使用 `router.replace()` |
| 5 | `display:flex/grid` 覆盖 `hidden` 属性 | CSS `display:flex` 会覆盖 HTML `hidden` 属性的默认 `display:none`，导致弹窗/元素无法隐藏 | AI 在使用 `hidden` 属性时，CSS 必须用 `.xxx:not([hidden]) { display: flex }` 而非 `.xxx { display: flex }`；或依赖全局 `[hidden] { display: none !important }` 防御（v5.13.4 已注入） |
| 6 | 页面显隐双轨混用（v5.14 新增） | 同一 demo 同时使用 CSS 类切换（`.xxx{display:none}` + `.xxx.active`）与 JS `hidden` 属性切换，两者错配会导致所有页面永久隐藏 | 禁止双轨混用，统一为单轨制（推荐 JS `hidden` 属性，与 HTML5 规范一致）。S-14 强制检测 |
| 7 | D3 弹窗触发属性定向修补（v5.14 新增） | AI 仅给按钮添加 `data-open-modal` 属性但不绑定事件，企图骗过 D3 检测 | D3 改为闭环验证：触发→显示→关闭→隐藏。点击触发按钮后弹窗必须实际显示，否则 FAIL |
| 8 | D6 disabled 按钮移除定向修补（v5.14 新增） | AI 移除按钮 `disabled` 属性以过 D6 响应率检测，但实际功能未实现 | D6 豁免 `disabled` / `aria-disabled="true"` / `.disabled` / `pointer-events:none` 按钮，仅检查启用按钮的 click 响应 |
| 9 | S-11/D8 静态 HTML 预放 L3 元件（v5.14 新增） | AI 在 tbody 中预放一行静态 HTML 含 `data-element-id`（DOMContentLoaded 时被 renderRows 替换），企图骗过 S-11 一致性检测 | S-11 保留静态初筛；D8 运行时 DOM 断言：用 Playwright 读取运行时 DOM，对每个 `data-element-id` 元件检测交互意图（天然可交互标签 / tabindex / onclick / data-action / cursor:pointer / 父元素可交互），无交互意图则用 click + MutationObserver 验证响应 |
| 10 | D9 标注面板与页面协同缺失（v5.14 新增） | AI 添加 `.l2-marker` 但标注开关点击后面板未显示，或面板显示后左侧页面内容被遮挡，导致标注不可用；或面板激活但左侧 `.anno-zone` 未高亮 / `.l3-dot` 未激活（面板-页面协同断裂） | D9 闭环验证：开关点击→面板显示→L2 点击→`.anno-zone.is-highlighted` + `.anno-card.is-active` + 无遮挡→L3 dot 点击→`.l3-dot.is-active` + `.anno-card.is-active`→关闭按钮→面板隐藏。协同缺失即 FAIL |

#### D9 L3 时序排查指引（v5.14.16 批次3 修复 N 新增）

D9 陷阱 #10 中 L3 协同失败（`.l3-dot` 未激活 / `.anno-card` 未切换）常见根因是**时序问题**，非标注引擎缺陷。按以下步骤排查：

1. **L3 dot 元素存在性**：打开 devtools，执行 `document.querySelectorAll('.l3-dot').length`，确认数量与 `data-element-id` 一致。若为 0，检查 `data-element-id` 包裹层是否在 DOMContentLoaded 时被 JS 重渲染替换（陷阱 #9）。
2. **L3 dot 点击事件绑定**：执行 `getEventListeners(document.querySelector('.l3-dot'))`（Chrome）或在 Console 手动 `document.querySelector('.l3-dot').click()` 观察面板是否切换。若点击无反应，确认标注引擎已初始化（`window.__ANNOTATION_ENGINE__` 存在）。
3. **时序冲突**：若 AI 的 init 序列在 `DOMContentLoaded` 后异步执行（如 setTimeout / fetch 回调），可能在标注引擎初始化前替换了 DOM，导致 `.l3-dot` 元素丢失事件绑定。解决：AI 的 DOM 替换操作应在同步 init 中完成，或替换后调用 `window.__ANNOTATION_ENGINE__.refresh()`。
4. **L3 数据完整性**：执行 `JSON.stringify(window.__ANNOTATION_DATA__.l3)` 检查 L3 数据结构，确认每个 `data-element-id` 有对应的 L3 卡片数据。数据缺失会导致 dot 点击后面板无内容。

#### 按钮绑定自检（v5.14.16 批次3 修复 N 新增 — warn 级）

D6 按钮响应率检测时，若按钮无 `onclick` 属性、无 `data-action`/`data-open-modal` 属性，且点击后无 DOM 变化，D6 输出 warn 级提示（非 fail）。AI 应按以下自检清单排查：

1. **事件绑定方式**：现代 SPA 常用事件委托（`document.addEventListener('click', handler)` + `event.target.closest('button')`），而非每个按钮单独 `addEventListener`。D6 检测支持事件委托模式（MutationObserver + 状态变化检测），但若委托 handler 逻辑有误（如 selector 匹配失败），按钮点击仍无响应。
2. **init 序列异常中断**：若 app.js 的 init 函数在某个按钮绑定前抛异常（如 `document.getElementById('non-existent')` 返回 null 后访问属性），后续所有按钮绑定都会被跳过。检查 Console 是否有未捕获异常。
3. **异步绑定延迟**：若按钮事件在 `fetch` 回调或 `setTimeout` 中绑定，D6 的 500ms 等待窗口可能不够。解决：将关键按钮绑定移到同步 init 中，或增大 D6 等待时间（需改 run-audit.mjs，非推荐）。
4. **CSS 遮挡**：按钮可见但被透明 overlay 遮挡（如 `position: fixed` 的全屏元素），点击实际落在 overlay 上。检查 devtools Elements 面板的点击命中元素。

> **warn 级说明**：按钮绑定自检失败不直接判 D6 fail（因事件委托模式合法），但会输出 warn 提示 AI 检查上述清单。若按钮完全无响应（响应率 < 50%），D6 才判 fail。

### AI 必须添加的 4 项 HTML 元素

标注引擎不自动创建以下元素，AI 必须在 HTML 中手动添加：

1. `data-zone-id` 属性 — 标注 L2 区域的容器
2. `data-element-id` 属性 — 标注 L3 元件的包裹层
3. `.l2-marker` 类 — L2 区域的可点击标记（绿色水滴形编号）
4. `window.__ANNOTATION_DATA__` — 标注数据对象（含 L1/L2/L3 结构）

### 标注开关与面板

- 标注开关 `[data-annotation-toggle]` 由 AI 在页面顶部工具栏放置
- 标注面板 `.annotation-panel` 由 `enhance-prototype.mjs` 自动注入，AI 无需创建
- 标注引擎在 `DOMContentLoaded` 后自动初始化，AI 无需手动调用

**运行时契约（v5.13.1 新增 — 禁止重复绑定）：**

- **禁止**在 app.js / components.js 中为 `[data-annotation-toggle]` 或 `#annotationToggle` 添加 `addEventListener('click', ...)`
- 标注引擎已自动绑定 click → `togglePanel()`，AI 重复绑定会导致 togglePanel 被调用两次（状态相互抵消，面板永远无法显示）
- AI 仅可通过 `window.__ANNOTATION_ENGINE__.refresh()` 通知引擎数据变化，**不要**调用 `window.__ANNOTATION_ENGINE__.togglePanel()`

### Footer 布局契约（v5.14.17 批次5 R-7 新增）

> **背景**：A/B 测试发现部分 demo 缺少 footer 或 footer 结构不规范，导致：
> 1. 页面内容被标注面板遮挡（标注面板开启时右侧滑入，若无 footer padding 适配，底部内容不可见）
> 2. 视觉启发式检查 D7 报告"首屏文本密度过低"（footer 缺失导致页面结构不完整）
> 3. 交付网站 index.html 的 IP 风格模板依赖 footer 渲染版权信息

**AI 必须遵守的 footer 契约**：

1. **每个页面都必须有 `<footer>` 元素**（ SPA 单页应用也需在每个 page-view 内包含 footer）
2. **footer 必须包含**：
   - 版权信息（如 `© 2026 奥凯信息` 或项目名称）
   - 版本号或日期标记
3. **footer 位置**：在页面内容流的最底部，**禁止**用 `position: fixed` 固定在视口底部（会遮挡内容）
4. **footer 与标注面板的协同**：
   - 标注面板开启时会给 body 添加 `padding-right`（避免面板遮挡内容）
   - footer 必须能随 padding 调整位置，**禁止**用绝对定位脱离文档流
5. **footer 样式**：
   ```css
   footer {
     padding: 16px 24px;
     text-align: center;
     color: #999;
     font-size: 12px;
     border-top: 1px solid #eee;
   }
   ```

**自检**：AI 生成 demo 后，检查每个 `data-page-id` 页面内是否都有 `<footer>` 元素且非空。

### R-7 footer 布局契约（v5.14.18 强化 — body 布局禁令）

> **背景**：A/B 测试偶发 footer 漂移到页面右侧。根因：AI 将 `body` 自身设为横向 flex/grid 容器，注入的 footer 作为 flex item 被挤到主轴末尾（右侧）。虽然 v5.14.18 已在 footer 模板加防御性 CSS（`width:100%; flex-basis:100%; align-self:stretch`），但 AI 侧应从源头避免。

**禁止**将 `body` 自身设为横向 flex/grid 容器：
- ❌ `body { display: flex }`（默认 row，footer 会被挤到右侧）
- ❌ `body { display: grid; grid-template-columns: ... }`

**正确做法**：body 保持默认 block，或用 `body { display:flex; flex-direction:column }`。横向布局请在 body 内部用 `.layout`/`.app-shell` 容器承载。

示例：
```html
<body data-annotation-root>
  <div class="app-shell">    <!-- column flex -->
    <header class="topbar">...</header>
    <div class="layout">     <!-- row flex，承载 sidebar + main -->
      <aside class="sidebar">...</aside>
      <main class="content">...</main>
    </div>
  </div>
  <!-- v5.24：骨架版权 footer 由 enhance-prototype.mjs 注入滚动内容容器内（.content 内主滚动区末尾），无容器时回退 body 末尾；不再造成 document 溢出 -->
</body>
```

**v5.24 修订（骨架 footer 注入位置）**：enhance-prototype 注入的**版权 footer** 已改为注入**滚动内容容器内**（`.content` 或 `[data-annotation-root]` 内主滚动区，无容器时回退 body 末尾）——消除 document 溢出导致的导航滚动缺陷（UAT0826 p3 实证）；run-audit D7 初始态新增 document 溢出检测（存在 .app-shell 且 `document.scrollHeight > clientHeight + 4` → WARN）。**AI 业务 footer 仍按原 R-7 要求执行**：每个 page-view 内包含 footer（版权信息 + 版本/日期标记，内容流最底部，禁止 fixed）。

**自检**：AI 生成 demo 后，在浏览器 Console 执行 `getComputedStyle(document.body).display`，若返回 `flex` 则进一步检查 `flex-direction` 是否为 `column`，若为 `row`（默认）需修正。pre-audit-check P010 会检测此问题并 WARN。

### 标注结构完整性自检指引（v5.14.17 批次5 R-9 新增）

> **详细内容已下沉至 `references/annotation-structure-check.md`，本节仅保留摘要**

> **背景**：A/B 测试反复出现"左侧页面缺失标注"问题，根因是 AI 忘记写 `data-zone-id`/`data-element-id`/`.l2-marker` 元素。虽然 v5.14.6 标注引擎 `ensureMarkers()` 已自动创建 `.l2-marker` 和 `.l3-dot` 子元素，但 AI 仍需确保父级 `data-zone-id`/`data-element-id` 属性存在。

**AI 生成 demo 后必须执行的自检清单**：

1. **data-zone-id 覆盖率**：
   - 每个页面的主要区域（hero/列表/表单/详情/操作/筛选/统计/弹窗）都必须有 `data-zone-id` 属性
   - 自检命令：`grep -c 'data-zone-id' demo/index.html`，结果应 >= 页面数 × 3（每页至少 3 个 L2 区域）

2. **data-element-id 覆盖率**：
   - 每个页面的可视范围内所有**去重后的可交互元件类型**（按元素类型+功能归并）必须至少有 1 个 `data-element-id` 标注；同类组按 v5.24 规模分流执行——≤4 个可见实例全部标注（描述同属性），>4 个实例只标首个可见实例且卡片 element 名含同类说明（详见"L2/L3 覆盖率要求"节的同类元件规模分流契约）
   - 自检命令：`grep -c 'data-element-id' demo/index.html`，结果应 >= 页面数 × 5（每页至少 5 个 L3 元件）

3. **.l2-marker 元素**：
   - v5.14.6 起标注引擎 `ensureMarkers()` 会自动创建 `.l2-marker` 子元素，AI 无需手动写
   - 但 AI 必须确保 `data-zone-id` 容器存在且可见（`display: none` 的容器不会被自动创建 marker）

4. **__ANNOTATION_DATA__ 结构完整性**：
   - 每个页面对象必须有 `name`/`L1`/`L2`/`L3` 四个字段
   - L2 数组的每个项必须有 `id`/`zone`/`description`（v5.19 P2-1：description 须含"功能 + 数据来源/业务规则"两要素，参考 ≥ 30 字）
   - L3 数组的每个项必须有 `id`/`element`/`function`/`trigger`/`response`（v5.19 P2-1：建议补充 `condition`/`exception`）
   - 自检命令：
     ```bash
     node -e "const d=require('./demo/assets/app.js'.replace('.js','')); ..." # 简化示例
     ```
     实际：在浏览器 Console 执行 `Object.keys(window.__ANNOTATION_DATA__).forEach(k=>{const p=window.__ANNOTATION_DATA__[k]; console.log(k, p.name, p.L2?.length, p.L3?.length)})`

5. **L3 元件一致性**（标注数据 ↔ HTML 元素）：
   - `__ANNOTATION_DATA__` 中定义的每个 L3 id 必须在 HTML 中有对应的 `data-element-id` 元素
   - 自检：D8 维度会检测 `d8MissingElements`，若 >0 则说明标注数据与 HTML 不一致

**常见错误**：
- ❌ 只在 `__ANNOTATION_DATA__` 中写 L3 数据，但 HTML 中忘记加 `data-element-id` 属性
- ❌ `data-zone-id` 容器设为 `display: none`（标注引擎不自动创建 marker）
- ❌ L3 卡片的 `(element, function, response)` 三元组完全相同（R-6 会判重告警）
- ❌ footer 缺失或用 `position: fixed`（R-7 会触发 D7 视觉启发式告警）

### R-9 标注数据契约（v5.14.18 强化 — 解决标注面板与页面对不上问题）

> **背景**：A/B 测试偶发"标注面板与页面对不上"问题：①页面与标注面板的标注数量对不上；②点击标注面板后左侧页面对应标注图标没闪烁；③左侧页面的相同标注项在标注面板重复展示。根因是 AI 生成 `__ANNOTATION_DATA__` 时数据结构不规范或 id 重复。

**AI 必须遵守的标注数据契约**：

1. **数据结构**：必须用扁平结构 `{P01:{L2:[...], L3:[...]}, P02:{...}}`，**禁止**用包装结构 `{version, pages:{}}`。审计侧 P009/D8/D10 已对齐引擎的包装结构兼容（支持两种格式检测），但扁平结构是首选。

2. **同页 id 唯一性**：同一页面内，L2 的 `id`（zone id）和 L3 的 `id`（element id）必须唯一，**禁止**同页内 id 重复。
   - 跨页 id 复用（如每页都有 `R-001`）是引擎设计支持的，**不禁止**。
   - 同页内 id 重复会导致 `querySelector` 只命中第一张卡片，第二张永不激活（P-A2 不闪烁），且渲染时不去重会重复展示（P-A3）。
   - 引擎 v5.14.18 已增加同页 id 去重（保留首条），AI 仍需保证数据源正确。

3. **data-zone-id 放置**：`data-zone-id` 必须写在 zone 容器（`.anno-zone`）上，**禁止**直接写在 `.l2-marker` 上。后者会导致 `ensureMarkers` 嵌套创建 marker，点击协同失效。

4. **CSS 保留类名**：禁止在 demo CSS 中重复定义 `.l2-marker`/`.l3-dot`/`.anno-zone`/`.anno-card` 等保留类名，尤其禁止用 `!important` 覆盖引擎的 `display:flex`/`display:block`。

5. **三元组去重**：L3 卡片的 `(element, function, response)` 三元组应去重。>4 实例同类组按 v5.24 规模分流只标首个（element 名含同类说明）；≤4 实例同类组全标时允许 element 名区分实例（如"指标卡·待处理/指标卡·已完成"同属性命名）。D8 序号型重复检测仅对 >4 组告警（v5.24 规模感知）。

6. **数量一致性**：`__ANNOTATION_DATA__` 中声明的 L2/L3 数量必须与 HTML 中 `data-zone-id`/`data-element-id` 元素数量一致。D10 会检测数量不一致并 WARN。

### R-10 跨页联动枚举一致性契约（v5.21 新增 — 解决跨页过滤值与数据层枚举不一致）

> **背景**：p10 UAT 实测——P01 漏斗按钮 `data-stage="MATCHING"`（英文），app.js 数据层 stage 为中文（匹配中等），`gotoFunnel` 将英文值写入过滤器后匹配 0 条，目标页表格空白且 select 赋值静默失败回退默认项，用户感知"元件无默认值导致区域空白"。

**AI 必须遵守的联动传值契约**：

1. **枚举字面量对齐**：HTML 中经 `getAttribute('data-xxx')` / `dataset.xxx` 消费、用于过滤/匹配/查找的自定义属性值，必须与 app.js 数据层的枚举字面量**完全一致**（含大小写与语言）。跨页联动（如漏斗/看板卡片跳转并过滤目标页列表）是高发场景。
2. **消费即自查**：每写一个 `data-xxx="值"` 且 app.js 会读取它，就确认该值能作为 token 在 app.js 中找到（对象键、字符串字面量或数字均可）。找不到 = 过滤必然落空。
3. **框架属性豁免**：data-nav/data-page-id/data-route/data-target（页面路由，由导航完备性维度保障）、data-action/data-open-modal/data-code（框架语义）不适用本契约。
4. **常见错误**：❌ HTML 用英文枚举、JS 数据用中文；❌ 复制需求文档中的状态码未与 demo 数据对齐；❌ 属性值拼写与对象键不一致（如 data-tpl="Buyout" vs `buyout:`）。
5. pre-audit-check.mjs **P037** 会对不一致 FAIL 硬阻断，修复方式是让 HTML 属性值与 app.js 枚举对齐（通常改 HTML 属性值为数据层既有字面量）。

### R-11 交互实质性与筛选实现契约（v5.22 新增 — 解决"筛选仅演示/开关点不动"死交互）

> **背景**：UAT 实测暴露"死交互"高发模式——筛选控件回调仅调用渲染函数但从不读取控件当前值（筛选形同虚设）、文本搜索无逐键响应、`handleDemoAction` 读取元素未携带的 `data-*` 属性恒为 null 形成死分支。此类缺陷 P036 语法级检测不可见，需数据流级静态检测（P038/P039）与 D6 运行时业务状态签名共同拦截。

**AI 必须遵守的交互实质性契约**：

1. **筛选实现检查清单**：每个筛选/搜索控件的处理必须读取控件当前值（`[data-action="X"]` 选择器 / 元素 id / `el.value`），且该值必须影响渲染输出（行集/统计/可见性变化）。调用渲染函数但忽略控件值 = 无操作筛选（P038 静态 WARN + D6 业务状态签名运行时拦截）
2. **搜索实时性**：文本类筛选/搜索控件依赖骨架内置 input 实时通道（v5.22 起默认提供，逐键派发），**禁止**再自建 input 监听形成双通道；select 类沿用 change 语义（骨架 input 通道已排除 SELECT，防 input+change 双触发）
3. **属性消费一致性**：`handleDemoAction` case 体读取的 `data-*` 属性名必须与携带该 `data-action` 的元素实际属性一致——读取元素未携带的属性恒为 null（死分支，P039 静态 WARN）
4. **事件派发契约**：骨架保证单事件单次派发（v5.22 幂等标志，元素级 onclick 与 document 委托互为冗余）；`data-action` 与 `data-open-modal`/`data-nav`/`data-route` 并存时按优先级链短路，`data-action` 仅作静态线索（对齐 P008）

### audit 高频失败模式自查清单（v5.14.18 批次1 新增 — 组A 重试治理）

> **详细内容已下沉至 `references/audit-failure-checklist.md`，本节仅保留摘要**

> **背景**：A/B 测试显示 40m+ 运行时长中 30-40m 耗费在 audit 失败重试。AI 若在 demo 生成阶段按本清单自查，可前置消除 80% 重试。配合 pre-audit-check.mjs P006-P010 硬拦截，重试次数从 4 轮降至 1-2 轮。

**D3 弹窗闭环失败自查**（对应 P008）：
- 每个弹窗触发按钮必须有事件绑定：`onclick` 属性 / `data-action` 属性 / app.js 中 `addEventListener` 三者至少其一
- 自检：在浏览器 Console 执行 `document.querySelectorAll('[data-open-modal]')`，对每个结果检查 `onclick` 属性或 app.js 中对应 id/class 的事件监听
- 常见错误：只写 `data-open-modal` 属性但不绑定 onclick，D3 闭环检测会 FAIL
- v2.2 决策A：demo 设计为无弹窗时 D3 记 n/a（`pass: n/a`）不计 warn；但需求要求弹窗交互时仍必须实现真实闭环，禁止以"无弹窗设计"为由省略需求要求的功能

**D9.4 L3 协同失败自查**（对应 P007）：
- `.l3-dot` 未激活时 `display:none` 是标注引擎正常设计，但激活后必须有 `[data-annotation-active] .l3-dot { display:block }` 规则
- 自检：`grep 'data-annotation-active.*l3-dot' demo/index.html`，应至少 1 条匹配
- 常见错误：AI 覆盖 `.l3-dot` 样式但忘记写激活规则，导致 L3 dot 永久隐藏

**D10 L3 激活失败自查**（对应 P006）：
- main 内容区不能被 `display:none` 或 `visibility:hidden`（即使有 JS 切换逻辑，静态预检会误报）
- main 容器的 `color` 与 `background` 不能完全相同（文本不可见）
- 自检：`grep -E 'main\s*\{' demo/assets/style.css`，检查 main 块无 display:none/visibility:hidden，且 color ≠ background
- 常见错误：body 设深色背景但 main 未设 background，透明背景暴露父元素深色，L3 文本不可见

**D5 多页锚点失败自查**（对应 P003）：
- 每个页面必须有 `data-page-id` 属性，且导航链接的 `data-nav` 值与页面 id 一一对应
- 自检：`grep -c 'data-page-id' demo/index.html` 应等于页面数；`grep -c 'data-nav=' demo/index.html` 应等于导航链接数
- 常见错误：新增页面但忘记加 data-page-id，或导航 data-nav 值与页面 id 不匹配

**L3 卡片三元组重复自查**（对应 P009）：
- L3 卡片的 `(element, function, response)` 三元组不能完全相同（R-6 判重）
- 自检：pre-audit-check P009 会自动检测，WARN 不阻断但建议修复（D8_l3_duplication 会 warn）
- 常见错误：多个页面的"提交"按钮都用相同的 element/function/response 描述，应差异化（如"提交预审案件"/"提交整改反馈"）

**L3 id 唯一性自查**（v5.15 新增 — L-3）：
- 同一页面内无重复 `data-element-id` 值（pre-audit-check P009 已检测，自查阶段消除）
- 自检：`grep -o 'data-element-id="[^"]*"' demo/index.html | sort | uniq -d`，应无输出

**反模式禁止（v5.15 新增 — L-5）**：
- **禁止 hidden/disabled 切换页面可见性**：用 `display:none`/`hidden` 切换页面会导致 D10 标注未激活。正确方式：路由函数 + `scrollIntoView` + 高亮，不用 hidden 属性切换页面
- **禁止全局 querySelector 查找标注**：必须限定到当前可见页面 `[data-page-id]:not([hidden])`，全局查询返回隐藏页面元素导致 D5/D10 假阴性

**状态文件回写门禁（v5.15 新增 — P2-1）**：
- package-delivery 前检查 decisions.yaml/context.yaml/conversation-log.yaml 非空：
  - decisions.yaml: `decisions[]` 至少 1 条
  - context.yaml: `design_methodology_read: true`
  - conversation-log.yaml: 至少 3 条记录
- 空置 → WARN（不阻断，但记录到 quality-report Q-8）

**conversation-log 即时追加规范（v5.23 新增）**：
- `.demora/conversation-log.yaml` 条目必须在事件发生时即时追加真实时间戳，禁止流程结束后统一补记估算时间戳
- 理由：事后补记的时间戳与脚本产物真实时间戳矛盾，过程记录失去可信度（UAT0824 opencode 案例实证）

**模型名规范（v5.15 新增 — P2-4）**：
- state.yaml 的 `model_name` 字段必须与 package.json 的 `demora.llmType` 一致
- 禁止使用别名：hy3 应写 GLM-5.2，deepseek-v4-flash 应写 DeepSeek-V4-Flash

### 上下文载入规范（v5.14.18 批次1 新增 — 组D AI 行为优化）

> v5.16 优化：state.yaml 通过 lib/state-cache.mjs 按 mtime 失效缓存复用，单次会话内多次读取同一 state.yaml 仅 1 次 IO。computeDirHash / SCREENSHOT_BLACKLIST_REGEX / SHELL_SIGNATURES 已抽取到 lib/hash-utils.mjs 共享，消除 4 个脚本间的重复实现。

**Phase 1 一次性载入**：
- SKILL.md：Phase 1 开始时完整读取 1 次，后续 Phase 2/3 不重复读（内存保留）
- requirement-model-schema.yaml：Phase 1 读取 1 次，校验时复用内存
- 禁止：每个 Phase 重新 Read SKILL.md（已读内容在上下文中）

**demo/index.html 载入**：
- Phase 2 生成 demo 后，如需检查结构，用 Grep 提取关键标记（data-page-id/data-zone-id/data-element-id 计数），不全文重读
- Phase 3 audit 后修复时，用 Edit 精确定位修改，不全文重读

**audit-result.json 载入**：
- run-audit 完成后读取 1 次，提取 dimensions 中 fail/warn 项
- 禁止：用 `grep -v` 过滤审计输出（批次1 修复 G-1 已禁令），必须完整读取 stdout
- 修复后重跑 audit，再读 1 次新 audit-result.json

## 脚本清单

| 脚本 | 说明 |
|------|------|
| `main.py` | CLI 入口 |
| `derive-project-name.mjs` | v5.12 AI 提炼项目名候选 |
| `scaffold-project.mjs` | 初始化项目目录（v5.12 支持 `--project-slug` 创建子目录） |
| `validate-model.mjs` | 校验需求模型完成度（v5.25 P0-2b：隐藏容器 L3 契约锁定前硬拦截——L3 锚点指向弹窗/抽屉内部控件判 FAIL，弹窗内交互由触发器承担标注） |
| `lock-model.mjs` | 锁定/解锁需求模型（v5.25 P0-2 解锁看门狗：第 2 次解锁 ESCALATION、第 3 次硬阻断 --force 放行；P1-3 写 phase2_started_at） |
| `append-conversation-log.mjs` | v5.25 P1-2 会话日志唯一追加入口（`--message "..." [--actor ai] [--phase N]`；时间戳取机器当前时间，禁止事后补记；conversation-log.yaml 为只读，直接编辑 EPERM） |
| `render-card.mjs` | 渲染交互卡片 |
| `generate-demo.mjs` | 创建空 demo/ 目录结构 |
| `enhance-prototype.mjs` | 注入标注三件套 |
| `generate-prd.mjs` | 生成 24 个 Markdown 文档 |
| `generate-product-docs.mjs` | 生成 HTML 产品文档 |
| `generate-traceability.mjs` | 生成追溯矩阵 |
| `check-structure.mjs` | 结构完整性校验 |
| `check-business-fill.mjs` | 业务填充完整性校验 |
| `quality-check.mjs` | 质量检查 |
| `sync-docs.mjs` | 同步决策到文档 |
| `package-delivery.mjs` | 打包交付（v5.14.16 批次1 硬门禁：runtime_audit_passed/final_approved 非 true 硬 FAIL + 截图黑名单 + label 过滤 + delivery_demo_hash 写入） |
| `verify-demo-runtime.mjs` | Demo 运行时验证 |
| `verify-delivery.mjs` | 交付物完整性校验（v5.14.16 批次1：V-1~V-13，含 V-12 状态机一致性 + V-13 洁净度+哈希绑定；批次2 修复 G：V-4 B 级 warn 严重性区分） |
| `run-audit.mjs` | 浏览器运行时审计（D0~D11，18 个维度；v5.24：D8_element_coverage 规模分流校验+FAIL 升级+d8_coverage_details 明细落盘 / D6 控件收集扩展 input[type=text]+select / 筛选往返一致性探针（挂 D10 循环）/ D10 导航后公共区域完整性断言 / D7 初始态 document 溢出检测；v5.23：D11 docs mermaid 渲染校验 / D7 逐页表格完整性 / D8 密度双向检测；v5.14.16 批次1：D6 全量页面遍历+状态复位/D10 全量激活；批次2 修复 J：截图清理 safeCleanFilesSync+shim 状态检测） |

## 交互契约

所有 .mjs 脚本遵循统一契约：
- 调用：`node <script>.mjs`，cwd 为用户项目根目录
- 导出：`export function main(args = {})`
- 编码：文件读写 `encoding: 'utf-8'`
- 输出：`[OK]` / `[FAIL]` / `[WARN]` / `[INFO]` / `[SUMMARY]`，禁止 emoji

## 文件结构

```
oc-demora/
├── SKILL.md                       # 本文件
├── README.md                      # 使用说明
├── package.json                   # 配置
├── scripts/                       # 脚本（19 个）
├── assets/                        # 静态资源
├── examples/                      # 使用示例
├── tests/                         # 基础测试
└── references/                    # 运行时依赖
    ├── annotation/                # 标注系统三件套
    ├── methodology/               # 产品需求方法论
    │   ├── annotation-spec.md     # L1/L2/L3 标注规范
    │   ├── doc-templates/         # 24 个文档模板
    │   ├── interaction-templates/ # 6 个交互卡片
    │   ├── schemas/               # 需求模型 Schema
    │   └── guides/                # 方法论指南
    └── scripts/                   # 共享脚本
```
