// app.js for p008-pass-demo
// 使用 0803 glm52 案例真实风格：$() 辅助函数 + .onclick= 属性赋值
// M1 修复后 P008 应识别此绑定模式，不触发 FAIL

// $() 辅助函数（demo 常见简写）
function $(selector) {
  if (typeof selector !== 'string') return selector;
  if (selector.startsWith('#')) return document.getElementById(selector.slice(1));
  if (selector.startsWith('.')) return document.getElementsByClassName(selector.slice(1));
  return document.getElementById(selector); // 无前缀时按 id 处理
}

// btnOpen 的 .onclick= 赋值（M1 修复目标模式）
$('btnOpen').onclick = function () {
  const modal = document.getElementById('m1');
  if (modal) modal.hidden = false;
};

// 关闭按钮
document.querySelector('.close-btn').addEventListener('click', function () {
  const modal = document.getElementById('m1');
  if (modal) modal.hidden = true;
});
