# 标注结构完整性自检指引（详版）

> SKILL.md「标注结构完整性自检指引」的详版参考。背景：A/B 测试反复出现"左侧页面缺失标注"，根因是 AI 忘记写 `data-zone-id`/`data-element-id` 或结构不规范。标注引擎 `ensureMarkers()` 自动创建 marker/dot 子元素，但父级属性与数据结构必须由 AI 保证。

## 1. AI 生成 demo 后必须执行的自检清单

1. **data-zone-id 覆盖率**：每页主要区域（hero/列表/表单/详情/操作/筛选/统计/弹窗）必须标注；自检 `grep -c 'data-zone-id' demo/index.html` 应 ≥ 页面数 × 3
2. **data-element-id 覆盖率**：每页可视范围**去重后的可交互元件类型**每类型至少 1 个；同类组按 v5.24 规模分流——≤4 实例全部标注（描述同属性），>4 实例只标 DOM 首个且卡片 element 名含"同类"说明；自检 `grep -c 'data-element-id' demo/index.html` 应 ≥ 页面数 × 5
3. **.l2-marker 元素**：引擎自动创建；但 `data-zone-id` 容器必须存在且可见（display:none 容器不会被创建 marker）
4. **__ANNOTATION_DATA__ 结构完整性**：每页含 `name`/`L1`/`L2`/`L3`；L2 每项 `id`/`zone`/`description`（description 须含"功能 + 数据来源/业务规则"两要素，参考 ≥30 字）；L3 每项 `id`/`element`/`function`/`trigger`/`response`（建议补 `condition`/`exception`）
5. **L3 元件一致性**：`__ANNOTATION_DATA__` 定义的每个 L3 id 必须在 HTML 有对应 `data-element-id`；运行时动态生成的锚点豁免为 WARN，由 D10 兜底

## 2. R-9 标注数据契约

1. **数据结构**：扁平 `{P01:{L2:[...], L3:[...]}, ...}`，禁止包装结构 `{version, pages:{}}`
2. **同页 id 唯一**：同页内 L2/L3 id 禁止重复（跨页复用允许）；重复会导致卡片点击只命中第一个（P-A2 不闪烁）与重复渲染（P-A3）
3. **data-zone-id 放置**：写在 zone 容器上，禁止直接写在 `.l2-marker` 上（嵌套创建 marker，点击协同失效）
4. **CSS 保留类名**：禁止在 demo CSS 重复定义 `.l2-marker`/`.l3-dot`/`.anno-zone`/`.anno-card`（S-6 FAIL），尤其禁止 `!important` 覆盖引擎 display
5. **三元组去重**：L3 卡片 `(element, function, response)` 应差异化（P009 WARN；>4 实例同类组只标首个时 element 名含同类说明）
6. **数量一致性**：`__ANNOTATION_DATA__` 声明的 L2/L3 数量必须与 HTML 中 `data-zone-id`/`data-element-id` 数量逐页一致（P018 FAIL 阻断）

## 3. 常见错误

- ❌ 只在 `__ANNOTATION_DATA__` 写 L3 数据，HTML 忘记加 `data-element-id`
- ❌ `data-zone-id` 容器设为 `display:none`
- ❌ 多页"提交"按钮共用相同三元组描述（应差异化："提交预审案件"/"提交整改反馈"）
- ❌ footer 缺失或 `position: fixed`（R-7 触发 D7 视觉告警）
- ❌ `data-element-id` 直接挂在 INPUT/SELECT 等内联元素上（l3-dot 渲染 0x0，P023 FAIL；AI 应包块级 div，引擎 C4 也会自动修正——注意 enhance 之后再手改 HTML 需重跑 `enhance-prototype.mjs --force`）
