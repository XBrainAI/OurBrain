# 标注系统 data-* 属性使用指南

> 本文件说明 AI 如何在生成的 HTML 中使用 `data-*` 属性与标注系统对接。
> 标注系统是独立叠加层，AI 代码零侵入——不需要引入任何标注相关的 JS/CSS。

## 核心约定

### 1. 标注数据定义

在页面的 `<script>` 中定义 `window.__ANNOTATION_DATA__`：

```javascript
window.__ANNOTATION_DATA__ = {
  P01: {
    L1: {
      summary: "客户列表页，展示所有客户并支持搜索筛选",
      entry: "侧边栏点击'客户管理'",
      precondition: "用户已登录",
      data_entity: "Customer",
      business_rules: ["默认按创建时间降序", "每页 20 条"],
      test_data: "搜索'科技'返回 5 条结果"
    },
    L2: [
      { id: "R-001", zone: "搜索区", description: "提供关键词搜索和状态筛选" },
      { id: "R-002", zone: "列表区", description: "展示客户列表表格" }
    ],
    L3: [
      {
        id: "C-001", element: "搜索按钮", zone: "R-001",
        function: "触发搜索", trigger: "点击",
        condition: "输入 >= 1 字符", response: "刷新列表",
        state: "可用", exception: "无结果时显示空状态"
      }
    ]
  }
};
```

### 2. 页面 ID 标记

在页面根元素上添加 `data-page-id` 属性：

```html
<div data-page-id="P01">
  <!-- 页面内容 -->
</div>
```

### 3. 布局根标记（可选）

在布局根元素上添加 `data-annotation-root` 属性：

```html
<div data-annotation-root>
  <!-- 布局内容，标注激活时此元素获得 padding-right -->
</div>
```

### 4. 标注开关按钮

在任意按钮/开关上添加 `data-annotation-toggle` 属性：

```html
<button data-annotation-toggle>标注</button>
```

支持两种实现形态，引擎均已兼容：
- **button 直标**：`<button data-annotation-toggle>标注</button>`
- **label>input 自定义开关**：`<label class="annotation-toggle"><input type="checkbox" data-annotation-toggle><span class="toggle-track"></span><span class="toggle-label">标注</span></label>`（属性必须放在 input 上）

客户视角（`?annotations=0`）下，引擎会隐藏整个可见开关容器（label 或 .annotation-toggle 包裹层）并禁用控件本身，确保无任何标注入口（v5.21 修复：原实现仅隐藏 input，label 形态下开关仍可见可点击）。

### 5. L2 区域标记

在区域的容器元素上添加 `data-zone-id` 和 `.anno-zone` 类：

```html
<div class="search-section anno-zone" data-zone-id="R-001">
  <!-- 区域内容 -->
  <!-- v5.19：.l2-marker 由引擎自动创建并显示 P01-L2-001 式编码，AI 禁止手写 -->
</div>
```

**v5.2.5 强制规范**：
- `data-zone-id` 的值在**同一页面内**必须唯一（如 `R-001`、`R-002`），不同页面可复用
- 编码体系 `Pn-Ln-xxx`（页面-级别-页内序号，每页每级别从 001 起，如 `P01-L2-001`、`P02-L2-001`）由引擎自动生成；**AI 禁止手写 marker**（引擎会自动创建并统一覆盖编码文本，手写 marker 的内容不生效）
- **v5.20 P1-3 显示形式（U3 澄清）**：marker 圆内与 dot 序号仅显示**去前导零页内序号**（如 `P01-L3-001` → "1"）；完整编码保留于 `data-code` + `title` 属性（hover 可见），标注面板卡片徽章显示完整编码——两态并存
- **v5.20.1 形态修正（UAT 三轮 U3-B）**：L2 绿色序号圆（20px 胶囊）与 L3 蓝色序号圆（18px）**序号均在圆内居中显示**，两态形态对齐（L3 不再使用圆点右下角徽章）；marker/dot 配色为标注系统自持的鲜艳绿 `#00c853` / 鲜艳蓝 `#2563eb`，**不随 demo 业务令牌（--success/--primary）漂移**
- 引擎在多页面场景下会自动查找当前可见页面的对应元素，marker 编码用于用户视觉识别，并与标注面板卡片徽章一一对应

**v5.2.6 强制规范（保留类名禁止覆盖）**：

以下类名是标注系统的保留类名，**禁止在 demo 的 `<style>` 或 `assets/style.css` 中重复定义**，否则会破坏标注交互：

| 保留类名 | 用途 | 禁止覆盖的关键属性 |
|---------|------|------------------|
| `.anno-zone` | L2 区域容器 | `position: relative` |
| `.l2-marker` | L2 编码徽章（引擎自动创建） | `pointer-events`、`position: absolute`、`z-index: 2000` |
| `.l3-dot` | L3 元件点 | `pointer-events`、`position: absolute`、`z-index: 2000` |
| `[data-element-id]` | L3 包裹容器 | `position: relative`、`display: inline-flex` |
| `.annotation-panel` | 标注面板 | 所有属性 |
| `[data-annotation-root]` | 布局根 | 所有属性 |
| `[data-annotation-toggle]` | 开关按钮 | 所有属性 |

**踩坑案例（v5.2.6 修复前）**：
- audit-trainer-v5.2 在 `assets/style.css` 重复定义 `.l3-dot { pointer-events: none }`，导致左侧页面 L3 dot 无法点击（但右侧标注面板可点）
- audit-printing-v5.2 重复定义 `.l3-dot` 视觉样式（位置/大小），导致 dot 偏移

**自检规则**：在 demo HTML/style.css 中搜索 `\.(l2-marker|l3-dot|anno-zone)\s*{`，若命中需删除该规则块。视觉定制应通过外层包裹元素 + 自定义类名实现，而非直接覆盖保留类名。

### 6. L3 元件标记

在元件外层包裹 `data-element-id` 属性，内部放置 `.l3-dot`：

```html
<span data-element-id="C-001">
  <button class="btn-primary">搜索</button>
  <span class="l3-dot"></span>
</span>
```

**表格结构标注禁令（v5.23 新增）**：禁止将 `data-element-id` 置于 tr/td/th/tbody/thead 等表格结构元素上——标注系统的 `[data-element-id]` 布局契约（`position: relative` + `display: inline-flex`，见上文保留类名表）会覆盖原生 table-row 显示，导致整行布局坍塌。行级标注应放在行内第一个交互元素（button/a/select）上；无交互元素时用行内 `<span data-element-id>` 包裹首个单元格内容（下文 6.1 的 `renderMeterRow` 即正确范式）。enhance-prototype C20 会自动迁移存量违规标注；pre-audit P040 静态检测兜底。

**同类元件标注规模分流（v5.24，简版——完整契约见 `references/methodology/annotation-spec.md`）**：同类组 ≤ 4 个可见实例（指标卡组等）全部实例必须标注且描述同属性；> 4 个实例（数据表多行操作按钮等）只标注首个可见实例，卡片 element 名须含同类说明（模板："xxx（同类首个，其余 N 个实例共用本说明）"）。检测：D8_element_coverage 按规模差异化校验，序号型重复仅对 >4 组告警。

**指标卡可交互指引（v5.24）**：指标卡/KPI 卡应实现为可交互元素（`button`/`role="button"` 或挂 `data-action`），从而纳入 L3 标注契约与 D8 覆盖检测；纯展示 div 卡片不在 L3 契约范围。

### 6.1 动态渲染元件的 L3 锚定契约（v5.2.3 新增 — 强制约束）

**问题背景**：当 AI 使用 `renderCard()` / `renderRow()` / `renderRows()` 等 JS 函数动态生成 HTML 元素时（如卡片列表、表格行操作按钮、Kanban 卡片），容易遗漏 `data-element-id` 与 `.l3-dot`，导致 `renderL3List()` 查询返回 null，L3 卡片在面板中不渲染（锚定率从 100% 降至 67%~90%）。

**强制契约**：所有在 `__ANNOTATION_DATA__` 中声明的 L3 元件，**无论静态还是动态渲染**，都必须在最终 DOM 中存在对应的 `[data-element-id]` 锚点 + `.l3-dot` 子元素。

**动态渲染范式**（适用于 `app.js` 内所有 `renderXxx()` 函数）：

```javascript
// 正确：动态生成卡片时为每个声明 L3 的元件添加锚点
function renderCourseCard(course) {
  return `
    <div class="kanban-card" data-course-no="${course.no}">
      <!-- 声明的 L3 元件：课程卡片本身 -->
      <span data-element-id="P04-C-001">
        <div class="card-title">${course.title}</div>
        <span class="l3-dot"></span>
      </span>
      <!-- 声明的 L3 元件：操作按钮 -->
      <span data-element-id="P04-C-002">
        <button class="btn-edit">编辑</button>
        <span class="l3-dot"></span>
      </span>
    </div>
  `;
}

// 正确：动态生成表格行操作按钮时包裹锚点
function renderMeterRow(meter) {
  return `
    <tr>
      <td>${meter.id}</td>
      <td>
        <span data-element-id="P02-C-002">
          <button class="btn-edit">编辑</button>
          <span class="l3-dot"></span>
        </span>
      </td>
    </tr>
  `;
}
```

**禁止模式**：

```javascript
// 错误：动态生成时未包裹 data-element-id（renderL3List 查询返回 null）
function renderCourseCard(course) {
  return `<div class="kanban-card" data-course-no="${course.no}">${course.title}</div>`;
}
```

**自检规则**：在生成 HTML 后立即检查 `__ANNOTATION_DATA__` 中每个 L3 声明的 `id` 是否能在 DOM 中通过 `document.querySelector('[data-element-id="P0X-C-00Y"]')` 命中。命中率为 100% 才算合格。

**AI 设计 HTML 时的检查清单**：
1. 每个声明 L3 ID（如 `P04-C-001`）在静态 HTML 或动态渲染函数中至少出现一次 `data-element-id="P04-C-001"`
2. 动态渲染函数中生成的每个声明 L3 元件必须包含 `<span class="l3-dot"></span>`
3. 在 `app.js` 中调用 `render()` 后，应通过 `MutationObserver` 或显式调用 `window.__ANNOTATION_ENGINE__.refresh()` 重新检测页面
4. 严禁出现"声明但无锚点"的 L3 元件（这会导致面板卡片缺失，双向激活失效）

## 完整示例

```html
<!DOCTYPE html>
<html>
<head>
  <title>Demo</title>
  <!-- annotation-styles.css 由 enhance-prototype.mjs 注入 -->
  <link rel="stylesheet" href="annotation-styles.css">
</head>
<body>
  <div data-annotation-root>
    <header>
      <h1>客户管理</h1>
      <button data-annotation-toggle>标注开关</button>
    </header>

    <div data-page-id="P01">
      <div class="search-area anno-zone" data-zone-id="R-001">
        <input type="text" placeholder="搜索客户">
        <span data-element-id="C-001">
          <button>搜索</button>
          <span class="l3-dot"></span>
        </span>
        <!-- v5.19：.l2-marker 由引擎自动创建并显示 P01-L2-001 式编码，AI 禁止手写 -->
      </div>

      <div class="list-area anno-zone" data-zone-id="R-002">
        <table><!-- 列表内容 --></table>
        <!-- v5.19：.l2-marker 由引擎自动创建并显示 P01-L2-002 式编码，AI 禁止手写 -->
      </div>
    </div>
  </div>

  <!-- annotation-panel.html 由 enhance-prototype.mjs 注入 -->
  <!-- annotation-engine.js 由 enhance-prototype.mjs 注入 -->
  <script src="annotation-engine.js"></script>
  <script>
    window.__ANNOTATION_DATA__ = { /* 见上文 */ };
  </script>
</body>
</html>
```

## 路由变化通知

如果 Demo 使用 SPA 路由（hash 或 History API），标注引擎自动监听 `hashchange` 和 `popstate` 事件。

如果使用自定义路由机制，在路由切换后调用：

```javascript
if (window.__ANNOTATION_ENGINE__) {
  window.__ANNOTATION_ENGINE__.refresh();
}
```

## v5.2.6 强制规范：SPA 路由契约（多页面 demo 必读）

**踩坑案例**：
- audit-coffee-v5.2、audit-carwash-v5.2 在导航中写了 `<a href="#/stores">门店列表</a>`，但 demo JS **完全没有**监听 `hashchange` 来切换 `<section class="page">` 的 `hidden` 属性，导致用户点击导航后 URL 变了但页面内容不变，反馈"功能点击无反应"。

**强制契约**：当 demo 包含多个 `[data-page-id]` section（多页面 SPA）时，**必须**实现以下路由切换逻辑：

```javascript
// === 必须实现：SPA hash 路由切换器 ===
// 路由表：hash → page-id 映射
var ROUTES = {
  '/stores': 'P01',
  '/stores/S01': 'P02',
  '/orders/dashboard': 'P03',
  '/members/analytics': 'P04'
};

// 默认首页路由（用户反馈 audit-printing 默认跳订单页而非首页）
var DEFAULT_ROUTE = '/stores';

function handleRoute() {
  var hash = location.hash.replace(/^#/, '') || DEFAULT_ROUTE;
  var pageId = ROUTES[hash] || 'P01';  // 未知 hash 回退首页
  document.querySelectorAll('[data-page-id]').forEach(function (page) {
    page.hidden = (page.getAttribute('data-page-id') !== pageId);
  });
  // 同步激活态 nav-link
  document.querySelectorAll('.nav-link').forEach(function (link) {
    var linkHash = link.getAttribute('href').replace(/^#/, '');
    link.classList.toggle('active', linkHash === hash);
  });
  // 通知标注引擎刷新
  if (window.__ANNOTATION_ENGINE__) {
    window.__ANNOTATION_ENGINE__.refresh();
  }
}

window.addEventListener('hashchange', handleRoute);
document.addEventListener('DOMContentLoaded', function () {
  if (!location.hash) location.hash = DEFAULT_ROUTE;
  handleRoute();
});
```

**自检规则**：在 demo 的 `<script>` 中必须能搜索到 `hashchange` 关键字 + `[data-page-id]` 的 `hidden` 切换逻辑。`check-structure.mjs` 会对多页面 demo 自动检测此契约。

## v5.2.6 强制规范：弹窗可关闭契约

**踩坑案例**：audit-printing-v5.2 的模态框 `×` 关闭按钮（`<button id="modalClose">×</button>`）的 `onclick` 事件未绑定，导致弹窗无法关闭。

**强制契约**：所有弹窗（modal/dialog）必须满足：

1. 关闭按钮（`.modal-close` / `#modalClose` / 自定义类）的 `click` 事件**必须绑定**到关闭函数
2. 遮罩层（`.modal-mask`）点击时也应关闭弹窗
3. ESC 键关闭弹窗（可选但推荐）

```javascript
// === 弹窗关闭契约 ===
function openModal(title, bodyHtml) { /* ... */ }
function closeModal() { document.getElementById('modalMask').hidden = true; }

// 必须在 init 中绑定关闭事件
function initModal() {
  var closeBtn = document.getElementById('modalClose');
  if (closeBtn) closeBtn.addEventListener('click', closeModal);
  var mask = document.getElementById('modalMask');
  if (mask) mask.addEventListener('click', function (e) { if (e.target === mask) closeModal(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && mask && !mask.hidden) closeModal();
  });
}
```

## Tab/页面切换刷新（v5.2）

当 Demo 内部使用 Tab 切换、折叠/展开、条件渲染等机制导致标注元素可见性变化时：

1. **自动检测**：标注引擎 v5.2 会监听全局 click 事件和 DOM 属性变化（style/class/hidden），在 300ms 延迟后自动刷新面板，更新标注卡片的可见性标记
2. **手动刷新**：如果自动检测未覆盖，在 Tab/页面切换后手动调用：

```javascript
if (window.__ANNOTATION_ENGINE__) {
  window.__ANNOTATION_ENGINE__.refreshVisibility();
}
```

3. **可见性标记**：v5.2 会检查每个标注对应的 DOM 元素是否实际可见（display/visibility/opacity/hidden）。不可见的标注卡片会：
   - 显示为灰色半透明（`.is-hidden` class）
   - 底部显示"当前不可见"提示
   - 仍然可点击（点击后会尝试 scrollIntoView，但可能无效）

## API 参考

标注引擎暴露 `window.__ANNOTATION_ENGINE__`：

| 方法 | 说明 |
|------|------|
| `togglePanel()` | 切换面板显隐 |
| `setPanelVisible(bool)` | 设置面板显隐 |
| `highlightZone(zoneId)` | 高亮 L2 区域 |
| `highlightElement(elemId)` | 高亮 L3 元件 |
| `focusZoneCard(zoneId)` | 点击左侧 L2 marker 行为 |
| `focusElementCard(elemId)` | 点击左侧 L3 dot 行为 |
| `switchTab(tab)` | 切换 Tab（L1/L2/L3）|
| `getState()` | 获取当前状态快照 |
| `refresh()` | 重新检测页面 + 重新渲染面板（v5.2 增强） |
| `refreshVisibility()` | 手动触发可见性刷新（v5.2 新增） |
