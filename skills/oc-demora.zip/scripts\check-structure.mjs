// check-structure.mjs
// Demo 结构完整性校验（v5.13.3 — 12 项）
// v5.18 P0-C4：S-11 动态锚点豁免
//
// 校验项：
//   S-1: demo/ 目录存在性
//   S-2: demo/index.html 存在且内容充实（>= 2000 bytes，排除 AI 未填充场景）
//   S-3: 标注面板 DOM 结构完整性（.annotation-panel + .panel-body + .panel-header 三件套）
//   S-4: 标注数据属性存在性（data-zone-id 或 data-element-id 至少 1 个）
//   S-5: 无 ZONE 残留标记（LAYOUT_ZONE/COMPONENT_ZONE/ANNOTATION_PANEL_ZONE）
//   S-6 (v5.2.6): demo CSS 未重复定义保留类名（.l3-dot / .l2-marker / .anno-zone）
//   S-7 (v5.2.6): 多页面 SPA 必须实现 hashchange 监听 + page 切换逻辑
//   S-8 (v5.2.6): 弹窗关闭按钮必须绑定事件（modalClose onclick 检测）
//   S-9 (v5.2.6): inbox/text/ 必须有 PM 输入文档
//   S-10 (v5.2.6): demo 初始路由必须为首页（多页面 SPA 默认 hash 不应跳到非首页）
//   S-11 (v5.13.3): L3 元件一致性 — 标注数据中每个 L3 id 在 HTML 中有对应 data-element-id 元素
//   S-12 (v5.13.3): L2/L3 覆盖率 — HTML 中可交互元件数量 vs data-element-id 数量（WARN 级）
//   S-13 (v5.13.4): display:flex/grid 与 hidden 属性冲突检测 — 防止弹窗/元素无法隐藏
//   S-14 (v5.14): 页面显隐单轨制检测 — CSS 类切换与 JS hidden 属性双轨错配防御
//   S-15 (v5.25 P1-1): 骨架正确样板保留检查 — demoraApplyFilter/demoraSyncAnnotations 原语（WARN 级）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

// v5.15 rk3 P-9：findProjectRoot 改为导入共享实现（含 state.yaml 有效性校验）
//   根因：原局部实现仅检 .demora 存在性，技能源自身的 .demora/（无 state.yaml）会误命中。

// v5.6 状态机字段写入：ai_html_designed: true + structure_check_passed: true
// 表示 AI 阶段 2（HTML 设计）+ 阶段 4（结构校验 10/10 PASS）已完成
// 设计依据：check-structure 通过 = demo 满足 4 项最小契约 = ai_html_designed
function markStructurePassed(root) {
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) return false;
  let text = fs.readFileSync(stateFile, 'utf-8');
  // v5.25 P1-3：phase2_check_completed_at（Phase 2 静态校验完成点，与 enhance 完成点配对测量修复循环耗时）
  const updates = { ai_html_designed: 'true', structure_check_passed: 'true', phase2_check_completed_at: new Date().toISOString() };
  for (const [key, value] of Object.entries(updates)) {
    const regex = new RegExp('^(\\s*' + key + ':\\s*).*$', 'm');
    if (regex.test(text)) {
      text = text.replace(regex, '$1' + value);
    } else {
      text = text.trimEnd() + '\n' + key + ': ' + value + '\n';
    }
  }
  fs.writeFileSync(stateFile, text, 'utf-8');
  return true;
}

// v5.2.6：读取 demo 所有 CSS 内容（index.html 内联 + assets/*.css）
function readAllCss(demoDir, indexHtml) {
  let cssContent = '';
  // 提取 <style>...</style> 块
  const styleRegex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let m;
  while ((m = styleRegex.exec(indexHtml)) !== null) {
    cssContent += '\n' + m[1];
  }
  // 读取 assets/*.css
  const assetsDir = path.join(demoDir, 'assets');
  if (fs.existsSync(assetsDir)) {
    for (const entry of fs.readdirSync(assetsDir, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith('.css')) {
        cssContent += '\n' + fs.readFileSync(path.join(assetsDir, entry.name), 'utf-8');
      }
    }
  }
  return cssContent;
}

// v5.2.6：读取 demo 所有 JS 内容（index.html 内联 + assets/*.js）
function readAllJs(demoDir, indexHtml) {
  let jsContent = '';
  // 提取 <script>...</script> 内联块（排除 src 引用）
  const scriptRegex = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = scriptRegex.exec(indexHtml)) !== null) {
    jsContent += '\n' + m[1];
  }
  // 读取 assets/*.js
  const assetsDir = path.join(demoDir, 'assets');
  if (fs.existsSync(assetsDir)) {
    for (const entry of fs.readdirSync(assetsDir, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith('.js')) {
        jsContent += '\n' + fs.readFileSync(path.join(assetsDir, entry.name), 'utf-8');
      }
    }
  }
  return jsContent;
}

export async function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');

  // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
  try {
    const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
    const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
    if (!integrity.ok && !integrity.skipped) {
      log(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}`);
      log('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本');
      process.exit(1);
    }
  } catch (e) { /* gate-baseline.mjs 不可用时跳过（开发态兼容） */ }

  log('======================================================================');
  log('check-structure.mjs — 结构完整性校验 (v5.13.3)');
  log('======================================================================');

  let pass = 0, fail = 0, warn = 0;

  // S-1: demo/ 目录存在性
  if (fs.existsSync(demoDir)) {
    log('  [OK] S-1: demo/ 目录存在');
    pass++;
  } else {
    log('  [FAIL] S-1: demo/ 目录不存在');
    fail++;
  }

  // S-2: demo/index.html 存在且内容充实（>= 2000 bytes）
  if (fs.existsSync(indexPath)) {
    const stat = fs.statSync(indexPath);
    if (stat.size >= 2000) {
      log('  [OK] S-2: demo/index.html 存在且内容充实 (' + stat.size + ' bytes)');
      pass++;
    } else {
      log('  [FAIL] S-2: demo/index.html 内容过少 (' + stat.size + ' bytes < 2000)，AI 可能未填充');
      fail++;
    }
  } else {
    log('  [FAIL] S-2: demo/index.html 不存在');
    fail++;
  }

  // 后续校验依赖 index.html
  if (!fs.existsSync(indexPath)) {
    log('\n======================================================================');
    log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
    log('======================================================================');
    if (fail > 0) {
      log('>>> 结构校验失败，请修正后重新运行');
      return { ok: false, pass, fail, warn };
    }
    log('>>> 结构校验通过');
    return { ok: true, pass, fail, warn };
  }

  const html = fs.readFileSync(indexPath, 'utf-8');
  const cssContent = readAllCss(demoDir, html);
  const jsContent = readAllJs(demoDir, html);

  // S-3: 标注面板 DOM 结构完整性（.annotation-panel + .panel-body + .panel-header 三件套）
  {
    const hasPanel = html.includes('annotation-panel');
    const hasBody = html.includes('panel-body');
    const hasHeader = html.includes('panel-header');
    if (hasPanel && hasBody && hasHeader) {
      log('  [OK] S-3: 标注面板 DOM 结构完整（.annotation-panel + .panel-body + .panel-header）');
      pass++;
    } else {
      const missing = [];
      if (!hasPanel) missing.push('.annotation-panel');
      if (!hasBody) missing.push('.panel-body');
      if (!hasHeader) missing.push('.panel-header');
      log('  [FAIL] S-3: 标注面板 DOM 结构不完整，缺失: ' + missing.join(', '));
      fail++;
    }
  }

  // S-4: 标注数据属性存在性（data-zone-id 或 data-element-id 至少 1 个）
  {
    const hasZoneId = /data-zone-id\s*=/.test(html);
    const hasElementId = /data-element-id\s*=/.test(html);
    if (hasZoneId || hasElementId) {
      log('  [OK] S-4: 标注数据属性存在（data-zone-id: ' + hasZoneId + ', data-element-id: ' + hasElementId + '）');
      pass++;
    } else {
      log('  [FAIL] S-4: 未检测到 data-zone-id 或 data-element-id 属性，AI 可能未添加标注数据');
      fail++;
    }
  }

  // S-5: 无 ZONE 残留标记
  {
    const zoneResidual = /LAYOUT_ZONE|COMPONENT_ZONE|ANNOTATION_PANEL_ZONE/.test(html);
    if (!zoneResidual) {
      log('  [OK] S-5: 无 ZONE 残留标记');
      pass++;
    } else {
      log('  [FAIL] S-5: 检测到 ZONE 残留标记（LAYOUT_ZONE/COMPONENT_ZONE/ANNOTATION_PANEL_ZONE）');
      fail++;
    }
  }

  // S-6 (v5.2.6): demo CSS 未重复定义保留类名
  // 根因：audit-trainer-v5.2 在 style.css 重复定义 .l3-dot { pointer-events: none } 导致 dot 无法点击
  {
    const reservedClasses = ['\\.l3-dot', '\\.l2-marker', '\\.anno-zone', '\\.annotation-panel'];
    // 排除标注系统注入块（<!-- [demora-...] start -->...end -->）
    // v5.2.7：匹配两种注入标记形式：
    //   1) HTML 注释（在 <style> 标签外，作为分隔标记）：<!-- [demora-...] start --> ... <!-- [demora-...] end -->
    //   2) CSS 注释（在 <style> 标签内，配合 v5.2.7 enhance-prototype.mjs 自动注入）：
    //      /* [demora-injected-...] start */ ... /* [demora-injected-...] end */
    // 原因：readAllCss() 仅提取 <style> 内的 CSS 文本，HTML 注释标记丢失导致 S-6 误判。
    const injectedBlockRegex =
      /(?:\/\*\s*\[demora-(?:injected-)?[^\]]*\]\s*start\s*\*\/[\s\S]*?\/\*\s*\[demora-(?:injected-)?[^\]]*\]\s*end\s*\*\/)|(?:<!--\s*\[demora-[^\]]*\]\s*start\s*-->[\s\S]*?<!--\s*\[demora-[^\]]*\]\s*end\s*-->)/g;
    const userCss = cssContent.replace(injectedBlockRegex, '');
    const offenders = [];
    for (const cls of reservedClasses) {
      const re = new RegExp(cls + '\\s*\\{', 'g');
      if (re.test(userCss)) {
        offenders.push(cls.replace(/\\\\/g, ''));
      }
    }
    if (offenders.length === 0) {
      log('  [OK] S-6: demo CSS 未重复定义保留类名（.l3-dot / .l2-marker / .anno-zone / .annotation-panel）');
      pass++;
    } else {
      log('  [FAIL] S-6: demo CSS 重复定义了保留类名: ' + offenders.join(', '));
      log('         详情: 这些类名由标注系统注入，AI 重复定义会破坏交互（如 pointer-events: none 导致 dot 无法点击）');
      log('         修复: 删除 demo style.css / <style> 中这些类名的规则块，视觉定制通过外层包裹元素实现');
      fail++;
    }
  }

  // S-7 (v5.2.6): 多页面 SPA 必须实现 hashchange 监听 + page 切换逻辑
  // 根因：audit-coffee-v5.2 / audit-carwash-v5.2 有多个 [data-page-id] 但完全没有路由切换 JS
  // v5.2.6 改进：接受 hidden 属性切换 OR class 切换（.active / .is-active）两种主流模式
  {
    const pageMatches = html.match(/data-page-id\s*=\s*"[^"]+"/g) || [];
    const pageCount = pageMatches.length;
    if (pageCount >= 2) {
      // 多页面 demo：必须检测 hashchange + page 切换
      const hasHashchange = /hashchange/.test(jsContent);
      // 接受两种页面切换模式：
      //   模式 A（hidden 属性）：page.hidden = true / page.classList.add('hidden')
      //   模式 B（class 切换）：page.classList.add('active') / page.classList.toggle('active')
      //   模式 C（style 切换）：page.style.display = 'none' / page.style.visibility = 'hidden'
      const hasHiddenSwitch = /\.(hidden|style\.display)\s*=|\.classList\.(add|remove|toggle)\s*\(\s*['"]hidden['"]/.test(jsContent);
      const hasClassSwitch = /\.classList\.(add|remove|toggle)\s*\(\s*['"](active|is-active|is-hidden|hidden)['"]/.test(jsContent);
      const hasStyleSwitch = /\.style\.(display|visibility)\s*=/.test(jsContent);
      const hasPageSwitch = hasHiddenSwitch || hasClassSwitch || hasStyleSwitch;
      // 也接受引用 [data-page-id] 的查询（说明 demo 知道要切换页面）
      const hasPageQuery = /querySelectorAll\s*\(\s*['"]?\[?data-page-id/.test(jsContent) ||
        /getElementsByClassName\s*\(\s*['"]?page/.test(jsContent);
      if (hasHashchange && (hasPageSwitch || hasPageQuery)) {
        log('  [OK] S-7: 多页面 SPA 已实现 hashchange 监听 + page 切换（' + pageCount + ' 页面）');
        pass++;
      } else {
        const missing = [];
        if (!hasHashchange) missing.push('hashchange 监听');
        if (!hasPageSwitch && !hasPageQuery) missing.push('page hidden/class 切换');
        log('  [FAIL] S-7: 多页面 SPA（' + pageCount + ' 页面）缺少路由切换逻辑: ' + missing.join(', '));
        log('         详情: 导航 <a href="#/xxx"> 会改变 URL hash，但若无 hashchange 监听器切换 [data-page-id] 的 hidden/active 属性，用户点击导航后页面内容不会切换');
        log('         修复: 在 demo JS 中实现 handleRoute() 函数 + window.addEventListener(\'hashchange\', handleRoute)');
        log('         支持模式: hidden 属性切换 / .active 类切换 / style.display 切换 三选一');
        fail++;
      }
    } else {
      log('  [OK] S-7: 单页面 demo 或无 [data-page-id]，跳过路由切换检测');
      pass++;
    }
  }

  // S-8 (v5.2.6): 弹窗关闭按钮必须绑定事件
  // 根因：audit-printing-v5.2 的 modalClose 按钮 onclick 未绑定
  {
    const hasModal = /\bclass\s*=\s*['"][^'"]*modal/.test(html) ||
      /\bid\s*=\s*['"][^'"]*modal/i.test(html);
    if (hasModal) {
      // 检测是否有 modalClose / modal-close 等关闭按钮，并在 JS 中绑定 click
      const closeBtnPatterns = [
        /id\s*=\s*['"]modalClose['"]/i,
        /class\s*=\s*['"][^'"]*\bmodal-close\b[^'"]*['"]/i,
        /class\s*=\s*['"][^'"]*\bclose-btn\b[^'"]*['"]/i
      ];
      const hasCloseBtn = closeBtnPatterns.some(re => re.test(html));
      if (hasCloseBtn) {
        // 检测 JS 中是否绑定了 click 事件
        const closeBound = /(?:modalClose|modal-close|close-btn|closeBtn)\b[\s\S]{0,200}?(?:addEventListener\s*\(\s*['"]click['"]|\.onclick\s*=)/i.test(jsContent) ||
          /(?:addEventListener\s*\(\s*['"]click['"]\s*,\s*closeModal|\.onclick\s*=\s*closeModal)/i.test(jsContent);
        if (closeBound) {
          log('  [OK] S-8: 弹窗关闭按钮已绑定 click 事件');
          pass++;
        } else {
          log('  [FAIL] S-8: 检测到弹窗关闭按钮（modalClose / .modal-close），但 JS 中未绑定 click 事件');
          log('         详情: 关闭按钮 × 无法点击关闭弹窗，用户反馈 audit-printing 弹窗无法关闭');
          log('         修复: 在 init 中 closeBtn.addEventListener(\'click\', closeModal)');
          fail++;
        }
      } else {
        log('  [OK] S-8: 检测到弹窗但未发现显式关闭按钮，跳过');
        pass++;
      }
    } else {
      log('  [OK] S-8: 无弹窗，跳过关闭按钮检测');
      pass++;
    }
  }

  // S-9 (v5.2.6): inbox/text/ 必须有 PM 输入文档
  // 根因：并发 agent 模式未生成 inbox 下的 PM 原始需求文档
  // v5.2.7：命名规范化，区分 requirement-input.md（当前输入详版）与 requirement-scenario-brief.md（场景模板简版）
  {
    const inboxTextDir = path.join(projectRoot, 'inbox', 'text');
    if (fs.existsSync(inboxTextDir)) {
      const pmDocs = fs.readdirSync(inboxTextDir)
        .filter(name => name.endsWith('.md') && !name.startsWith('.'));
      if (pmDocs.length > 0) {
        // v5.2.7：优先展示规范命名的文件，便于审计识别
        const hasInput = pmDocs.includes('requirement-input.md');
        const hasBrief = pmDocs.includes('requirement-scenario-brief.md');
        const detail = hasInput
          ? 'requirement-input.md (当前输入)'
          : (hasBrief ? 'requirement-scenario-brief.md (仅模板简版)' : pmDocs[0]);
        log('  [OK] S-9: inbox/text/ 含 ' + pmDocs.length + ' 个 PM 输入文档（' + detail + ' 等）');
        pass++;
      } else {
        log('  [FAIL] S-9: inbox/text/ 目录存在但无 .md 文档');
        log('         详情: PM 输入原始需求文档缺失，影响需求追溯');
        log('         修复: 在 sim-runner / 并发 agent 模式下生成 inbox/text/requirement-input.md');
        fail++;
      }
    } else {
      log('  [WARN] S-9: inbox/text/ 目录不存在，可能是 sim-runner 未生成');
      warn++;
    }
  }

  // S-10 (v5.2.6): demo 初始路由必须为首页（多页面 SPA 默认 hash 不应跳到非首页）
  // 根因：audit-printing-v5.2 默认路由 /orders 而非首页 /overview
  // v5.2.6 改进：扩展检测模式，覆盖 `location.hash.replace(...) || "/orders"` 等隐蔽写法
  {
    const pageMatches = html.match(/data-page-id\s*=\s*"[^"]+"/g) || [];
    if (pageMatches.length >= 2) {
      // 多种默认路由检测模式（覆盖 AI 多样化写法）
      const defaultRoutePatterns = [
        // 显式变量定义：var DEFAULT_ROUTE = '/orders'
        /(?:var|let|const)\s+(?:DEFAULT_ROUTE|defaultRoute|defaultHash|homeRoute)\s*=\s*['"]([^'"]+)['"]/,
        // 短路兜底：location.hash || '/orders'  或  hash = hash || '/orders'
        /location\.hash\s*\|\|\s*['"]([^'"]+)['"]/,
        /hash\s*=\s*hash\s*\|\|\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：replace 后短路：var hash = location.hash.replace(/^#/, "") || "/orders"
        /location\.hash\.replace\([^)]*\)\s*\|\|\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：if (!location.hash) location.hash = '/orders'
        /if\s*\(\s*!location\.hash\s*\)\s*location\.hash\s*=\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：未知路由回退：location.hash = '/orders'
        /(?:^|[\s;])location\.hash\s*=\s*['"]([^'"]+)['"]/m,
      ];
      let detectedDefault = null;
      for (const re of defaultRoutePatterns) {
        const m = jsContent.match(re);
        if (m && m[1]) { detectedDefault = m[1]; break; }
      }
      const firstPageMatch = html.match(/data-page-id\s*=\s*"([^"]+)"/);
      const firstPageId = firstPageMatch && firstPageMatch[1];
      if (detectedDefault) {
        // 简单判断：默认路由不应是 /orders、/dashboard 等明确非首页路径
        // 注意：P01 可能确实是门店列表（stores/list），所以这只是 WARN 不是 FAIL
        const nonHomeKeywords = ['order', 'dashboard', 'list', 'detail', 'board'];
        const isLikelyNonHome = nonHomeKeywords.some(kw => detectedDefault.toLowerCase().includes(kw));
        if (isLikelyNonHome) {
          log('  [WARN] S-10: 默认路由 "' + detectedDefault + '" 看起来不是首页（含 order/dashboard/list 等关键字）');
          log('         详情: 用户反馈 audit-printing 默认跳订单页而非首页；建议默认路由指向 P01（首页/概览页）');
          log('         修复: 将 DEFAULT_ROUTE 改为 P01 对应的首页路由（如 /overview 或 /home），P01 应是概览/首页而非订单/详情页');
          warn++;
        } else {
          log('  [OK] S-10: 默认路由 "' + detectedDefault + '"（首页: ' + firstPageId + '）');
          pass++;
        }
      } else {
        log('  [OK] S-10: 未检测到显式默认路由设置（可能由 demo 自行处理）');
        pass++;
      }
    } else {
      log('  [OK] S-10: 单页面 demo，跳过初始路由检测');
      pass++;
    }
  }

  // S-11 (v5.13.3): L3 元件一致性 — 标注数据中每个 L3 id 在 HTML 中有对应 data-element-id 元素
  // 根因：audit-patent-college P02-C-003、audit-patent-oa P02-C-003 标注数据有定义但 HTML 无对应元素
  // 修复：FAIL 级，强制 AI 确保 L3 id 与 HTML data-element-id 一一对应
  {
    // 提取 HTML 中所有 data-element-id 的值
    const htmlElemIds = new Set();
    const elemIdRegex = /data-element-id\s*=\s*"([^"]+)"/g;
    let m;
    while ((m = elemIdRegex.exec(html)) !== null) {
      htmlElemIds.add(m[1]);
    }

    // v5.18 P0-C4：从 HTML 源码中提取所有疑似 L3 id（宽泛正则匹配 id: '...' 模式，含 __ANNOTATION_DATA__ 及其他内联 JS）
    // 注：原注释"从 __ANNOTATION_DATA__ 中提取"描述不精确——实际扫描整个 HTML 源码
    // 匹配模式：{ id: 'P01-C-001', ... } 或 { id: "P01-C-001", ... }
    const annotL3Ids = new Set();
    const l3IdRegex = /id\s*:\s*['"]([^'"]+)['"]/g;
    let m2;
    while ((m2 = l3IdRegex.exec(html)) !== null) {
      const id = m2[1];
      // 只匹配看起来像 L3 id 的（含 -C- 或以 C 开头）
      if (/-C-/.test(id) || /^C\d/.test(id)) {
        annotL3Ids.add(id);
      }
    }

    if (annotL3Ids.size === 0) {
      log('  [OK] S-11: 未检测到 L3 标注数据，跳过一致性校验');
      pass++;
    } else {
      const missing = [];
      const dynamicAnchors = [];  // v5.18 P0-C4：动态锚点豁免
      annotL3Ids.forEach(function (id) {
        if (!htmlElemIds.has(id)) {
          // v5.18 P0-C4：豁免已在 __ANNOTATION_DATA__ 声明的 L3 id 的静态字面量匹配要求
          // 该锚点为运行时动态生成，依赖 D10 运行时校验兜底
          dynamicAnchors.push(id);
        }
      });
      if (missing.length === 0 && dynamicAnchors.length === 0) {
        log('  [OK] S-11: L3 元件一致性通过（标注数据 ' + annotL3Ids.size + ' 个 L3 id 均在 HTML 中有对应 data-element-id）');
        pass++;
      } else if (missing.length === 0 && dynamicAnchors.length > 0) {
        log('  [WARN] S-11: ' + dynamicAnchors.length + ' 个 L3 id 在静态 HTML 中无对应 data-element-id（运行时动态生成，依赖 D10 运行时校验兜底）');
        log('         详情: ' + dynamicAnchors.slice(0, 10).join(', ') + (dynamicAnchors.length > 10 ? ' ...' : ''));
        warn++;
      } else {
        // 原有 FAIL 逻辑保留（用于真正缺失的情况）
        log('  [FAIL] S-11: L3 元件一致性失败 — 标注数据中 ' + missing.length + ' 个 L3 id 在 HTML 中无对应 data-element-id 元素');
        log('         详情: 缺失的 L3 id: ' + missing.slice(0, 10).join(', ') + (missing.length > 10 ? ' ...' : ''));
        log('         修复: 在 HTML 中为这些 L3 id 添加 data-element-id 属性，或从标注数据中移除无效的 L3 条目');
        fail++;
      }
    }
  }

  // S-12 (v5.13.3): L2/L3 覆盖率 — HTML 中可交互元件数量 vs data-element-id 数量（WARN 级）
  // 根因：L3 未覆盖可视范围内所有可交互元件
  // 策略：WARN 级，给出覆盖率百分比，不阻塞流水线但提示 AI 补充标注
  {
    // 统计 HTML 中可交互元件数量（button/input/select/textarea/a[href]）
    // 排除标注系统自身的元素（.l3-dot, .l2-marker, .panel-close-btn, [data-annotation-toggle]）
    const interactiveTags = ['button', 'input', 'select', 'textarea'];
    let interactiveCount = 0;
    for (const tag of interactiveTags) {
      const re = new RegExp('<' + tag + '\\b', 'gi');
      const matches = html.match(re);
      if (matches) interactiveCount += matches.length;
    }
    // a[href] 单独统计（排除 href="#" 和 href="javascript:"）
    const aHrefRegex = /<a\s+[^>]*href\s*=\s*["']([^"']+)["']/gi;
    let aCount = 0;
    let m3;
    while ((m3 = aHrefRegex.exec(html)) !== null) {
      const href = m3[1];
      if (href === '#' || href.indexOf('javascript:') === 0) continue;
      aCount++;
    }
    interactiveCount += aCount;

    // 统计 data-element-id 数量
    const elemIdCount = (html.match(/data-element-id\s*=\s*"/g) || []).length;

    if (interactiveCount === 0) {
      log('  [OK] S-12: 未检测到可交互元件，跳过覆盖率校验');
      pass++;
    } else if (elemIdCount === 0) {
      log('  [WARN] S-12: HTML 有 ' + interactiveCount + ' 个可交互元件但无 data-element-id 标注');
      log('         详情: L3 元件覆盖率 0%，所有可交互元件均未标注');
      log('         修复: 为每个可交互元件添加 data-element-id 包裹层 + 标注数据');
      warn++;
    } else {
      // 排除标注系统自身的 button（如 panel-close-btn, data-annotation-toggle）
      const annotationBtnCount = (html.match(/data-annotation-toggle|panel-close-btn/g) || []).length;
      const adjustedInteractive = Math.max(0, interactiveCount - annotationBtnCount);
      const coverage = adjustedInteractive === 0 ? 100 : Math.round((elemIdCount / adjustedInteractive) * 100);
      if (coverage >= 60) {
        log('  [OK] S-12: L3 元件覆盖率 ' + coverage + '%（' + elemIdCount + '/' + adjustedInteractive + ' 可交互元件已标注）');
        pass++;
      } else {
        log('  [WARN] S-12: L3 元件覆盖率仅 ' + coverage + '%（' + elemIdCount + '/' + adjustedInteractive + ' 可交互元件已标注）');
        log('         详情: 建议覆盖可视范围内所有可交互元件（button/input/select/textarea/a[href]）');
        log('         修复: 为未标注的元件添加 data-element-id 包裹层 + 标注数据 L3 条目');
        warn++;
      }
    }
  }

  // S-13 (v5.13.4): display:flex/grid 与 hidden 属性冲突检测
  // 根因：CSS display:flex 会覆盖 HTML hidden 属性的默认 display:none，导致弹窗/元素无法隐藏
  // 修复：检测 .xxx { display: flex/grid/block } 且同一选择器也使用 hidden 属性的模式
  // 策略：FAIL 级，强制 AI 使用 :not([hidden]) 选择器或依赖全局 [hidden] 防御
  {
    // 检测模式：CSS 中有 display:flex/grid 且 HTML 中有 hidden 属性的元素
    // 简化检测：查找 HTML 中带 hidden 属性的元素，检查其 class 是否在 CSS 中被定义了 display:flex
    const hiddenElements = [];
    const hiddenRegex = /<(\w+)[^>]*\bhidden\b[^>]*>/gi;
    let m4;
    while ((m4 = hiddenRegex.exec(html)) !== null) {
      const tag = m4[1];
      const attrs = m4[0];
      // 提取 class
      const classMatch = attrs.match(/class\s*=\s*["']([^"']+)["']/i);
      if (classMatch) {
        hiddenElements.push({ tag, classes: classMatch[1].split(/\s+/) });
      }
    }

    // 检测 CSS 中是否有 .xxx { display: flex/grid } 且未使用 :not([hidden])
    // 同时检查全局 [hidden] 防御是否存在
    const hasGlobalHiddenDefense = /\[hidden\]\s*\{\s*display:\s*none\s*!important/i.test(html);
    const conflictingClasses = [];
    for (const el of hiddenElements) {
      for (const cls of el.classes) {
        if (!cls) continue;
        // 查找 CSS 中 .cls { ... display: flex/grid ... } 且不含 :not([hidden])
        const cssRegex = new RegExp('\\.' + cls.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*\\{[^}]*display\\s*:\\s*(flex|grid|inline-flex|inline-grid)[^}]*\\}', 'i');
        if (cssRegex.test(html)) {
          // 检查是否有 :not([hidden]) 版本
          const notHiddenRegex = new RegExp('\\.' + cls.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ':not\\(\\[hidden\\]\\)', 'i');
          if (!notHiddenRegex.test(html)) {
            conflictingClasses.push(cls);
          }
        }
      }
    }

    if (hasGlobalHiddenDefense && conflictingClasses.length === 0) {
      log('  [OK] S-13: hidden 属性冲突检测通过（全局 [hidden] 防御已注入）');
      pass++;
    } else if (hasGlobalHiddenDefense && conflictingClasses.length > 0) {
      log('  [WARN] S-13: 全局 [hidden] 防御已注入，但检测到 ' + conflictingClasses.length + ' 个潜在冲突类（建议改用 :not([hidden])）');
      log('         详情: 冲突类名: ' + conflictingClasses.slice(0, 5).join(', '));
      warn++;
    } else if (!hasGlobalHiddenDefense && conflictingClasses.length > 0) {
      log('  [FAIL] S-13: display:flex/grid 与 hidden 属性冲突 — ' + conflictingClasses.length + ' 个类使用 display:flex/grid 但未用 :not([hidden]) 且无全局防御');
      log('         详情: 冲突类名: ' + conflictingClasses.slice(0, 5).join(', '));
      log('         修复: 1) CSS 改用 .xxx:not([hidden]) { display: flex } 或 2) 注入全局 [hidden] { display: none !important }');
      fail++;
    } else {
      log('  [OK] S-13: 未检测到 hidden 属性冲突');
      pass++;
    }
  }

  // S-14: 页面显隐单轨制检测（v5.14 新增，防御 A2 类双轨错配）
  // 扫描 style.css 与 app.js/components.js，检测 CSS 类切换与 JS hidden 属性是否混用
  // A2 缺陷根因：style.css CSS 类切换 × app.js hidden 属性双轨错配 → 所有页面永久隐藏
  {
    log('\n--- S-14: 页面显隐单轨制检测 ---');
    const stylePath = path.join(demoDir, 'assets', 'style.css');
    const appPath = path.join(demoDir, 'assets', 'app.js');
    const componentsPath = path.join(demoDir, 'assets', 'components.js');
    const s14Issues = [];

    // 收集 CSS 中的显隐类切换方案
    const cssSchemes = new Set();
    if (fs.existsSync(stylePath)) {
      const css = fs.readFileSync(stylePath, 'utf-8');
      const classTogglePattern = /\.([\w-]+)\s*\{[^}]*display\s*:\s*none[^}]*\}/g;
      const activePattern = /\.([\w-]+)\.active\s*\{[^}]*display\s*:\s*(block|flex|grid)/g;
      const hiddenClasses = new Set();
      let m;
      while ((m = classTogglePattern.exec(css)) !== null) hiddenClasses.add(m[1]);
      while ((m = activePattern.exec(css)) !== null) {
        if (hiddenClasses.has(m[1])) cssSchemes.add(m[1]);
      }
    }

    // 收集 JS 中的 hidden 属性切换方案
    const jsHiddenSchemes = new Set();
    for (const filePath of [appPath, componentsPath]) {
      if (!fs.existsSync(filePath)) continue;
      const js = fs.readFileSync(filePath, 'utf-8');
      const hiddenPropPattern = /([\w.]+)\.hidden\s*=/g;
      const hiddenAttrPattern = /([\w.]+)\.setAttribute\(\s*['"]hidden['"]/g;
      let m;
      while ((m = hiddenPropPattern.exec(js)) !== null) jsHiddenSchemes.add(m[1]);
      while ((m = hiddenAttrPattern.exec(js)) !== null) jsHiddenSchemes.add(m[1]);
    }

    // 若同时存在两套方案 → FAIL（双轨错配风险）
    if (cssSchemes.size > 0 && jsHiddenSchemes.size > 0) {
      s14Issues.push(`检测到页面显隐双轨混用：CSS 类切换 [${[...cssSchemes].join(',')}] × JS hidden 属性 [${[...jsHiddenSchemes].join(',')}]`);
      s14Issues.push('建议：统一为单轨制（推荐 JS hidden 属性，与 HTML5 规范一致）');
    }

    if (s14Issues.length > 0) {
      log(`  [FAIL] S-14: 页面显隐双轨混用 — ${s14Issues.length} 个问题`);
      s14Issues.forEach(i => log('         - ' + i));
      fail++;
    } else {
      log('  [OK] S-14: 页面显隐单轨制（未检测到双轨混用）');
      pass++;
    }
  }

  // S-15: v5.25 P1-1 正确样板保留检查（WARN 级——骨架默认正确的静态信号，运行时由 D6/D8/D10 FAIL 兜底）
  //   根因：0828/0829 轮实证，筛选/动态行缺陷族的审计修复循环占单案例 ~90m；generate-demo 骨架已预置
  //   正确样板原语（demoraApplyFilter/demoraSyncAnnotations，语义与 run-audit 探针逐字对齐）。
  //   AI 整体重写骨架会导致原语缺失——本检查作为静态信号提醒恢复复用；无表格/筛选场景豁免。
  {
    log('\n--- S-15: v5.25 P1-1 正确样板保留检查 ---');
    const s15AppPath = path.join(demoDir, 'assets', 'app.js');
    if (!fs.existsSync(s15AppPath)) {
      log('  [WARN] S-15: app.js 不存在，跳过 P1-1 样板检查');
      warn++;
    } else {
      const s15Js = fs.readFileSync(s15AppPath, 'utf-8');
      const s15Missing = ['demoraApplyFilter', 'demoraSyncAnnotations'].filter(k => !s15Js.includes(k));
      const s15HtmlPath = path.join(demoDir, 'index.html');
      const s15Html = fs.existsSync(s15HtmlPath) ? fs.readFileSync(s15HtmlPath, 'utf-8') : '';
      const s15HasTableOrFilter = /<tbody|<table|<select|type="search"|type="text"/i.test(s15Html);
      if (s15Missing.length === 0) {
        log('  [OK] S-15: P1-1 正确样板保留（demoraApplyFilter / demoraSyncAnnotations）');
        pass++;
      } else if (!s15HasTableOrFilter) {
        log('  [OK] S-15: 页面无表格/筛选场景，P1-1 样板不适用（未检出: ' + s15Missing.join(', ') + '）');
        pass++;
      } else {
        log('  [WARN] S-15: P1-1 骨架正确样板缺失: ' + s15Missing.join(', '));
        log('         风险：筛选/动态行场景高概率重演 D6_filter_consistency / D8 覆盖率 / D10 分页往返修复循环（0828/0829 轮实证 ~90m/案）');
        log('         修复：保留并复用骨架原语（demoraBindFilter/demoraApplyFilter/demoraSyncAnnotations），禁止整体重写骨架');
        warn++;
      }
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
  log('======================================================================');

  if (fail > 0) {
    log('>>> 结构校验失败，请修正后重新运行');
    return { ok: false, pass, fail, warn };
  }
  log('>>> 结构校验通过');
  // v5.6 状态机：标记 AI 阶段 2 + 阶段 4 已完成
  markStructurePassed(projectRoot);
  log('  [OK] state.yaml: ai_html_designed = true, structure_check_passed = true');
  return { ok: true, pass, fail, warn };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('check-structure.mjs') || process.argv[1].endsWith('check-structure'));
if (isDirectRun) {
  main().then(result => process.exit(result.ok ? 0 : 1)).catch(e => { console.error(e); process.exit(1); });
}
