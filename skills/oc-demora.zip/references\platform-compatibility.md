# 平台兼容性契约（详版）

> SKILL.md「平台兼容性契约」的详版参考。来源：WorkBuddy A/B 测试三类跨平台缺陷实证（W-7 / C-1 / G-4）+ 后续各轮 UAT 补充。

## 1. 平台预检（scaffold 前必执行）

```bash
node scripts/lib/platform-check.mjs    # 跨平台兼容性预检（shim/编码/路径/权限）
```

预检输出 `[SUMMARY]` 行含 `overall: OK/WARN/FAIL`：

- `OK`：无平台风险，继续 scaffold
- `WARN`：存在风险但可继续（如 shim 激活，agent 应使用 platform-utils 工具）
- `FAIL`：致命风险（如关键目录不可写），**禁止继续 scaffold**，先修复环境

## 2. Agent 平台错误应对规范（铁律）

1. **使用 platform-utils 工具**：涉及目录/文件删除时**必须**使用 `scripts/lib/platform-utils.mjs` 的 `safeRemoveDir` / `safeRemoveFile`（同步版 `safeRemoveDirSync` / `safeRemoveFileSync`），禁止直接调用 `fs.rmSync`
   - 原因：platform-utils 多策略降级（重命名轮转 → rmSync → 逐个 unlink），shim 拦截时自动降级
   - 示例：`import { safeRemoveDirSync } from './lib/platform-utils.mjs';`
2. **禁止 Python shutil.rmtree 绕过 shim**：shim 是平台层强制策略，Python 绕过属于规避行为，且会导致路径格式不一致（/c/ vs C:\）引发后续问题
3. **禁止跳过脚本逻辑**：任何脚本失败应**报告并停止**，而非跳过继续。例如：
   - 清理失败 → 报告 `[WARN]` 但继续流程（清理非阻塞）
   - 状态机校验失败 → 报告 `[FAIL]` 并停止（必阻塞）
4. **PowerShell 编码处理**：Windows 平台读取 UTF-8 文件（SKILL.md / requirement-model.yaml）**必须**用 Node.js `fs.readFileSync(file, 'utf-8')`，禁止用 PowerShell `Get-Content`（默认 CP936 致中文乱码）
5. **路径含特殊字符**：项目路径含空格/中文时，PowerShell 命令必须用单引号包裹路径参数；建议优先使用纯英文路径避免编码问题

## 3. Windows 截图/Playwright 专项

- 自写 Playwright 脚本**必须指定 `channel: 'msedge'`**（缺省时 Playwright 尝试下载 chromium 二进制，p1 实证超时 124s 白耗）：

```js
// demo/shot.mjs — 自写截图最小模板（调试文件，用后必须删除并重跑 quality-check）
import { chromium } from 'playwright';
const browser = await chromium.launch({ channel: 'msedge' });  // Windows 必须指定，免下载
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.goto('http://127.0.0.1:8802/', { waitUntil: 'networkidle' });
await page.screenshot({ path: 'shot.png', fullPage: true });
await browser.close();
```

- run-audit / diagnose-runtime / verify-demo-runtime 内部已按平台自适应（Windows → msedge，其余 → chromium），无需手动指定

## 4. 失败处理原则

- **可恢复失败**（清理失败、临时文件残留）：`[WARN]` + 继续流程
- **不可恢复失败**（状态机不一致、门禁未通过、关键目录不可写）：`[FAIL]` + 停止流程 + 报告根因
- **禁止**：吞掉异常静默继续、跳过校验、伪造状态字段
