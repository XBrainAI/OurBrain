// diagnose-button-failure.mjs
// 按钮失效真因确诊脚本（v5.14.16 批次1 修复 L）
//
// 设计目标：
//   A/B 测试 wb-dsf/wb-glm52 暴露按钮/导航失效，但 B-1（标注引擎拦截）/B-2（绑定遗漏）/
//   B-3（路由缺陷）均被证伪。更可能的方向是 init 序列异常中断导致后续绑定集体失效
//   （能统一解释"P06 搜索无反应 + P02-P05 导航不工作"的群发症状）。
//
//   本脚本不修改 demo 源码，而是用 Playwright 打开页面，注入 init 序列监控代码：
//   1. 捕获 window.onerror / unhandledrejection 全局异常
//   2. 注入 init 序列探针：包裹 DOMContentLoaded 监听器，捕获首个抛出的异常及堆栈
//   3. 逐页测试按钮点击，记录无响应按钮 + 关联的 init 异常
//   4. 输出确诊报告：首个 init 异常 + 受影响的按钮列表 + 修复建议
//
// 用法：
//   node scripts/diagnose-button-failure.mjs --demo <demo-path> [--port 8801]
//
// 退出码：0=诊断完成，1=参数错误，2=Playwright 不可用

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { spawn, execSync } from 'child_process';
import http from 'http';
import { findFreePort } from './lib/port-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const skillDirRequire = createRequire(path.join(__dirname, 'dummy.js'));

function log(msg) { process.stdout.write(msg + '\n'); }

// ===== 参数解析 =====
function parseArgs(argv) {
  const args = { demo: null, port: 8801, help: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--help' || a === '-h') args.help = true;
    else if (a === '--demo') args.demo = argv[++i];
    else if (a === '--port') args.port = parseInt(argv[++i], 10);
  }
  return args;
}

function showHelp() {
  console.log(`Demora 按钮失效真因确诊 (v5.14.16 批次1 修复 L)

用法：
  node scripts/diagnose-button-failure.mjs --demo <demo-path> [--port 8801]

参数：
  --demo <path>    demo 目录路径（包含 index.html）
  --port <num>     本地 HTTP 端口（默认 8801，避免与 run-audit 8800 冲突）

输出：
  - 全局异常清单（window.onerror / unhandledrejection）
  - init 序列异常（首个抛出的异常 + 堆栈）
  - 逐页按钮测试结果（响应/无响应 + 关联异常）
  - 确诊结论 + 修复建议

退出码：0=诊断完成，1=参数错误，2=Playwright 不可用`);
}

// ===== 启动本地 HTTP 服务器（复用 run-audit 模式）=====
let httpServerProc = null;

function startHttpServer(demoDir, port) {
  return new Promise((resolve) => {
    const args = ['-m', 'http.server', String(port), '--bind', '127.0.0.1'];
    httpServerProc = spawn('python', args, {
      cwd: demoDir, stdio: 'ignore', detached: false, shell: false,
    });
    httpServerProc.on('error', () => resolve(startNodeStaticServer(demoDir, port)));
    let attempts = 0;
    const maxAttempts = 20;
    const poll = () => {
      attempts++;
      const req = http.get(`http://127.0.0.1:${port}/`, (res) => {
        res.resume();
        resolve(true);
      });
      req.on('error', () => {
        if (attempts < maxAttempts) setTimeout(poll, 300);
        else resolve(false);
      });
      req.setTimeout(1000, () => { req.destroy(); if (attempts < maxAttempts) setTimeout(poll, 300); else resolve(false); });
    };
    setTimeout(poll, 500);
  });
}

function startNodeStaticServer(demoDir, port) {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) => {
      let urlPath = req.url.split('?')[0];
      if (urlPath === '/') urlPath = '/index.html';
      const filePath = path.join(demoDir, urlPath);
      if (!fs.existsSync(filePath)) { res.writeHead(404); res.end('Not Found'); return; }
      const ext = path.extname(filePath);
      const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };
      res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream' });
      fs.createReadStream(filePath).pipe(res);
    });
    server.listen(port, '127.0.0.1', () => { httpServerProc = server; resolve(true); });
    server.on('error', () => resolve(false));
  });
}

function stopHttpServer() {
  try {
    if (httpServerProc) {
      if (typeof httpServerProc.kill === 'function') httpServerProc.kill();
      else if (httpServerProc.close) httpServerProc.close();
      httpServerProc = null;
    }
  } catch (e) { /* 忽略 */ }
}

// ===== 主流程 =====
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.demo) { showHelp(); process.exit(args.help ? 0 : 1); }

  const demoDir = path.resolve(args.demo);
  const indexPath = path.join(demoDir, 'index.html');
  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在: ' + indexPath);
    process.exit(1);
  }

  // 加载 Playwright
  let chromium;
  try {
    const playwright = skillDirRequire('playwright');
    chromium = playwright.chromium;
  } catch (e) {
    try {
      const playwrightCore = skillDirRequire('playwright-core');
      chromium = playwrightCore.chromium;
    } catch (e2) {
      log('[FAIL] Playwright 不可用: ' + e2.message);
      log('       运行: npm install playwright 或 npx playwright install chromium');
      process.exit(2);
    }
  }

  // v5.18 P1-D3：端口治理改用 Node 原生 findFreePort（不 kill），替代 PowerShell 清理（历史 ETIMEDOUT 源）
  const freePort = await findFreePort(args.port, 20);
  if (freePort === null) { log('[FAIL] 无可用端口（' + args.port + ' 起连续 20 个被占用）'); process.exit(1); }
  const URL = `http://127.0.0.1:${freePort}/`;

  log('======================================================================');
  log('diagnose-button-failure.mjs — 按钮失效真因确诊 (v5.14.16 批次1 修复 L)');
  log('======================================================================');
  log(`  demo:  ${demoDir}`);
  log(`  URL:   ${URL}`);
  log('');

  // 启动 HTTP 服务器
  log('[INFO] 启动本地 HTTP 服务器...');
  const serverOk = await startHttpServer(demoDir, freePort);
  if (!serverOk) {
    log('[FAIL] HTTP 服务器启动失败');
    process.exit(1);
  }
  log('[OK] HTTP 服务器已启动');

  // 启动浏览器
  let browser;
  try {
    browser = await chromium.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });
  } catch (e) {
    log('[FAIL] 浏览器启动失败: ' + e.message);
    stopHttpServer();
    process.exit(2);
  }

  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });

  // ===== 阶段 1：捕获全局异常 + init 序列异常 =====
  log('\n--- 阶段 1：捕获全局异常 + init 序列异常 ---');

  const globalErrors = [];
  const initErrors = [];
  const consoleErrors = [];

  // 捕获页面全局异常
  page.on('pageerror', (error) => {
    globalErrors.push({
      message: error.message,
      stack: error.stack,
      time: new Date().toISOString(),
    });
  });

  // 捕获 console.error
  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleErrors.push({
        text: msg.text(),
        time: new Date().toISOString(),
      });
    }
  });

  // 注入 init 序列探针（在页面任何脚本执行前）
  await page.addInitScript(() => {
    // 探针 1：包裹 addEventListener，捕获 DOMContentLoaded 监听器异常
    const origAddEventListener = EventTarget.prototype.addEventListener;
    window.__initErrors__ = [];
    window.__initProbeActive__ = true;

    // 探针 2：包裹 window.onload / DOMContentLoaded
    document.addEventListener('DOMContentLoaded', function() {
      // 在所有 DOMContentLoaded 监听器执行后检查
      setTimeout(() => {
        window.__initProbeActive__ = false;
      }, 100);
    }, { capture: true, once: false });

    // 探针 3：捕获 window.onerror（同步异常）
    window.addEventListener('error', function(e) {
      window.__initErrors__.push({
        type: 'window.onerror',
        message: e.message,
        filename: e.filename,
        lineno: e.lineno,
        colno: e.colno,
        time: new Date().toISOString(),
        isInit: window.__initProbeActive__,
      });
    }, true);

    // 探针 4：捕获 unhandledrejection（Promise 异常）
    window.addEventListener('unhandledrejection', function(e) {
      window.__initErrors__.push({
        type: 'unhandledrejection',
        message: e.reason && e.reason.message ? e.reason.message : String(e.reason),
        stack: e.reason && e.reason.stack ? e.reason.stack : null,
        time: new Date().toISOString(),
        isInit: window.__initProbeActive__,
      });
    }, true);

    // 探针 5：包裹 setTimeout/setInterval，捕获回调异常（init 常用 setTimeout 延迟绑定）
    const origSetTimeout = window.setTimeout;
    window.setTimeout = function(fn, delay, ...args) {
      if (typeof fn === 'function') {
        const wrapped = function(...a) {
          try {
            return fn.apply(this, a);
          } catch (e) {
            window.__initErrors__.push({
              type: 'setTimeout-callback',
              message: e.message,
              stack: e.stack,
              time: new Date().toISOString(),
              isInit: window.__initProbeActive__,
              delay: delay,
            });
            throw e;
          }
        };
        return origSetTimeout.call(window, wrapped, delay, ...args);
      }
      return origSetTimeout.call(window, fn, delay, ...args);
    };
  });

  // 导航到首页
  await page.goto(URL, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(2000);  // 等待 init 序列完成

  // 收集探针捕获的异常
  const probeErrors = await page.evaluate(() => window.__initErrors__ || []);

  log(`[INFO] 全局异常 (pageerror): ${globalErrors.length} 个`);
  log(`[INFO] init 探针异常: ${probeErrors.length} 个`);
  log(`[INFO] console.error: ${consoleErrors.length} 个`);

  if (globalErrors.length > 0) {
    log('\n[全局异常清单]');
    globalErrors.forEach((e, i) => {
      log(`  ${i + 1}. [${e.time}] ${e.message}`);
      if (e.stack) log(`     堆栈: ${e.stack.split('\n').slice(0, 5).join('\n     ')}`);
    });
  }

  if (probeErrors.length > 0) {
    log('\n[init 序列异常清单（探针捕获）]');
    probeErrors.forEach((e, i) => {
      log(`  ${i + 1}. [${e.type}] ${e.message}`);
      log(`     时间: ${e.time}, init 期: ${e.isInit}`);
      if (e.filename) log(`     位置: ${e.filename}:${e.lineno}:${e.colno}`);
      if (e.stack) log(`     堆栈: ${e.stack.split('\n').slice(0, 5).join('\n     ')}`);
    });
  }

  if (consoleErrors.length > 0) {
    log('\n[console.error 清单]');
    consoleErrors.slice(0, 20).forEach((e, i) => {
      log(`  ${i + 1}. [${e.time}] ${e.text}`);
    });
    if (consoleErrors.length > 20) log(`  ... 共 ${consoleErrors.length} 条`);
  }

  // ===== 阶段 2：逐页测试按钮响应 =====
  log('\n--- 阶段 2：逐页测试按钮响应（关联 init 异常）---');

  // 探测 navLinks
  const navLinks = await page.evaluate(() => {
    const links = [];
    document.querySelectorAll('a[href^="#"]:not([hidden])').forEach(a => {
      const cs = window.getComputedStyle(a);
      if (cs.display === 'none' || cs.visibility === 'hidden') return;
      links.push({ href: a.getAttribute('href'), text: (a.textContent || '').trim().substring(0, 20), type: 'hash' });
    });
    if (links.length < 2) {
      document.querySelectorAll('[data-nav]').forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width > 0 && r.height > 0) {
          links.push({ href: '#nav-' + el.getAttribute('data-nav'), text: (el.textContent || '').trim().substring(0, 20), type: 'data-nav', navId: el.getAttribute('data-nav') });
        }
      });
    }
    const seen = new Set();
    return links.filter(l => { if (seen.has(l.href)) return false; seen.add(l.href); return true; });
  });

  const pageList = [{ label: '首页', type: 'home' }, ...navLinks.map(l => ({ label: l.text || l.href, ...l }))];
  log(`[INFO] 将遍历 ${pageList.length} 个页面测试按钮`);

  const buttonTestResults = [];
  for (const pageInfo of pageList) {
    if (pageInfo.type !== 'home') {
      let clickArg;
      if (pageInfo.type === 'data-nav') clickArg = `[data-nav="${pageInfo.navId}"]`;
      else clickArg = `a[href="${pageInfo.href}"]`;
      await page.evaluate((sel) => {
        const el = document.querySelector(sel);
        if (el) el.click();
      }, clickArg).catch(() => {});
      await page.waitForTimeout(500);
    }

    const buttons = await page.evaluate(() => {
      const allBtns = Array.from(document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"]'));
      const result = [];
      for (let i = 0; i < allBtns.length; i++) {
        const b = allBtns[i];
        const r = b.getBoundingClientRect();
        const s = window.getComputedStyle(b);
        const visible = r.width > 0 && r.height > 0 && s.display !== 'none' && s.visibility !== 'hidden';
        const isAnnotation = b.closest('.annotation-panel') || b.hasAttribute('data-annotation-toggle');
        if (!visible || isAnnotation) continue;
        const isDisabled = b.disabled === true || b.getAttribute('aria-disabled') === 'true' || s.pointerEvents === 'none';
        if (isDisabled) continue;
        result.push({ globalIndex: i, text: (b.textContent || b.value || '').trim().substring(0, 30), hasOnclick: b.hasAttribute('onclick') });
      }
      return result;
    });

    for (const btn of buttons.slice(0, 10)) {  // 每页最多测 10 个按钮
      const result = await page.evaluate((globalIdx) => {
        return new Promise((resolve) => {
          const btns = Array.from(document.querySelectorAll('button, [role="button"], input[type="button"], input[type="submit"]'));
          const target = btns[globalIdx];
          if (!target) { resolve({ clicked: false, text: 'not found' }); return; }

          const before = { domNodes: document.querySelectorAll('*').length, hash: location.hash };
          let mutated = false;
          const observer = new MutationObserver(() => { mutated = true; });
          observer.observe(document.body, { childList: true, subtree: true, attributes: true });

          target.click();
          setTimeout(() => {
            observer.disconnect();
            const after = { domNodes: document.querySelectorAll('*').length, hash: location.hash };
            const responded = mutated || before.domNodes !== after.domNodes || before.hash !== after.hash;
            resolve({
              clicked: true,
              text: (target.textContent || target.value || '').trim().substring(0, 30),
              responded,
              hasOnclick: target.hasAttribute('onclick'),
              hasDataAction: target.hasAttribute('data-action') || target.hasAttribute('data-open-modal'),
              // 检查按钮是否绑定了事件监听器（通过 getEventListeners 不可用，用 onclick 属性近似）
              hasOnclickAttr: target.hasAttribute('onclick'),
              onclickValue: target.getAttribute('onclick'),
            });
          }, 500);
        });
      }, btn.globalIndex);

      buttonTestResults.push({
        page: pageInfo.label,
        text: result.text,
        responded: result.responded,
        hasOnclick: result.hasOnclick,
        hasDataAction: result.hasDataAction,
      });

      if (!result.responded) {
        log(`  [WARN] ${pageInfo.label} "${result.text}" 无响应 (onclick=${result.hasOnclick}, data-action=${result.hasDataAction})`);
      }
    }
  }

  // ===== 阶段 3：确诊结论 =====
  log('\n--- 阶段 3：确诊结论 ---');

  const totalButtons = buttonTestResults.length;
  const unresponsiveButtons = buttonTestResults.filter(b => !b.responded);
  const responsiveButtons = buttonTestResults.filter(b => b.responded);

  log(`[INFO] 测试按钮总数: ${totalButtons}`);
  log(`[INFO] 响应: ${responsiveButtons.length}, 无响应: ${unresponsiveButtons.length}`);

  // 确诊逻辑
  let diagnosis = 'UNKNOWN';
  let diagnosisDetail = '';
  let fixSuggestion = '';

  if (probeErrors.length > 0 && unresponsiveButtons.length > 0) {
    const initError = probeErrors.find(e => e.isInit) || probeErrors[0];
    diagnosis = 'INIT_SEQUENCE_EXCEPTION';
    diagnosisDetail = `init 序列异常导致后续绑定集体失效。首个异常: [${initError.type}] ${initError.message}`;
    fixSuggestion = `修复 init 序列中的首个异常（${initError.message}），该异常中断了后续所有事件绑定。` +
                   `常见根因：对 null 元素赋值 onclick（如 document.getElementById('xxx').onclick = ... 时 xxx 不存在）。` +
                   `建议：在绑定前检查元素是否存在（if (el) el.onclick = ...），或使用事件委托。`;
  } else if (globalErrors.length > 0 && unresponsiveButtons.length > 0) {
    diagnosis = 'GLOBAL_EXCEPTION';
    diagnosisDetail = `全局异常导致按钮失效。首个异常: ${globalErrors[0].message}`;
    fixSuggestion = `修复全局异常: ${globalErrors[0].message}。检查堆栈定位异常源头。`;
  } else if (unresponsiveButtons.length > 0 && probeErrors.length === 0 && globalErrors.length === 0) {
    // 无异常但按钮无响应 — 检查是否绑定事件
    const noBindingButtons = unresponsiveButtons.filter(b => !b.hasOnclick && !b.hasDataAction);
    if (noBindingButtons.length === unresponsiveButtons.length) {
      diagnosis = 'NO_EVENT_BINDING';
      diagnosisDetail = `按钮无响应但无异常 — 所有无响应按钮均未绑定事件（onclick/data-action 均无）`;
      fixSuggestion = `为以下按钮绑定事件监听器: ${unresponsiveButtons.map(b => `"${b.text}"(${b.page})`).slice(0, 5).join(', ')}`;
    } else {
      diagnosis = 'PARTIAL_BINDING_MISSING';
      diagnosisDetail = `部分按钮无响应 — 部分有 onclick/data-action 但无响应，部分完全未绑定`;
      fixSuggestion = `检查事件绑定逻辑：有 onclick 属性但无响应的按钮可能 onclick 表达式有误；无绑定的按钮需添加事件监听器`;
    }
  } else if (unresponsiveButtons.length === 0) {
    diagnosis = 'ALL_BUTTONS_WORKING';
    diagnosisDetail = '所有测试的按钮均响应正常，按钮失效问题未复现';
    fixSuggestion = '问题可能已修复，或在特定操作序列下才触发。建议用浏览器 devtools 手动复现。';
  }

  log('\n[确诊结论]');
  log(`  诊断: ${diagnosis}`);
  log(`  详情: ${diagnosisDetail}`);
  log(`  建议: ${fixSuggestion}`);

  if (unresponsiveButtons.length > 0) {
    log('\n[无响应按钮清单]');
    const grouped = {};
    for (const b of unresponsiveButtons) {
      if (!grouped[b.page]) grouped[b.page] = [];
      grouped[b.page].push(b);
    }
    for (const [p, btns] of Object.entries(grouped)) {
      log(`  ${p}:`);
      btns.forEach(b => log(`    - "${b.text}" (onclick=${b.hasOnclick}, data-action=${b.hasDataAction})`));
    }
  }

  log('\n======================================================================');
  log('[SUMMARY] 诊断完成');
  log('======================================================================');
  log(`  诊断: ${diagnosis}`);
  log(`  init 异常: ${probeErrors.length}, 全局异常: ${globalErrors.length}, console.error: ${consoleErrors.length}`);
  log(`  按钮测试: ${responsiveButtons.length}/${totalButtons} 响应, ${unresponsiveButtons.length} 无响应`);

  await browser.close();
  stopHttpServer();
  process.exit(0);
}

main().catch(e => {
  console.error('[FAIL] 诊断异常: ' + e.message);
  console.error(e.stack);
  try { stopHttpServer(); } catch (_) {}
  process.exit(1);
});
