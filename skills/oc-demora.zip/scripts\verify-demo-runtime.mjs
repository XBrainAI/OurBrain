// verify-demo-runtime.mjs
// Demo 运行时验证（v5.1 step 分组 + 失败截图）
//
// 使用 Playwright 验证 Demo 运行时可用性：
//   R-1: 页面可加载（HTTP 200 或 file:// 可访问）
//   R-2: 无 JS 控制台错误与请求失败
//   R-3: 标注面板可显示（web-first assertion: toBeAttached）
//   R-4: 标注开关可切换（web-first assertion: toBeVisible + click）
//   R-5: 页面无空白（body 有内容，排除占位文本）
//
// v5.1 Sprint 1 P1-4 增强：
//   - step 分组：每项检查包裹在 runStep() 中，输出清晰的步骤边界
//   - 失败截图：检查失败时自动 page.screenshot() 保存到 demo/verify-fail-*.png
//   - 保留 v5.0 P0-4 反模式修复（networkidle / locator / web-first assertions）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { createRequire } from 'module';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// v5.14.9：从 cwd（项目目录）创建 require，用于解析项目目录 node_modules 里的 playwright
const cwdRequire = createRequire(path.join(process.cwd(), 'dummy.js'));

function log(msg) { process.stdout.write(msg + '\n'); }

/**
 * step 分组包装器（v5.1）
 * - 输出步骤边界（--- name ---）
 * - 失败时自动保存 page.screenshot() 到 demo/verify-fail-<safeName>-<ts>.png
 * - 不依赖 @playwright/test，使用轻量级自定义实现
 *
 * @param {string} name 步骤名（如 "R-1: 页面可加载"）
 * @param {Function} fn 异步检查函数（抛出 Error 表示失败）
 * @param {object|null} page Playwright page 对象（用于失败截图）
 * @param {string} screenshotDir 截图保存目录
 * @param {object} results 累计 { pass, fail }
 */
async function runStep(name, fn, page, screenshotDir, results) {
  log('\n  --- ' + name + ' ---');
  try {
    await fn();
    results.pass++;
    log('  [OK] ' + name);
  } catch (e) {
    results.fail++;
    log('  [FAIL] ' + name + ' - ' + e.message);
    // 失败截图：保存到 demo/ 目录便于诊断
    if (page) {
      try {
        const ts = Date.now();
        const safeName = name.replace(/[^a-zA-Z0-9-]/g, '_');
        const screenshotPath = path.join(screenshotDir, `verify-fail-${safeName}-${ts}.png`);
        await page.screenshot({ path: screenshotPath, fullPage: true });
        log('  [INFO] 失败截图已保存: ' + screenshotPath);
      } catch (se) {
        log('  [WARN] 截图保存失败: ' + se.message);
      }
    }
  }
}

export async function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const indexPath = path.join(projectRoot, 'demo', 'index.html');
  const screenshotDir = path.join(projectRoot, 'demo');

  // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
  try {
    const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
    const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
    if (!integrity.ok && !integrity.skipped) {
      log(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}`);
      log('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本');
      process.exit(1);
    }
  } catch (e) { /* gate-baseline.mjs 不可用时跳过（开发态兼容） */ }

  log('======================================================================');
  log('verify-demo-runtime.mjs — 运行时验证 (v5.1 step 分组 + 失败截图)');
  log('======================================================================');

  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在');
    return { ok: false, pass: 0, fail: 1 };
  }

  const results = { pass: 0, fail: 0 };

  try {
    // v5.14 修复 F2：expect 必须从 @playwright/test 导入（playwright 主包不导出 web-first matcher）
    // v5.14.9：对齐 run-audit.mjs 三层降级（cwdRequire fallback + msedge 优先 + ESM/CJS 兼容）
    let chromium, expect;
    try {
      const pw = await import('playwright');
      chromium = pw.chromium || (pw.default && pw.default.chromium);
    } catch (e) {
      // 兜底：从 cwd（项目目录）解析 playwright
      try {
        const playwrightEntry = cwdRequire.resolve('playwright');
        const pw = await import(pathToFileURL(playwrightEntry).href);
        chromium = pw.chromium || (pw.default && pw.default.chromium);
        if (!chromium) {
          throw new Error('playwright 模块已加载但 chromium 导出缺失');
        }
        log('[INFO] Playwright 从项目目录加载: ' + path.dirname(cwdRequire.resolve('playwright/package.json')));
      } catch (e2) {
        throw { code: 'ERR_MODULE_NOT_FOUND', message: 'Playwright 未安装: ' + e.message + '（修复：node scripts/install-deps.mjs 或 npm install playwright）', cause: e };
      }
    }
    try {
      expect = (await import('@playwright/test')).expect;
    } catch (e) {
      // @playwright/test 不可用时，自实现 web-first 断言等价语义
      expect = (locator) => ({
        toBeAttached: async ({ timeout = 5000 } = {}) => {
          await locator.waitFor({ state: 'attached', timeout });
        },
        toBeVisible: async ({ timeout = 5000 } = {}) => {
          await locator.waitFor({ state: 'visible', timeout });
        },
      });
    }
    // v5.14.9：Windows 优先 msedge（系统自带，免下载 chromium），与 run-audit.mjs 一致
    let browser;
    if (process.platform === 'win32') {
      try {
        browser = await chromium.launch({ headless: true, channel: 'msedge' });
      } catch (e1) {
        browser = await chromium.launch({ headless: true });
      }
    } else {
      browser = await chromium.launch({ headless: true });
    }
    const context = await browser.newContext();
    const page = await context.newPage();

    const errors = [];
    page.on('console', msg => {
      if (msg.type() === 'error') errors.push(msg.text());
    });
    page.on('pageerror', err => errors.push(err.message));
    page.on('requestfailed', req => {
      const url = req.url();
      if (!url.endsWith('/favicon.ico') && !url.endsWith('/favicon.png')) {
        errors.push(`requestfailed: ${url} - ${req.failure()?.errorText || 'unknown'}`);
      }
    });

    // R-1: 页面可加载
    await runStep('R-1: 页面可加载', async () => {
      const fileUrl = 'file:///' + indexPath.replace(/\\/g, '/');
      await page.goto(fileUrl, { timeout: 10000 });
      await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {
        // networkidle 在无网络请求的 file:// 场景可能超时，忽略
      });
    }, page, screenshotDir, results);

    // R-2: 无 JS 控制台错误与请求失败
    await runStep('R-2: 无 JS 控制台错误与请求失败', async () => {
      if (errors.length > 0) {
        const detail = errors.slice(0, 5).map(e => '    - ' + e).join('\n');
        throw new Error(`${errors.length} 个错误（含 console.error / pageerror / requestfailed）\n${detail}`);
      }
    }, page, screenshotDir, results);

    // R-3: 标注面板可显示（契约要求：enhance-prototype.mjs 必须注入）
    await runStep('R-3: 标注面板存在（toBeAttached）', async () => {
      const panelLocator = page.locator('.annotation-panel').first();
      await expect(panelLocator).toBeAttached({ timeout: 3000 });
    }, page, screenshotDir, results);

    // R-4: 标注开关可切换（契约要求：data-annotation-toggle 必须存在）
    await runStep('R-4: 标注开关可点击（toBeVisible + click）', async () => {
      const toggleLocator = page.locator('[data-annotation-toggle]').first();
      await expect(toggleLocator).toBeVisible({ timeout: 3000 });
      await toggleLocator.click();
      await page.waitForLoadState('networkidle', { timeout: 1000 }).catch(() => {});
    }, page, screenshotDir, results);

    // R-5: 页面有充实内容（不能是占位文本）
    await runStep('R-5: 页面有充实内容', async () => {
      const bodyText = await page.evaluate(() => document.body.innerText.trim());
      const bodyLen = bodyText.length;
      const isPlaceholder = bodyText === 'Loading...' || bodyText.startsWith('Demo - 待 AI 设计');
      if (bodyLen <= 200 || isPlaceholder) {
        throw new Error(`内容过少或为占位文本 (${bodyLen} 字符: "${bodyText.slice(0, 40)}...")`);
      }
    }, page, screenshotDir, results);

    await browser.close();
  } catch (e) {
    // v5.14 修复 F2 修复点 B：仅捕获 Playwright 模块缺失，运行时断言错误计入 fail
    if (e.code === 'ERR_MODULE_NOT_FOUND' || /Cannot find package 'playwright'/.test(e.message)) {
      log('[FAIL] Playwright 未安装，运行时验证无法执行: ' + e.message);
      log('  [INFO] 请运行 npm install playwright 后重试');
      results.fail += 1;  // 计为失败，不再静默通过
    } else {
      // 运行时断言错误：计入 fail 并记录
      log('[FAIL] 运行时验证异常: ' + e.message);
      results.fail += 1;
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${results.pass}, 失败: ${results.fail}`);
  log('======================================================================');

  // v5.14 修复 F2 修复点 C：零项检查执行 = 未验证，禁止判通过
  if (results.pass === 0 && results.fail === 0) {
    log('>>> 运行时验证未执行（0 通过 / 0 失败）');
    log('>>> 判定: FAIL（未执行验证不得判通过）');
    return { ok: false, pass: 0, fail: 1 };
  }
  if (results.fail > 0) {
    log('>>> 运行时验证失败');
    return { ok: false, pass: results.pass, fail: results.fail };
  }
  log('>>> 运行时验证通过');
  return { ok: true, pass: results.pass, fail: results.fail };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('verify-demo-runtime.mjs') || process.argv[1].endsWith('verify-demo-runtime'));
if (isDirectRun) {
  main().then(result => process.exit(result.ok ? 0 : 1));
}
