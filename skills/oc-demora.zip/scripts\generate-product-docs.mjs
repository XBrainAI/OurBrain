// generate-product-docs.mjs
// Phase 2 HTML 产品文档生成器：单页 PRD（v5.6 重构）
//
// v5.18 P0-B1/B3：BOM strip + 防死循环守卫 + 进度可见性
//
// v5.20（P2-2，UAT 二轮 U17）：
//   - 章节 4↔5 对调并更名：新 §4 业务流程（原"业务过程"：主/分支/异常/状态流转）、
//     新 §5 产品流程（原"流程视图"：任务/数据/页面流）；锚点 id 不变（#business-process/#business-flow），
//     TOC 与 section-num 同步；认知次序：现有业务流程 → 规划设计产品流程
//
// v5.19（P0-2/P2-4/P2-7/P034）：
//   - P0-2：新增 §11 研发文档章节（data-audience="dev"，聚合 docs/spec|test|handoff 全文）
//   - P2-4：.mermaid svg max-height 420px → 720px + 容器 cursor: zoom-in（配合 mermaid-init.js 点击放大）
//   - P2-7：原 §4 业务流程拆分为 §4 流程视图（三大 Flow）+ §5 业务过程（主/分支/异常/状态），后续章节编号顺延
//   - P034：index.html 写盘后新增 mermaid 渲染自检（mermaid.parse 逐块校验，失败置 exitCode=1）
//
// v5.6 重构说明：
//   原 v5.5 生成 5 个独立 HTML（index 导航页 + 4 子页面），对 PM 不友好：
//     - HTML 与 markdown PRD 内容割裂，仅展示 YAML 结构化数据
//     - 多页跳转体验差，违反业界"单页优先"原则
//   v5.6 重构为单页 PRD（docs/index.html），整合 markdown PRD 叙事 + YAML 数据：
//     1. 项目元数据（Metadata）
//     2. 业务背景（Problem + Why）— 来自 docs/prd/01-background.md
//     3. 目标用户 — 来自 docs/prd/02-target-audience.md + YAML roles
//     4. 解决方案概述 — 来自 inbox/text/requirement-input.md + 04-business-flow.md
//     5. 页面规格 — 来自 YAML pages + annotations（整合原 page-spec.html）
//     6. 数据模型 — 来自 YAML entities（整合原 data-model.html）
//     7. 角色权限 — 来自 YAML roles（整合原 role-permission.html）
//     8. 成功指标与时间线 — 来自 docs/prd/10/11-*.md
//     9. 范围与风险 — 来自 docs/prd/12/13-*.md
//    10. PM 原始需求 — 来自 inbox/text/requirement-input.md（<details> 折叠）
//    11. 详细文档下载 — 链接到 docs/prd/、spec/、test/、handoff/
//
//   4 个子页面（product-overview/page-spec/data-model/role-permission.html）
//   改为重定向存根（<script>location.href='index.html#anchor'</script>），
//   保留文件名以保持向后兼容（外部链接 + verify-delivery V-6 校验）。
//
// 设计原则：
//   - HTML 文档基于 Demora IP 规范（暗色主题、Teal 主色）
//   - 不含 emoji（遵循 FP-013）
//   - 自包含（无外部 CSS/JS 依赖，内联样式）
//   - 响应式布局，适配桌面与移动端
//   - 单页 PRD + 锚点导航 + <details> 折叠面板
//   - 业界对标：Lenny's 1-Pager + Notion Ultimate PRD
//
// 调用：node generate-product-docs.mjs
// cwd：sim-project 目录
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import vm from 'vm'; // v5.19 P034：mermaid 渲染自检用（全局作用域执行 mermaid.min.js）
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * 轻量 YAML 解析（仅处理需求模型涉及的子集）
 */
function parseYAML(text) {
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let pos = 0;

  function isBlankOrComment(line) {
    const t = line.trim();
    return t === '' || t.startsWith('#');
  }
  function indentOf(line) { return line.search(/\S/); }
  function peek() {
    while (pos < lines.length && isBlankOrComment(lines[pos])) pos++;
    return pos < lines.length ? lines[pos] : null;
  }
  function parseValue(parentIndent) {
    const line = peek();
    if (line === null) return null;
    const ind = indentOf(line);
    if (ind <= parentIndent) return null;
    return parseBlock(ind);
  }
  function parseBlock(blockIndent) {
    const first = peek();
    if (first === null) return null;
    if (first.trim().startsWith('-')) return parseSequence(blockIndent);
    return parseMapping(blockIndent);
  }
  function parseMapping(blockIndent) {
    const obj = {};
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      const m = trimmed.match(/^([\w-]+):\s*(.*)$/);
      if (!m) break;
      const key = m[1];
      const rest = m[2].trim();
      pos++;
      if (rest === '') {
        obj[key] = parseValue(blockIndent);
      } else if (rest === '|' || rest === '|-') {
        obj[key] = parseLiteralBlock(blockIndent, rest === '|-');
      } else if (rest.startsWith('[') && rest.endsWith(']')) {
        const inner = rest.slice(1, -1).trim();
        obj[key] = inner === '' ? [] : inner.split(',').map(x => parseScalar(x.trim()));
      } else {
        obj[key] = parseScalar(rest);
      }
    }
    return obj;
  }
  function parseSequence(blockIndent) {
    const arr = [];
    while (true) {
      const line = peek();
      if (line === null) break;
      const ind = indentOf(line);
      if (ind !== blockIndent) break;
      const trimmed = line.trim();
      if (!trimmed.startsWith('-')) break;
      const dashEnd = line.indexOf('-') + 1;
      let contentStart = dashEnd;
      while (contentStart < line.length && line[contentStart] === ' ') contentStart++;
      const after = line.slice(contentStart);
      if (after === '') {
        pos++;
        arr.push(parseValue(blockIndent));
      } else {
        const m = after.match(/^([\w-]+):\s*(.*)$/);
        if (m) {
          const itemIndent = contentStart;
          lines[pos] = ' '.repeat(itemIndent) + after;
          arr.push(parseMapping(itemIndent));
        } else {
          pos++;
          arr.push(parseScalar(after));
        }
      }
    }
    return arr;
  }
  function parseLiteralBlock(parentIndent, strip) {
    const blockLines = [];
    let blockIndent = -1;
    while (true) {
      if (pos >= lines.length) break;
      const line = lines[pos];
      if (line.trim() === '') { blockLines.push(''); pos++; continue; }
      const ind = indentOf(line);
      if (ind <= parentIndent) break;
      if (blockIndent === -1) blockIndent = ind;
      if (ind < blockIndent) break;
      blockLines.push(line.slice(blockIndent));
      pos++;
    }
    while (blockLines.length > 0 && blockLines[blockLines.length - 1] === '') blockLines.pop();
    let content = blockLines.join('\n');
    if (!strip) content += '\n';
    return content;
  }
  function parseScalar(s) {
    if (s === 'true') return true;
    if (s === 'false') return false;
    if (s === 'null' || s === '~') return null;
    if ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'"))) return s.slice(1, -1);
    return s;
  }
  return parseBlock(0);
}

/**
 * HTML 转义
 */
function esc(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ============================================================================
// S1: 轻量级 Markdown → HTML 解析器（~150 行，无外部依赖）
// 支持：标题/段落/列表/表格/代码块/引用块/分割线/行内格式（粗体/斜体/行内代码/链接）
// ============================================================================

/**
 * 行内格式处理：粗体、斜体、行内代码、链接
 * 注意：先处理行内代码（避免内部内容被其他规则误处理）
 */
function applyInlineMarkdown(text) {
  // 先用占位符提取行内代码
  const codeBlocks = [];
  let processed = text.replace(/`([^`]+)`/g, (m, code) => {
    codeBlocks.push(code);
    return `\u0000CODE${codeBlocks.length - 1}\u0000`;
  });

  // 粗体 **text** 或 __text__
  processed = processed.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  processed = processed.replace(/__([^_]+)__/g, '<strong>$1</strong>');

  // 斜体 *text* 或 _text_（避免与粗体冲突）
  processed = processed.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  processed = processed.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '<em>$1</em>');

  // 链接 [text](url)
  processed = processed.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');

  // 还原行内代码
  processed = processed.replace(/\u0000CODE(\d+)\u0000/g, (m, idx) => {
    return '<code>' + esc(codeBlocks[Number(idx)]) + '</code>';
  });

  return processed;
}

/**
 * 轻量 Markdown → HTML 转换
 * 支持：#, ##, ###, #### 标题；段落；- / * 无序列表；1. 有序列表；
 *       |表格|；```代码块```；> 引用块；--- 分割线；行内格式
 * @param {string} md - markdown 文本
 * @returns {string} HTML 字符串
 */
function markdownToHtml(md) {
  if (!md || typeof md !== 'string') return '';
  const lines = md.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const out = [];
  let i = 0;
  let listType = null; // 'ul' | 'ol' | null

  function closeList() {
    if (listType) {
      out.push(`</${listType}>`);
      listType = null;
    }
  }

  while (i < lines.length) {
    const line = lines[i];

    // 代码块（v5.7：识别 mermaid / ascii / text，分别特殊处理）
    const codeBlockMatch = line.trim().match(/^```(\w*)/);
    if (codeBlockMatch) {
      closeList();
      const lang = codeBlockMatch[1] || '';
      const codeLines = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i].trim())) {
        codeLines.push(lines[i]);
        i++;
      }
      i++; // 跳过结束 ```
      const rawCode = codeLines.join('\n');

      if (lang === 'mermaid') {
        // v5.7：Mermaid 代码块转为 <div class="mermaid">，不转义（mermaid.js 自行解析）
        out.push(`<div class="mermaid">${rawCode}</div>`);
      } else if (lang === 'ascii' || lang === 'text') {
        // v5.7：ASCII 流程图保留 --> 等箭头字符（不转义 < > &）
        // 仅转义可能引起 HTML 解析问题的字符，但保留 ASCII 字符画的可读性
        // 使用 <pre class="ascii-flow"> + 白空格保留
        const safeCode = rawCode
          .replace(/&/g, '&amp;')   // & 必须最先转义
          .replace(/</g, '&lt;')    // < 转义避免被识别为标签
          .replace(/>/g, '&gt;');   // > 转义保持一致性（HTML 规范要求）
        // 注意：> 转义为 &gt; 后浏览器渲染仍显示为 >，不影响 ASCII 箭头视觉效果
        out.push(`<pre class="ascii-flow"><code>${safeCode}</code></pre>`);
      } else {
        // 普通代码块：完整转义
        out.push(`<pre><code${lang ? ` class="language-${esc(lang)}"` : ''}>${esc(rawCode)}</code></pre>`);
      }
      continue;
    }

    // 空行
    if (line.trim() === '') {
      closeList();
      i++;
      continue;
    }

    // 标题 # ## ### #### #####
    const hMatch = line.match(/^(#{1,5})\s+(.+)$/);
    if (hMatch) {
      closeList();
      const level = hMatch[1].length;
      out.push(`<h${level}>${applyInlineMarkdown(esc(hMatch[2]))}</h${level}>`);
      i++;
      continue;
    }

    // 分割线 ---
    if (/^---+\s*$/.test(line)) {
      closeList();
      out.push('<hr>');
      i++;
      continue;
    }

    // 表格 |...|...|
    if (/^\|/.test(line.trim())) {
      closeList();
      const tableRows = [];
      while (i < lines.length && /^\|/.test(lines[i].trim())) {
        tableRows.push(lines[i].trim());
        i++;
      }
      if (tableRows.length >= 2) {
        // 解析表头
        const headers = tableRows[0].split('|').slice(1, -1).map(s => s.trim());
        // 跳过分隔行 |---|---|
        const bodyRows = tableRows.slice(1).filter(r => !/^\|[\s-:|]+\|$/.test(r));
        out.push('<table><thead><tr>');
        for (const h of headers) out.push(`<th>${applyInlineMarkdown(esc(h))}</th>`);
        out.push('</tr></thead><tbody>');
        for (const r of bodyRows) {
          const cells = r.split('|').slice(1, -1).map(s => s.trim());
          out.push('<tr>');
          for (const c of cells) out.push(`<td>${applyInlineMarkdown(esc(c))}</td>`);
          out.push('</tr>');
        }
        out.push('</tbody></table>');
      }
      continue;
    }

    // 引用块 >
    if (/^>\s?/.test(line.trim())) {
      closeList();
      const quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i].trim())) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, ''));
        i++;
      }
      out.push(`<blockquote>${applyInlineMarkdown(esc(quoteLines.join(' ')))}</blockquote>`);
      continue;
    }

    // 无序列表 - 或 *
    const ulMatch = line.match(/^(\s*)[-*]\s+(.+)$/);
    if (ulMatch) {
      if (listType !== 'ul') {
        closeList();
        out.push('<ul>');
        listType = 'ul';
      }
      out.push(`<li>${applyInlineMarkdown(esc(ulMatch[2]))}</li>`);
      i++;
      continue;
    }

    // 有序列表 1. 2. 3.
    const olMatch = line.match(/^(\s*)\d+\.\s+(.+)$/);
    if (olMatch) {
      if (listType !== 'ol') {
        closeList();
        out.push('<ol>');
        listType = 'ol';
      }
      out.push(`<li>${applyInlineMarkdown(esc(olMatch[2]))}</li>`);
      i++;
      continue;
    }

    // 段落（连续非空行合并）
    closeList();
    const paraLines = [];
    while (i < lines.length &&
      lines[i].trim() !== '' &&
      !/^(#{1,5}\s|---+\s*$|```|>|[-*]\s|\d+\.\s|\|)/.test(lines[i].trim())) {
      paraLines.push(lines[i].trim());
      i++;
    }
    if (paraLines.length > 0) {
      out.push(`<p>${applyInlineMarkdown(esc(paraLines.join(' ')))}</p>`);
    } else {
      // v5.18 P0-B1：防死循环守卫——一轮无进展则强制前进
      i++;
    }
  }
  closeList();
  return out.join('\n');
}

// ============================================================================
// S2: Markdown 段落提取（按 ## 标题分块）
// ============================================================================

/**
 * 从 markdown 文件提取指定 ## 段落内容
 * @param {string} filePath - markdown 文件绝对路径
 * @param {string} sectionTitle - 段落标题（不含 ## 前缀，如 "业务背景"）
 * @returns {string} 段落内容（不含标题行，含子内容；如不存在返回空字符串）
 *
 * v5.7 提取规则变更：
 *   - 从 `## sectionTitle` 行之后开始
 *   - 仅在遇到下一个 `## ` 二级标题时结束
 *   - **不再因 `---` 分割线结束**（修复 v5.6 的 Q3 问题：
 *     04-business-flow.md 含多个 `---` 分隔的子段落，原逻辑遇 `---` 即结束，
 *     导致 Task Flow / Data Flow / Page Flow / 分支流程 / 异常流程 / 状态流转 等段落无法提取）
 *   - 跳过 `>` 引用块开头（如模板说明）
 */
function extractMarkdownSection(filePath, sectionTitle) {
  if (!filePath || !sectionTitle) return '';
  if (!fs.existsSync(filePath)) return '';
  const text = fs.readFileSync(filePath, { encoding: 'utf-8' });
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

  let inSection = false;
  let content = [];
  // v5.10 修复：改为前缀匹配，支持 v5.10 标题含业界标准后缀
  //   例：调用参数 'Task Flow（任务流）' 可匹配实际标题 'Task Flow（任务流，BPMN 2.0）'
  //   原正则 `^##\s+sectionTitle\s*$` 要求标题精确匹配，v5.10 三大 Flow 标题含 ", BPMN 2.0" 等后缀导致匹配失败
  // v5.10.1 修复：原 v5.10 正则虽含 .*$ 但因 sectionTitle 含 ） 与源标题 ，XXX） 位置字符不一致导致匹配失败
  //   根因：'Task Flow（任务流）' 中的 ） 与 'Task Flow（任务流，BPMN 2.0）' 中的 ， 位置不一致
  //   修复：将 sectionTitle 中的 （...） 全角括号内容替换为 （[^）]*） 通配符，真正实现"逻辑前缀"匹配
  //   兼容性：无全角括号的 sectionTitle（如 '业务背景'）不受影响；ASCII 括号场景（如 '产品目标 \(OKR\)'）走原有 fallback
  //   注意：不使用 \b 是因为 \b 在中文全角括号 ）后不生效（\b 仅在 ASCII 单词字符边界生效）
  const escapedTitle = sectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wildcardTitle = escapedTitle.replace(/（[^）]*）/g, '（[^）]*）');
  const headingRegex = new RegExp('^##\\s+' + wildcardTitle + '.*$');

  for (const line of lines) {
    if (headingRegex.test(line.trim())) {
      inSection = true;
      continue;
    }
    if (inSection) {
      // v5.7 修复：仅在遇到下一个 ## 二级标题时结束，不再因 --- 结束
      if (/^##\s+/.test(line.trim())) break;
      content.push(line);
    }
  }

  // 移除开头的空行和引用块
  let result = content.join('\n').trim();
  // 移除开头引用块（> ...）
  result = result.replace(/^>.*(\n|$)/, '').trim();
  return result;
}

/**
 * 读取 markdown 文件全文（用于 PM 原始需求展示）
 * @param {string} filePath - markdown 文件绝对路径
 * @returns {string} 文件内容（如不存在返回空字符串）
 */
function readMarkdownFile(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return '';
  return fs.readFileSync(filePath, { encoding: 'utf-8' });
}

/**
 * v5.7 新增：从 markdown 文件提取指定 ### 三级子标题段落内容
 * 用于提取 01-background.md 中"### 范围外"等三级子段落（Non-Goals 数据源）
 *
 * @param {string} filePath - markdown 文件绝对路径
 * @param {string} sectionTitle - 二级标题（不含 ## 前缀，如 "范围与约束"）
 * @param {string} subsectionTitle - 三级标题（不含 ### 前缀，如 "范围外"）
 * @returns {string} 子段落内容（不含标题行）；如不存在返回空字符串
 *
 * 提取规则：
 *   - 先定位 `## sectionTitle` 段落
 *   - 在该段落内查找 `### subsectionTitle` 行
 *   - 从该行之后开始，直到遇到下一个 `### ` 或 `## ` 标题时结束
 */
function extractMarkdownSubsection(filePath, sectionTitle, subsectionTitle) {
  if (!filePath || !sectionTitle || !subsectionTitle) return '';
  if (!fs.existsSync(filePath)) return '';
  const text = fs.readFileSync(filePath, { encoding: 'utf-8' });
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');

  // 先定位 ## sectionTitle
  const sectionRegex = new RegExp('^##\\s+' + sectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$');
  let inSection = false;
  let inSubsection = false;
  const content = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (sectionRegex.test(trimmed)) {
      inSection = true;
      continue;
    }
    if (inSection) {
      // 遇到下一个 ## 标题，结束 section
      if (/^##\s+/.test(trimmed)) break;
      // 查找 ### subsectionTitle
      const subRegex = new RegExp('^###\\s+' + subsectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$');
      if (subRegex.test(trimmed)) {
        inSubsection = true;
        continue;
      }
      if (inSubsection) {
        // 遇到下一个 ### 或 ## 标题，结束 subsection
        if (/^(?:##|###)\s+/.test(trimmed)) break;
        content.push(line);
      }
    }
  }

  return content.join('\n').trim();
}

// ============================================================================
// CSS 样式（v5.6 增强：单页 PRD 锚点导航 + 折叠面板 + 叙事排版）
// ============================================================================

function genCss() {
  return `
  :root {
    --color-bg: #070708;
    --color-surface: #0A0A0A;
    --color-surface-hover: #111114;
    --color-text: #F5F5F7;
    --color-text-muted: #A1A1AA;
    --color-text-dim: #71717A;
    --color-border: #1A1A1F;
    --color-border-light: #27272A;
    --color-accent: #14B8A6;
    --color-accent-dim: rgba(20, 184, 166, 0.15);
    --font-body: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Noto Sans SC", sans-serif;
    --font-mono: "JetBrains Mono", "SF Mono", Consolas, monospace;
    --radius-sm: 8px;
    --radius-md: 12px;
    --radius-lg: 20px;
  }
  /* v5.13.4: 浅色主题 — 白底 + #14B8A6 强调色（与深色同色系，IP 协调） */
  [data-theme="light"] {
    --color-bg: #FFFFFF;
    --color-surface: #FAFAFA;
    --color-surface-hover: #F4F4F5;
    --color-text: #18181B;
    --color-text-muted: #52525B;
    --color-text-dim: #A1A1AA;
    --color-border: #E4E4E7;
    --color-border-light: #D4D4D8;
    --color-accent: #14B8A6;
    --color-accent-dim: rgba(20, 184, 166, 0.12);
  }
  /* v5.13.4: 主题切换按钮 */
  .theme-toggle {
    position: fixed;
    top: 16px;
    right: 20px;
    z-index: 200;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 1px solid var(--color-border-light);
    background: var(--color-surface);
    color: var(--color-text);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    transition: all 0.2s;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }
  .theme-toggle:hover {
    border-color: var(--color-accent);
    color: var(--color-accent);
    transform: scale(1.05);
  }
  [data-theme="light"] .theme-toggle { box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html { font-size: 16px; -webkit-font-smoothing: antialiased; scroll-behavior: smooth; }
  body {
    font-family: var(--font-body);
    background: var(--color-bg);
    color: var(--color-text);
    line-height: 1.7;
    min-height: 100vh;
    padding: 0;
  }
  .container { max-width: 1100px; margin: 0 auto; padding: 40px 20px 80px; }
  .header { text-align: center; margin-bottom: 48px; padding: 40px 0 24px; border-bottom: 1px solid var(--color-border); }
  .header h1 { font-size: 36px; font-weight: 700; color: var(--color-text); margin-bottom: 12px; }
  .header .subtitle { font-size: 16px; color: var(--color-text-muted); max-width: 720px; margin: 0 auto 12px; }
  .header .badge { display: inline-block; padding: 4px 12px; background: var(--color-accent-dim); color: var(--color-accent); border-radius: 99px; font-size: 13px; font-weight: 500; }
  /* 锚点导航栏（sticky） */
  .anchor-nav {
    position: sticky;
    top: 0;
    z-index: 100;
    background: var(--color-surface);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    border-bottom: 1px solid var(--color-border);
    padding: 12px 20px;
    margin: 0 -20px 40px;
  }
  .anchor-nav-inner { max-width: 1100px; margin: 0 auto; display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; }
  .anchor-nav a {
    display: inline-block;
    padding: 6px 14px;
    color: var(--color-text-muted);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    border-radius: 99px;
    border: 1px solid var(--color-border);
    transition: all 0.2s;
  }
  .anchor-nav a:hover { color: var(--color-accent); border-color: var(--color-accent); background: var(--color-accent-dim); }
  /* v5.13.8: 顶部导航栏 scroll spy 高亮当前章节 */
  .anchor-nav a.active { color: var(--color-accent); border-color: var(--color-accent); background: var(--color-accent-dim); font-weight: 600; }
  /* 章节 */
  section { margin-bottom: 56px; scroll-margin-top: 80px; }
  section h2 {
    font-size: 24px; font-weight: 700; color: var(--color-accent);
    margin-bottom: 20px; padding-bottom: 10px;
    border-bottom: 1px solid var(--color-border);
    display: flex; align-items: center; gap: 12px;
  }
  section h2 .section-num {
    display: inline-flex; align-items: center; justify-content: center;
    width: 32px; height: 32px; border-radius: 50%;
    background: var(--color-accent-dim); color: var(--color-accent);
    font-size: 14px; font-weight: 700;
  }
  section h3 { font-size: 18px; font-weight: 600; color: var(--color-text); margin: 28px 0 12px; }
  section h4 { font-size: 15px; font-weight: 600; color: var(--color-text); margin: 20px 0 8px; }
  section p { color: var(--color-text-muted); margin-bottom: 12px; }
  section ul, section ol { padding-left: 24px; margin-bottom: 16px; color: var(--color-text-muted); }
  section li { margin-bottom: 6px; }
  section strong { color: var(--color-text); }
  section blockquote {
    border-left: 3px solid var(--color-accent);
    padding: 12px 20px;
    margin: 16px 0;
    background: var(--color-surface);
    border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
    color: var(--color-text-muted);
  }
  section hr { border: none; border-top: 1px solid var(--color-border); margin: 24px 0; }
  section pre {
    background: var(--color-surface); border: 1px solid var(--color-border);
    border-radius: var(--radius-sm); padding: 16px;
    overflow-x: auto; margin: 16px 0;
  }
  section pre code { background: none; padding: 0; color: var(--color-text); font-size: 13px; }
  section table { width: 100%; border-collapse: collapse; margin: 16px 0; }
  section th, section td { padding: 10px 14px; text-align: left; border-bottom: 1px solid var(--color-border); font-size: 14px; }
  section th { color: var(--color-accent); font-weight: 600; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }
  section td { color: var(--color-text-muted); }
  section tr:hover td { color: var(--color-text); }
  code { background: var(--color-surface); padding: 2px 6px; border-radius: 4px; font-family: var(--font-mono); font-size: 13px; color: var(--color-accent); }
  a { color: var(--color-accent); text-decoration: none; }
  a:hover { text-decoration: underline; }
  .card { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-md); padding: 24px; margin-bottom: 16px; }
  .card:hover { background: var(--color-surface-hover); }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; }
  .tag { display: inline-block; padding: 2px 8px; background: var(--color-accent-dim); color: var(--color-accent); border-radius: 99px; font-size: 12px; font-weight: 500; margin-right: 4px; }
  .field-list { list-style: none; padding: 0; }
  .field-list li { padding: 8px 0; border-bottom: 1px solid var(--color-border); display: flex; justify-content: space-between; align-items: center; }
  .field-list li:last-child { border-bottom: none; }
  .field-name { font-family: var(--font-mono); color: var(--color-accent); font-size: 14px; }
  .field-type { color: var(--color-text-dim); font-size: 13px; }
  .field-desc { color: var(--color-text-muted); font-size: 14px; }
  /* 叙事段落（业务背景/痛点/解决方案等） */
  .narrative { background: var(--color-surface); border-left: 3px solid var(--color-accent); padding: 16px 20px; margin: 16px 0; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
  .narrative h4 { color: var(--color-accent); font-size: 14px; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 1px; }
  .narrative p, .narrative ul, .narrative ol { color: var(--color-text-muted); font-size: 14px; }
  /* 折叠面板（PM 原始需求等）— v5.13.4: 突出可展开感知 */
  details {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-md);
    padding: 0;
    margin: 16px 0;
    overflow: hidden;
    transition: border-color 0.2s, box-shadow 0.2s;
  }
  details:hover {
    border-color: var(--color-accent);
    box-shadow: 0 2px 8px rgba(20, 184, 166, 0.12);
  }
  details summary {
    padding: 16px 20px 16px 24px;
    cursor: pointer;
    font-weight: 600;
    color: var(--color-text);
    background: var(--color-surface-hover);
    list-style: none;
    display: flex; align-items: center; justify-content: space-between;
    user-select: none;
    position: relative;
    transition: background 0.2s, padding-left 0.2s;
  }
  /* v5.13.4: 左侧色条 — 默认 3px，hover 时变粗 */
  details summary::before {
    content: "";
    position: absolute;
    left: 0; top: 0; bottom: 0;
    width: 3px;
    background: var(--color-accent);
    opacity: 0.4;
    transition: width 0.2s, opacity 0.2s;
  }
  details summary:hover::before { width: 5px; opacity: 1; }
  details summary:hover {
    background: var(--color-accent-dim);
    padding-left: 28px;
  }
  details summary::-webkit-details-marker { display: none; }
  /* v5.13.4: 箭头图标替代 +/-，旋转动画 */
  details summary::after {
    content: "▶";
    font-size: 12px;
    color: var(--color-accent);
    font-weight: 700;
    transition: transform 0.2s;
    display: inline-block;
  }
  details[open] summary::after { transform: rotate(90deg); }
  details .details-content { padding: 20px; border-top: 1px solid var(--color-border); }
  details .details-content h1, details .details-content h2, details .details-content h3 { color: var(--color-text); margin: 16px 0 8px; }
  details .details-content h1 { font-size: 20px; }
  details .details-content h2 { font-size: 17px; color: var(--color-accent); }
  details .details-content h3 { font-size: 15px; }
  /* 元数据网格 */
  .meta-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; }
  .meta-item { background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-sm); padding: 16px; }
  .meta-label { font-size: 11px; font-weight: 600; color: var(--color-text-dim); letter-spacing: 1.5px; text-transform: uppercase; margin-bottom: 6px; }
  .meta-value { font-size: 15px; font-weight: 500; color: var(--color-text); }
  /* 下载链接卡片 */
  .download-links { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; margin-top: 16px; }
  .download-link { display: block; padding: 16px; background: var(--color-surface); border: 1px solid var(--color-border); border-radius: var(--radius-sm); text-decoration: none; color: var(--color-text); transition: all 0.2s; }
  .download-link:hover { border-color: var(--color-accent); background: var(--color-surface-hover); }
  .download-link-title { font-size: 14px; font-weight: 600; color: var(--color-accent); margin-bottom: 4px; }
  .download-link-desc { font-size: 12px; color: var(--color-text-muted); }
  /* 页面规格折叠面板（每页一个） */
  .page-spec { margin-bottom: 16px; }
  .page-spec summary { padding: 14px 20px; }
  .page-spec .details-content { padding: 16px 20px; }
  .annotation-block { background: var(--color-bg); border-left: 3px solid var(--color-accent); padding: 12px 16px; margin: 10px 0; border-radius: 0 var(--radius-sm) var(--radius-sm) 0; }
  .annotation-block h4 { color: var(--color-accent); font-size: 13px; margin-bottom: 6px; }
  .annotation-block p { color: var(--color-text-muted); font-size: 13px; margin: 0; }
  /* 提示框 */
  .tip-box {
    display: flex; gap: 12px; padding: 16px 20px;
    background: var(--color-accent-dim); border: 1px solid rgba(20, 184, 166, 0.25);
    border-radius: var(--radius-sm); margin-top: 24px;
  }
  .tip-box-icon { font-size: 16px; color: var(--color-accent); font-weight: 700; flex-shrink: 0; }
  .tip-box-content { font-size: 13px; line-height: 1.7; color: var(--color-text-muted); }
  .tip-box-content strong { color: var(--color-text); }
  /* 页脚（v5.9: Ourchem × Demora 联合版权） */
  /* v5.13.6: footer 始终深色底色（不随主题切换），确保 Ourchem 纯白 logo 可见 */
  .footer {
    text-align: center;
    padding: 40px 20px 32px;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    margin-top: 56px;
    color: rgba(255, 255, 255, 0.5);
    font-size: 13px;
    background: #0a0e14;
  }
  .footer-coop {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
    margin-bottom: 16px;
  }
  .footer-brand-logo {
    display: flex;
    align-items: center;
    height: 28px;
  }
  .footer-brand-ourchem svg {
    height: 28px;
    width: auto;
    /* v5.10: 改用奥凯logo-长-白.svg 纯白版本，无需 filter 转色 */
    opacity: 0.95;
  }
  .footer-brand-demora svg {
    height: 24px;
    width: auto;
  }
  .footer-coop-x {
    font-size: 18px;
    font-weight: 300;
    color: rgba(255, 255, 255, 0.4);
    user-select: none;
  }
  .footer-copyright {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.5);
    line-height: 1.7;
    margin: 0;
  }
  .footer-copyright .footer-meta {
    display: inline-block;
    margin-top: 4px;
    font-family: var(--font-mono);
    font-size: 11px;
    opacity: 0.75;
  }
  @media (max-width: 768px) {
    .footer { padding: 32px 20px 24px; }
    .footer-coop { gap: 12px; }
    .footer-brand-ourchem svg, .footer-brand-demora svg { height: 22px; }
    .footer-coop-x { font-size: 16px; }
  }
  /* v5.7: Mermaid 流程图样式 */
  .mermaid {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: 16px;
    margin: 16px 0;
    text-align: center;
    overflow: auto;
    max-height: 480px;
    /* v5.19 P2-4: 容器可点击放大（配合 mermaid-init.js 的 dialog 放大机制） */
    cursor: zoom-in;
  }
  /* v5.19 P2-4: 图表放大 — svg 硬上限 420px → 720px，大图（如 2583×1364 的 DFD）不再被过度压缩 */
  .mermaid svg { max-width: 100%; max-height: 720px; height: auto; width: auto; }
  /* v5.7: Mermaid 加载失败时的兜底样式 */
  .mermaid-fallback {
    background: var(--color-surface);
    border: 1px dashed var(--color-border);
    border-radius: var(--radius-sm);
    padding: 16px;
    margin: 16px 0;
    font-family: var(--font-mono, 'Cascadia Code', Consolas, monospace);
    font-size: 13px;
    color: var(--color-text-muted);
    white-space: pre;
    overflow-x: auto;
  }
  /* v5.7: ASCII 流程图样式 */
  .ascii-flow {
    background: var(--color-surface);
    border: 1px solid var(--color-border);
    border-radius: var(--radius-sm);
    padding: 16px;
    margin: 16px 0;
    font-family: var(--font-mono, 'Cascadia Code', Consolas, monospace);
    font-size: 13px;
    color: var(--color-accent);
    white-space: pre;
    overflow-x: auto;
    line-height: 1.4;
  }
  /* v5.7: 受众视图 Tab */
  .audience-tabs {
    display: flex; gap: 4px; padding: 8px 24px;
    background: var(--color-surface); border-bottom: 1px solid var(--color-border);
    position: sticky; top: 0; z-index: 100;
  }
  .tab-btn {
    padding: 6px 16px; background: transparent;
    border: 1px solid var(--color-border); border-radius: var(--radius-sm);
    color: var(--color-text-muted); font-size: 13px; cursor: pointer;
    transition: all 0.2s;
  }
  .tab-btn:hover { color: var(--color-text); border-color: var(--color-accent); }
  .tab-btn.active {
    background: var(--color-accent); color: white; border-color: var(--color-accent);
  }
  /* v5.7: 受众视图切换 CSS（默认全部显示，Tab 切换时隐藏非目标受众） */
  section[data-audience] { display: block; }
  body.audience-dev section[data-audience]:not([data-audience*="dev"]) { display: none; }
  body.audience-pm section[data-audience]:not([data-audience*="pm"]) { display: none; }
  /* v5.7: 打印时显示所有受众内容 */
  @media print {
    section[data-audience] { display: block !important; }
    .audience-tabs { display: none; }
  }
  /* v5.7: TL;DR / Non-Goals 样式 */
  .tldr-box {
    background: var(--color-accent-dim); border: 1px solid rgba(20, 184, 166, 0.3);
    border-radius: var(--radius-sm); padding: 20px 24px; margin: 24px 0;
  }
  .tldr-box h3 { color: var(--color-accent); margin-bottom: 12px; }
  .tldr-box ul { margin: 0; padding-left: 20px; }
  .tldr-box li { margin: 6px 0; color: var(--color-text); font-size: 14px; line-height: 1.7; }
  .non-goals-box {
    background: var(--color-surface); border-left: 3px solid #F59E0B;
    padding: 16px 20px; margin: 16px 0; border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
  }
  .non-goals-box h3 { color: #F59E0B; margin-bottom: 8px; }
  .non-goals-box ul { margin: 0; padding-left: 20px; }
  .non-goals-box li { color: var(--color-text-muted); font-size: 13px; line-height: 1.7; }
  /* v5.7: 版本信息 */
  .version-info {
    display: flex; gap: 16px; padding: 8px 24px;
    background: var(--color-bg); border-bottom: 1px solid var(--color-border);
    font-size: 12px; color: var(--color-text-dim);
  }
  /* v5.13.8: 左侧目录导航布局 */
  .docs-layout {
    display: grid;
    grid-template-columns: 220px 1fr;
    gap: 32px;
    align-items: start;
  }
  .toc-sidebar {
    position: sticky;
    top: 80px;
    max-height: calc(100vh - 100px);
    overflow-y: auto;
    padding: 16px 0;
    border-right: 1px solid var(--color-border);
  }
  .toc-sidebar h4 {
    font-size: 12px;
    color: var(--color-text-muted);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 12px;
    padding-left: 12px;
  }
  .toc-sidebar ul { list-style: none; padding: 0; margin: 0; }
  .toc-sidebar li { margin: 0; }
  .toc-sidebar a {
    display: block;
    padding: 6px 12px;
    color: var(--color-text-muted);
    text-decoration: none;
    font-size: 13px;
    border-left: 2px solid transparent;
    transition: all 0.2s;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .toc-sidebar a:hover { color: var(--color-text); background: var(--color-surface); }
  .toc-sidebar a.active {
    color: var(--color-accent);
    border-left-color: var(--color-accent);
    background: var(--color-accent-dim);
    font-weight: 600;
  }
  .main-content { min-width: 0; }
  /* 响应式 */
  @media (max-width: 768px) {
    .container { padding: 24px 16px 60px; }
    .header h1 { font-size: 26px; }
    .anchor-nav { margin: 0 -16px 32px; padding: 10px 16px; }
    .anchor-nav a { font-size: 12px; padding: 4px 10px; }
    .grid { grid-template-columns: 1fr; }
    .meta-grid { grid-template-columns: 1fr 1fr; }
    .download-links { grid-template-columns: 1fr; }
  }
  @media (max-width: 1024px) {
    .docs-layout { grid-template-columns: 1fr; }
    .toc-sidebar { display: none; }
  }
  `;
}

// ============================================================================
// S3: 单页 PRD 生成器（10 章节）
// ============================================================================

/**
 * 生成 HTML 文档头部
 * v5.7 新增：引入 mermaid.min.js + mermaid-init.js 用于流程图渲染
 */
function genHtmlHead(title, projectName) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(title)} - ${esc(projectName)} 产品文档</title>
<style>${genCss()}</style>
<!-- v5.7: Mermaid 流程图渲染（离线打包，无外部依赖） -->
<script src="assets/mermaid/mermaid.min.js"></script>
<script src="assets/mermaid/mermaid-init.js"></script>
</head>
<body>
<button class="theme-toggle" id="themeToggle" title="切换深色/浅色主题" aria-label="切换主题">🌙</button>
<div class="container">
<div class="docs-layout">
<aside class="toc-sidebar" id="tocSidebar"></aside>
<main class="main-content">
`;
}

/**
 * 生成 HTML 文档尾部
 */
function genHtmlFooter() {
  return `
</main>
</div>
<script>
(function(){
  var btn = document.getElementById('themeToggle');
  if (!btn) return;
  // 读取 localStorage 主题偏好，默认深色
  var saved = localStorage.getItem('demora-theme') || 'dark';
  if (saved === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
    btn.textContent = '☀';
  }
  btn.addEventListener('click', function(){
    var isLight = document.documentElement.getAttribute('data-theme') === 'light';
    if (isLight) {
      document.documentElement.removeAttribute('data-theme');
      btn.textContent = '🌙';
      localStorage.setItem('demora-theme', 'dark');
    } else {
      document.documentElement.setAttribute('data-theme', 'light');
      btn.textContent = '☀';
      localStorage.setItem('demora-theme', 'light');
    }
  });
  // v5.13.7: 监听其他页面的主题变更（跨标签页同步）
  window.addEventListener('storage', function(e) {
    if (e.key === 'demora-theme') {
      if (e.newValue === 'light') {
        document.documentElement.setAttribute('data-theme', 'light');
        btn.textContent = '☀';
      } else {
        document.documentElement.removeAttribute('data-theme');
        btn.textContent = '🌙';
      }
    }
  });
})();

// v5.13.8: 左侧 TOC 动态生成 + 顶部导航栏 scroll spy
(function() {
  var sections = document.querySelectorAll('.main-content section[id]');
  var navLinks = document.querySelectorAll('.anchor-nav a[href^="#"]');
  var sidebar = document.getElementById('tocSidebar');

  // 生成左侧 TOC
  if (sidebar && sections.length) {
    var html = '<h4>目录</h4><ul>';
    sections.forEach(function(s) {
      var id = s.getAttribute('id');
      var h2 = s.querySelector('h2');
      var label = h2 ? h2.textContent.trim() : id;
      html += '<li><a href="#' + id + '" data-toc-target="' + id + '">' + label + '</a></li>';
    });
    html += '</ul>';
    sidebar.innerHTML = html;
    // v5.20.2（UAT 四轮 U-A）：TOC 生成后立即应用当前受众过滤——
    //   localStorage 恢复偏好的联动先于本 IIFE 执行（时序漏洞），此处补一次同步，
    //   确保 PM/研发视图下左侧 TOC 不显示隐藏章节链接
    if (typeof window.__demoraSyncTocAudience === 'function') {
      window.__demoraSyncTocAudience();
    }
  }

  // scroll spy: 高亮当前可见章节对应的导航项 + TOC 项
  if (!sections.length) return;
  var tocLinks = sidebar ? sidebar.querySelectorAll('a[data-toc-target]') : [];

  var observer = new IntersectionObserver(function(entries) {
    entries.forEach(function(entry) {
      if (entry.isIntersecting) {
        var id = entry.target.getAttribute('id');
        navLinks.forEach(function(link) {
          link.classList.toggle('active', link.getAttribute('href') === '#' + id);
        });
        tocLinks.forEach(function(link) {
          link.classList.toggle('active', link.getAttribute('data-toc-target') === id);
        });
      }
    });
  }, { rootMargin: '-80px 0px -70% 0px' });

  sections.forEach(function(s) { observer.observe(s); });
})();
</script>
</body>
</html>
`;
}

/**
 * 生成锚点导航栏
 * v5.8：从 14 锚点精简到 8 锚点 — 聚焦 PM/业务方关心的章节
 * 移除的锚点（章节仍在 body，只是不在主导航显示）：
 *   - non-goals（合并到业务背景章节概念上，PM 可在 §2 内查看）
 *   - pages / data / roles（dev/test 专属，PM 默认隐藏，不进主显眼导航）
 *   - pm-requirement（PM 专属，dev/test 隐藏，且属于原始资料非主流程导航）
 *   - downloads（v5.8 已移除，下载入口移至页脚）
 */
function genAnchorNav() {
  // v5.9：移除项目元数据/解决方案锚点，TL;DR 改名为"摘要"
  // v5.19 P2-7：原"业务流程"锚点拆分为"流程视图"（#business-flow 保留旧锚点兼容）+ "业务过程"
  // v5.19 P0-2：新增"研发文档"锚点（dev 视图专属章节）
  // v5.20 P2-2（U17）：章节 4↔5 对调并更名——新 4 业务流程（主/分支/异常/状态流转，#business-process）、
  //   新 5 产品流程（任务/数据/页面流，#business-flow）；认知次序：现有业务流程 → 规划设计产品流程。
  //   锚点 id 维持不变（避免外部引用断裂，语义由章名承载）
  const anchors = [
    { id: 'tldr', label: '摘要' },
    { id: 'problem', label: '业务背景' },
    { id: 'users', label: '目标用户' },
    { id: 'business-process', label: '业务流程' },
    { id: 'business-flow', label: '产品流程' },
    { id: 'metrics', label: '指标时间线' },
    { id: 'scope', label: '范围风险' },
    { id: 'dev-docs', label: '研发文档' },
  ];
  const links = anchors.map(a => `<a href="#${a.id}">${esc(a.label)}</a>`).join('\n    ');
  return `
<nav class="anchor-nav">
  <div class="anchor-nav-inner">
    ${links}
  </div>
</nav>
`;
}

/**
 * v5.7 新增 §0 TL;DR（一页纸摘要）
 * 数据源（按优先级）：
 *   1. docs/prd/00-overview.md 的 "TL;DR（一页纸摘要）" 段落
 *   2. 兜底：从 01-background.md 拼装业务背景 + 解决方案 + 业务目标前 200 字
 *
 * 业界对标：Lenny's Newsletter "1-Pager" / Notion "TL;DR" 模板
 */
function genSectionTldr(root, model) {
  const overviewFile = path.join(root, 'docs', 'prd', '00-overview.md');
  const bgFile = path.join(root, 'docs', 'prd', '01-background.md');
  const project = model.project || { name: 'Demo', description: '' };

  // 优先从 00-overview.md 提取 TL;DR 段落
  let tldrMd = extractMarkdownSection(overviewFile, 'TL;DR（一页纸摘要）') ||
               extractMarkdownSection(overviewFile, 'TL;DR');

  // v5.8 兜底：从 01-background.md 拼装 — 必须保持 markdown 块级结构
  // 修复 PM 反馈"渲染问题：项目摘要部分内容渲染异常"
  // 旧逻辑把表格多行压成单行，导致 markdownToHtml 识别为段落而非表格
  if (!tldrMd) {
    const businessBg = extractMarkdownSection(bgFile, '业务背景');
    const painPoints = extractMarkdownSection(bgFile, '核心痛点');
    const solution = extractMarkdownSection(bgFile, '解决方案');
    const okrSection = extractMarkdownSection(bgFile, '产品目标 (OKR 格式)');

    const parts = [];
    if (project.description) {
      parts.push(`**项目定位**：${project.description}`);
    }
    if (businessBg) {
      // 仅取首段（按空行分割），换行替换为空格，截断 150 字符
      const firstPara = businessBg.split(/\n\s*\n/)[0].replace(/\n/g, ' ').trim();
      parts.push(`**业务背景**：${firstPara.length > 150 ? firstPara.slice(0, 150) + '...' : firstPara}`);
    }
    if (painPoints) {
      // 仅保留前 3 个列表项（按编号或项目符号）
      const bullets = painPoints.split('\n')
        .filter(l => /^\s*(\d+\.|[-*])\s/.test(l))
        .slice(0, 3)
        .map(l => l.trim().replace(/^\d+\.\s/, '- ').replace(/^[-*]\s/, '- '));
      if (bullets.length > 0) parts.push(`**核心痛点**：\n${bullets.join('\n')}`);
    }
    if (solution) {
      // 取引言段（非列表项的首行）+ 前 3 个项目符号
      const lines = solution.split('\n');
      const intro = lines.find(l => {
        const t = l.trim();
        return t && !/^[-*]\s/.test(t) && !/^\d+\./.test(t) && !/^---+\s*$/.test(t);
      });
      const bullets = lines.filter(l => /^\s*[-*]\s/.test(l)).slice(0, 3).map(l => l.trim());
      const solParts = [];
      if (intro) solParts.push(intro.trim());
      if (bullets.length > 0) solParts.push(bullets.join('\n'));
      if (solParts.length > 0) parts.push(`**解决方案**：${solParts.join('\n\n')}`);
    }
    if (okrSection) {
      // 提取 Objective 行（避免引入 KR 表格）
      const m = okrSection.match(/\*\*Objective\*\*[:：]\s*(.+)/);
      if (m) parts.push(`**核心目标**：${m[1].trim()}`);
    }
    if (parts.length > 0) {
      tldrMd = parts.join('\n\n');
    }
  }

  let html = `
<section id="tldr" data-audience="pm dev test">
  <h2><span class="section-num">0</span> 摘要</h2>
  <p class="section-hint">让 PM/研发在 30 秒内理解项目本质。</p>
  <div class="tldr-box">
    <h3>项目摘要</h3>
`;
  if (tldrMd) {
    html += markdownToHtml(tldrMd);
  } else {
    html += `<p>暂无摘要数据。请在 <code>docs/prd/00-overview.md</code> 的 "TL;DR（一页纸摘要）" 段落中补充 3-5 行项目摘要，包括：项目定位、核心价值、关键功能、目标用户、关键约束。</p>`;
  }
  html += `
  </div>
</section>
`;
  return html;
}

/**
 * v5.7 新增 §0.5 版本信息
 * 展示文档版本、生成时间、模板版本、对标业界规范
 * v5.9：移除 "Skill 版本" 字段（PM 反馈：去除 skill 相关描述，保留 demora 标识）
 */
function genSectionVersionInfo(generatedAt, skillVersion) {
  return `
<div class="version-info" data-audience="pm dev test">
  <span><strong>文档版本：</strong>v1.0</span>
  <span><strong>生成时间：</strong>${esc(generatedAt)}</span>
  <span><strong>模板版本：</strong>v5.7</span>
  <span><strong>对标：</strong>Lenny's 1-Pager + Notion Ultimate PRD</span>
</div>
`;
}

/**
 * v5.7 新增 §2.5 Non-Goals（明确不做的事）
 * 数据源（按优先级）：
 *   1. docs/prd/00-overview.md 的 "Non-Goals（明确不做的事）" 段落
 *   2. 兜底：01-background.md 的 ## 范围与约束 > ### 范围外
 *
 * 业界对标：Meta/Notion PRD 模板均要求显式声明 Non-Goals 防止范围蔓延
 */
function genSectionNonGoals(root) {
  const overviewFile = path.join(root, 'docs', 'prd', '00-overview.md');
  const bgFile = path.join(root, 'docs', 'prd', '01-background.md');

  // 优先从 00-overview.md 提取 Non-Goals 段落
  let nonGoalsMd = extractMarkdownSection(overviewFile, 'Non-Goals（明确不做的事）') ||
                   extractMarkdownSection(overviewFile, 'Non-Goals');

  // 兜底：从 01-background.md 的 ## 范围与约束 > ### 范围外 提取
  if (!nonGoalsMd) {
    nonGoalsMd = extractMarkdownSubsection(bgFile, '范围与约束', '范围外');
  }

  let html = `
<section id="non-goals" data-audience="pm dev test">
  <h2><span class="section-num">1.5</span> Non-Goals 明确不做的事</h2>
  <p class="section-hint">显式声明不在本期范围内的事项，避免范围蔓延。</p>
  <div class="non-goals-box">
    <h3>本期不实现</h3>
`;
  if (nonGoalsMd) {
    html += markdownToHtml(nonGoalsMd);
  } else {
    html += `<p>暂无 Non-Goals 声明。建议在 <code>docs/prd/00-overview.md</code> 的 "Non-Goals" 段落或 <code>01-background.md</code> 的"范围外"子段落中补充 3-5 项明确不做的事。</p>`;
  }
  html += `
  </div>
</section>
`;
  return html;
}

/**
 * 章节 1：业务背景（Problem + Why It Matters）
 * 数据源：docs/prd/01-background.md 的"业务背景"/"核心痛点"/"解决方案"/"业务目标"段落
 */
function genSectionProblem(root, model) {
  const bgFile = path.join(root, 'docs', 'prd', '01-background.md');
  const businessBg = extractMarkdownSection(bgFile, '业务背景');
  const painPoints = extractMarkdownSection(bgFile, '核心痛点');
  const solution = extractMarkdownSection(bgFile, '解决方案');
  const businessGoals = extractMarkdownSection(bgFile, '业务目标');
  const objectives = extractMarkdownSection(bgFile, '产品目标 \\(OKR 格式\\)') || extractMarkdownSection(bgFile, '产品目标');

  let html = `
<section id="problem" data-audience="pm dev test">
  <h2><span class="section-num">1</span> 业务背景</h2>
  <p>本章节阐述项目的业务背景、核心痛点与解决方案，对标业界 PRD "Problem before solution" 原则。</p>
`;

  if (businessBg) {
    html += `
  <div class="narrative">
    <h4>业务背景</h4>
    ${markdownToHtml(businessBg)}
  </div>`;
  }

  if (painPoints) {
    html += `
  <div class="narrative">
    <h4>核心痛点</h4>
    ${markdownToHtml(painPoints)}
  </div>`;
  }

  if (solution) {
    html += `
  <div class="narrative">
    <h4>解决方案</h4>
    ${markdownToHtml(solution)}
  </div>`;
  }

  if (businessGoals) {
    html += `
  <div class="narrative">
    <h4>业务目标</h4>
    ${markdownToHtml(businessGoals)}
  </div>`;
  }

  if (objectives) {
    html += `
  <div class="narrative">
    <h4>产品目标 (OKR)</h4>
    ${markdownToHtml(objectives)}
  </div>`;
  }

  if (!businessBg && !painPoints && !solution) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>业务背景资料暂未生成（<code>docs/prd/01-background.md</code> 不存在或段落为空）。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * v5.8：从 role.permissions / page_visibility 反推角色描述（兜底空 description）
 * 输出示例："对 行程 全部操作；对 订单 自有读写；可见 4 个页面"
 * 仅当 role.description 为空时使用，避免覆盖作者手工撰写的描述
 *
 * @param {object} role - 角色对象（含 permissions/page_visibility）
 * @param {Array} entities - 实体列表（用于 displayName 查询）
 * @returns {string} 可读描述
 */
function formatRoleDescription(role, entities = []) {
  const parts = [];
  const perms = role.permissions || [];
  if (perms.length > 0) {
    const entMap = new Map(entities.map(e => [e.name, e.displayName || e.name]));
    const scopeMap = { all: '全部', own: '自有', department: '本部门', team: '本团队' };
    const actionMap = {
      create: '创建', read: '查看', update: '编辑', delete: '删除',
      export: '导出', import: '导入', audit: '审计', approve: '审批', share: '分享'
    };
    const permStrs = perms.map(p => {
      const entName = entMap.get(p.entity) || p.entity;
      const actions = (p.actions || []).map(a => actionMap[a] || a);
      const scope = p.scope ? scopeMap[p.scope] || p.scope : null;
      const actStr = actions.length > 0 ? actions.join('、') : '操作';
      return scope ? `对 ${entName} ${scope}${actStr}` : `对 ${entName} ${actStr}`;
    });
    parts.push(permStrs.join('；'));
  }
  const pv = role.page_visibility || [];
  if (pv.length > 0) parts.push(`可见 ${pv.length} 个页面`);
  return parts.length > 0 ? parts.join('；') : '权限配置见下方矩阵';
}

/**
 * 章节 3：目标用户
 * 数据源：docs/prd/02-target-audience.md + YAML roles
 */
function genSectionUsers(root, model) {
  const audienceFile = path.join(root, 'docs', 'prd', '02-target-audience.md');
  const userGroups = extractMarkdownSection(audienceFile, '用户分群') || extractMarkdownSection(audienceFile, '目标用户');
  const personas = extractMarkdownSection(audienceFile, '用户画像');
  const scenarios = extractMarkdownSection(audienceFile, '使用场景');
  const roles = model.roles || [];

  let html = `
<section id="users" data-audience="pm dev test">
  <h2><span class="section-num">3</span> 目标用户</h2>
  <p>目标用户分群、画像与角色定义。</p>
`;

  if (userGroups) {
    html += `
  <h3>用户分群</h3>
  <div class="narrative">
    ${markdownToHtml(userGroups)}
  </div>`;
  }

  if (personas) {
    html += `
  <h3>用户画像</h3>
  <div class="narrative">
    ${markdownToHtml(personas)}
  </div>`;
  }

  if (scenarios) {
    html += `
  <h3>使用场景</h3>
  <div class="narrative">
    ${markdownToHtml(scenarios)}
  </div>`;
  }

  // v5.8：移除本节重复的角色清单卡片 — 角色详情统一在 §8 角色权限章节呈现
  // 避免"目标用户"与"角色权限"内容冗余（PM 反馈：重复冗余）

  if (!userGroups && !personas && roles.length === 0) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>目标用户资料暂未生成。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * v5.19 P2-7：原 §4 业务流程章节拆分 — 本函数生成结构性视图章节
 * v5.20 P2-2（U17）：更名"流程视图"→"产品流程"并后移至 §5（认知次序：先业务流程后产品流程）
 * 数据源：docs/prd/04-business-flow.md
 * 包含：Task Flow（任务流）/ Data Flow（数据流）/ Page Flow（页面流）
 * 受众：PM 关心 Task Flow；研发关心 Page Flow / Data Flow
 * 兼容性：section id 保留 "business-flow"（外部旧锚点 #business-flow 不失效）
 */
function genSectionFlowViews(root) {
  const flowFile = path.join(root, 'docs', 'prd', '04-business-flow.md');
  if (!fs.existsSync(flowFile)) {
    return `
<section id="business-flow" data-audience="pm dev test">
  <h2><span class="section-num">5</span> 产品流程</h2>
  <div class="narrative">
    <p>业务流程文档暂未生成（<code>docs/prd/04-business-flow.md</code> 不存在）。</p>
  </div>
</section>`;
  }

  const taskFlow = extractMarkdownSection(flowFile, 'Task Flow（任务流）');
  const dataFlow = extractMarkdownSection(flowFile, 'Data Flow（数据流）');
  const pageFlow = extractMarkdownSection(flowFile, 'Page Flow（页面流）');

  let html = `
<section id="business-flow" data-audience="pm dev test">
  <h2><span class="section-num">5</span> 产品流程</h2>
  <p>包含任务流、数据流与页面流三类结构性视图。</p>
`;

  // 三大 Flow（折叠面板，默认 Task Flow 与 Page Flow 展开，Data Flow 折叠）
  if (taskFlow) {
    html += `
  <h3>Task Flow（任务流）</h3>
  <p class="section-hint">用户完成业务任务的操作步骤序列，按角色分泳道。PM 与培训关注。</p>
  <div class="narrative">
    ${markdownToHtml(taskFlow)}
  </div>`;
  }

  if (dataFlow) {
    html += `
  <details>
    <summary>Data Flow（数据流）</summary>
    <p class="section-hint">数据在系统各模块/角色间的流动路径。研发与架构关注。</p>
    <div class="narrative">
      ${markdownToHtml(dataFlow)}
    </div>
  </details>`;
  }

  if (pageFlow) {
    html += `
  <h3>Page Flow（页面流）</h3>
  <p class="section-hint">页面间的跳转关系。前端与交互设计关注。</p>
  <div class="narrative">
    ${markdownToHtml(pageFlow)}
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * v5.19 P2-7：原 §4 业务流程章节拆分 — 本函数生成过程性叙事章节
 * v5.20 P2-2（U17）：更名"业务过程"→"业务流程"并前移至 §4（认知次序：先业务流程后产品流程）
 * 数据源：docs/prd/04-business-flow.md
 * 包含：主流程 / 分支流程 / 异常流程 / 状态流转
 * 受众：PM 关心主流程；测试关心异常流程 / 状态流转
 * 注意：flowFile 不存在或四段全部为空时返回空串（不输出 section，避免空壳）
 */
function genSectionBusinessProcess(root) {
  const flowFile = path.join(root, 'docs', 'prd', '04-business-flow.md');
  if (!fs.existsSync(flowFile)) return '';

  const mainFlow = extractMarkdownSection(flowFile, '主流程（业务流程）') || extractMarkdownSection(flowFile, '主流程');
  const branchFlow = extractMarkdownSection(flowFile, '分支流程');
  const exceptionFlow = extractMarkdownSection(flowFile, '异常流程');
  const stateFlow = extractMarkdownSection(flowFile, '状态流转');
  if (!mainFlow && !branchFlow && !exceptionFlow && !stateFlow) return '';

  let html = `
<section id="business-process" data-audience="pm dev test">
  <h2><span class="section-num">4</span> 业务流程</h2>
  <p>包含主流程、分支流程、异常流程与状态流转。</p>
`;

  // 主流程（业务流程）
  if (mainFlow) {
    html += `
  <details>
    <summary>主流程（业务流程）</summary>
    <div class="narrative">
      ${markdownToHtml(mainFlow)}
    </div>
  </details>`;
  }

  // 分支流程
  if (branchFlow) {
    html += `
  <details>
    <summary>分支流程</summary>
    <div class="narrative">
      ${markdownToHtml(branchFlow)}
    </div>
  </details>`;
  }

  // 异常流程
  if (exceptionFlow) {
    html += `
  <details>
    <summary>异常流程</summary>
    <p class="section-hint">测试关注：覆盖所有异常场景的测试用例。</p>
    <div class="narrative">
      ${markdownToHtml(exceptionFlow)}
    </div>
  </details>`;
  }

  // 状态流转
  if (stateFlow) {
    html += `
  <details>
    <summary>状态流转</summary>
    <p class="section-hint">测试关注：状态机覆盖测试。</p>
    <div class="narrative">
      ${markdownToHtml(stateFlow)}
    </div>
  </details>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 5：页面规格（整合原 page-spec.html）
 * 数据源：YAML pages + annotations
 */
function genSectionPages(model) {
  const pages = model.pages || [];
  let html = `
<section id="pages" data-audience="dev test">
  <h2><span class="section-num">6</span> 页面规格</h2>
  <p>页面清单与三层标注体系（L1 摘要 / L2 区域 / L3 元件）。共 ${pages.length} 个页面。</p>
`;

  // 页面清单总表
  if (pages.length > 0) {
    html += `
  <h3>页面清单</h3>
  <table>
    <thead><tr><th>ID</th><th>页面名称</th><th>类型</th><th>路由</th><th>实体</th><th>优先级</th></tr></thead>
    <tbody>`;
    for (const p of pages) {
      html += `
      <tr><td>${esc(p.id)}</td><td>${esc(p.name)}</td><td><span class="tag">${esc(p.type)}</span></td><td><code>${esc(p.route)}</code></td><td>${esc(p.entity || '-')}</td><td>${esc(p.priority || '-')}</td></tr>`;
    }
    html += `
    </tbody>
  </table>`;
  }

  // 每页详细规格（折叠面板）
  html += `
  <h3>页面详情</h3>`;
  for (const p of pages) {
    const ann = p.annotations || {};
    const L1 = ann.L1 || {};
    const L2 = ann.L2 || [];
    const L3 = ann.L3 || [];

    html += `
  <details class="page-spec">
    <summary>${esc(p.id)} · ${esc(p.name)} <span style="font-size:12px;color:var(--color-text-dim);margin-left:8px;">[${esc(p.type)}]</span></summary>
    <div class="details-content">
      <table>
        <tr><th>页面 ID</th><td>${esc(p.id)}</td></tr>
        <tr><th>页面名称</th><td>${esc(p.name)}</td></tr>
        <tr><th>页面类型</th><td><span class="tag">${esc(p.type)}</span></td></tr>
        <tr><th>路由</th><td><code>${esc(p.route)}</code></td></tr>
        <tr><th>关联实体</th><td>${esc(p.entity || '-')}</td></tr>
      </table>

      <h4>L1 页面说明</h4>
      <div class="annotation-block">`;

    if (Object.keys(L1).length > 0) {
      if (L1.summary) html += `        <h4>摘要</h4><p>${esc(L1.summary)}</p>`;
      if (L1.entry) html += `        <h4>入口</h4><p>${esc(L1.entry)}</p>`;
      if (L1.precondition) html += `        <h4>前置条件</h4><p>${esc(L1.precondition)}</p>`;
      if (L1.data_entity) html += `        <h4>数据实体</h4><p>${esc(L1.data_entity)}</p>`;
      if (L1.test_data) html += `        <h4>测试数据</h4><p>${esc(L1.test_data)}</p>`;
      if (L1.business_rules && L1.business_rules.length > 0) {
        html += `        <h4>业务规则</h4><ul style="padding-left: 20px; color: var(--color-text-muted); font-size: 13px;">`;
        for (const r of L1.business_rules) html += `<li>${esc(r)}</li>`;
        html += `</ul>`;
      }
    } else {
      html += `        <p>（无 L1 标注）</p>`;
    }

    html += `      </div>

      <h4>L2 区域标注（${L2.length}）</h4>`;
    if (L2.length > 0) {
      html += `      <table><thead><tr><th>区域 ID</th><th>区域名称</th><th>说明</th></tr></thead><tbody>`;
      for (const z of L2) {
        html += `<tr><td>${esc(z.id || '-')}</td><td>${esc(z.zone || z.name || '-')}</td><td>${esc(z.description || '-')}</td></tr>`;
      }
      html += `</tbody></table>`;
    } else {
      html += `      <p style="color: var(--color-text-muted); font-size: 14px;">（无 L2 标注）</p>`;
    }

    html += `      <h4>L3 元件标注（${L3.length}）</h4>`;
    if (L3.length > 0) {
      html += `      <table><thead><tr><th>元件 ID</th><th>元件名称</th><th>功能</th><th>触发</th><th>响应</th></tr></thead><tbody>`;
      for (const e of L3) {
        html += `<tr><td>${esc(e.id || '-')}</td><td>${esc(e.element || '-')}</td><td>${esc(e.function || '-')}</td><td>${esc(e.trigger || '-')}</td><td>${esc(e.response || '-')}</td></tr>`;
      }
      html += `</tbody></table>`;
    } else {
      html += `      <p style="color: var(--color-text-muted); font-size: 14px;">（无 L3 标注）</p>`;
    }

    html += `    </div>
  </details>`;
  }

  if (pages.length === 0) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>页面清单暂未生成。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 7：数据模型（整合原 data-model.html）
 */
function genSectionData(model) {
  const entities = model.entities || [];
  let html = `
<section id="data" data-audience="dev test">
  <h2><span class="section-num">7</span> 数据模型</h2>
  <p>实体定义、字段清单、状态字典与关联关系。共 ${entities.length} 个实体。</p>
`;

  // 实体卡片网格
  if (entities.length > 0) {
    html += `
  <h3>实体清单</h3>
  <div class="grid">`;
    for (const e of entities) {
      html += `
    <div class="card">
      <h4>${esc(e.displayName || e.name)}</h4>
      <p style="color: var(--color-text-muted); font-size: 14px; margin-bottom: 8px;">${esc(e.description || '-')}</p>
      <p style="font-size: 13px;"><code>${esc(e.name)}</code> · ${e.fields ? e.fields.length : 0} 字段</p>
    </div>`;
    }
    html += `
  </div>`;
  }

  // 每实体详细规格
  for (const e of entities) {
    html += `
  <h3>${esc(e.displayName || e.name)}</h3>
  <div class="card">
    <table>
      <tr><th>实体名称</th><td><code>${esc(e.name)}</code></td></tr>
      <tr><th>显示名称</th><td>${esc(e.displayName || '-')}</td></tr>
      <tr><th>描述</th><td>${esc(e.description || '-')}</td></tr>
    </table>
  </div>

  <h4>字段清单</h4>`;
    const fields = e.fields || [];
    if (fields.length > 0) {
      html += `  <table><thead><tr><th>字段名</th><th>类型</th><th>显示名称</th><th>必填</th><th>说明</th></tr></thead><tbody>`;
      for (const f of fields) {
        html += `<tr><td><code>${esc(f.name)}</code></td><td>${esc(f.type || '-')}</td><td>${esc(f.displayName || '-')}</td><td>${f.required ? '是' : '否'}</td><td>${esc(f.description || '-')}</td></tr>`;
      }
      html += `</tbody></table>`;
    } else {
      html += `  <p style="color: var(--color-text-muted);">（无字段定义）</p>`;
    }

    const statuses = e.statuses || [];
    if (statuses.length > 0) {
      html += `  <h4>状态字典</h4>
  <table><thead><tr><th>状态值</th><th>显示名称</th><th>标签颜色</th></tr></thead><tbody>`;
      for (const s of statuses) {
        html += `<tr><td><code>${esc(s.value)}</code></td><td>${esc(s.label || '-')}</td><td><span class="tag">${esc(s.color || 'info')}</span></td></tr>`;
      }
      html += `</tbody></table>`;
    }

    const relations = e.relations || [];
    if (relations.length > 0) {
      html += `  <h4>关联关系</h4>
  <table><thead><tr><th>关系类型</th><th>目标实体</th></tr></thead><tbody>`;
      for (const r of relations) {
        html += `<tr><td><span class="tag">${esc(r.type)}</span></td><td><code>${esc(r.target)}</code></td></tr>`;
      }
      html += `</tbody></table>`;
    }
  }

  if (entities.length === 0) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>实体清单暂未生成。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 8：角色权限（整合原 role-permission.html）
 * v5.19 P2-7：编号 7 → 8（业务流程拆分顺延）
 */
function genSectionRoles(model) {
  const roles = model.roles || [];
  const entities = model.entities || [];
  let html = `
<section id="roles" data-audience="dev test">
  <h2><span class="section-num">8</span> 角色权限</h2>
  <p>角色清单、权限矩阵与页面可见性。共 ${roles.length} 个角色。</p>
`;

  if (roles.length === 0) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>角色清单暂未生成。</p>
  </div>
</section>`;
    return html;
  }

  // 角色清单
  html += `
  <h3>角色清单</h3>
  <div class="grid">`;
  for (const r of roles) {
    // v5.8：description 为空时从 permissions/page_visibility 反推描述，避免 "-" 占位
    const desc = r.description || formatRoleDescription(r, entities);
    html += `
    <div class="card">
      <h4>${esc(r.displayName || r.name)}</h4>
      <p style="font-size: 13px; margin-bottom: 8px;"><code>${esc(r.name)}</code></p>
      <p style="color: var(--color-text-muted); font-size: 14px;">${esc(desc)}</p>
    </div>`;
  }
  html += `
  </div>`;

  // 权限矩阵
  if (entities.length > 0) {
    html += `
  <h3>权限矩阵</h3>`;
    const headerCells = entities.map(e => `<th>${esc(e.displayName || e.name)}</th>`).join('');
    html += `  <table><thead><tr><th>角色</th>${headerCells}</tr></thead><tbody>`;
    for (const r of roles) {
      const perms = r.permissions || [];
      const cells = entities.map(e => {
        const perm = perms.find(p => p.entity === e.name);
        if (!perm) return '<td>-</td>';
        const actions = (perm.actions || []).join(', ');
        return `<td><span class="tag">${esc(perm.scope || 'all')}</span> ${esc(actions)}</td>`;
      }).join('');
      html += `<tr><td>${esc(r.displayName || r.name)}</td>${cells}</tr>`;
    }
    html += `</tbody></table>`;
  }

  // 页面可见性
  const hasVisibility = roles.some(r => r.page_visibility && r.page_visibility.length > 0);
  if (hasVisibility) {
    html += `
  <h3>页面可见性</h3>
  <table><thead><tr><th>角色</th><th>可见页面</th></tr></thead><tbody>`;
    for (const r of roles) {
      const pv = r.page_visibility || [];
      const pages = pv.map(p => `<span class="tag">${esc(typeof p === 'string' ? p : (p.pageId || p.id || JSON.stringify(p)))}</span>`).join(' ');
      html += `<tr><td>${esc(r.displayName || r.name)}</td><td>${pages || '-'}</td></tr>`;
    }
    html += `</tbody></table>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 8：成功指标与时间线
 * 数据源：docs/prd/10-success-metrics.md + docs/prd/11-timeline.md
 */
function genSectionMetrics(root, model) {
  const metricsFile = path.join(root, 'docs', 'prd', '10-success-metrics.md');
  const timelineFile = path.join(root, 'docs', 'prd', '11-timeline.md');
  const metrics = extractMarkdownSection(metricsFile, '指标定义') || extractMarkdownSection(metricsFile, '成功指标');
  const measurement = extractMarkdownSection(metricsFile, '测量计划');
  const milestones = extractMarkdownSection(timelineFile, '关键里程碑') || extractMarkdownSection(timelineFile, '里程碑');
  const roadmap = extractMarkdownSection(timelineFile, '路线图');

  let html = `
<section id="metrics" data-audience="pm dev test">
  <h2><span class="section-num">9</span> 成功指标与时间线</h2>
  <p>产品成功指标定义、测量计划与发布时间线。</p>
`;

  if (metrics) {
    html += `
  <h3>指标定义</h3>
  <div class="narrative">
    ${markdownToHtml(metrics)}
  </div>`;
  }

  if (measurement) {
    html += `
  <h3>测量计划</h3>
  <div class="narrative">
    ${markdownToHtml(measurement)}
  </div>`;
  }

  if (milestones) {
    html += `
  <h3>关键里程碑</h3>
  <div class="narrative">
    ${markdownToHtml(milestones)}
  </div>`;
  }

  if (roadmap) {
    html += `
  <h3>路线图</h3>
  <div class="narrative">
    ${markdownToHtml(roadmap)}
  </div>`;
  }

  if (!metrics && !milestones) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>指标与时间线资料暂未生成。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 10：范围与风险
 * 数据源：docs/prd/12-risk-assumptions.md + docs/prd/13-open-questions.md
 */
function genSectionScope(root, model) {
  const riskFile = path.join(root, 'docs', 'prd', '12-risk-assumptions.md');
  const questionsFile = path.join(root, 'docs', 'prd', '13-open-questions.md');
  const assumptions = extractMarkdownSection(riskFile, '假设清单') || extractMarkdownSection(riskFile, '假设');
  const risks = extractMarkdownSection(riskFile, '风险矩阵') || extractMarkdownSection(riskFile, '风险');
  const scope = extractMarkdownSection(riskFile, '范围') || extractMarkdownSection(riskFile, '范围与约束');
  const openQuestions = extractMarkdownSection(questionsFile, '开放问题') || extractMarkdownSection(questionsFile, '待确认问题');

  let html = `
<section id="scope" data-audience="pm dev test">
  <h2><span class="section-num">10</span> 范围与风险</h2>
  <p>项目范围、假设清单、风险矩阵与待确认问题。</p>
`;

  if (scope) {
    html += `
  <h3>范围与约束</h3>
  <div class="narrative">
    ${markdownToHtml(scope)}
  </div>`;
  }

  if (assumptions) {
    html += `
  <h3>假设清单</h3>
  <div class="narrative">
    ${markdownToHtml(assumptions)}
  </div>`;
  }

  if (risks) {
    html += `
  <h3>风险矩阵</h3>
  <div class="narrative">
    ${markdownToHtml(risks)}
  </div>`;
  }

  if (openQuestions) {
    html += `
  <h3>待确认问题</h3>
  <div class="narrative">
    ${markdownToHtml(openQuestions)}
  </div>`;
  }

  if (!scope && !risks && !openQuestions) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>范围与风险资料暂未生成。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * v5.19 P0-2 新增：§11 研发文档（聚合章节，data-audience="dev" 仅研发视图可见）
 *
 * 背景：v5.9 删除"详细文档下载"章节后，docs/ 下 spec(×7)/test(×3)/handoff(×1)
 *      共 11 个 markdown 在 index.html 零嵌入零链接（U18 研发视图遗漏）。
 *      原"研发视图" tab 仅为 CSS 受众过滤，无内容聚合 — 本章节补全该回归。
 *
 * 数据源（与 genSection* 读取 docs/prd 的路径解析方式一致，root 为 sim-project 根目录）：
 *   - <root>/docs/spec/*.md
 *   - <root>/docs/test/*.md
 *   - <root>/docs/handoff/*.md
 *
 * 呈现：每类一个小节标题；每个 md 渲染为默认收起的 <details> 折叠面板
 *      （summary 含相对路径 code + 文件首行标题文本），正文复用 markdownToHtml。
 * 兜底：目录不存在或无 .md 文件时输出"（无研发文档）"提示行，不报错。
 * TOC：左侧目录由运行时 JS 从 .main-content section[id] 自动收集，本章节自动收录。
 */
function genSectionDevDocs(root) {
  const categories = [
    { dir: 'spec', label: 'spec 规格文档' },
    { dir: 'test', label: 'test 测试文档' },
    { dir: 'handoff', label: 'handoff 交接文档' },
  ];

  let html = `
<section id="dev-docs" data-audience="dev">
  <h2><span class="section-num">11</span> 研发文档</h2>
  <p>聚合 spec / test / handoff 研发文档全文（默认收起，点击文件名展开）。本章节仅在"研发视图"下显示。</p>
`;

  for (const cat of categories) {
    const dirPath = path.join(root, 'docs', cat.dir);
    let files = [];
    if (fs.existsSync(dirPath)) {
      files = fs.readdirSync(dirPath).filter(f => f.endsWith('.md')).sort();
    }

    html += `
  <h3>${esc(cat.label)}（${files.length}）</h3>`;

    if (files.length === 0) {
      // 兜底：目录不存在或无文件时输出提示行，不报错
      html += `
  <p>（无研发文档：docs/${esc(cat.dir)}/ 目录不存在或无 .md 文件）</p>`;
      continue;
    }

    for (const f of files) {
      const content = fs.readFileSync(path.join(dirPath, f), { encoding: 'utf-8' });
      // 提取首个标题行文本作为折叠面板副标题（无标题时留空，仅显示文件名）
      const hm = content.match(/^#{1,6}\s+(.+)$/m);
      const headingText = hm ? hm[1].trim() : '';
      html += `
  <details>
    <summary><code>${esc(cat.dir)}/${esc(f)}</code> <span style="font-size:12px;color:var(--color-text-dim);margin-left:8px;">${esc(headingText)}</span></summary>
    <div class="details-content">
      ${markdownToHtml(content)}
    </div>
  </details>`;
    }
  }

  html += `</section>`;
  return html;
}

/**
 * 章节 11：PM 原始需求（折叠面板）
 * v5.11 重构：按时间顺序展示阶段 0 场景简报 + 阶段 1 完整需求，体现需求导入与迭代过程
 * 数据源：
 *   - inbox/text/requirement-scenario-brief.md（PM 阶段 0 输入的场景简报）
 *   - inbox/text/requirement-input.md（PM 阶段 1 输入的完整需求文档）
 */
function genSectionPmRequirement(root) {
  const briefFile = path.join(root, 'inbox', 'text', 'requirement-scenario-brief.md');
  const inputFile = path.join(root, 'inbox', 'text', 'requirement-input.md');
  const briefContent = readMarkdownFile(briefFile);
  const inputContent = readMarkdownFile(inputFile);
  const briefWordCount = briefContent ? briefContent.length : 0;
  const inputWordCount = inputContent ? inputContent.length : 0;

  let html = `
<section id="pm-requirement" data-audience="pm dev">
  <h2><span class="section-num">2</span> PM 原始需求</h2>
  <p>本章节按时间顺序展示 PM 在阶段 0（场景简报）与阶段 1（完整需求）输入的原始资料，体现需求从模糊到清晰的迭代过程。</p>
`;

  // 阶段 0：场景简报（requirement-scenario-brief.md）
  if (briefContent) {
    html += `
  <details>
    <summary>阶段 0 · 场景简报（requirement-scenario-brief.md · ${briefWordCount} 字符）</summary>
    <div class="details-content">
      ${markdownToHtml(briefContent)}
    </div>
  </details>`;
  }

  // 阶段 1：完整需求文档（requirement-input.md）
  if (inputContent) {
    html += `
  <details>
    <summary>阶段 1 · 完整需求文档（requirement-input.md · ${inputWordCount} 字符）</summary>
    <div class="details-content">
      ${markdownToHtml(inputContent)}
    </div>
  </details>`;
  }

  // 兜底：两份都没有
  if (!briefContent && !inputContent) {
    html += `
  <div class="narrative">
    <h4>说明</h4>
    <p>PM 原始需求文档暂未提供（<code>inbox/text/</code> 目录下未发现 requirement-scenario-brief.md 与 requirement-input.md）。</p>
  </div>`;
  }

  html += `</section>`;
  return html;
}

/**
 * 生成单页 PRD 主页面 index.html
 * v5.7 重构：新增 TL;DR / 版本信息 / Non-Goals / 业务流程章节 + 受众 Tab + footer v5.7
 * v5.8 重构：移除 §12 详细文档下载章节，下载入口移至页脚
 */
function genIndexHtml(model, root, generatedAt, skillVersion) {
  const project = model.project || { name: 'Demo', description: '', domain: 'APP' };

  let body = genHtmlHead('产品需求文档（PRD）', project.name);
  body += `
<header class="header">
  <h1>${esc(project.name)} 产品需求文档</h1>
  <p class="subtitle">${esc(project.description || '基于 Demora 生成的单页 PRD，整合 markdown 叙事与结构化数据')}</p>
  <span class="badge">Demora v5.7 单页 PRD</span>
</header>
`;
  // v5.9：受众视图 Tab（PM / 研发）— 移除测试视图
  body += `
<nav class="audience-tabs" id="audienceTabs">
  <button class="tab-btn active" data-audience="all">全部</button>
  <button class="tab-btn" data-audience="pm">PM 视图</button>
  <button class="tab-btn" data-audience="dev">研发视图</button>
</nav>
`;
  // v5.7：版本信息栏
  body += genSectionVersionInfo(generatedAt, skillVersion);

  body += genAnchorNav();

  // v5.9：§0 摘要（原 TL;DR 改名）
  body += genSectionTldr(root, model);
  // §1 业务背景
  body += genSectionProblem(root, model);
  // v5.7：§1.5 Non-Goals
  body += genSectionNonGoals(root);
  // v5.9：§2 PM 原始需求（移至业务背景之后，便于 PM 比对原始需求与系统化整理）
  body += genSectionPmRequirement(root);
  // §3 目标用户
  body += genSectionUsers(root, model);
  // v5.19 P2-7：§4 流程视图 + §5 业务过程（原 §4 业务流程拆分，#business-flow 锚点保留兼容）
  // v5.20 P2-2（U17）：输出顺序对调——§4 业务流程（business-process）在前，§5 产品流程（business-flow）在后
  body += genSectionBusinessProcess(root);
  body += genSectionFlowViews(root);
  // §6 页面规格（v5.19 P2-7：编号顺延）
  body += genSectionPages(model);
  // §7 数据模型（v5.19 P2-7：编号顺延）
  body += genSectionData(model);
  // §8 角色权限（v5.19 P2-7：编号顺延）
  body += genSectionRoles(model);
  // §9 成功指标与时间线（v5.19 P2-7：编号顺延）
  body += genSectionMetrics(root, model);
  // §10 范围与风险（v5.19 P2-7：编号顺延 9 → 10）
  body += genSectionScope(root, model);
  // v5.19 P0-2：§11 研发文档（dev 视图专属，聚合 docs/spec|test|handoff 全文）
  body += genSectionDevDocs(root);
  // v5.9：移除 §项目元数据 + §解决方案概述 + §详细文档下载
  // （PM 反馈：项目元数据对 PM 无价值；解决方案概述与业务背景/摘要重复；下载入口移至页脚）

  // 页脚（v5.9: Ourchem × Demora 联合版权，移除 Skill 标识）
  body += `
<div class="footer">
  <div class="footer-coop">
    <div class="footer-brand-logo footer-brand-ourchem" aria-label="Ourchem">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 133.24 25.6">
<defs><style>.cls-1{fill:#fff;}</style></defs><polygon class="cls-1" points="28.83 4.2 27.95 4.46 27.95 5.2 28.83 4.94 28.83 4.2"/><polygon class="cls-1" points="29.77 4.05 29.22 4.21 29.22 4.67 29.77 4.51 29.77 4.05"/><polygon class="cls-1" points="29.59 4.92 29.05 5.07 29.05 5.53 29.59 5.37 29.59 4.92"/><polygon class="cls-1" points="28.83 5.86 28.83 5.41 28.29 5.57 28.29 6.02 28.83 5.86"/><polygon class="cls-1" points="27.85 6.89 28.39 6.73 28.39 6.28 27.85 6.44 27.85 6.89"/><polygon class="cls-1" points="29.32 6.2 28.77 6.36 28.77 6.82 29.32 6.66 29.32 6.2"/><polygon class="cls-1" points="28.69 3.93 29.69 3.64 29.69 2.77 28.69 3.06 28.69 3.93"/><path class="cls-1" d="M11.69,21.54c-3.11,1.15-5.69,1.26-6.92,0-1-1-1-2.59-.13-4.55a3,3,0,0,1-.9-2.11v-3C.31,16.18-1,20.42.81,22.81c1.61,2.15,5.35,2.3,9.77.8v-1l1.11-.35Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M11.93,8.21c6.49-5.31,13.62-7.59,15.73-5a2.77,2.77,0,0,1,.42.75l.26-.09v-1l.91-.27a4.42,4.42,0,0,0-.44-.76C26.15-1.74,17.73.08,10,5.93a35.79,35.79,0,0,0-5.44,5H9A36.4,36.4,0,0,1,11.93,8.21Z" transform="translate(0 -0.01)"/><polygon class="cls-1" points="29.01 7.11 28.39 7.29 28.39 7.82 29.01 7.63 29.01 7.11"/><polygon class="cls-1" points="27.58 8.38 28.12 8.22 28.12 7.76 27.58 7.92 27.58 8.38"/><polygon class="cls-1" points="28.46 8.43 28.03 8.56 28.03 8.92 28.46 8.79 28.46 8.43"/><polygon class="cls-1" points="27.22 9.09 27.64 8.97 27.64 8.61 27.22 8.73 27.22 9.09"/><polygon class="cls-1" points="27.13 9.96 27.67 9.8 27.67 9.35 27.13 9.5 27.13 9.96"/><polygon class="cls-1" points="26.81 10.43 26.81 10.09 26.4 10.21 26.4 10.55 26.81 10.43"/><polygon class="cls-1" points="27.84 7.55 28.21 7.44 28.21 7.13 27.84 7.24 27.84 7.55"/><polygon class="cls-1" points="19.08 18.49 19.5 18.36 19.5 18 19.08 18.13 19.08 18.49"/><polygon class="cls-1" points="17.71 19.86 18.16 19.73 18.16 19.35 17.71 19.49 17.71 19.86"/><polygon class="cls-1" points="16.89 19.52 17.44 19.36 17.44 18.89 16.89 19.06 16.89 19.52"/><polygon class="cls-1" points="15.16 20.3 14.75 20.42 14.75 20.76 15.16 20.64 15.16 20.3"/><polygon class="cls-1" points="16.99 20.38 17.39 20.26 17.39 19.91 16.99 20.03 16.99 20.38"/><polygon class="cls-1" points="14.98 21.58 15.61 21.39 15.61 20.87 14.98 21.05 14.98 21.58"/><polygon class="cls-1" points="13.69 22.24 14.54 21.99 14.54 21.27 13.69 21.52 13.69 22.24"/><polygon class="cls-1" points="14.4 21.03 14.4 20.49 13.75 20.68 13.75 21.22 14.4 21.03"/><polygon class="cls-1" points="12.67 22.87 13.31 22.68 13.31 22.14 12.67 22.33 12.67 22.87"/><polygon class="cls-1" points="15.66 20.72 16.61 20.44 16.61 19.64 15.66 19.92 15.66 20.72"/><polygon class="cls-1" points="18.03 19.12 18.57 18.96 18.57 18.51 18.03 18.66 18.03 19.12"/><polygon class="cls-1" points="13.23 21.66 13.23 20.76 12.16 21.08 12.16 21.97 13.23 21.66"/><polygon class="cls-1" points="11.01 23.83 12.19 23.48 12.19 22.48 11.01 22.83 11.01 23.83"/><path class="cls-1" d="M18.82,12.61a1.69,1.69,0,0,1,1.51,1l1-.54a2.87,2.87,0,0,0-2.54-1.6,3,3,0,0,0,0,5.89,2.87,2.87,0,0,0,2.54-1.6l-1-.54a1.69,1.69,0,0,1-1.51,1,1.79,1.79,0,0,1,0-3.57Z" transform="translate(0 -0.01)"/><polygon class="cls-1" points="25.91 17.33 27.07 17.33 27.07 11.43 25.91 11.43 25.91 13.82 23.44 13.82 23.44 11.43 22.28 11.43 22.28 17.33 23.44 17.33 23.44 14.93 25.91 14.93 25.91 17.33"/><polygon class="cls-1" points="38.23 11.43 36.68 15.48 35.13 11.43 33.84 11.43 33.84 17.33 34.97 17.33 34.97 14.04 36.25 17.33 37.11 17.33 38.39 14.04 38.39 17.33 39.55 17.33 39.55 11.43 38.23 11.43"/><path class="cls-1" d="M6.67,17.34a2.42,2.42,0,0,0,2.42-2.42V11.44H7.93v3.48a1.26,1.26,0,0,1-2.52,0V11.44H4.24v3.48A2.43,2.43,0,0,0,6.67,17.34Z" transform="translate(0 -0.01)"/><polygon class="cls-1" points="28.29 17.33 32.87 17.33 32.87 16.27 29.45 16.27 29.45 14.93 32.34 14.93 32.34 13.83 29.45 13.83 29.45 13.75 29.45 12.54 32.87 12.54 32.87 11.43 28.29 11.43 28.29 17.33"/><polygon class="cls-1" points="11.71 13.9 11.71 13.9 11.71 13.9 11.71 13.9"/><path class="cls-1" d="M15.94,17.34l-2-2.39a1.81,1.81,0,0,0-.64-3.51h-3v5.9h1.16V12.6h1.89a.66.66,0,1,1,.16,1.31H12.35a.31.31,0,0,0-.29.3.32.32,0,0,0,.08.21h0l2.38,2.92Z" transform="translate(0 -0.01)"/><polygon class="cls-1" points="35.84 20.37 35.84 20.26 35.84 19.09 35.19 19.09 35.19 20.26 34.9 20.26 34.9 18.73 34.11 18.73 34.11 20.26 33.82 20.26 33.82 19.09 33.17 19.09 33.17 20.26 33.17 20.37 33.17 20.69 35.84 20.69 35.84 20.37"/><path class="cls-1" d="M38.71,23.26V19.08H36.24v4.16c0,.88-.65,1-.8,1H34.16v-1.5h1.68V21.08H33.17v.43h1.69v.78H33.17v2.36h2.77c.9,0,1.26-.43,1.26-1.43V19.53h.52v3.68c0,1,.34,1.4,1.17,1.43h.66v-.43h0C39.36,24.21,38.71,24.14,38.71,23.26Z" transform="translate(0 -0.01)"/><polygon class="cls-1" points="26.17 19.71 25.77 19.71 26.11 20.47 26.51 20.47 26.17 19.71"/><polygon class="cls-1" points="27.97 19.71 27.63 20.47 28.02 20.47 28.37 19.71 27.97 19.71"/><polygon class="cls-1" points="27.97 22.04 28.37 22.04 28.02 21.27 27.63 21.27 27.97 22.04"/><polygon class="cls-1" points="26.17 22.04 26.51 21.27 26.11 21.27 25.77 22.04 26.17 22.04"/><polygon class="cls-1" points="28.37 21.06 28.37 20.68 28.37 20.66 27.46 20.66 27.46 19.64 26.68 19.64 26.68 20.66 25.77 20.66 25.77 20.68 25.77 21.06 25.77 21.09 26.68 21.09 26.68 22.1 27.46 22.1 27.46 21.09 28.37 21.09 28.37 21.06"/><polygon class="cls-1" points="29.56 22.5 29.56 19.52 29.56 19.09 28.58 19.09 25.9 19.09 26.14 18.73 24.82 18.73 24.58 19.09 24.58 19.12 24.58 19.52 24.58 22.53 25.56 22.53 25.56 19.52 28.58 19.52 28.58 22.5 29.56 22.5"/><path class="cls-1" d="M27.48,22.29H26.24l-.36.54h-2v.43h1.74c-.19.29-.36.54-.4.62a.94.94,0,0,1-.75.33v.43c.86,0,1.46,0,1.73-.4l.64-1h.46l.64,1c.27.41.88.4,1.72.4v-.43a.92.92,0,0,1-.74-.33l-.4-.62h1.72v-.43H27.12Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M49.63,13.14H44.51v1.44a5.9,5.9,0,0,1-1,3.72,4.27,4.27,0,0,0-.74-.67,4.68,4.68,0,0,0,.78-3.06V12.26h2.69a8.68,8.68,0,0,0-.27-1l1-.17a7.65,7.65,0,0,1,.27,1.17h2.4Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M51.58,13.19A7.74,7.74,0,0,1,51,15.4l-.77-.32A6.39,6.39,0,0,0,50.82,13Zm1.67,0a9.12,9.12,0,0,1,.6,1.9l-.76.36a9.28,9.28,0,0,0-.42-1.65c0,1.55-.19,3.26-1.61,4.44a3.32,3.32,0,0,0-.65-.7,4.58,4.58,0,0,0,1.37-3.82V11.29h.89v2.09Zm3.67-1.88v6.77H56V15l-.67.37a8.14,8.14,0,0,0-.61-1.67v4h-.88v-6.2h.88v1.9l.55-.28A11,11,0,0,1,56,14.73V11.26Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M62.24,16.38a3.58,3.58,0,0,0,2.69,1,2.87,2.87,0,0,0-.55.86,3.54,3.54,0,0,1-3-1.6c-.39.82-1.22,1.33-3.14,1.61a3,3,0,0,0-.43-.79c1.63-.18,2.32-.52,2.65-1.06H58v-.76h2.74a.82.82,0,0,1,.06-.37h.94v.37h3v.76Zm-2.74-1h-.83V11.73h2q.12-.3.21-.6l1,.14c-.08.16-.15.32-.21.46h2.38v3.62h-.87V12.46H59.49Zm3.08-.16a8.71,8.71,0,0,0-.83-.64l.41-.4h-.42v.9H61V14.5a4.64,4.64,0,0,1-.93.78,2.52,2.52,0,0,0-.47-.51,4.16,4.16,0,0,0,.87-.62H59.7v-.59h.54a4.6,4.6,0,0,0-.39-.68l.56-.26a6.2,6.2,0,0,1,.44.69l-.5.25H61v-1h.76v1h.57l-.46-.23a4.88,4.88,0,0,0,.42-.74l.66.29-.55.68H63v.59h-.76c.27.18.65.43.83.58Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M68.34,16.63a5.72,5.72,0,0,0,.08.76,13.87,13.87,0,0,0-2.61.66,2.34,2.34,0,0,0-.28-.72c.12-.06.21-.17.21-.44V15.33h2.14v-.6H65.59v-.79h3.09v2.14h-2.2V17Zm.46-3.13H65.62V11.57h.72v1.24h.49V11.17h.76v1.64h.47V11.57h.74Zm2.92,3.84c.08,0,.1-.2.12-1a2.3,2.3,0,0,0,.67.32c-.06,1-.24,1.29-.72,1.29h-.37c-.56,0-.7-.24-.7-1V12.27h-.64V13.9a7.67,7.67,0,0,1-1,4.32,2.83,2.83,0,0,0-.65-.55,6.57,6.57,0,0,0,.83-3.78V11.52h2.26V17c0,.3,0,.35.09.35Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M75.24,11.43a13,13,0,0,1-.55,1.34v5.46h-.82V14.18c-.18.25-.37.5-.55.71a4.91,4.91,0,0,0-.46-.88,7.72,7.72,0,0,0,1.58-2.82Zm4.63.9v.75H75v-.73h2.16a9.59,9.59,0,0,0-.47-.9l.76-.28a6.49,6.49,0,0,1,.55,1l-.43.19Zm-4.42,3.34h4v2.5h-.79V18H76.24v.23h-.76Zm3.88-1.51H75.56v-.7h3.77Zm-3.77.39h3.77v.7H75.56Zm.65,1.84v.85h2.43v-.85Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M80.44,17.44a8.3,8.3,0,0,0,.71-1.58l.8.33a14.69,14.69,0,0,1-.68,1.65Zm3.29-1.92H81.57V11.83H83.3a6.17,6.17,0,0,0,.19-.74l1.09.13c-.11.23-.23.43-.32.61h2.06v3.69H84.15a4.77,4.77,0,0,1,.79,1L84.2,17a5.21,5.21,0,0,0-.89-1.19Zm1.06,1.74c.36,0,.42-.1.47-.82a2.18,2.18,0,0,0,.81.32c-.11,1-.37,1.31-1.21,1.31H83.43c-1.06,0-1.34-.25-1.34-1v-1H83v1c0,.22.07.25.5.25Zm-2.36-4.4h3v-.35h-3Zm0,1h3v-.34h-3Zm0,1h3v-.35h-3Zm4.13.87a6.18,6.18,0,0,1,.84,1.61l-.86.37a6.71,6.71,0,0,0-.77-1.65Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M90.41,14.08l-2.08.9L88,14.1c.57-.16,1.45-.46,2.3-.74Zm-.72-1.3a6.58,6.58,0,0,0-1.39-.73l.44-.64a6.79,6.79,0,0,1,1.42.66Zm-.63,2.62h5v2.84h-1V18H89.94v.3H89Zm3.87-2.72a1.78,1.78,0,0,1-.09.47,2.28,2.28,0,0,0,2.09,1.41,3,3,0,0,0-.51.77,2.78,2.78,0,0,1-1.94-1.28,3.32,3.32,0,0,1-2,1.33,2.54,2.54,0,0,0-.49-.76c1.54-.37,1.92-1,2.06-1.94h-.7a5,5,0,0,1-.64.93,4.37,4.37,0,0,0-.78-.47,4.31,4.31,0,0,0,1.11-2l.87.18a1.77,1.77,0,0,1-.19.56h2.53l.62.16a9.43,9.43,0,0,1-.62,1.63l-.73-.21c.1-.25.19-.5.27-.76ZM90,16.2v1h3.12v-1Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M97.92,15.84a5.4,5.4,0,0,0,.29.76,13.61,13.61,0,0,0-1.74,1.48,3.17,3.17,0,0,0-.43-.76.93.93,0,0,0,.38-.72V14.33h-.9v-.86h1.77v2.85Zm-1-2.78a11.39,11.39,0,0,0-1-1.25l.61-.52a9.44,9.44,0,0,1,1.09,1.19Zm5.43-.83v.42c-.09,3.45-.18,4.66-.47,5a.92.92,0,0,1-.64.38,6.73,6.73,0,0,1-1.1,0,1.93,1.93,0,0,0-.27-.87h1a.35.35,0,0,0,.31-.15c.2-.23.29-1.36.37-4.13H99.11q-.18.29-.36.54h2.17v3.1H99.14v.51h-.82v-3l-.09.1a4.88,4.88,0,0,0-.75-.61,6,6,0,0,0,1.44-2.37l.91.24c-.1.28-.22.55-.34.83ZM99.11,14.3v.5H100v-.5ZM100,16v-.49h-.93V16Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M105.87,12.91q-.14.3-.3.6h3.49v3.72c0,.44-.09.68-.4.82a3.33,3.33,0,0,1-1.33.15,4.39,4.39,0,0,0-.27-.87h1c.18,0,.17,0,.17-.15v-.45h-2.72v1.44h-.89V14.91a5,5,0,0,1-1,.89,4.3,4.3,0,0,0-.59-.69,5.8,5.8,0,0,0,1.88-2.2h-1.67v-.83h2c.11-.3.21-.6.29-.91l.93.21c-.08.23-.16.46-.25.7h3.68v.84Zm2.31,1.38h-2.72v.48h2.72Zm0,1.72v-.49h-2.72V16Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M113.41,11.76c-.2.63-.45,1.39-.65,2a2.42,2.42,0,0,1,.54,1.57,1.13,1.13,0,0,1-.34,1,.82.82,0,0,1-.42.17,4,4,0,0,1-.49,0,1.86,1.86,0,0,0-.19-.77h.32a.29.29,0,0,0,.2-.07c.1-.06.14-.23.14-.44a2.12,2.12,0,0,0-.53-1.38c.15-.46.31-1.07.43-1.56h-.73v5.9h-.78V11.46h1.91Zm4.06,3.87c-.33.26-.72.54-1.06.76a3.29,3.29,0,0,0,1.22,1,3.48,3.48,0,0,0-.59.78A4.68,4.68,0,0,1,115,14.91h-.45v2.17l1-.24a5.61,5.61,0,0,0,0,.82,8.15,8.15,0,0,0-1.93.6,2.64,2.64,0,0,0-.38-.7.73.73,0,0,0,.35-.66V11.47H117v3.45h-1.3a4,4,0,0,0,.3.82,6.72,6.72,0,0,0,.86-.74Zm-3-3.4v.59h1.66v-.59Zm0,1.92h1.66v-.61h-1.66Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M121.07,11.61A9.13,9.13,0,0,1,119,14.73a10.34,10.34,0,0,0-.84-.64,6.47,6.47,0,0,0,1.94-2.76Zm2.11,3.47a21.11,21.11,0,0,1,1.7,2.6l-.9.48c-.11-.25-.28-.54-.46-.86a30,30,0,0,0-4.53.47,8.19,8.19,0,0,0-.35-.94,1.52,1.52,0,0,0,.71-.59,13,13,0,0,0,1.79-2.89l1,.43a16.14,16.14,0,0,1-2,2.86l2.81-.18-.67-1ZM123,11.24a10,10,0,0,0,2.1,2.69,4.49,4.49,0,0,0-.75.76,13.94,13.94,0,0,1-2.24-3.09Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M132.17,17.08c0,.51-.09.78-.42.94a3.46,3.46,0,0,1-1.46.18,3.83,3.83,0,0,0-.29-1,9.37,9.37,0,0,0,1.06,0c.14,0,.19,0,.19-.17V12.47H126v-.85h6.18ZM130.5,13.8h-4.43V13h4.43Zm-3.17,3.11v.54h-.88V14.34h3.66v2.55Zm0-1.78v1h1.91v-1Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M42.92,22.86a1.88,1.88,0,0,1,.47-1.36,1.59,1.59,0,0,1,1.2-.49,1.74,1.74,0,0,1,.87.23,1.58,1.58,0,0,1,.59.64,2.18,2.18,0,0,1,.2.94,2.14,2.14,0,0,1-.21,1,1.43,1.43,0,0,1-.61.63,1.77,1.77,0,0,1-.84.21,1.81,1.81,0,0,1-.88-.23,1.61,1.61,0,0,1-.59-.65A2,2,0,0,1,42.92,22.86Zm.48,0a1.39,1.39,0,0,0,.34,1,1.17,1.17,0,0,0,1.7,0,1.42,1.42,0,0,0,.34-1,1.77,1.77,0,0,0-.15-.75,1.06,1.06,0,0,0-.39-.52,1.23,1.23,0,0,0-.62-.17,1.2,1.2,0,0,0-.84.33,1.56,1.56,0,0,0-.38,1.13Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M48.51,24.55v-.37a.9.9,0,0,1-.8.43,1.15,1.15,0,0,1-.41-.08.67.67,0,0,1-.42-.54,2.54,2.54,0,0,1,0-.39V22.08h.36v1.4a3.38,3.38,0,0,0,0,.45.55.55,0,0,0,.17.27.63.63,0,0,0,.33.09.74.74,0,0,0,.36-.09.57.57,0,0,0,.24-.27,1.68,1.68,0,0,0,.07-.5V22.08h.42V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M49.63,24.55V22.08H50v.39a1.18,1.18,0,0,1,.23-.39.46.46,0,0,1,.28-.08.84.84,0,0,1,.44.13l-.15.4a.56.56,0,0,0-.31-.09.44.44,0,0,0-.25.08.45.45,0,0,0-.16.24,1.62,1.62,0,0,0-.08.49v1.32Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M53,23.63l.42.06a1.14,1.14,0,0,1-.36.68,1,1,0,0,1-.69.24,1.07,1.07,0,0,1-.84-.34,1.39,1.39,0,0,1-.31-1,1.72,1.72,0,0,1,.13-.71.9.9,0,0,1,.42-.46,1.24,1.24,0,0,1,.6-.15,1.08,1.08,0,0,1,.67.2,1,1,0,0,1,.34.59l-.42.07a.68.68,0,0,0-.21-.38.5.5,0,0,0-.37-.13.65.65,0,0,0-.52.23,1.11,1.11,0,0,0-.2.73,1.15,1.15,0,0,0,.19.74.66.66,0,0,0,.51.23.6.6,0,0,0,.42-.15A.83.83,0,0,0,53,23.63Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M53.82,24.55V21.08h.42v1.25A1,1,0,0,1,55,22a.93.93,0,0,1,.49.11.6.6,0,0,1,.29.3,1.39,1.39,0,0,1,.09.57v1.59h-.42V23a.71.71,0,0,0-.14-.47.54.54,0,0,0-.4-.15.74.74,0,0,0-.35.1.57.57,0,0,0-.24.27,1.25,1.25,0,0,0-.07.47v1.37Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M58.32,23.74l.44.06a1.06,1.06,0,0,1-.39.6,1.32,1.32,0,0,1-1.6-.13,1.7,1.7,0,0,1,0-2,1.1,1.1,0,0,1,.85-.35,1.06,1.06,0,0,1,.82.34,1.36,1.36,0,0,1,.32,1v.11H56.89a1,1,0,0,0,.24.64.64.64,0,0,0,.52.22.65.65,0,0,0,.4-.12A.83.83,0,0,0,58.32,23.74Zm-1.41-.66h1.41a.92.92,0,0,0-.16-.48.72.72,0,0,0-1-.05A.8.8,0,0,0,56.91,23.08Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M59.36,24.55V22.08h.39v.36a.75.75,0,0,1,.31-.3.79.79,0,0,1,.45-.11.83.83,0,0,1,.46.11.63.63,0,0,1,.25.33A.89.89,0,0,1,62,22a.82.82,0,0,1,.58.2.93.93,0,0,1,.2.64V24.6h-.42V23a.92.92,0,0,0,0-.37.27.27,0,0,0-.15-.18.43.43,0,0,0-.25-.07.61.61,0,0,0-.44.17.78.78,0,0,0-.18.57v1.46h-.43V22.92a.72.72,0,0,0-.1-.43.4.4,0,0,0-.34-.14.67.67,0,0,0-.34.09.6.6,0,0,0-.22.28,1.36,1.36,0,0,0-.07.53v1.3Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M65,24.55V21.08h.46v3.48Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M66.32,24.55V22.08h.39v.36a.89.89,0,0,1,.8-.41,1,1,0,0,1,.42.08.58.58,0,0,1,.28.21.77.77,0,0,1,.14.32,2.81,2.81,0,0,1,0,.41V24.6h-.43V23a.86.86,0,0,0,0-.39.39.39,0,0,0-.17-.21.63.63,0,0,0-.3-.07.64.64,0,0,0-.47.17.87.87,0,0,0-.2.66v1.37Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M69.24,24.55V22.37h-.38v-.29h.38v-.27a1.15,1.15,0,0,1,0-.37.58.58,0,0,1,.22-.27.76.76,0,0,1,.44-.11h.39l-.06.37H70a.4.4,0,0,0-.28.08.48.48,0,0,0-.08.31v.26h.49v.34h-.49V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M70.35,23.29a1.3,1.3,0,0,1,.39-1,1.17,1.17,0,0,1,.8-.28,1.12,1.12,0,0,1,.85.34,1.29,1.29,0,0,1,.33.94,1.67,1.67,0,0,1-.15.76,1.11,1.11,0,0,1-.42.44,1.31,1.31,0,0,1-.61.15,1.11,1.11,0,0,1-.86-.34A1.3,1.3,0,0,1,70.35,23.29Zm.44,0A1,1,0,0,0,71,24a.65.65,0,0,0,.53.24.68.68,0,0,0,.53-.24,1.09,1.09,0,0,0,.21-.74,1.06,1.06,0,0,0-.21-.71.71.71,0,0,0-.53-.24.65.65,0,0,0-.53.24A1,1,0,0,0,70.79,23.29Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M73.24,24.55V22.08h.39v.39a1,1,0,0,1,.27-.36.43.43,0,0,1,.27-.08.84.84,0,0,1,.44.13l-.15.4a.56.56,0,0,0-.31-.09.44.44,0,0,0-.25.08.49.49,0,0,0-.16.24,1.61,1.61,0,0,0-.07.49V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M75,24.55V22.08h.39v.36a.75.75,0,0,1,.31-.3.79.79,0,0,1,.45-.11.83.83,0,0,1,.46.11.63.63,0,0,1,.25.33.89.89,0,0,1,.78-.44.82.82,0,0,1,.58.2.93.93,0,0,1,.2.64V24.6H78V23a1.15,1.15,0,0,0,0-.37.27.27,0,0,0-.15-.18.43.43,0,0,0-.25-.07.61.61,0,0,0-.44.17.78.78,0,0,0-.18.57v1.46h-.43V22.92a.72.72,0,0,0-.1-.43.4.4,0,0,0-.34-.14.67.67,0,0,0-.34.09.6.6,0,0,0-.22.28,1.36,1.36,0,0,0-.07.53v1.3Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M80.74,24.24a1.7,1.7,0,0,1-.46.29,1.5,1.5,0,0,1-.47.08,1,1,0,0,1-.64-.2.64.64,0,0,1-.22-.52.81.81,0,0,1,.08-.34.64.64,0,0,1,.22-.24.87.87,0,0,1,.31-.14,1.59,1.59,0,0,1,.38-.07A3.3,3.3,0,0,0,80.7,23v-.11a.46.46,0,0,0-.13-.37.75.75,0,0,0-.48-.14.71.71,0,0,0-.45.11.69.69,0,0,0-.21.37L79,22.75a1,1,0,0,1,.19-.43.84.84,0,0,1,.38-.26,1.83,1.83,0,0,1,.57-.08,1.52,1.52,0,0,1,.52.07.58.58,0,0,1,.43.48,2.67,2.67,0,0,1,0,.4v.57a4.7,4.7,0,0,0,0,.75,1,1,0,0,0,.11.3h-.45A1.08,1.08,0,0,1,80.74,24.24Zm0-1a2.84,2.84,0,0,1-.7.16,1.18,1.18,0,0,0-.37.09.37.37,0,0,0-.17.13.39.39,0,0,0-.06.21.37.37,0,0,0,.13.28.53.53,0,0,0,.38.12,1,1,0,0,0,.44-.11.68.68,0,0,0,.28-.3.87.87,0,0,0,.07-.42Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M82.8,24.17l.06.38h-.32a.64.64,0,0,1-.36-.08.34.34,0,0,1-.18-.19,1.4,1.4,0,0,1-.06-.5V22.37h-.31v-.29h.31v-.62l.43-.26v.88h.43v.34h-.43v1.47a1,1,0,0,0,0,.24.3.3,0,0,0,.08.08h.14Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M83.29,21.57v-.49h.42v.5Zm0,3V22.08h.42V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M84.24,23.29a1.3,1.3,0,0,1,.39-1,1.17,1.17,0,0,1,.8-.28,1.12,1.12,0,0,1,.85.34,1.29,1.29,0,0,1,.33.94,1.67,1.67,0,0,1-.15.76,1.11,1.11,0,0,1-.42.44,1.31,1.31,0,0,1-.61.15,1.11,1.11,0,0,1-.86-.34A1.3,1.3,0,0,1,84.24,23.29Zm.44,0a1,1,0,0,0,.22.73.65.65,0,0,0,.53.24A.68.68,0,0,0,86,24a1.09,1.09,0,0,0,.21-.74,1.06,1.06,0,0,0-.21-.71.71.71,0,0,0-.53-.24.65.65,0,0,0-.53.24,1,1,0,0,0-.19.72Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M87.24,24.55V22.08h.38v.36a.89.89,0,0,1,.8-.41.88.88,0,0,1,.42.08.56.56,0,0,1,.29.21.8.8,0,0,1,.13.32,2.81,2.81,0,0,1,0,.41V24.6h-.43V23a1.27,1.27,0,0,0,0-.39.46.46,0,0,0-.18-.21.53.53,0,0,0-.3-.07.64.64,0,0,0-.47.17.87.87,0,0,0-.2.66v1.37Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M93.94,23.33l.46.12a1.6,1.6,0,0,1-.52.87,1.46,1.46,0,0,1-.92.29,1.65,1.65,0,0,1-.92-.22,1.54,1.54,0,0,1-.54-.67,2.48,2.48,0,0,1-.18-.93,1.94,1.94,0,0,1,.21-.95,1.41,1.41,0,0,1,.59-.62A1.77,1.77,0,0,1,93,21a1.36,1.36,0,0,1,1.38,1l-.46.11a.89.89,0,0,0-.93-.73,1.14,1.14,0,0,0-.67.19,1,1,0,0,0-.38.52,2.19,2.19,0,0,0-.11.67,2.27,2.27,0,0,0,.13.77,1,1,0,0,0,.41.5,1.11,1.11,0,0,0,.59.16,1,1,0,0,0,.65-.22A1.19,1.19,0,0,0,93.94,23.33Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M94.82,23.29a1.3,1.3,0,0,1,.39-1A1.14,1.14,0,0,1,96,22a1.12,1.12,0,0,1,.85.34,1.29,1.29,0,0,1,.33.94,1.8,1.8,0,0,1-.14.76,1.07,1.07,0,0,1-.43.44,1.31,1.31,0,0,1-.61.15,1.09,1.09,0,0,1-.85-.34A1.3,1.3,0,0,1,94.82,23.29Zm.44,0a1.06,1.06,0,0,0,.21.73.71.71,0,0,0,1,.06l.06-.06a1.09,1.09,0,0,0,.21-.74,1.06,1.06,0,0,0-.21-.71.71.71,0,0,0-1-.06l-.06.06a1.09,1.09,0,0,0-.23.72Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M97.75,24.55V22.08h.39v.36a.89.89,0,0,1,.8-.41,1,1,0,0,1,.42.08.58.58,0,0,1,.28.21.77.77,0,0,1,.14.32,2.81,2.81,0,0,1,0,.41V24.6h-.43V23a.86.86,0,0,0,0-.39.39.39,0,0,0-.17-.21.63.63,0,0,0-.3-.07.64.64,0,0,0-.47.17.83.83,0,0,0-.2.66v1.37Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M100.35,23.8l.43-.06a.56.56,0,0,0,.19.38.85.85,0,0,0,.9,0,.35.35,0,0,0,.14-.28.28.28,0,0,0-.13-.23,1.41,1.41,0,0,0-.44-.14,3.79,3.79,0,0,1-.65-.21.69.69,0,0,1-.27-.24.63.63,0,0,1,0-.65.61.61,0,0,1,.21-.24A.66.66,0,0,1,101,22a1.15,1.15,0,0,1,.37,0,1.32,1.32,0,0,1,.52.08.86.86,0,0,1,.33.23.93.93,0,0,1,.15.39l-.42.06a.43.43,0,0,0-.16-.3.6.6,0,0,0-.39-.11.76.76,0,0,0-.42.09.31.31,0,0,0-.12.23.21.21,0,0,0,0,.15.31.31,0,0,0,.16.12l.38.11c.21.05.42.12.63.19a.7.7,0,0,1,.28.23.68.68,0,0,1,0,.77.79.79,0,0,1-.36.29,1.22,1.22,0,0,1-.53.1,1.17,1.17,0,0,1-.75-.2A1,1,0,0,1,100.35,23.8Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M104.68,24.55v-.37a.93.93,0,0,1-.8.43,1.2,1.2,0,0,1-.42-.08.7.7,0,0,1-.29-.22A1,1,0,0,1,103,24a2.54,2.54,0,0,1,0-.39V22.08h.43v1.4a1.7,1.7,0,0,0,0,.45.41.41,0,0,0,.17.27.59.59,0,0,0,.32.09.74.74,0,0,0,.36-.09.57.57,0,0,0,.24-.27,1.21,1.21,0,0,0,.07-.5V22.08h.43V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M105.79,24.55V21.08h.45v3.48Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M107.88,24.17l.06.38h-.32a.64.64,0,0,1-.36-.08.44.44,0,0,1-.19-.19,1.67,1.67,0,0,1,0-.5V22.37h-.31v-.29H107v-.62l.43-.26v.88h.43v.34h-.43v1.47a1,1,0,0,0,0,.24.27.27,0,0,0,.07.08h.15Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M108.37,21.57v-.49h.42v.5Zm0,3V22.08h.42V24.6Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M109.51,24.55V22.08h.39v.36a.89.89,0,0,1,.8-.41,1,1,0,0,1,.42.08.58.58,0,0,1,.28.21.77.77,0,0,1,.14.32,2.81,2.81,0,0,1,0,.41V24.6h-.43V23a.86.86,0,0,0,0-.39.39.39,0,0,0-.17-.21.63.63,0,0,0-.3-.07.64.64,0,0,0-.47.17.87.87,0,0,0-.2.66v1.37Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M112.24,24.76l.41.07a.43.43,0,0,0,.15.28.73.73,0,0,0,.43.11.83.83,0,0,0,.46-.11.57.57,0,0,0,.22-.34,2.53,2.53,0,0,0,0-.55.9.9,0,0,1-.7.33.93.93,0,0,1-.8-.37,1.47,1.47,0,0,1-.29-.9,1.7,1.7,0,0,1,.13-.67,1,1,0,0,1,.38-.47,1,1,0,0,1,.58-.16.89.89,0,0,1,.74.36v-.26h.39v2.18a2.06,2.06,0,0,1-.1.82.89.89,0,0,1-.38.39,1.3,1.3,0,0,1-.64.14,1.26,1.26,0,0,1-.73-.2A.7.7,0,0,1,112.24,24.76Zm.35-1.51a1.08,1.08,0,0,0,.2.72.65.65,0,0,0,.92.08l.08-.08a1.06,1.06,0,0,0,.19-.71,1,1,0,0,0-.2-.7.66.66,0,0,0-.5-.23.63.63,0,0,0-.48.23,1,1,0,0,0-.24.69Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M119,23.33l.47.12a1.53,1.53,0,0,1-.53.87,1.46,1.46,0,0,1-.92.29,1.62,1.62,0,0,1-.91-.22,1.48,1.48,0,0,1-.54-.67,2.48,2.48,0,0,1-.18-.93,1.94,1.94,0,0,1,.21-.95,1.36,1.36,0,0,1,.59-.62A1.77,1.77,0,0,1,118,21a1.36,1.36,0,0,1,1.38,1l-.46.11a1.14,1.14,0,0,0-.35-.56,1,1,0,0,0-.58-.17,1.14,1.14,0,0,0-.67.19,1,1,0,0,0-.38.52,2.19,2.19,0,0,0-.11.67,2.27,2.27,0,0,0,.13.77,1,1,0,0,0,.41.5,1.11,1.11,0,0,0,.59.16,1,1,0,0,0,.65-.22A1.11,1.11,0,0,0,119,23.33Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M119.9,23.29a1.3,1.3,0,0,1,.39-1,1.14,1.14,0,0,1,.79-.28,1.12,1.12,0,0,1,.85.34,1.29,1.29,0,0,1,.33.94,1.67,1.67,0,0,1-.15.76,1,1,0,0,1-.42.44,1.31,1.31,0,0,1-.61.15,1.16,1.16,0,0,1-.86-.34A1.37,1.37,0,0,1,119.9,23.29Zm.44,0a1.06,1.06,0,0,0,.21.73.71.71,0,0,0,1,.06l.06-.06a1.09,1.09,0,0,0,.21-.74,1.06,1.06,0,0,0-.21-.71.71.71,0,0,0-1-.06l-.06.06A1.09,1.09,0,0,0,120.34,23.29Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M123,24.55v-.47h.49v.48Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M124.36,24.55v-.47h.49v.48a.84.84,0,0,1-.1.44.57.57,0,0,1-.3.25l-.12-.18a.41.41,0,0,0,.2-.17.8.8,0,0,0,.07-.34Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M125.7,24.55V21.08h.46v3.07h1.72v.41Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M129.37,24.17l.07.38h-.33a.76.76,0,0,1-.36-.08.41.41,0,0,1-.18-.19,1.67,1.67,0,0,1,0-.5V22.37h-.28v-.29h.31v-.62l.42-.26v.88h.43v.34H129v1.47a.49.49,0,0,0,0,.24.18.18,0,0,0,.07.08h.15Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M131.5,24.55v-.31a.8.8,0,0,1-.71.37,1,1,0,0,1-.55-.16,1.21,1.21,0,0,1-.4-.47,1.59,1.59,0,0,1-.13-.68,2,2,0,0,1,.12-.69,1,1,0,0,1,.94-.63,1,1,0,0,1,.41.09,1,1,0,0,1,.29.25V21.08h.42v3.48Zm-1.36-1.25a1.09,1.09,0,0,0,.21.72.61.61,0,0,0,.85.15.54.54,0,0,0,.15-.15,1,1,0,0,0,.19-.7,1.2,1.2,0,0,0-.2-.76.63.63,0,0,0-.49-.24.58.58,0,0,0-.47.23A1.13,1.13,0,0,0,130.14,23.3Z" transform="translate(0 -0.01)"/><path class="cls-1" d="M132.75,24.55v-.47h.49v.48Z" transform="translate(0 -0.01)"/>
      </svg>
    </div>
    <span class="footer-coop-x" aria-hidden="true">×</span>
    <div class="footer-brand-logo footer-brand-demora" aria-label="Demora">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 32" fill="none">
        <g transform="translate(0, 2)">
          <rect x="4" y="0" width="12" height="6" rx="3" fill="#14B8A6" opacity="0.4"/>
          <rect x="6" y="11" width="20" height="6" rx="3" fill="#14B8A6" opacity="0.7"/>
          <rect x="0" y="22" width="36" height="6" rx="3" fill="#14B8A6"/>
        </g>
        <text x="48" y="23" font-family="Inter, -apple-system, sans-serif" font-weight="700" font-size="20" fill="#F5F5F7">Demora</text>
      </svg>
    </div>
  </div>
  <p class="footer-copyright">
    © 2026 Ourchem × Demora · 保留所有权利
  </p>
</div>
`;

  // v5.7：受众 Tab 切换 JS（含 localStorage 记忆）
  body += `
<script>
// v5.20.2（UAT 四轮 U-A）：TOC 受众过滤全局函数——顶部 anchor-nav 与左侧 tocSidebar 双覆盖
//   根因（codex-p10 实证）：左侧 TOC 在后续 IIFE 动态生成且全量列出全部章节，
//   v5.20.1 联动只过滤 .anchor-nav；且 localStorage 恢复偏好的联动先于左侧 TOC 生成执行而空转
//   → PM 视图下左侧 TOC 仍显示「研发文档」「数据模型」等隐藏章节链接；
//   研发视图下「PM 原始需求」链接显示但章节隐藏 → 点击无反应（锚点跳转到不可见 section）
window.__demoraSyncTocAudience = function() {
  document.querySelectorAll('.anchor-nav a[href^="#"], #tocSidebar a[data-toc-target]').forEach(function(link) {
    var href = link.getAttribute('href') || ('#' + (link.getAttribute('data-toc-target') || ''));
    var target = href.length > 1 ? document.getElementById(href.slice(1)) : null;
    link.style.display = (target && getComputedStyle(target).display === 'none') ? 'none' : '';
  });
};
(function() {
  // 受众 Tab 切换：通过 body.className 控制 section[data-audience] 显示
  var tabs = document.querySelectorAll('.tab-btn');
  var STORAGE_KEY = 'demora-audience-preference';

  function applyAudience(audience) {
    // 移除所有 audience-* class
    document.body.className = document.body.className.replace(/\\baudience-\\w+\\b/g, '').trim();
    if (audience !== 'all') {
      document.body.classList.add('audience-' + audience);
    }
    // 更新 Tab active 状态
    tabs.forEach(function(tab) {
      if (tab.dataset.audience === audience) {
        tab.classList.add('active');
      } else {
        tab.classList.remove('active');
      }
    });
    // v5.20.1（UAT 三轮 U18-A）+ v5.20.2（UAT 四轮 U-A）：TOC 联动受众过滤——
    //   目标 section 在当前受众视图下隐藏时，对应 TOC 链接（顶部 + 左侧）同步隐藏
    if (typeof window.__demoraSyncTocAudience === 'function') {
      window.__demoraSyncTocAudience();
    }
    // 记忆用户偏好
    try { localStorage.setItem(STORAGE_KEY, audience); } catch (e) {}
  }

  tabs.forEach(function(tab) {
    tab.addEventListener('click', function() {
      applyAudience(tab.dataset.audience);
    });
  });

  // 恢复上次偏好
  try {
    var saved = localStorage.getItem(STORAGE_KEY);
    // v5.9：移除 'test' 受众（仅保留 全部/PM/研发）
    if (saved && ['all', 'pm', 'dev'].indexOf(saved) >= 0) {
      applyAudience(saved);
    }
  } catch (e) {}
})();
</script>
`;
  body += genHtmlFooter();
  return body;
}

// ============================================================================
// S4: 4 个子页面重定向存根
// ============================================================================

/**
 * 生成重定向存根 HTML
 * @param {string} anchor - 目标锚点（如 "#pages"）
 * @param {string} title - 页面标题（用于 <title>）
 * @param {string} projectName - 项目名
 * @returns {string} 重定向 HTML
 */
function genRedirectStub(anchor, title, projectName) {
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>${esc(title)} - ${esc(projectName)} 产品文档</title>
<meta http-equiv="refresh" content="0; url=index.html${anchor}">
<script>window.location.href = 'index.html${anchor}';</script>
<style>body { font-family: Inter, sans-serif; background: #070708; color: #F5F5F7; padding: 40px; text-align: center; } a { color: #14B8A6; }</style>
</head>
<body>
<p>已重构为单页 PRD，正在跳转到 <a href="index.html${anchor}">${esc(title)}</a>...</p>
</body>
</html>
`;
}

/**
 * 生成 4 个子页面重定向存根
 */
function genRedirectStubs(model) {
  const project = model.project || { name: 'Demo' };
  return [
    {
      name: 'product-overview.html',
      // v5.9：metadata 章节已删除，重定向到 #tldr（摘要）
      content: genRedirectStub('#tldr', '产品概览', project.name),
      title: '产品概览（已重定向）',
    },
    {
      name: 'page-spec.html',
      content: genRedirectStub('#pages', '页面规格', project.name),
      title: '页面规格（已重定向）',
    },
    {
      name: 'data-model.html',
      content: genRedirectStub('#data', '数据模型', project.name),
      title: '数据模型（已重定向）',
    },
    {
      name: 'role-permission.html',
      content: genRedirectStub('#roles', '角色权限', project.name),
      title: '角色权限（已重定向）',
    },
  ];
}

// ============================================================================
// v5.19 P034: Mermaid 渲染自检（index.html 写盘后校验所有 mermaid 块可渲染）
// 背景：此前 9/10 案例 BPMN 风格块（>{{ 等语法）渲染失败无人发现，交付后图缺失
// ============================================================================

/**
 * v5.19 P034：加载本地 mermaid（node 环境）用于 parse 语法校验
 * 候选路径（按序尝试）：
 *   1. skill 包 assets/mermaid/mermaid.min.js — 与 main step 5.0 复制来源一致
 *      （打包后布局：<skill>/scripts/ + <skill>/assets/mermaid/）
 *   2. 源码仓库 src/assets/mermaid/mermaid.min.js — 开发环境直接运行时的布局
 *      （本文件位于 src/templates/skill-template/scripts/，上溯 3 级到 src/）
 * 加载方式：vm.runInThisContext 在全局作用域执行。
 *   注意：本仓库的 mermaid.min.js 为 esbuild 打包格式（非标准 UMD）—
 *   主体挂载到顶层 var __esbuild_esm_mermaid_nm，末尾桥接行
 *   `globalThis["mermaid"] = globalThis.__esbuild_esm_mermaid_nm["mermaid"].default`。
 *   若用 new Function 包裹执行，var 为局部变量、globalThis 上取不到 → TypeError；
 *   故必须全局作用域执行（var 落到 globalThis），随后读取 globalThis.mermaid。
 * @returns {object|null} mermaid 命名空间（含 parse），不可寻址/加载失败返回 null
 */
function loadMermaidForSelfCheck() {
  const candidates = [
    path.join(__dirname, '..', 'assets', 'mermaid', 'mermaid.min.js'),
    path.join(__dirname, '..', '..', '..', 'assets', 'mermaid', 'mermaid.min.js'),
  ];
  for (const p of candidates) {
    if (!fs.existsSync(p)) continue;
    try {
      const code = fs.readFileSync(p, { encoding: 'utf-8' });
      // v5.23：mermaid.min.js 内置 dompurify 在 node 无 DOM 环境初始化失效，
      // parse 时对任何带引号 label 的块抛 "TypeError: addHook is not a function"，
      // 真实语法错误被降级漏检。执行前注入最小 DOMPurify stub（不覆盖已有全局），
      // 恢复 parse 真实语法校验（jison 错误正则可命中）；若 stub 不生效，
      // 错误仍走 mermaidBlacklistCheck 黑名单兜底（现含引号平衡检查）
      if (!globalThis.DOMPurify) {
        globalThis.DOMPurify = {
          addHook: function () {},
          removeHook: function () {},
          sanitize: function (dirty) { return dirty; },
          isSupported: true,
        };
      }
      vm.runInThisContext(code);
      const mermaid = globalThis.mermaid;
      if (mermaid && typeof mermaid.parse === 'function') {
        return mermaid;
      }
    } catch (e) {
      // 该候选路径加载失败，继续尝试下一候选
    }
  }
  return null;
}

/**
 * v5.19 P034：语法黑名单自检（mermaid.min.js 不可寻址时的降级方案）
 * 黑名单：`>{{`（BPMN 风格标签，mermaid 不支持）、空标签 `[]`、行尾尾随 `-->`
 * v5.23：新增行内双引号奇偶检查（边标签 |"…"| 缺闭合引号）——
 * 缺陷背景：node 无 DOM 环境下 mermaid 内置 dompurify 缺 addHook，parse 对
 * 带引号 label 的块（无论语法对错）抛 TypeError 而被降级到本黑名单，
 * `P04 -->|"生成报告| P05`（缺右引号）类真实缺陷曾漏检。
 * 跳过 %% 注释行；局限：块级引号注释（""" / ''' 分隔行）未处理，
 * 此类行含奇数双引号会误报（实际生成场景极少使用）
 * @param {string} text - mermaid 块源码
 * @returns {string|null} 错误描述；通过返回 null
 */
function mermaidBlacklistCheck(text) {
  if (text.includes('>{{')) return '包含 mermaid 不支持的 ">{{" 标签';
  if (text.includes('[]')) return '包含空标签 "[]"';
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].trim().endsWith('-->')) {
      return '第 ' + (i + 1) + ' 行尾随 "-->"（缺少目标节点）';
    }
    // v5.23：引号平衡检查（跳过 %% 注释行；块级引号注释 """ / ''' 未处理）
    if (lines[i].trim().startsWith('%%')) continue;
    const dq = (lines[i].match(/"/g) || []).length;
    if (dq % 2 === 1) {
      return '第 ' + (i + 1) + ' 行双引号数量为奇数（疑似缺失闭合引号）';
    }
  }
  return null;
}

/**
 * v5.19 P034：提取 mermaid 块首个非空行作为上下文片段（截断 40 字符）
 */
function mermaidSnippet(text) {
  const firstLine = (text.split('\n').find(l => l.trim() !== '') || '').trim();
  return '"' + (firstLine.length > 40 ? firstLine.slice(0, 40) + '...' : firstLine) + '"';
}

/**
 * v5.19 P034：mermaid 渲染自检主函数（index.html 写盘后调用）
 * 1. 提取所有 <div class="mermaid">…</div> 块内文
 * 2. mermaid.min.js 可加载时逐块 mermaid.parse（异步）；不可寻址时降级为语法黑名单自检并说明原因
 * 3. 任一块失败：console.error('[FAIL] P034 ...') 且 process.exitCode = 1；全部通过打印一行 OK
 * @param {string} htmlContent - index.html 全文
 * @returns {Promise<boolean>} 全部通过返回 true
 */
async function selfCheckMermaidRendering(htmlContent) {
  const blocks = [];
  const re = /<div class="mermaid">([\s\S]*?)<\/div>/g;
  let m;
  while ((m = re.exec(htmlContent)) !== null) {
    blocks.push(m[1].trim());
  }
  if (blocks.length === 0) {
    process.stdout.write('  [OK] P034 mermaid 渲染自检: 未发现 mermaid 块，跳过\n');
    return true;
  }

  const mermaid = loadMermaidForSelfCheck();
  let failCount = 0;

  if (!mermaid) {
    process.stdout.write('  [WARN] P034 mermaid 渲染自检: mermaid.min.js 不可寻址（skill assets 与 src/assets 均未命中或加载失败），降级为语法黑名单自检(含引号平衡检查)\n');
    for (let i = 0; i < blocks.length; i++) {
      const err = mermaidBlacklistCheck(blocks[i]);
      if (err) {
        failCount++;
        console.error('[FAIL] P034 mermaid 渲染自检: 第 ' + (i + 1) + ' 块 ' + mermaidSnippet(blocks[i]) + ' ' + err);
        process.exitCode = 1;
      }
    }
    if (failCount === 0) {
      process.stdout.write('  [OK] P034 mermaid 渲染自检(降级黑名单): ' + blocks.length + '/' + blocks.length + ' 块通过\n');
    }
    return failCount === 0;
  }

  for (let i = 0; i < blocks.length; i++) {
    const text = blocks[i];
    try {
      await mermaid.parse(text);
    } catch (e) {
      const msg = e && e.message ? String(e.message) : String(e);
      // jison 语法错误特征（真实渲染必失败）→ FAIL
      if (/Parse error on line|Expecting '|No diagram type detected/.test(msg)) {
        failCount++;
        console.error('[FAIL] P034 mermaid 渲染自检: 第 ' + (i + 1) + ' 块 ' + mermaidSnippet(text) + ' ' + msg.split('\n')[0]);
        process.exitCode = 1;
      } else {
        // 环境限制错误（如 node 无 DOM 时 mermaid 内置 dompurify 缺 addHook，
        // 带引号 label 的合法块 parse 时触发 TypeError）→ 该块退回黑名单自检，避免误报
        const err = mermaidBlacklistCheck(text);
        if (err) {
          failCount++;
          console.error('[FAIL] P034 mermaid 渲染自检: 第 ' + (i + 1) + ' 块 ' + mermaidSnippet(text) + ' ' + err + '（parse 环境受限，黑名单兜底命中）');
          process.exitCode = 1;
        }
      }
    }
  }
  if (failCount === 0) {
    process.stdout.write('  [OK] P034 mermaid 渲染自检: ' + blocks.length + '/' + blocks.length + ' 块 parse 通过\n');
  }
  return failCount === 0;
}

// ============================================================================
// 主入口
// ============================================================================

/**
 * 从 .demora/model-lock.yaml 抽取 Skill 版本
 */
function extractSkillVersion(root) {
  const lockFile = path.join(root, '.demora', 'model-lock.yaml');
  if (fs.existsSync(lockFile)) {
    const t = fs.readFileSync(lockFile, { encoding: 'utf-8' });
    const m = t.match(/^skillName:\s*(.+)$/m);
    if (m) return m[1].trim();
  }
  return 'oc-demora';
}

export function main(args = {}) {
  const root = args.root || process.cwd();

  process.stdout.write('======================================================================\n');
  process.stdout.write('HTML 产品文档生成（v5.6 单页 PRD）\n');
  process.stdout.write('======================================================================\n');

  // 1. 读取需求模型
  const modelFile = path.join(root, '.demora', 'requirement-model.yaml');
  if (!fs.existsSync(modelFile)) {
    process.stderr.write('[FAIL] 需求模型不存在: ' + modelFile + '\n');
    process.exit(1);
  }

  const text = fs.readFileSync(modelFile, { encoding: 'utf-8' });
  let model;
  try {
    model = parseYAML(text);
  } catch (e) {
    process.stderr.write('[FAIL] 需求模型解析失败: ' + e.message + '\n');
    process.exit(1);
  }

  const entities = model.entities || [];
  const pages = model.pages || [];
  const roles = model.roles || [];
  const project = model.project || { name: 'Demo', description: '', domain: 'APP' };

  process.stdout.write('  [INFO] 项目: ' + project.name + '\n');
  process.stdout.write('  [INFO] 实体: ' + entities.length + ' 个\n');
  process.stdout.write('  [INFO] 页面: ' + pages.length + ' 个\n');
  process.stdout.write('  [INFO] 角色: ' + roles.length + ' 个\n');

  // 2. 准备生成参数
  const skillVersion = extractSkillVersion(root);
  const generatedAt = new Date().toISOString().slice(0, 10);

  // 3. 检查 markdown PRD 是否存在（用于叙事内容）
  const prdDir = path.join(root, 'docs', 'prd');
  if (fs.existsSync(prdDir)) {
    const prdMdFiles = fs.readdirSync(prdDir).filter(f => f.endsWith('.md'));
    process.stdout.write('  [INFO] PRD markdown: ' + prdMdFiles.length + ' 个文件\n');
  } else {
    process.stdout.write('  [WARN] docs/prd/ 目录不存在，业务背景/痛点等叙事章节将显示"暂未生成"\n');
  }

  // 4. 检查 PM 原始需求是否存在
  const inputFile = path.join(root, 'inbox', 'text', 'requirement-input.md');
  if (fs.existsSync(inputFile)) {
    const stat = fs.statSync(inputFile);
    process.stdout.write('  [INFO] PM 原始需求: ' + stat.size + ' bytes\n');
  } else {
    process.stdout.write('  [WARN] inbox/text/requirement-input.md 不存在，PM 原始需求章节将显示"暂未提供"\n');
  }

  // 5. 生成 HTML 文档到 docs/ 目录
  const docsDir = path.join(root, 'docs');
  if (!fs.existsSync(docsDir)) {
    fs.mkdirSync(docsDir, { recursive: true });
  }

  // 5.0 v5.7 新增：复制 mermaid 资产到 docs/assets/mermaid/
  //     源：skill 包 assets/mermaid/（mermaid.min.js + mermaid-init.js）
  //     目标：sim-project/docs/assets/mermaid/
  //     说明：docs/index.html 通过 <script src="assets/mermaid/mermaid.min.js"> 引用，
  //          资产必须与 index.html 同级（docs/assets/mermaid/）
  const mermaidSrcDir = path.join(__dirname, '..', 'assets', 'mermaid');
  const mermaidDstDir = path.join(docsDir, 'assets', 'mermaid');
  if (fs.existsSync(mermaidSrcDir)) {
    if (!fs.existsSync(mermaidDstDir)) fs.mkdirSync(mermaidDstDir, { recursive: true });
    let mermaidCount = 0;
    for (const fname of fs.readdirSync(mermaidSrcDir)) {
      const sFull = path.join(mermaidSrcDir, fname);
      const dFull = path.join(mermaidDstDir, fname);
      if (fs.statSync(sFull).isFile()) {
        fs.copyFileSync(sFull, dFull);
        mermaidCount++;
      }
    }
    process.stdout.write('  [OK] 复制 mermaid 资产: ' + mermaidCount + ' 文件 -> docs/assets/mermaid/\n');
  } else {
    process.stdout.write('  [WARN] skill 包 assets/mermaid/ 不存在，docs/index.html 中的 Mermaid 图将无法渲染\n');
    process.stdout.write('       预期位置: ' + mermaidSrcDir + '\n');
  }

  // 5.1 主单页 PRD
  const indexHtml = genIndexHtml(model, root, generatedAt, skillVersion);
  const indexPath = path.join(docsDir, 'index.html');
  fs.writeFileSync(indexPath, indexHtml, { encoding: 'utf-8' });
  const indexSize = fs.statSync(indexPath).size;
  process.stdout.write('  [OK] 生成 index.html（单页 PRD，' + (indexSize / 1024).toFixed(2) + ' KB）\n');

  // v5.19 P034：mermaid 渲染自检（异步执行；失败块已在内部 console.error 并置 process.exitCode = 1）
  const selfCheckPromise = selfCheckMermaidRendering(indexHtml);
  selfCheckPromise.catch(function () { /* 失败处理已由自检内部完成 */ });

  // 5.2 4 个重定向存根
  const stubs = genRedirectStubs(model);
  for (const s of stubs) {
    const filePath = path.join(docsDir, s.name);
    fs.writeFileSync(filePath, s.content, { encoding: 'utf-8' });
    process.stdout.write('  [OK] 生成 ' + s.name + '（重定向存根）\n');
  }

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] HTML 产品文档生成汇总（v5.6 单页 PRD）\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write('  输出目录: docs/\n');
  // v5.19 P2-7 + P0-2：章节 10 → 12（业务流程拆分 +1、研发文档 +1）
  process.stdout.write('  主文档:  docs/index.html（单页 PRD，12 章节 + 锚点导航）\n');
  process.stdout.write('  重定向存根: 4 个（product-overview/page-spec/data-model/role-permission.html）\n');
  process.stdout.write('  业界对标: Lenny\'s 1-Pager + Notion Ultimate PRD\n');
  process.stdout.write('\n>>> HTML 产品文档生成完成\n');

  return { ok: true, docCount: 1 + stubs.length, docsDir, indexSize, selfCheckPromise };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  const result = main();
  // v5.19 P034：等待自检 Promise 完成后再退出（自检失败已置 process.exitCode = 1）
  if (result && result.selfCheckPromise && typeof result.selfCheckPromise.then === 'function') {
    result.selfCheckPromise.then(function () { /* 输出与退出码已在自检内部处理 */ });
  }
}
