/* ============================================================
 * annotation-engine.js — 自包含标注引擎（v5.2.3）
 *
 * v5.2.3 变更（覆盖完整性与页面名称）：
 *   - renderPanel() 的 page-id-tag 显示 "P01 - 页面中文名称"（从 page.name 字段读取）
 *     修复标注面板头部仅显示页面编号无中文名称的问题
 *   - 新增 hasVisibleInteractiveChild()：检查 data-element-id 容器内是否有可见的实际交互元件
 *     （button/input/select/textarea/a/[role=button]/[contenteditable]）
 *   - renderL3List() 增强：当 data-element-id 容器可见但内部实际元件全隐藏时（如按钮按状态
 *     display:none），不渲染 L3 卡片，修复"有标注图标但无元件"的困惑
 *   - isElementVisible() 增强：对 [data-element-id] 容器，若内部实际交互元件全不可见，
 *     则认为该 L3 标注不可见
 *
 * v5.2.2 变更（标注一致性修正）：
 *   - 新增 getAnnotationPages()：兼容 {P01:{...}} 与 {version,pages:{P01:{...}}} 两种数据结构
 *     修复 audit-hr-v5.2 等"标注面板没有内容"问题
 *   - renderL2List/renderL3List 改为过滤不可见标注（不再显示灰色"当前不可见"卡片）
 *     严格保持标注面板与页面可视区域一致
 *   - 过滤后为空时显示"当前可视区域内无 L2/L3 标注"
 *   - scheduleVisibilityRefresh 延迟从 300ms 降至 100ms，提升响应速度
 *   - detectCurrentPage 从 pages 结构推断页面 ID
 *
 * v5.2.0 变更（标注一致性修复）：
 *   - 新增 isElementVisible()：检查元素及其祖先的 display/visibility/opacity/hidden
 *   - detectCurrentPage() 优先选择可见的 [data-page-id] 元素（SPA 多页面场景）
 *   - highlightZone/highlightElement 先 renderPanel() 确保卡片渲染再高亮
 *   - focusZoneCard/focusElementCard 先 renderPanel() 确保卡片存在再滚动
 *   - 全局 click 监听：tab/页面切换后延迟刷新面板可见性
 *   - refresh() API 增强：重新检测页面 + 重新渲染
 *
 * 设计理念：
 *   标注系统作为"独立叠加层"，通过 data-* 属性约定与 AI 生成的 HTML 对接。
 *   AI 不需要在 JS 中引入任何标注相关代码，不需要 mixin/插件/全局状态。
 *
 * 工作方式：
 *   1. AI 在 HTML 元素上添加 data-zone-id="R-001" / data-element-id="C-001" 属性
 *   2. AI 在页面中放置标注数据：window.__ANNOTATION_DATA__ = { ... }
 *   3. 本引擎在 DOMContentLoaded 后自动扫描 data-* 属性，构建标注 UI 并绑定交互
 *
 * 注入方式（enhance-prototype.mjs 执行）：
 *   - 注入 annotation-styles.css 到 <head>
 *   - 注入 annotation-panel.html 到 <body> 末尾
 *   - 注入本文件 annotation-engine.js 到 <body> 末尾
 *
 * AI 代码零侵入：
 *   - 不需要全局状态对象 / mixin / 框架响应式
 *   - 不需要在 setup() 中引入标注变量
 *   - 只需在 HTML 元素上加 data-* 属性 + 定义标注数据对象
 *
 * 依赖：无（纯 vanilla JS，不依赖 Vue/React 等框架）
 * 版本：5.2.3
 * ============================================================ */

(function () {
  'use strict';

  // ==========================================
  // 1. 状态管理
  // ==========================================

  var state = {
    showPanel: false,
    activeTab: 'L1',
    activePageId: null,
    highlightedZone: null,
    highlightedElement: null,
    annotationData: {},
    currentPageZones: [],
    currentPageElements: [],
    suppressRefresh: 0  // v5.2.5：用户主动高亮后抑制 refresh 的时间戳
  };

  // DOM 引用缓存
  var dom = {
    panel: null,
    panelHeader: null,
    panelTabs: null,
    panelBody: null,
    toggleBtn: null,
    contentRoot: null,
    shadowRoot: null  // v5.1：Shadow DOM 根（面板在 Shadow DOM 内）
  };

  // v5.2：可见性刷新 debounce 定时器
  var visibilityRefreshTimer = null;

  // ==========================================
  // 1.1 数据结构兼容（v5.2.2 新增）
  // ==========================================

  /**
   * v5.2.2：从 __ANNOTATION_DATA__ 中提取页面映射对象
   * 兼容两种数据结构：
   *   结构 A（扁平）：{ P01: {...}, P02: {...} }
   *   结构 B（包装）：{ version: "5.2.0", pages: { P01: {...}, P02: {...} } }
   * @returns {Object} 页面 ID 到页面标注数据的映射
   */
  function getAnnotationPages() {
    var data = state.annotationData;
    if (!data || typeof data !== 'object') return {};
    // 结构 B：存在 data.pages 且是对象
    if (data.pages && typeof data.pages === 'object' && !Array.isArray(data.pages)) {
      return data.pages;
    }
    // 结构 A：过滤掉非页面字段（如 version），只保留以 P 开头或全大写的 key
    var result = {};
    var keys = Object.keys(data);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      // 页面 ID 通常以 P 开头（如 P01, P02），或至少不含 version/pages/metadata 等保留字
      if (k === 'version' || k === 'pages' || k === 'metadata' || k === 'config') continue;
      if (data[k] && typeof data[k] === 'object') {
        result[k] = data[k];
      }
    }
    return result;
  }

  // ==========================================
  // 2. 初始化
  // ==========================================

  function init() {
    // v5.13.4: 双视角切换 — URL 参数 ?annotations=0 为客户视角（无标注），?annotations=1 为产研视角（有标注，默认）
    // 用途：delivery demo 兼容产研沟通（需标注）与客户沟通（不需标注）两种场景
    var urlParams = new URLSearchParams(window.location.search);
    var annotationsParam = urlParams.get('annotations');
    state.clientMode = (annotationsParam === '0');

    // 读取标注数据
    if (window.__ANNOTATION_DATA__) {
      state.annotationData = window.__ANNOTATION_DATA__;
    }

    // v5.1：通过 Shadow DOM 宿主查找面板
    var host = document.getElementById('demora-annotation-host');
    if (host && host.shadowRoot) {
      dom.shadowRoot = host.shadowRoot;
      dom.panel = dom.shadowRoot.querySelector('.annotation-panel');
    } else {
      // 向后兼容：无 Shadow DOM 宿主时回退到 document 查找
      dom.panel = document.querySelector('.annotation-panel');
    }

    dom.contentRoot = document.querySelector('[data-annotation-root]') || document.body;

    if (!dom.panel) {
      console.warn('[annotation-engine] 未找到 .annotation-panel，标注系统未初始化');
      return;
    }

    // 面板内元素通过 dom.panel 查找
    dom.panelHeader = dom.panel.querySelector('.panel-header');
    dom.panelTabs = dom.panel.querySelector('.panel-tabs');
    dom.panelBody = dom.panel.querySelector('.panel-body');

    // 主页面元素：标注开关按钮
    dom.toggleBtn = document.querySelector('[data-annotation-toggle]');

    // 检测当前页面 ID
    detectCurrentPage();

    // 绑定事件
    bindEvents();

    // v5.1.1：数据校验兜底
    validateAnnotationData(state.annotationData);

    // 初始渲染
    renderPanel();

    // v5.13.4: 客户视角模式 — 隐藏标注开关，移除标注面板，完全不激活标注功能
    if (state.clientMode) {
      if (dom.toggleBtn) {
        dom.toggleBtn.style.display = 'none';
      }
      if (dom.panel) {
        dom.panel.style.display = 'none';
      }
      // 确保不设置 data-annotation-active，L2/L3 标记通过 CSS 默认 display:none 隐藏
      if (dom.contentRoot) {
        dom.contentRoot.removeAttribute('data-annotation-active');
      }
      console.log('[annotation-engine] 客户视角模式（?annotations=0），标注功能已隐藏');
      return;
    }

    // 默认隐藏面板
    setPanelVisible(false);

    // v5.1.1：MutationObserver 监听 SPA 异步渲染
    setupMutationObserver();

    console.log('[annotation-engine] 标注引擎已初始化 v5.2.4，页面:', state.activePageId, dom.shadowRoot ? '(Shadow DOM)' : '(document)');
  }

  // ==========================================
  // 2.1 元素可见性检查（v5.2 新增，v5.2.3 增强）
  // ==========================================

  /**
   * 检查元素是否在页面中实际可见
   * 遍历元素及其所有祖先，检查 display/visibility/opacity/hidden 属性
   * @param {Element} el 目标元素
   * @returns {boolean} 是否可见
   */
  function isElementVisible(el) {
    if (!el) return false;
    var current = el;
    while (current && current !== document.body) {
      // HTML hidden 属性
      if (current.hasAttribute && current.hasAttribute('hidden')) return false;
      // CSS 计算样式
      var style = window.getComputedStyle(current);
      if (style.display === 'none') return false;
      if (style.visibility === 'hidden') return false;
      if (parseFloat(style.opacity) === 0) return false;
      current = current.parentElement;
    }
    return true;
  }

  /**
   * v5.2.3 新增：检查 data-element-id 容器内是否有可见的实际交互元件
   *
   * 解决问题：AI 将 data-element-id 放在 <span> 容器上，span 内有 button 和 l3-dot。
   * 当 button 按状态 display:none 时，span 容器和 l3-dot 仍可见，导致
   * "标注面板有卡片 + 页面有 l3-dot 蓝点，但实际元件（button）被隐藏"的困惑。
   *
   * 实际交互元件选择器：
   *   button, input, select, textarea, a[href], [role="button"], [contenteditable], [tabindex]
   * 排除：.l3-dot（标注系统自身的指示器）、.l2-marker（标注系统自身的标记）
   *
   * @param {Element} container data-element-id 容器元素
   * @returns {boolean} true=有可见交互元件 / false=容器可见但内部元件全隐藏
   */
  function hasVisibleInteractiveChild(container) {
    if (!container) return false;
    var interactiveSelector = 'button, input, select, textarea, a[href], [role="button"], [contenteditable], [tabindex]';
    var candidates = container.querySelectorAll(interactiveSelector);
    if (candidates.length === 0) {
      // 容器内无交互元件（可能是卡片/标签等非交互元件）→ 视为"有内容"，返回 true
      // 避免误伤非交互型 L3 标注（如纯展示型卡片）
      return true;
    }
    for (var i = 0; i < candidates.length; i++) {
      // 排除标注系统自身的元素
      var el = candidates[i];
      if (el.classList && (el.classList.contains('l3-dot') || el.classList.contains('l2-marker'))) continue;
      if (isElementVisible(el)) return true;
    }
    return false;
  }

  /**
   * v5.2.5 新增：在所有匹配选择器的元素中找到第一个可见的
   * 修复多页面场景下 L2/L3 id 重复问题（如每个页面都有 R-001）
   * 旧逻辑 querySelector 只返回第一个匹配，当第一个匹配在隐藏页面时导致标注面板缺内容
   * @param {string} selector CSS 选择器
   * @returns {Element|null} 第一个可见的匹配元素
   */
  function findVisibleElement(selector) {
    var matches = document.querySelectorAll(selector);
    for (var i = 0; i < matches.length; i++) {
      if (isElementVisible(matches[i])) return matches[i];
    }
    return null;
  }

  /**
   * v5.2.2：调度可见性刷新（debounce 100ms，从 300ms 降低以提升响应速度）
   * 在 tab/页面切换后延迟检测页面变化和元素可见性变化，刷新面板
   * v5.2.2 变更：不可见标注直接过滤（不渲染），面板与可视区域严格一致
   * v5.2.5 变更：用户主动点击高亮后 500ms 内抑制 refresh，避免 scrollToElement 触发的闪缩
   */
  function scheduleVisibilityRefresh() {
    // v5.2.5：用户主动高亮后短时间内抑制 refresh，避免滚动触发闪缩
    if (state.suppressRefresh && Date.now() - state.suppressRefresh < 500) {
      return;
    }
    if (visibilityRefreshTimer) clearTimeout(visibilityRefreshTimer);
    visibilityRefreshTimer = setTimeout(function () {
      visibilityRefreshTimer = null;
      var oldPageId = state.activePageId;
      detectCurrentPage();
      if (oldPageId !== state.activePageId) {
        // 页面切换：清除高亮，回到 L1
        clearHighlights();
        state.activeTab = 'L1';
        renderPanel();
      } else if (state.showPanel) {
        // 同一页面内 tab 切换：重新渲染面板（过滤可见性变化后的标注）
        renderPanel();
      }
    }, 100);
  }

  // ==========================================
  // 2.2 MutationObserver + 数据校验（v5.1.1 P3-4）
  // ==========================================

  function setupMutationObserver() {
    if (typeof MutationObserver === 'undefined') {
      console.warn('[annotation-engine] MutationObserver 不可用，跳过 SPA 异步渲染监听');
      return;
    }

    var debounceTimer = null;
    var observer = new MutationObserver(function (mutations) {
      var shouldRefresh = false;
      for (var i = 0; i < mutations.length; i++) {
        var mutation = mutations[i];
        // v5.2.7：过滤标注系统自身触发的 class 变化（is-highlighted/is-active 等）
        // 原因：highlightZone/focusZoneCard 添加 is-highlighted → MutationObserver 监听 class 变化
        //       → 触发 renderPanel → renderPanel 重置 is-active 卡片 → MutationObserver 再次触发
        //       → 自反馈循环，导致右侧面板 L2 卡片"点击激活后不停闪烁"
        if (mutation.type === 'attributes' && mutation.attributeName === 'class' && mutation.target) {
          var oldVal = mutation.oldValue || '';
          var newVal = mutation.target.className || '';
          // 提取差异 class（仅在 old/new 间变化的 class）
          var oldSet = new Set(oldVal.split(/\s+/).filter(Boolean));
          var newSet = new Set(newVal.split(/\s+/).filter(Boolean));
          var diffClasses = [];
          newSet.forEach(function (c) { if (!oldSet.has(c)) diffClasses.push(c); });
          oldSet.forEach(function (c) { if (!newSet.has(c)) diffClasses.push(c); });
          // v5.2.8：修复 diff 为空时 filter 失效的 bug（customer-management L2 闪烁根因）
          // 原因：MutationObserver 批量处理时，mutation.target.className 读取的是最终值（不是 mutation 发生时的值）。
          //   applyHighlights 先 remove('is-highlighted') 再 add('is-highlighted') 产生 2 个 mutation：
          //   - mutation 1（remove）：oldValue="...is-highlighted"，但 className 已是 add 后的"...is-highlighted" → diff=[]
          //   - mutation 2（add）：oldValue="...no"，className="...is-highlighted" → diff=["is-highlighted"]
          //   原 filter 的 `diffClasses.length > 0 && diffClasses.every(...)` 在 diff=[] 时返回 false，
          //   导致 annotOnlyChange=false，不 continue，走到第二个 if 块 shouldRefresh=true，触发循环。
          //   customer-management 独有：R-001 zone 在 switchTab 时已带 is-highlighted，产生 remove+add 对；
          //   其他场景 state.highlightedZone=null，只 add 不 remove，单个 mutation diff=["is-highlighted"]，filter 成功。
          // 修复：diff 为空时直接 continue（无实际变化）；否则检查是否全是标注 class。
          if (diffClasses.length === 0) continue;
          // 仅标注系统自身 class 变化 → 跳过（避免自反馈循环）
          var annotOnlyChange = diffClasses.every(function (c) {
            return c === 'is-highlighted' || c === 'is-active' || c === 'is-expanded' ||
              c === 'is-collapsed' || c === 'annotation-active';
          });
          if (annotOnlyChange) continue;
        }
        if (mutation.type === 'attributes' && mutation.target) {
          var t = mutation.target;
          if (t.matches && (t.matches('[data-zone-id]') || t.matches('[data-element-id]') ||
              t.querySelector('[data-zone-id], [data-element-id]'))) {
            shouldRefresh = true;
            break;
          }
        }
        for (var j = 0; j < mutation.addedNodes.length; j++) {
          var node = mutation.addedNodes[j];
          if (node.nodeType !== 1) continue;
          if (node.matches && node.matches('[data-zone-id], [data-element-id]')) {
            shouldRefresh = true;
            break;
          }
          if (node.querySelector && node.querySelector('[data-zone-id], [data-element-id]')) {
            shouldRefresh = true;
            break;
          }
        }
        if (shouldRefresh) break;
      }
      if (shouldRefresh) {
        if (debounceTimer) clearTimeout(debounceTimer);
        debounceTimer = setTimeout(function () {
          debounceTimer = null;
          console.log('[annotation-engine] 检测到 DOM 变化，刷新面板');
          detectCurrentPage();
          renderPanel();
        }, 200);
      }
    });
    // v5.2.7：attributeOldValue 启用，用于区分标注系统自身 class 变化 vs demo 触发的 class 变化
    observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeOldValue: true, attributeFilter: ['style', 'class', 'hidden'] });
  }

  function validateAnnotationData(data) {
    if (!data || typeof data !== 'object') {
      console.warn('[annotation-engine] __ANNOTATION_DATA__ 不是有效对象');
      return false;
    }
    // v5.2.2：使用 getAnnotationPages 兼容 {P01:{...}} 与 {version,pages:{P01:{...}}} 结构
    // 临时设置 state.annotationData 以便 getAnnotationPages 能读取
    var origData = state.annotationData;
    state.annotationData = data;
    var pages = getAnnotationPages();
    state.annotationData = origData;

    var keys = Object.keys(pages);
    if (keys.length === 0) {
      console.log('[annotation-engine] __ANNOTATION_DATA__ 无页面标注数据');
      return true;
    }
    for (var i = 0; i < keys.length; i++) {
      var pageId = keys[i];
      var pageData = pages[pageId];
      if (!pageData || typeof pageData !== 'object') {
        console.warn('[annotation-engine] 页面 ' + pageId + ' 数据不是有效对象');
        continue;
      }
      if (Array.isArray(pageData.L2)) {
        for (var k = 0; k < pageData.L2.length; k++) {
          var item = pageData.L2[k];
          if (!item.id || !item.zone) {
            console.warn('[annotation-engine] 页面 ' + pageId + ' L2 项缺少 id 或 zone 字段', item);
          }
        }
      }
    }
    return true;
  }

  // ==========================================
  // 3. 页面检测（v5.2：优先可见页面，v5.2.2：兼容 pages 包装结构）
  // ==========================================

  /**
   * 检测当前页面 ID：
   * v5.2：优先从可见的 [data-page-id] 元素读取（SPA 多页面场景）
   * 其次从第一个 [data-page-id] 读取
   * 最后从 annotationData 的页面 key 推断（v5.2.2：使用 getAnnotationPages 兼容 pages 包装）
   */
  function detectCurrentPage() {
    var pageEls = document.querySelectorAll('[data-page-id]');
    if (pageEls.length > 0) {
      // v5.2：优先选择可见的页面
      for (var i = 0; i < pageEls.length; i++) {
        if (isElementVisible(pageEls[i])) {
          state.activePageId = pageEls[i].getAttribute('data-page-id');
          return;
        }
      }
      // 回退到第一个
      state.activePageId = pageEls[0].getAttribute('data-page-id');
      return;
    }

    // v5.2.2：从 getAnnotationPages() 推断（兼容 pages 包装结构）
    var pages = getAnnotationPages();
    var keys = Object.keys(pages);
    if (keys.length > 0) {
      state.activePageId = keys[0];
    }
  }

  // ==========================================
  // 4. 事件绑定
  // ==========================================

  function bindEvents() {
    // 标注开关
    if (dom.toggleBtn) {
      dom.toggleBtn.addEventListener('click', function () {
        togglePanel();
      });
    }

    // 面板关闭按钮
    var closeBtn = dom.panel ? dom.panel.querySelector('[data-annotation-close]') : null;
    if (closeBtn) {
      closeBtn.addEventListener('click', function () {
        setPanelVisible(false);
      });
    }

    // Tab 切换
    if (dom.panelTabs) {
      var tabBtns = dom.panelTabs.querySelectorAll('[data-tab]');
      tabBtns.forEach(function (btn) {
        btn.addEventListener('click', function () {
          switchTab(btn.getAttribute('data-tab'));
        });
      });
    }

    // 左侧标注标记点击 + v5.2 可见性刷新（事件委托）
    document.addEventListener('click', function (e) {
      var zoneMarker = e.target.closest('.l2-marker');
      if (zoneMarker) {
        e.stopPropagation();
        var zoneId = zoneMarker.closest('[data-zone-id]');
        if (zoneId) focusZoneCard(zoneId.getAttribute('data-zone-id'));
        return;
      }

      var elementDot = e.target.closest('.l3-dot');
      if (elementDot) {
        e.stopPropagation();
        var wrap = elementDot.closest('[data-element-id]');
        if (wrap) focusElementCard(wrap.getAttribute('data-element-id'));
        return;
      }

      // v5.2：检测 tab/页面切换（延迟刷新面板可见性）
      // 排除标注面板内部（Shadow DOM）的点击
      if (dom.shadowRoot && dom.shadowRoot.contains(e.target)) return;
      // 排除标注开关按钮的点击（上面已处理）
      if (dom.toggleBtn && (e.target === dom.toggleBtn || dom.toggleBtn.contains(e.target))) return;
      // 面板打开时才需要刷新可见性
      if (state.showPanel) {
        scheduleVisibilityRefresh();
      }
    });

    // 路由变化监听（SPA 场景）
    window.addEventListener('hashchange', function () {
      onRouteChange();
    });

    // 监听 popstate（History API 场景）
    window.addEventListener('popstate', function () {
      onRouteChange();
    });
  }

  // ==========================================
  // 5. 面板控制
  // ==========================================

  function togglePanel() {
    setPanelVisible(!state.showPanel);
  }

  function setPanelVisible(visible) {
    state.showPanel = visible;

    if (dom.panel) {
      dom.panel.style.display = visible ? 'flex' : 'none';
    }

    if (dom.contentRoot) {
      if (visible) {
        dom.contentRoot.setAttribute('data-annotation-active', '');
      } else {
        dom.contentRoot.removeAttribute('data-annotation-active');
        // 关闭时清空高亮
        clearHighlights();
      }
    }

    if (visible && dom.toggleBtn) {
      dom.toggleBtn.setAttribute('data-annotation-on', '');
    } else if (dom.toggleBtn) {
      dom.toggleBtn.removeAttribute('data-annotation-on');
    }

    // v5.2：面板打开时刷新可见性
    if (visible) {
      detectCurrentPage();
      renderPanel();
    }
  }

  function switchTab(tab) {
    state.activeTab = tab;
    renderPanel();
  }

  function clearHighlights() {
    state.highlightedZone = null;
    state.highlightedElement = null;
    document.querySelectorAll('.anno-zone.is-highlighted').forEach(function (el) {
      el.classList.remove('is-highlighted');
    });
    document.querySelectorAll('.l3-dot.is-active').forEach(function (el) {
      el.classList.remove('is-active');
    });
    if (dom.panelBody) {
      dom.panelBody.querySelectorAll('.anno-card.is-active').forEach(function (el) {
        el.classList.remove('is-active');
      });
    }
  }

  // ==========================================
  // 6. 交互方法（v5.2：确保双向激活一致性）
  // ==========================================

  /**
   * 点击右侧 L2 卡片：高亮左侧对应区域
   * v5.2：先 renderPanel() 确保卡片渲染，再高亮 + 滚动
   */
  function highlightZone(zoneId) {
    if (state.highlightedZone === zoneId) {
      state.highlightedZone = null;
      state.highlightedElement = null;
    } else {
      state.highlightedZone = zoneId;
      state.highlightedElement = null;
    }
    state.activeTab = 'L2';
    // v5.2.5：设置 suppressRefresh，阻止 scrollToElement 触发的 refresh 导致闪缩
    state.suppressRefresh = Date.now();
    renderPanel();  // v5.2：先渲染确保卡片存在
    scrollToElement('[data-zone-id="' + zoneId + '"]');
  }

  /**
   * 点击右侧 L3 卡片：高亮左侧对应元素
   * v5.2：先 renderPanel() 确保卡片渲染，再高亮 + 滚动
   */
  function highlightElement(elemId) {
    if (state.highlightedElement === elemId) {
      state.highlightedElement = null;
      state.highlightedZone = null;
    } else {
      state.highlightedElement = elemId;
      state.highlightedZone = null;
    }
    state.activeTab = 'L3';
    // v5.2.5：设置 suppressRefresh，阻止 scrollToElement 触发的 refresh 导致闪缩
    state.suppressRefresh = Date.now();
    renderPanel();  // v5.2：先渲染确保卡片存在
    scrollToElement('[data-element-id="' + elemId + '"]');
  }

  /**
   * 点击左侧 L2 marker：打开面板 + 切换到 L2 Tab
   * v5.2：先 renderPanel() 确保卡片渲染，再滚动到面板卡片
   */
  function focusZoneCard(zoneId) {
    if (state.highlightedZone === zoneId) {
      state.highlightedZone = null;
      state.highlightedElement = null;
      applyHighlights();
      return;
    }
    setPanelVisible(true);
    state.activeTab = 'L2';
    state.highlightedZone = zoneId;
    state.highlightedElement = null;
    // v5.2.5：设置 suppressRefresh 避免闪缩
    state.suppressRefresh = Date.now();
    renderPanel();  // v5.2：先渲染面板，确保卡片存在
    scrollToPanelCard('[data-card-zone="' + zoneId + '"]');
  }

  /**
   * 点击左侧 L3 dot：打开面板 + 切换到 L3 Tab
   * v5.2：先 renderPanel() 确保卡片渲染，再滚动到面板卡片
   */
  function focusElementCard(elemId) {
    if (state.highlightedElement === elemId) {
      state.highlightedElement = null;
      state.highlightedZone = null;
      applyHighlights();
      return;
    }
    setPanelVisible(true);
    state.activeTab = 'L3';
    state.highlightedElement = elemId;
    state.highlightedZone = null;
    // v5.2.5：设置 suppressRefresh 避免闪缩
    state.suppressRefresh = Date.now();
    renderPanel();  // v5.2：先渲染面板，确保卡片存在
    scrollToPanelCard('[data-card-element="' + elemId + '"]');
  }

  // ==========================================
  // 7. DOM 操作
  // ==========================================

  function scrollToElement(selector) {
    setTimeout(function () {
      // v5.2.5：使用 findVisibleElement 找到可见的目标元素
      var el = findVisibleElement(selector);
      if (el) {
        // v5.2：如果元素不可见，尝试展开其祖先
        if (!isElementVisible(el)) {
          console.warn('[annotation-engine] 目标元素不可见，scrollIntoView 可能无效:', selector);
        }
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 50);
  }

  function scrollToPanelCard(selector) {
    setTimeout(function () {
      var panelBody = dom.panelBody;
      var card = panelBody ? panelBody.querySelector(selector) : null;
      if (panelBody && card) {
        var panelRect = panelBody.getBoundingClientRect();
        var cardRect = card.getBoundingClientRect();
        var isVisible = cardRect.top >= panelRect.top && cardRect.bottom <= panelRect.bottom;
        if (!isVisible) {
          card.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        }
      }
    }, 150);
  }

  /**
   * 应用高亮状态到 DOM
   */
  function applyHighlights() {
    // 清除所有高亮
    document.querySelectorAll('.anno-zone.is-highlighted').forEach(function (el) {
      el.classList.remove('is-highlighted');
    });
    document.querySelectorAll('.l3-dot.is-active').forEach(function (el) {
      el.classList.remove('is-active');
    });
    if (dom.panelBody) {
      dom.panelBody.querySelectorAll('.anno-card.is-active').forEach(function (el) {
        el.classList.remove('is-active');
      });
    }

    // 应用 L2 高亮
    if (state.highlightedZone) {
      // v5.2.5：使用 findVisibleElement 避免高亮到隐藏页面的元素
      var zoneEl = findVisibleElement('[data-zone-id="' + state.highlightedZone + '"]');
      if (zoneEl) zoneEl.classList.add('is-highlighted');
      var cardEl = dom.panelBody ? dom.panelBody.querySelector('[data-card-zone="' + state.highlightedZone + '"]') : null;
      if (cardEl) cardEl.classList.add('is-active');
    }

    // 应用 L3 高亮
    if (state.highlightedElement) {
      // v5.2.5：使用 findVisibleElement 避免高亮到隐藏页面的元素
      var elemWrap = findVisibleElement('[data-element-id="' + state.highlightedElement + '"]');
      if (elemWrap) {
        var dot = elemWrap.querySelector('.l3-dot');
        if (dot) dot.classList.add('is-active');
      }
      var elemCard = dom.panelBody ? dom.panelBody.querySelector('[data-card-element="' + state.highlightedElement + '"]') : null;
      if (elemCard) elemCard.classList.add('is-active');
    }

    // 更新 Tab 激活状态
    renderTabState();
  }

  /**
   * 路由变化处理
   */
  function onRouteChange() {
    detectCurrentPage();
    clearHighlights();
    state.activeTab = 'L1';
    renderPanel();
  }

  // ==========================================
  // 8. 面板渲染（v5.2.2：可见性过滤，不渲染不可见标注）
  // ==========================================

  function renderPanel() {
    if (!dom.panelBody) return;

    renderTabState();

    // v5.2.2：使用 getAnnotationPages() 兼容 {P01:{...}} 与 {version,pages:{P01:{...}}} 两种结构
    var pages = getAnnotationPages();
    var ann = pages[state.activePageId];
    if (!ann) {
      dom.panelBody.innerHTML = '<div style="color:#909399;text-align:center;padding:40px 0">当前页面暂无标注</div>';
      return;
    }

    var html = '';

    if (state.activeTab === 'L1' && ann.L1) {
      html = renderL1(ann.L1);
    } else if (state.activeTab === 'L2' && ann.L2) {
      html = renderL2List(ann.L2);
    } else if (state.activeTab === 'L3' && ann.L3) {
      html = renderL3List(ann.L3);
    }

    if (!html) {
      // v5.2.2：区分"页面无此层级标注"和"可视区域内无此层级标注"
      var hasLevel = (state.activeTab === 'L1' && ann.L1) ||
                     (state.activeTab === 'L2' && ann.L2 && ann.L2.length > 0) ||
                     (state.activeTab === 'L3' && ann.L3 && ann.L3.length > 0);
      if (hasLevel) {
        // 有此层级标注但都被过滤（当前可视区域内无可见标注）
        html = '<div style="color:#909399;text-align:center;padding:40px 0;line-height:1.8;">当前可视区域内无 ' + state.activeTab + ' 标注<br><span style="font-size:12px;color:#c0c4cc;">切换 tab 或展开折叠区后自动刷新</span></div>';
      } else {
        html = '<div style="color:#909399;text-align:center;padding:40px 0">当前页面暂无 ' + state.activeTab + ' 标注</div>';
      }
    }

    dom.panelBody.innerHTML = html;

    // 绑定卡片点击事件
    dom.panelBody.querySelectorAll('[data-card-zone]').forEach(function (card) {
      card.addEventListener('click', function () {
        highlightZone(card.getAttribute('data-card-zone'));
      });
    });

    dom.panelBody.querySelectorAll('[data-card-element]').forEach(function (card) {
      card.addEventListener('click', function () {
        highlightElement(card.getAttribute('data-card-element'));
      });
    });

    // 更新页面 ID 标签
    // v5.2.3：显示 "P01 - 页面中文名称"（从 page.name 字段读取，兼容 page.title）
    var pageTag = dom.panelHeader ? dom.panelHeader.querySelector('.page-id-tag') : null;
    if (pageTag) {
      var pageName = '';
      if (ann) {
        pageName = ann.name || ann.title || '';
      }
      if (pageName) {
        pageTag.textContent = (state.activePageId || '') + ' - ' + pageName;
      } else {
        pageTag.textContent = state.activePageId || '';
      }
    }

    // 应用当前高亮
    applyHighlights();
  }

  function renderTabState() {
    if (!dom.panelTabs) return;
    dom.panelTabs.querySelectorAll('[data-tab]').forEach(function (btn) {
      if (btn.getAttribute('data-tab') === state.activeTab) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  function renderL1(l1) {
    var rules = '';
    if (l1.business_rules) {
      if (Array.isArray(l1.business_rules)) {
        rules = '<div class="l1-rules"><div class="l1-rules-title">业务规则</div><ul class="l1-rules-list">';
        l1.business_rules.forEach(function (r) { rules += '<li>' + escapeHtml(r) + '</li>'; });
        rules += '</ul></div>';
      } else {
        rules = '<div class="l1-rules"><div class="l1-rules-title">业务规则</div><p class="l1-rules-text">' + escapeHtml(l1.business_rules) + '</p></div>';
      }
    }

    var testData = '';
    if (l1.test_data) {
      testData = '<blockquote class="l1-test-data"><div class="l1-test-data-title">测试数据</div><p>' + escapeHtml(l1.test_data) + '</p></blockquote>';
    }

    return '<div class="anno-card anno-card-l1">' +
      '<div class="anno-card-head"><span class="l1-tag">L1</span><span class="anno-card-title">' + escapeHtml(l1.summary || '') + '</span></div>' +
      '<div class="anno-card-desc l1-detail"><dl class="l1-meta">' +
      '<dt>入口</dt><dd>' + escapeHtml(l1.entry || '') + '</dd>' +
      '<dt>前置条件</dt><dd>' + escapeHtml(l1.precondition || '') + '</dd>' +
      '<dt>数据实体</dt><dd>' + escapeHtml(l1.data_entity || '') + '</dd>' +
      '</dl>' + rules + testData + '</div></div>';
  }

  /**
   * v5.2.2：渲染 L2 卡片列表，过滤不可见标注（不再显示灰色"当前不可见"卡片）
   * 标注面板与页面可视区域严格一致：不可见的 L2 区域不渲染卡片
   * @param {Array} zones L2 区域数组
   * @returns {string} HTML 字符串（可能为空字符串）
   */
  function renderL2List(zones) {
    var html = '';
    zones.forEach(function (z) {
      // v5.2.5：使用 findVisibleElement 替代 querySelector
      // 修复多页面场景下 L2 id 重复（每个页面都有 R-001）导致 querySelector 返回隐藏页面元素的问题
      var zoneEl = findVisibleElement('[data-zone-id="' + z.id + '"]');
      // v5.2.2：过滤不可见元素，保持面板与可视区域一致
      if (!zoneEl) return;
      var activeClass = state.highlightedZone === z.id ? ' is-active' : '';
      html += '<div class="anno-card l2-card' + activeClass + '" data-card-zone="' + escapeHtml(z.id) + '">' +
        '<div class="anno-card-head"><span class="l2-tag">' + escapeHtml(z.id) + '</span><span class="anno-card-title">' + escapeHtml(z.zone || '') + '</span></div>' +
        '<div class="anno-card-desc">' + escapeHtml(z.description || '') + '</div>' +
        '</div>';
    });
    return html;
  }

  /**
   * v5.2.2：渲染 L3 卡片列表，过滤不可见标注（不再显示灰色"当前不可见"卡片）
   * v5.2.3：增强 — 当 data-element-id 容器可见但内部实际交互元件全隐藏时，
   *         也不渲染卡片（修复"有标注图标但无元件"的困惑）
   * 标注面板与页面可视区域严格一致：不可见的 L3 元素不渲染卡片
   * @param {Array} elements L3 元素数组
   * @returns {string} HTML 字符串（可能为空字符串）
   */
  function renderL3List(elements) {
    var html = '';
    elements.forEach(function (e) {
      // v5.2.5：使用 findVisibleElement 替代 querySelector
      var elemEl = findVisibleElement('[data-element-id="' + e.id + '"]');
      // v5.2.2：过滤不可见元素，保持面板与可视区域一致
      if (!elemEl) return;
      // v5.2.3：容器可见但内部实际交互元件全隐藏时，也跳过
      // 例如按钮按状态 display:none，但 span 容器 + l3-dot 仍可见 → 不应显示卡片
      if (!hasVisibleInteractiveChild(elemEl)) return;
      var activeClass = state.highlightedElement === e.id ? ' is-active' : '';
      html += '<div class="anno-card l3-card' + activeClass + '" data-card-element="' + escapeHtml(e.id) + '">' +
        '<div class="anno-card-head"><span class="l3-tag">' + escapeHtml(e.id) + '</span><span class="anno-card-title">' + escapeHtml(e.element || '') + '</span></div>' +
        '<div class="anno-card-grid">' +
        '<div><b>功能：</b>' + escapeHtml(e.function || '') + '</div>' +
        '<div><b>触发：</b>' + escapeHtml(e.trigger || '') + '</div>' +
        '<div><b>条件：</b>' + escapeHtml(e.condition || '') + '</div>' +
        '<div><b>响应：</b>' + escapeHtml(e.response || '') + '</div>' +
        '<div><b>状态：</b>' + escapeHtml(e.state || '') + '</div>' +
        '<div><b>异常：</b>' + escapeHtml(e.exception || '') + '</div>' +
        '</div>' +
        '</div>';
    });
    return html;
  }

  function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ==========================================
  // 9. 自动初始化
  // ==========================================

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // 暴露 API 供外部调用
  window.__ANNOTATION_ENGINE__ = {
    togglePanel: togglePanel,
    setPanelVisible: setPanelVisible,
    highlightZone: highlightZone,
    highlightElement: highlightElement,
    focusZoneCard: focusZoneCard,
    focusElementCard: focusElementCard,
    switchTab: switchTab,
    getState: function () { return Object.assign({}, state); },
    // v5.2：refresh 增强 — 重新检测页面 + 重新渲染
    refresh: function () {
      detectCurrentPage();
      renderPanel();
    },
    // v5.2：新增 — 手动触发可见性刷新
    refreshVisibility: scheduleVisibilityRefresh
  };

})();
