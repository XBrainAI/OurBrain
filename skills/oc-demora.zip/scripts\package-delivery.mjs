// package-delivery.mjs
// 打包 demo/ + docs/ 为交付网站（v5.7 — 交付网站 + 三种角色下载包 + mermaid 资产）
//
// 调用：node package-delivery.mjs（无参数）
// cwd：sim-project 目录
// 功能：
//   1. 校验 demo_protected: true 状态 + 质量门禁通过
//   2. 从 .demora/requirement-model.yaml 抽取项目元数据
//   3. 创建 delivery/<项目名>/ 交付网站目录：
//      - index.html（从 delivery-site-template.html 渲染，IP 风格）
//      - project-info.json（项目元数据）
//      - demo/、docs/ 完整副本（在线可浏览，含 docs/assets/mermaid/ 流程图资产）
//      - downloads/demo-only.zip（仅 demo/，面向客户）
//      - downloads/full-delivery.zip（完整交付网站，排除 downloads/，面向产品研发）
//   4. 更新 state.yaml 的 delivery_packaged: true
//
// v5.7 变更：
//   - docs/ 现在包含 assets/mermaid/ 子目录（mermaid.min.js + mermaid-init.js）
//   - copyDir 自动递归复制，无需特殊处理
//   - full-delivery.zip 会自动包含 mermaid 资产（约 3.4 MB）
//
// 设计要点：
//   - full-delivery.zip 在 downloads/ 创建之前打包，天然排除自身，避免递归
//   - 项目名取自 requirement-model.yaml 的 project.name，非法路径字符替换为 -
//   - 模板路径：../assets/delivery-site-template.html（构建包与源码通用）
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 遍历目录，返回相对路径文件列表
 */
function walkRelative(dir, base) {
  const result = [];
  if (!fs.existsSync(dir)) return result;
  function walk(d) {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else {
        const rel = path.relative(base, full).replace(/\\/g, '/');
        result.push({ full, rel });
      }
    }
  }
  walk(dir);
  return result;
}

/**
 * 将源目录打包为标准 ZIP（使用 PowerShell Compress-Archive）
 * 跨平台兼容：Windows 使用 PowerShell，其它平台使用 zip 命令
 * @param {string} srcDir - 源目录
 * @param {string} outputPath - 输出 ZIP 路径
 * @returns {number} ZIP 文件大小（字节）
 */
function packToZipStandard(srcDir, outputPath) {
  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
  }
  if (process.platform === 'win32') {
    const srcPath = path.resolve(srcDir).replace(/\\/g, '\\');
    const dstPath = path.resolve(outputPath).replace(/\\/g, '\\');
    const cmd = `powershell.exe -NoProfile -Command "Compress-Archive -Path '${srcPath}\\*' -DestinationPath '${dstPath}' -Force"`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('Compress-Archive 失败: ' + e.message);
    }
  } else {
    const cmd = `cd "${srcDir}" && zip -r "${outputPath}" .`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('zip 命令失败: ' + e.message);
    }
  }
  return fs.statSync(outputPath).size;
}

/**
 * 复制目录（递归）
 * @returns {number} 复制文件数
 */
function copyDir(src, dst) {
  if (!fs.existsSync(src)) return 0;
  fs.mkdirSync(dst, { recursive: true });
  let count = 0;
  function walk(s, d) {
    for (const entry of fs.readdirSync(s, { withFileTypes: true })) {
      const sFull = path.join(s, entry.name);
      const dFull = path.join(d, entry.name);
      if (entry.isDirectory()) {
        fs.mkdirSync(dFull, { recursive: true });
        walk(sFull, dFull);
      } else {
        fs.copyFileSync(sFull, dFull);
        count++;
      }
    }
  }
  walk(src, dst);
  return count;
}

/**
 * 将 YAML 文本按顶层 key 分段（顶层 key = column 0 起的 `xxx:` 行）
 * 返回 { keyName: sectionContent } 映射；sectionContent 含该 key 下所有缩进行
 * 用于轻量解析 requirement-model.yaml，无 js-yaml 依赖
 */
function splitYamlSections(text) {
  const sections = {};
  const lines = text.split('\n');
  let currentKey = null;
  let currentContent = [];
  for (const line of lines) {
    // 顶层 key：行首非空白 + 以冒号结尾（允许 `key: value` 形式，但 section 类 key 通常为 `key:` 空值）
    const keyMatch = line.match(/^(\S[^:]*):\s*$/);
    if (keyMatch) {
      if (currentKey) sections[currentKey] = currentContent.join('\n');
      currentKey = keyMatch[1];
      currentContent = [];
    } else if (currentKey) {
      currentContent.push(line);
    }
  }
  if (currentKey) sections[currentKey] = currentContent.join('\n');
  return sections;
}

// ============================================================================
// v5.6 新增：Markdown 解析与段落提取（用于 PROJECT BACKGROUND 增强）
// 与 generate-product-docs.mjs 中的实现保持一致，无外部依赖
// ============================================================================

/**
 * HTML 转义
 */
function escHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * 行内格式处理：粗体、斜体、行内代码、链接
 */
function applyInlineMarkdownPd(text) {
  const codeBlocks = [];
  let processed = text.replace(/`([^`]+)`/g, (m, code) => {
    codeBlocks.push(code);
    return `\u0000CODE${codeBlocks.length - 1}\u0000`;
  });
  processed = processed.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  processed = processed.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  processed = processed.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  processed = processed.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '<em>$1</em>');
  processed = processed.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  processed = processed.replace(/\u0000CODE(\d+)\u0000/g, (m, idx) => {
    return '<code>' + escHtml(codeBlocks[Number(idx)]) + '</code>';
  });
  return processed;
}

/**
 * 轻量 Markdown → HTML 转换（用于 delivery 入口 HTML 的 PM 需求展示）
 * 支持：标题、段落、列表、表格、代码块、引用块、分割线、行内格式
 */
function markdownToHtmlPd(md) {
  if (!md || typeof md !== 'string') return '';
  const lines = md.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const out = [];
  let i = 0;
  let listType = null;

  function closeList() {
    if (listType) { out.push(`</${listType}>`); listType = null; }
  }

  while (i < lines.length) {
    const line = lines[i];

    if (/^```/.test(line.trim())) {
      closeList();
      const codeLines = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i].trim())) { codeLines.push(lines[i]); i++; }
      i++;
      out.push(`<pre><code>${escHtml(codeLines.join('\n'))}</code></pre>`);
      continue;
    }
    if (line.trim() === '') { closeList(); i++; continue; }

    const hMatch = line.match(/^(#{1,5})\s+(.+)$/);
    if (hMatch) {
      closeList();
      const level = hMatch[1].length;
      out.push(`<h${level}>${applyInlineMarkdownPd(escHtml(hMatch[2]))}</h${level}>`);
      i++; continue;
    }
    if (/^---+\s*$/.test(line)) { closeList(); out.push('<hr>'); i++; continue; }

    if (/^\|/.test(line.trim())) {
      closeList();
      const tableRows = [];
      while (i < lines.length && /^\|/.test(lines[i].trim())) { tableRows.push(lines[i].trim()); i++; }
      if (tableRows.length >= 2) {
        const headers = tableRows[0].split('|').slice(1, -1).map(s => s.trim());
        const bodyRows = tableRows.slice(1).filter(r => !/^\|[\s-:|]+\|$/.test(r));
        out.push('<table><thead><tr>');
        for (const h of headers) out.push(`<th>${applyInlineMarkdownPd(escHtml(h))}</th>`);
        out.push('</tr></thead><tbody>');
        for (const r of bodyRows) {
          const cells = r.split('|').slice(1, -1).map(s => s.trim());
          out.push('<tr>');
          for (const c of cells) out.push(`<td>${applyInlineMarkdownPd(escHtml(c))}</td>`);
          out.push('</tr>');
        }
        out.push('</tbody></table>');
      }
      continue;
    }

    if (/^>\s?/.test(line.trim())) {
      closeList();
      const quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i].trim())) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, '')); i++;
      }
      out.push(`<blockquote>${applyInlineMarkdownPd(escHtml(quoteLines.join(' ')))}</blockquote>`);
      continue;
    }

    const ulMatch = line.match(/^(\s*)[-*]\s+(.+)$/);
    if (ulMatch) {
      if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; }
      out.push(`<li>${applyInlineMarkdownPd(escHtml(ulMatch[2]))}</li>`);
      i++; continue;
    }
    const olMatch = line.match(/^(\s*)\d+\.\s+(.+)$/);
    if (olMatch) {
      if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; }
      out.push(`<li>${applyInlineMarkdownPd(escHtml(olMatch[2]))}</li>`);
      i++; continue;
    }

    closeList();
    const paraLines = [];
    while (i < lines.length && lines[i].trim() !== '' &&
      !/^(#{1,5}\s|---+\s*$|```|>|[-*]\s|\d+\.\s|\|)/.test(lines[i].trim())) {
      paraLines.push(lines[i].trim()); i++;
    }
    if (paraLines.length > 0) {
      out.push(`<p>${applyInlineMarkdownPd(escHtml(paraLines.join(' ')))}</p>`);
    }
  }
  closeList();
  return out.join('\n');
}

/**
 * 从 markdown 文件提取指定 ## 段落内容
 * 规则：从 `## sectionTitle` 后开始，到下一个 `## ` 或 `---` 或 EOF 结束
 */
function extractMarkdownSectionPd(filePath, sectionTitle) {
  if (!filePath || !sectionTitle) return '';
  if (!fs.existsSync(filePath)) return '';
  const text = fs.readFileSync(filePath, { encoding: 'utf-8' });
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let inSection = false;
  let content = [];
  const headingRegex = new RegExp('^##\\s+' + sectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$');
  for (const line of lines) {
    if (headingRegex.test(line.trim())) { inSection = true; continue; }
    if (inSection) {
      if (/^##\s+/.test(line.trim())) break;
      if (/^---\s*$/.test(line.trim())) break;
      content.push(line);
    }
  }
  let result = content.join('\n').trim();
  result = result.replace(/^>.*(\n|$)/, '').trim();
  return result;
}

/**
 * 从 requirement-model.yaml 抽取项目元数据（轻量解析，无 js-yaml 依赖）
 * v5.6 新增：5 个 PROJECT BACKGROUND 增强字段（businessBackground/corePainPoints/
 *            solutionOverview/pmRequirementBrief/pmRequirementWordCount）
 * @param {string} root - sim-project 根目录
 * @returns {object} 项目元数据
 */
function extractProjectInfo(root) {
  const modelPath = path.join(root, '.demora', 'requirement-model.yaml');
  const fallbackName = path.basename(root);

  // v5.6 新增：从 docs/prd/01-background.md 提取业务背景/痛点/解决方案
  // 从 inbox/text/requirement-input.md 提取 PM 完整需求
  const bgFile = path.join(root, 'docs', 'prd', '01-background.md');
  const inputFile = path.join(root, 'inbox', 'text', 'requirement-input.md');

  const businessBgMd = extractMarkdownSectionPd(bgFile, '业务背景');
  const painPointsMd = extractMarkdownSectionPd(bgFile, '核心痛点');
  const solutionMd = extractMarkdownSectionPd(bgFile, '解决方案');

  let pmRequirementRaw = '';
  if (fs.existsSync(inputFile)) {
    pmRequirementRaw = fs.readFileSync(inputFile, { encoding: 'utf-8' });
  }
  const pmRequirementWordCount = pmRequirementRaw ? pmRequirementRaw.length : 0;

  // PROJECT BACKGROUND 增强字段（v5.6）
  const bgFields = {
    businessBackground: businessBgMd ? markdownToHtmlPd(businessBgMd) : '',
    corePainPoints: painPointsMd ? markdownToHtmlPd(painPointsMd) : '',
    solutionOverview: solutionMd ? markdownToHtmlPd(solutionMd) : '',
    pmRequirementBrief: pmRequirementRaw ? markdownToHtmlPd(pmRequirementRaw) : '',
    pmRequirementWordCount: String(pmRequirementWordCount),
  };

  if (!fs.existsSync(modelPath)) {
    return {
      projectName: fallbackName,
      projectSlug: generateSlugFromName(fallbackName),
      projectDescription: '',
      domain: '-',
      rolesList: '-',
      pageCount: '-',
      entityCount: '-',
      raw: null,
      ...bgFields,
    };
  }

  const text = fs.readFileSync(modelPath, { encoding: 'utf-8' });
  const sections = splitYamlSections(text);

  // project 段：抽取 name / description / domain / slug（2 空格缩进的子字段）
  // v5.11 新增：project.slug 字段（PM 手工输入的英文 slug，用于公网发布）
  const projectSection = sections['project'] || '';
  const nameMatch = projectSection.match(/^  name:\s*(.+)$/m);
  const descMatch = projectSection.match(/^  description:\s*(.+)$/m);
  const domainMatch = projectSection.match(/^  domain:\s*(.+)$/m);
  const slugMatch = projectSection.match(/^  slug:\s*(.+)$/m);

  // entities 段：统计顶层条目（2 空格缩进的 `  - name:`，排除 6 空格的字段 `- name:`）
  let entityCount = 0;
  const entitiesSection = sections['entities'] || '';
  if (entitiesSection) {
    entityCount = (entitiesSection.match(/^  - name:/gm) || []).length;
  }

  // pages 段：统计顶层条目（2 空格缩进的 `  - ` 列表项）
  let pageCount = 0;
  const pagesSection = sections['pages'] || '';
  if (pagesSection) {
    pageCount = (pagesSection.match(/^  - /gm) || []).length;
  }

  // roles 段：抽取顶层条目的 name 字段
  let rolesList = '-';
  const rolesSection = sections['roles'] || '';
  if (rolesSection) {
    const roleNames = (rolesSection.match(/^  - name:\s*(.+)$/gm) || [])
      .map(s => s.replace(/^  - name:\s*/, '').trim().replace(/^["']|["']$/g, ''))
      .filter(s => s);
    if (roleNames.length > 0) rolesList = roleNames.join('、');
  }

  // v5.11：抽取 project.slug，校验 + 自动生成兜底
  const rawProjectName = (nameMatch ? nameMatch[1].trim() : fallbackName).replace(/^["']|["']$/g, '');
  let projectSlug = slugMatch ? slugMatch[1].trim().replace(/^["']|["']$/g, '') : '';
  // 校验 PM 手工输入的 slug；不合法则丢弃改用自动生成
  if (projectSlug && !isValidSlug(projectSlug)) {
    process.stderr.write(`[WARN] project.slug "${projectSlug}" 格式不合法（需小写字母开头，仅含小写字母/数字/连字符，3-64 字符），改用自动生成\n`);
    projectSlug = '';
  }
  if (!projectSlug) {
    projectSlug = generateSlugFromName(rawProjectName);
  }

  return {
    projectName: rawProjectName,
    projectSlug,
    projectDescription: descMatch ? descMatch[1].trim().replace(/^["']|["']$/g, '') : '',
    domain: domainMatch ? domainMatch[1].trim() : '-',
    rolesList,
    pageCount: pageCount > 0 ? String(pageCount) : '-',
    entityCount: entityCount > 0 ? String(entityCount) : '-',
    raw: text,
    ...bgFields,
  };
}

/**
 * 净化项目名为合法目录名（保留中文，替换非法字符）
 */
function sanitizeProjectName(name) {
  return name.replace(/[\/\\:*?"<>|]/g, '-').trim() || 'unnamed-project';
}

/**
 * v5.11 新增：从中文项目名生成英文 slug
 * 策略（决策 5-C 组合）：
 *   - 优先从 requirement-model.yaml 的 project.slug 字段读取（PM 手工输入）
 *   - 若未提供，则从此字典映射查找常见行业 slug
 *   - 字典未命中时，回退为 'project-<时间戳后 6 位>' 兜底
 * 字典覆盖 demora 常见 audit 场景与典型业务领域
 */
const SLUG_DICT = {
  // audit 场景
  '旅游行程预订系统': 'travel-booking',
  '餐饮点餐系统': 'restaurant-order',
  '诊所预约挂号系统': 'clinic-appointment',
  // 通用业务
  '客户关系管理': 'crm',
  '订单管理': 'order-mgmt',
  '库存管理': 'inventory',
  '人事管理': 'hr',
  '财务管理': 'finance',
  '项目管理': 'project-mgmt',
  '内容管理': 'cms',
  '电商': 'ecommerce',
  '支付': 'payment',
  '物流': 'logistics',
};

function generateSlugFromName(projectName) {
  if (!projectName) return 'project-' + Date.now().toString(36).slice(-6);
  // 1. 字典精确匹配
  if (SLUG_DICT[projectName]) return SLUG_DICT[projectName];
  // 2. 字典包含匹配（项目名含字典 key）
  for (const [k, v] of Object.entries(SLUG_DICT)) {
    if (projectName.includes(k)) return v;
  }
  // 3. 提取项目名中的英文字母/数字（如 "CRM 系统" → "crm"）
  const en = projectName.match(/[A-Za-z][A-Za-z0-9]+/);
  if (en && en[0].length >= 2) return en[0].toLowerCase();
  // 4. 兜底：project-<短时间戳>
  return 'project-' + Date.now().toString(36).slice(-6);
}

/**
 * 校验 slug 格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符
 */
function isValidSlug(slug) {
  return typeof slug === 'string' && /^[a-z][a-z0-9-]{2,63}$/.test(slug);
}

/**
 * 查找交付网站模板（构建包与源码通用）
 * 构建包：scripts/ → ../assets/delivery-site-template.html
 * 源码：  scripts/ → ../assets/delivery-site-template.html
 */
function findDeliveryTemplate() {
  const candidate = path.join(__dirname, '..', 'assets', 'delivery-site-template.html');
  if (fs.existsSync(candidate)) return candidate;
  return null;
}

/**
 * 从 SKILL.md frontmatter 抽取 Skill 版本（name 字段）
 */
function extractSkillVersion(root) {
  // 优先从 .demora/model-lock.yaml 读取 skillName
  const lockFile = path.join(root, '.demora', 'model-lock.yaml');
  if (fs.existsSync(lockFile)) {
    const t = fs.readFileSync(lockFile, { encoding: 'utf-8' });
    const m = t.match(/^skillName:\s*(.+)$/m);
    if (m) return m[1].trim();
  }
  return 'oc-demora';
}

/**
 * 渲染交付网站 index.html（占位符替换）
 * v5.6 增强：
 *   1. 新增 5 个 PROJECT BACKGROUND 占位符替换
 *      - {{businessBackground}} / {{corePainPoints}} / {{solutionOverview}}
 *      - {{pmRequirementBrief}} / {{pmRequirementWordCount}}
 *   2. 新增条件渲染：{{#if field}}...{{/if}} 语法
 *      - field 为空时移除整个块（含标记）
 *      - field 非空时保留块内容（移除标记）
 */
function renderDeliveryIndex(templatePath, info, generatedAt, skillVersion) {
  let html = fs.readFileSync(templatePath, { encoding: 'utf-8' });

  // 1. 处理条件渲染：{{#if field}}...{{/if}}
  //    field 为空时移除整个块；非空时保留内容（移除标记）
  const conditionalFields = [
    'businessBackground',
    'corePainPoints',
    'solutionOverview',
    'pmRequirementBrief',
  ];
  for (const field of conditionalFields) {
    const value = info[field];
    const isEmpty = !value || String(value).trim() === '';
    // 匹配 {{#if field}}...{{/if}}（非贪婪，允许跨行）
    const regex = new RegExp(
      '\\{\\{#if\\s+' + field + '\\}\\}([\\s\\S]*?)\\{\\{/if\\}\\}',
      'g'
    );
    if (isEmpty) {
      // 移除整个条件块
      html = html.replace(regex, '');
    } else {
      // 保留块内容，移除条件标记
      html = html.replace(regex, '$1');
    }
  }

  // 2. 标准占位符替换
  const replacements = {
    '{{projectName}}': info.projectName,
    '{{projectSlug}}': info.projectSlug || '',
    '{{projectDescription}}': info.projectDescription || '（无描述）',
    '{{domain}}': info.domain,
    '{{rolesList}}': info.rolesList,
    '{{pageCount}}': info.pageCount,
    '{{entityCount}}': info.entityCount,
    '{{generatedAt}}': generatedAt,
    '{{skillVersion}}': skillVersion,
    // v5.6 新增：PROJECT BACKGROUND 增强字段
    '{{businessBackground}}': info.businessBackground || '',
    '{{corePainPoints}}': info.corePainPoints || '',
    '{{solutionOverview}}': info.solutionOverview || '',
    '{{pmRequirementBrief}}': info.pmRequirementBrief || '',
    '{{pmRequirementWordCount}}': info.pmRequirementWordCount || '0',
  };
  for (const [k, v] of Object.entries(replacements)) {
    html = html.split(k).join(String(v));
  }

  // v5.13.7: 双视角替换逻辑已移除 — 模板内置单 Demo 卡片 + 给客户 checkbox
  // v5.13.5 曾将单个 Demo 入口替换为客户/产研双视角入口，v5.13.7 改为单 Demo + checkbox 方案
  // checkbox 默认勾选（给客户）→ demo/index.html?annotations=0（无标注）
  // checkbox 取消勾选 → demo/index.html?annotations=1（含标注）
  // 模板已内置 checkbox JS 逻辑，无需此处替换

  return html;
}

/**
 * 主入口
 * @param {object} args - { root?: string }
 */
export function main(args = {}) {
  const root = args.root || process.cwd();

  process.stdout.write('======================================================================\n');
  process.stdout.write('打包交付（v5.3 交付网站 + 三种角色下载包）\n');
  process.stdout.write('======================================================================\n');

  // 1. 校验状态机门禁（v5.6 修复 v5.5 时序错位）
  // v5.5 缺陷：仅检查 demo_protected: true，但该字段在 lock-model.mjs 阶段就设为 true
  //           （demo 仍是空骨架），导致 package-delivery 在 AI 阶段 2 之前执行，
  //           把空壳 demo 打包到 delivery/
  // v5.6 修复：
  //   - audit 模式（DEMORA_AUDIT_MODE=1）：必须 runtime_audit_passed: true（AI 阶段 5 完成的标志）
  //     这是 v5.6 的核心修复，确保 audit 场景下 Phase 3 必须在 AI 阶段 5 之后执行
  //   - 非 audit 模式（sim-project / 常规项目）：接受 final_approved: true 或 demo_protected: true
  //     sim-runner 流水线不跑 run-audit.mjs，所以不会有 runtime_audit_passed 字段
  //     通过 final_approved: true（Phase 3 完成的标志）或 demo_protected: true 通过门禁
  const isAuditMode = process.env.DEMORA_AUDIT_MODE === '1';
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) {
    process.stderr.write('[FAIL] state.yaml 不存在\n');
    process.exit(1);
  }
  const stateText = fs.readFileSync(stateFile, { encoding: 'utf-8' });

  if (isAuditMode) {
    // audit 模式：严格要求 runtime_audit_passed: true
    if (!/runtime_audit_passed:\s*true/.test(stateText)) {
      process.stderr.write('[FAIL] audit 模式（DEMORA_AUDIT_MODE=1）下 runtime_audit_passed != true，禁止打包\n');
      process.stderr.write('       v5.6 门禁：package-delivery 必须在 AI 阶段 5（run-audit.mjs A/B 评级）之后执行\n');
      process.exit(1);
    }
    process.stdout.write('  [OK]   runtime_audit_passed: true（audit 模式门禁通过）\n');
  } else {
    // 非 audit 模式：接受 final_approved: true 或 demo_protected: true
    if (/final_approved:\s*true/.test(stateText)) {
      process.stdout.write('  [OK]   final_approved: true（Phase 3 已完成）\n');
    } else if (/demo_protected:\s*true/.test(stateText)) {
      process.stdout.write('  [WARN] demo_protected: true（旧门禁，建议补充 final_approved）\n');
    } else {
      process.stderr.write('[FAIL] state.yaml 既无 final_approved: true 也无 demo_protected: true，禁止打包\n');
      process.exit(1);
    }
  }
  const qReportFile = path.join(root, '.demora', 'quality-report.yaml');
  if (fs.existsSync(qReportFile)) {
    const qText = fs.readFileSync(qReportFile, { encoding: 'utf-8' });
    if (!/^passed:\s*true\s*$/m.test(qText)) {
      process.stderr.write('[FAIL] 质量门禁未通过，禁止打包\n');
      process.exit(1);
    }
    process.stdout.write('  [OK]   质量门禁通过\n');
  }

  // 2. 抽取项目元数据
  const info = extractProjectInfo(root);
  const projectName = sanitizeProjectName(info.projectName);
  process.stdout.write(`  [OK]   项目名: ${projectName}\n`);
  if (info.projectDescription) {
    process.stdout.write(`  [INFO] 描述: ${info.projectDescription.slice(0, 60)}${info.projectDescription.length > 60 ? '...' : ''}\n`);
  }

  // 3. 准备交付网站目录 delivery/<项目名>/
  const deliveryRoot = path.join(root, 'delivery');
  const siteDir = path.join(deliveryRoot, projectName);
  // 清理旧交付网站（含旧 delivery-package.zip 与旧 <项目名> 目录）
  if (fs.existsSync(deliveryRoot)) {
    fs.rmSync(deliveryRoot, { recursive: true, force: true });
  }
  fs.mkdirSync(siteDir, { recursive: true });

  // 4. 复制 demo/ 与 docs/ 到交付网站
  const demoDir = path.join(root, 'demo');
  const docsDir = path.join(root, 'docs');
  let totalFiles = 0;

  if (fs.existsSync(demoDir)) {
    const demoFiles = walkRelative(demoDir, demoDir);
    totalFiles += demoFiles.length;
    copyDir(demoDir, path.join(siteDir, 'demo'));
    process.stdout.write(`  [OK]   demo/ 文件数: ${demoFiles.length}\n`);
  } else {
    process.stderr.write('[FAIL] demo/ 目录不存在\n');
    process.exit(1);
  }

  if (fs.existsSync(docsDir)) {
    const docsFiles = walkRelative(docsDir, docsDir);
    totalFiles += docsFiles.length;
    copyDir(docsDir, path.join(siteDir, 'docs'));
    process.stdout.write(`  [OK]   docs/ 文件数: ${docsFiles.length}\n`);
  } else {
    process.stderr.write('[FAIL] docs/ 目录不存在\n');
    process.exit(1);
  }

  // 5. 生成 project-info.json
  const skillVersion = extractSkillVersion(root);
  const generatedAt = new Date().toISOString().slice(0, 10);
  const projectInfo = {
    projectName: info.projectName,
    projectSlug: info.projectSlug,
    projectNameEn: info.projectSlug, // 英文名 = slug，便于服务端索引
    version: '1.0.0',                // 默认版本，发布时由 release 表单覆盖
    description: info.projectDescription,
    domain: info.domain,
    roles: info.rolesList === '-' ? [] : info.rolesList.split('、'),
    pageCount: info.pageCount === '-' ? null : Number(info.pageCount),
    entityCount: info.entityCount === '-' ? null : Number(info.entityCount),
    generatedAt,
    skillVersion,
  };
  fs.writeFileSync(
    path.join(siteDir, 'project-info.json'),
    JSON.stringify(projectInfo, null, 2),
    { encoding: 'utf-8' }
  );
  process.stdout.write('  [OK]   project-info.json 已生成\n');

  // 6. 渲染交付网站 index.html
  const templatePath = findDeliveryTemplate();
  if (!templatePath) {
    process.stderr.write('[WARN] delivery-site-template.html 未找到，跳过 index.html 生成\n');
    process.stderr.write('       （预期位置: assets/delivery-site-template.html）\n');
  } else {
    const html = renderDeliveryIndex(templatePath, info, generatedAt, skillVersion);
    fs.writeFileSync(path.join(siteDir, 'index.html'), html, { encoding: 'utf-8' });
    process.stdout.write('  [OK]   index.html 已渲染（IP 风格交付网站）\n');
  }

  // 7. 生成三个下载包
  //    关键：先打 full-delivery.zip（此时 downloads/ 尚未创建，天然排除）
  //         再创建 downloads/ 并放入三个 zip
  const downloadsDir = path.join(siteDir, 'downloads');
  fs.mkdirSync(downloadsDir, { recursive: true });

  // 7.1 full-delivery.zip — 完整交付网站（排除 downloads/）
  //     用临时目录：复制 siteDir 内容（不含 downloads）到临时目录再压缩
  const tmpFullDir = path.join(deliveryRoot, '.tmp-full');
  if (fs.existsSync(tmpFullDir)) {
    fs.rmSync(tmpFullDir, { recursive: true, force: true });
  }
  fs.mkdirSync(tmpFullDir, { recursive: true });
  // 复制 siteDir 下所有项（排除 downloads/）到临时目录
  for (const entry of fs.readdirSync(siteDir, { withFileTypes: true })) {
    if (entry.name === 'downloads') continue;
    const src = path.join(siteDir, entry.name);
    const dst = path.join(tmpFullDir, entry.name);
    if (entry.isDirectory()) {
      copyDir(src, dst);
    } else {
      fs.copyFileSync(src, dst);
    }
  }
  const fullZipPath = path.join(downloadsDir, 'full-delivery.zip');
  const fullSize = packToZipStandard(tmpFullDir, fullZipPath);
  fs.rmSync(tmpFullDir, { recursive: true, force: true });
  process.stdout.write(`  [OK]   full-delivery.zip (${(fullSize / 1024).toFixed(2)} KB) — 产品研发团队\n`);

  // 7.2 demo-only.zip — 仅 demo/
  const demoZipPath = path.join(downloadsDir, 'demo-only.zip');
  const demoSize = packToZipStandard(path.join(siteDir, 'demo'), demoZipPath);
  process.stdout.write(`  [OK]   demo-only.zip (${(demoSize / 1024).toFixed(2)} KB) — 客户\n`);

  // v5.9：移除 docs-only.zip（测试开发文档包），仅保留 demo-only.zip + full-delivery.zip

  // 8. 更新 state.yaml
  let updatedState = stateText;
  if (/delivery_packaged:\s*false/.test(updatedState)) {
    updatedState = updatedState.replace(/delivery_packaged:\s*false/, 'delivery_packaged: true');
  } else if (!/delivery_packaged:/.test(updatedState)) {
    updatedState = updatedState.trimEnd() + '\ndelivery_packaged: true\n';
  }
  fs.writeFileSync(stateFile, updatedState, { encoding: 'utf-8' });
  process.stdout.write('  [OK]   state.yaml 已更新（delivery_packaged: true）\n');

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] 交付网站打包汇总\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`  交付网站:   ${path.relative(root, siteDir)}/\n`);
  process.stdout.write(`  入口文件:   ${path.relative(root, path.join(siteDir, 'index.html'))}\n`);
  process.stdout.write(`  打包文件数: ${totalFiles}（demo + docs）\n`);
  process.stdout.write(`  下载包:\n`);
  process.stdout.write(`    - demo-only.zip      ${(demoSize / 1024).toFixed(2)} KB（客户）\n`);
  process.stdout.write(`    - full-delivery.zip  ${(fullSize / 1024).toFixed(2)} KB（产品研发）\n`);

  process.stdout.write('\n>>> 打包完成\n');
  return {
    ok: true,
    siteDir,
    zipPaths: { demo: demoZipPath, full: fullZipPath },
    fileCount: totalFiles,
  };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main();
}
