// package-delivery.mjs
// 打包 demo/ + docs/ 为交付网站（v5.7 — 交付网站 + 三种角色下载包 + mermaid 资产）
//
// 调用：node package-delivery.mjs（无参数）
// cwd：sim-project 目录
// 功能：
//   1. 校验 runtime_audit_passed/final_approved 硬门禁 + 质量门禁通过
//   2. 从 .demora/requirement-model.yaml 抽取项目元数据
//   3. 创建 delivery/<项目名>/ 交付网站目录：
//      - index.html（从 delivery-site-template.html 渲染，IP 风格）
//      - project-info.json（项目元数据）
//      - demo/、docs/ 完整副本（在线可浏览，含 docs/assets/mermaid/ 流程图资产）
//      - downloads/demo-only.zip（仅 demo/，面向客户）
//      - downloads/full-delivery.zip（完整交付网站，排除 downloads/，面向产品研发）
//      - <项目根>/delivery.zip（整站打包，发布到公网用）+ 站点根 release-payload.js（file:// 发布兜底）（v5.21）
//   4. 更新 state.yaml 的 delivery_packaged: true
//   5. v5.25 P0-1：写入 delivery_packaged_at 时间戳 + 冻结 demo/（全部文件只读，技术阻断打包后改写）；
//      修复 demo 前必须先 node package-delivery.mjs --unfreeze-demo 显式解冻
//
// v5.14.16 根治修复（A/B 测试 wb-dsf-0731-2 暴露的 3 个漏洞）：
//   1. 软门禁升级为硬门禁：删除 demo_protected 软分支 + UNVERIFIED-LABEL 软警告
//      根因：wb-dsf-0731-2 在 D 评级下利用软分支"标注未审计后继续打包"，违反 Phase 3 门禁
//      修复：runtime_audit_passed !== true 且 final_approved !== true 时硬 FAIL 退出码 1
//   2. 截图黑名单：失败证据截图不再进入客户交付包
//      根因：wb-dsf-0731-2 把 patent-fto-D10-activation-failed.png 等失败截图打入 zip
//      修复：copyDir 时对 screenshots/ 子目录做黑名单过滤（含 failed/no-coop/error 关键词的不复制）
//   3. .tmp-full 位置迁移：从 delivery/.tmp-full 改到 .demora/.tmp-full-package/
//      根因：wb-dsf-0731-2 的 WorkBuddy safe-delete 因路径格式失败导致 .tmp-full 残留污染 delivery/
//      修复：临时目录迁移到 .demora/ 下，即使清理失败也不会污染交付目录
//
// v5.7 变更：
//   - docs/ 现在包含 assets/mermaid/ 子目录（mermaid.min.js + mermaid-init.js）
//   - copyDir 自动递归复制，无需特殊处理
//   - full-delivery.zip 会自动包含 mermaid 资产（约 3.4 MB）
//
// 设计要点：
//   - full-delivery.zip 在 downloads/ 创建之前打包，天然排除自身，避免递归
//   - 项目名取自 requirement-model.yaml 的 project.name，非法路径字符替换为 -
//   - 模板路径：../assets/delivery-site-template.html（构建包与源码通用）
//
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { safeRemoveDirSync } from './lib/platform-utils.mjs';
import { readStateYaml, invalidate } from './lib/state-cache.mjs';
import { computeDirHash, SCREENSHOT_BLACKLIST_REGEX } from './lib/hash-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 遍历目录，返回相对路径文件列表
 */
function walkRelative(dir, base) {
  const result = [];
  if (!fs.existsSync(dir)) return result;
  function walk(d) {
    for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, entry.name);
      if (entry.isDirectory()) {
        walk(full);
      } else {
        const rel = path.relative(base, full).replace(/\\/g, '/');
        result.push({ full, rel });
      }
    }
  }
  walk(dir);
  return result;
}

/**
 * 将源目录打包为标准 ZIP（使用 PowerShell Compress-Archive）
 * 跨平台兼容：Windows 使用 PowerShell，其它平台使用 zip 命令
 * @param {string} srcDir - 源目录
 * @param {string} outputPath - 输出 ZIP 路径
 * @returns {number} ZIP 文件大小（字节）
 */
function packToZipStandard(srcDir, outputPath) {
  if (fs.existsSync(outputPath)) {
    fs.unlinkSync(outputPath);
  }
  if (process.platform === 'win32') {
    const srcPath = path.resolve(srcDir).replace(/\\/g, '\\');
    const dstPath = path.resolve(outputPath).replace(/\\/g, '\\');
    const cmd = `powershell.exe -NoProfile -Command "Compress-Archive -Path '${srcPath}\\*' -DestinationPath '${dstPath}' -Force"`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('Compress-Archive 失败: ' + e.message);
    }
  } else {
    const cmd = `cd "${srcDir}" && zip -r "${outputPath}" .`;
    try {
      execSync(cmd, { stdio: 'pipe' });
    } catch (e) {
      throw new Error('zip 命令失败: ' + e.message);
    }
  }
  return fs.statSync(outputPath).size;
}

/**
 * 复制目录（递归）
 * @returns {number} 复制文件数
 */
function copyDir(src, dst) {
  if (!fs.existsSync(src)) return 0;
  fs.mkdirSync(dst, { recursive: true });
  let count = 0;
  function walk(s, d) {
    for (const entry of fs.readdirSync(s, { withFileTypes: true })) {
      const sFull = path.join(s, entry.name);
      const dFull = path.join(d, entry.name);
      if (entry.isDirectory()) {
        // v5.19 D-1：排除 IDE 规则目录（.cursor/.windsurf），跳过整个子树
        if (DELIVERY_EXCLUDE_DIR_NAMES.has(entry.name)) {
          process.stdout.write(`  [INFO] v5.19 D-1 交付排除 IDE 规则目录: ${entry.name}/（工作区保留，不进入交付包）\n`);
          continue;
        }
        fs.mkdirSync(dFull, { recursive: true });
        walk(sFull, dFull);
      } else {
        fs.copyFileSync(sFull, dFull);
        count++;
      }
    }
  }
  walk(src, dst);
  return count;
}

// v5.16 Task 9.3：SCREENSHOT_BLACKLIST_REGEX 已抽取到 lib/hash-utils.mjs（删除本地定义）
//   原本地定义与 verify-delivery.mjs V11_BLACKLIST_REGEX 完全一致，已统一为共享常量
//   lib/hash-utils.mjs 导出的 SCREENSHOT_BLACKLIST_REGEX 与原实现字符级一致

/**
 * v5.14.16 修复 D（批次1）：调试文件黑名单正则
 * 防御 W-1（8 个调试 JS 文件入库）
 * 匹配：_*.js / _*.tmp / _annotation_data.js 等 AI 调试残留文件
 */
const DEBUG_FILE_BLACKLIST_REGEX = /^_.*\.(js|tmp)$|^_annotation_data\.js$/i;

// v5.19 D-1 交付目录排除 IDE 规则目录（工作区保留，对终端交付用户无价值）
//   背景：.cursor/ 与 .windsurf/ 由 scaffold 的 injectIdeRules 注入工作区（demora.mdc 等
//         含三阶段流程 + 标注契约，对开发接手方有价值），但交付包面向客户/产品研发，
//         IDE 规则文件无意义。用户决策（方案 a）：交付目录（delivery/）排除，工作区保留。
//   实现：copyDir / copyDemoDirWithScreenshotFilter 递归复制时，命中目录名则跳过整个子树
//   说明：正常场景 .cursor/.windsurf 位于项目根（本就不在 demo/、docs/ 复制范围内），
//         此排除为目录级防御——即使 IDE 规则目录被误放进 demo/ 或 docs/ 子树也不会进入交付包
const DELIVERY_EXCLUDE_DIR_NAMES = new Set(['.cursor', '.windsurf']);

/**
 * v5.14.16 修复 D（批次1）：读取 audit-result.json 的 label 字段
 * 用于历史截图 label 过滤（仅保留当前 label + d7-visual-* 截图）
 * @param {string} demoDir - demo/ 目录路径
 * @returns {string|null} label 字段值，读取失败返回 null（不启用 label 过滤）
 */
function readAuditLabel(demoDir) {
  const auditFile = path.join(demoDir, 'audit-result.json');
  if (!fs.existsSync(auditFile)) return null;
  try {
    const data = JSON.parse(fs.readFileSync(auditFile, 'utf-8'));
    // 兼容多种字段名：label / scenario / audit_label
    return data.label || data.scenario || data.audit_label || null;
  } catch (e) {
    return null;
  }
}

/**
 * v5.14.16 修复 D（批次1）：复制 demo/ 目录并做多级过滤
 *   1. 调试文件黑名单过滤：_*.js / _*.tmp / _annotation_data.js 不复制
 *   2. 失败截图黑名单过滤：screenshots/ 下含 fail/error/unresponsive/overlap 的图片不复制
 *   3. 历史 label 过滤：screenshots/ 下仅保留当前 label + d7-visual-* 截图
 *      根因：wb-glm52 实测 148 张历史截图堆积（v1~v7），命名不含 fail，黑名单无法治理
 *      实现：读取 audit-result.json 的 label 字段，仅复制匹配 label 或 d7-visual-* 的截图
 *      降级：audit-result.json 不存在或无 label 字段时，仅做黑名单过滤（不启用 label 过滤）
 * @param {string} src - 源 demo/ 目录
 * @param {string} dst - 目标 demo/ 目录
 * @returns {{count: number, filtered: number, filteredNames: string[], filterReasons: object}}
 */
function copyDemoDirWithScreenshotFilter(src, dst) {
  if (!fs.existsSync(src)) return { count: 0, filtered: 0, filteredNames: [], filterReasons: {} };
  fs.mkdirSync(dst, { recursive: true });
  let count = 0;
  let filtered = 0;
  const filteredNames = [];
  const filterReasons = { debug: 0, blacklist: 0, label: 0 };

  // 读取当前 audit label（用于历史截图过滤）
  const currentLabel = readAuditLabel(src);
  if (currentLabel) {
    process.stdout.write(`  [INFO] audit-result.json label: "${currentLabel}"，启用历史截图 label 过滤\n`);
  } else {
    process.stdout.write(`  [INFO] audit-result.json 无 label 字段，仅做黑名单过滤（不启用 label 过滤）\n`);
  }

  function walk(s, d) {
    for (const entry of fs.readdirSync(s, { withFileTypes: true })) {
      const sFull = path.join(s, entry.name);
      const dFull = path.join(d, entry.name);
      if (entry.isDirectory()) {
        // v5.19 D-1：排除 IDE 规则目录（.cursor/.windsurf），跳过整个子树
        if (DELIVERY_EXCLUDE_DIR_NAMES.has(entry.name)) {
          process.stdout.write(`  [INFO] v5.19 D-1 交付排除 IDE 规则目录: ${entry.name}/（工作区保留，不进入交付包）\n`);
          continue;
        }
        fs.mkdirSync(dFull, { recursive: true });
        walk(sFull, dFull);
      } else {
        // 过滤 1：调试文件黑名单（全目录生效，不限 screenshots/）
        if (DEBUG_FILE_BLACKLIST_REGEX.test(entry.name)) {
          filtered++;
          filteredNames.push(entry.name);
          filterReasons.debug++;
          continue;
        }

        // 过滤 2 & 3：仅对 screenshots/ 目录下的图片文件
        const inScreenshotsDir = /[/\\]screenshots[/\\]?$/i.test(s) || /[/\\]screenshots[/\\]/i.test(s);
        const isImage = /\.(png|jpg|jpeg)$/i.test(entry.name);

        if (inScreenshotsDir && isImage) {
          // 过滤 2：失败截图黑名单
          if (SCREENSHOT_BLACKLIST_REGEX.test(entry.name)) {
            filtered++;
            filteredNames.push(entry.name);
            filterReasons.blacklist++;
            continue;
          }
          // 过滤 3：历史 label 过滤
          // 仅保留当前 label 截图 + d7-visual-* 截图（视觉检查截图不与 label 绑定）
          // 命名规范：<label>-D<N>-<step>.png 或 d7-visual-<label>-<step>.png
          if (currentLabel) {
            const matchesCurrentLabel = entry.name.toLowerCase().includes(currentLabel.toLowerCase());
            const isD7Visual = /d7-visual/i.test(entry.name);
            if (!matchesCurrentLabel && !isD7Visual) {
              filtered++;
              filteredNames.push(entry.name);
              filterReasons.label++;
              continue;
            }
          }
        }

        fs.copyFileSync(sFull, dFull);
        count++;
      }
    }
  }
  walk(src, dst);
  return { count, filtered, filteredNames, filterReasons };
}

// v5.16 Task 9.1：computeDirHash 已抽取到 lib/hash-utils.mjs（删除本地定义）
//   原本地实现（无 filtered 选项）与 verify-delivery.mjs L735 实现（含 filtered 选项）
//   在 filtered=false 时行为完全等价，已统一为 lib/hash-utils.mjs 的 computeDirHash
//   lib 实现支持 filtered 选项（package-delivery 调用时 filtered=false 默认行为不变）
//   注意：lib 内部使用 crypto + path.relative 归一化，与本处原实现算法一致

/**
 * 将 YAML 文本按顶层 key 分段（顶层 key = column 0 起的 `xxx:` 行）
 * 返回 { keyName: sectionContent } 映射；sectionContent 含该 key 下所有缩进行
 * 用于轻量解析 requirement-model.yaml，无 js-yaml 依赖
 */
function splitYamlSections(text) {
  const sections = {};
  const lines = text.split('\n');
  let currentKey = null;
  let currentContent = [];
  for (const line of lines) {
    // 顶层 key：行首非空白 + 以冒号结尾（允许 `key: value` 形式，但 section 类 key 通常为 `key:` 空值）
    const keyMatch = line.match(/^(\S[^:]*):\s*$/);
    if (keyMatch) {
      if (currentKey) sections[currentKey] = currentContent.join('\n');
      currentKey = keyMatch[1];
      currentContent = [];
    } else if (currentKey) {
      currentContent.push(line);
    }
  }
  if (currentKey) sections[currentKey] = currentContent.join('\n');
  return sections;
}

// ============================================================================
// v5.6 新增：Markdown 解析与段落提取（用于 PROJECT BACKGROUND 增强）
// 与 generate-product-docs.mjs 中的实现保持一致，无外部依赖
// ============================================================================

/**
 * HTML 转义
 */
function escHtml(s) {
  if (s === null || s === undefined) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * 行内格式处理：粗体、斜体、行内代码、链接
 */
function applyInlineMarkdownPd(text) {
  const codeBlocks = [];
  let processed = text.replace(/`([^`]+)`/g, (m, code) => {
    codeBlocks.push(code);
    return `\u0000CODE${codeBlocks.length - 1}\u0000`;
  });
  processed = processed.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  processed = processed.replace(/__([^_]+)__/g, '<strong>$1</strong>');
  processed = processed.replace(/(?<!\*)\*([^*\n]+)\*(?!\*)/g, '<em>$1</em>');
  processed = processed.replace(/(?<!_)_([^_\n]+)_(?!_)/g, '<em>$1</em>');
  processed = processed.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  processed = processed.replace(/\u0000CODE(\d+)\u0000/g, (m, idx) => {
    return '<code>' + escHtml(codeBlocks[Number(idx)]) + '</code>';
  });
  return processed;
}

/**
 * 轻量 Markdown → HTML 转换（用于 delivery 入口 HTML 的 PM 需求展示）
 * 支持：标题、段落、列表、表格、代码块、引用块、分割线、行内格式
 */
function markdownToHtmlPd(md) {
  if (!md || typeof md !== 'string') return '';
  const lines = md.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  const out = [];
  let i = 0;
  let listType = null;

  function closeList() {
    if (listType) { out.push(`</${listType}>`); listType = null; }
  }

  while (i < lines.length) {
    const line = lines[i];

    if (/^```/.test(line.trim())) {
      closeList();
      const codeLines = [];
      i++;
      while (i < lines.length && !/^```/.test(lines[i].trim())) { codeLines.push(lines[i]); i++; }
      i++;
      out.push(`<pre><code>${escHtml(codeLines.join('\n'))}</code></pre>`);
      continue;
    }
    if (line.trim() === '') { closeList(); i++; continue; }

    const hMatch = line.match(/^(#{1,5})\s+(.+)$/);
    if (hMatch) {
      closeList();
      const level = hMatch[1].length;
      out.push(`<h${level}>${applyInlineMarkdownPd(escHtml(hMatch[2]))}</h${level}>`);
      i++; continue;
    }
    if (/^---+\s*$/.test(line)) { closeList(); out.push('<hr>'); i++; continue; }

    if (/^\|/.test(line.trim())) {
      closeList();
      const tableRows = [];
      while (i < lines.length && /^\|/.test(lines[i].trim())) { tableRows.push(lines[i].trim()); i++; }
      if (tableRows.length >= 2) {
        const headers = tableRows[0].split('|').slice(1, -1).map(s => s.trim());
        const bodyRows = tableRows.slice(1).filter(r => !/^\|[\s-:|]+\|$/.test(r));
        out.push('<table><thead><tr>');
        for (const h of headers) out.push(`<th>${applyInlineMarkdownPd(escHtml(h))}</th>`);
        out.push('</tr></thead><tbody>');
        for (const r of bodyRows) {
          const cells = r.split('|').slice(1, -1).map(s => s.trim());
          out.push('<tr>');
          for (const c of cells) out.push(`<td>${applyInlineMarkdownPd(escHtml(c))}</td>`);
          out.push('</tr>');
        }
        out.push('</tbody></table>');
      }
      continue;
    }

    if (/^>\s?/.test(line.trim())) {
      closeList();
      const quoteLines = [];
      while (i < lines.length && /^>\s?/.test(lines[i].trim())) {
        quoteLines.push(lines[i].trim().replace(/^>\s?/, '')); i++;
      }
      out.push(`<blockquote>${applyInlineMarkdownPd(escHtml(quoteLines.join(' ')))}</blockquote>`);
      continue;
    }

    const ulMatch = line.match(/^(\s*)[-*]\s+(.+)$/);
    if (ulMatch) {
      if (listType !== 'ul') { closeList(); out.push('<ul>'); listType = 'ul'; }
      out.push(`<li>${applyInlineMarkdownPd(escHtml(ulMatch[2]))}</li>`);
      i++; continue;
    }
    const olMatch = line.match(/^(\s*)\d+\.\s+(.+)$/);
    if (olMatch) {
      if (listType !== 'ol') { closeList(); out.push('<ol>'); listType = 'ol'; }
      out.push(`<li>${applyInlineMarkdownPd(escHtml(olMatch[2]))}</li>`);
      i++; continue;
    }

    closeList();
    const paraLines = [];
    while (i < lines.length && lines[i].trim() !== '' &&
      !/^(#{1,5}\s|---+\s*$|```|>|[-*]\s|\d+\.\s|\|)/.test(lines[i].trim())) {
      paraLines.push(lines[i].trim()); i++;
    }
    if (paraLines.length > 0) {
      out.push(`<p>${applyInlineMarkdownPd(escHtml(paraLines.join(' ')))}</p>`);
    }
  }
  closeList();
  return out.join('\n');
}

/**
 * 从 markdown 文件提取指定 ## 段落内容
 * 规则：从 `## sectionTitle` 后开始，到下一个 `## ` 或 `---` 或 EOF 结束
 */
function extractMarkdownSectionPd(filePath, sectionTitle) {
  if (!filePath || !sectionTitle) return '';
  if (!fs.existsSync(filePath)) return '';
  const text = fs.readFileSync(filePath, { encoding: 'utf-8' });
  const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
  let inSection = false;
  let content = [];
  const headingRegex = new RegExp('^##\\s+' + sectionTitle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\s*$');
  for (const line of lines) {
    if (headingRegex.test(line.trim())) { inSection = true; continue; }
    if (inSection) {
      if (/^##\s+/.test(line.trim())) break;
      if (/^---\s*$/.test(line.trim())) break;
      content.push(line);
    }
  }
  let result = content.join('\n').trim();
  result = result.replace(/^>.*(\n|$)/, '').trim();
  return result;
}

/**
 * 从 requirement-model.yaml 抽取项目元数据（轻量解析，无 js-yaml 依赖）
 * v5.6 新增：5 个 PROJECT BACKGROUND 增强字段（businessBackground/corePainPoints/
 *            solutionOverview/pmRequirementBrief/pmRequirementWordCount）
 * @param {string} root - sim-project 根目录
 * @returns {object} 项目元数据
 */
function extractProjectInfo(root) {
  const modelPath = path.join(root, '.demora', 'requirement-model.yaml');
  const fallbackName = path.basename(root);

  // v5.6 新增：从 docs/prd/01-background.md 提取业务背景/痛点/解决方案
  // 从 inbox/text/requirement-input.md 提取 PM 完整需求
  const bgFile = path.join(root, 'docs', 'prd', '01-background.md');
  const inputFile = path.join(root, 'inbox', 'text', 'requirement-input.md');

  const businessBgMd = extractMarkdownSectionPd(bgFile, '业务背景');
  const painPointsMd = extractMarkdownSectionPd(bgFile, '核心痛点');
  const solutionMd = extractMarkdownSectionPd(bgFile, '解决方案');

  let pmRequirementRaw = '';
  if (fs.existsSync(inputFile)) {
    pmRequirementRaw = fs.readFileSync(inputFile, { encoding: 'utf-8' });
  }
  const pmRequirementWordCount = pmRequirementRaw ? pmRequirementRaw.length : 0;

  // PROJECT BACKGROUND 增强字段（v5.6）
  const bgFields = {
    businessBackground: businessBgMd ? markdownToHtmlPd(businessBgMd) : '',
    corePainPoints: painPointsMd ? markdownToHtmlPd(painPointsMd) : '',
    solutionOverview: solutionMd ? markdownToHtmlPd(solutionMd) : '',
    pmRequirementBrief: pmRequirementRaw ? markdownToHtmlPd(pmRequirementRaw) : '',
    pmRequirementWordCount: String(pmRequirementWordCount),
  };

  if (!fs.existsSync(modelPath)) {
    return {
      projectName: fallbackName,
      projectSlug: generateSlugFromName(fallbackName),
      projectDescription: '',
      domain: '-',
      rolesList: '-',
      pageCount: '-',
      entityCount: '-',
      raw: null,
      ...bgFields,
    };
  }

  const text = fs.readFileSync(modelPath, { encoding: 'utf-8' });
  const sections = splitYamlSections(text);

  // project 段：抽取 name / description / domain / slug（2 空格缩进的子字段）
  // v5.11 新增：project.slug 字段（PM 手工输入的英文 slug，用于公网发布）
  const projectSection = sections['project'] || '';
  const nameMatch = projectSection.match(/^  name:\s*(.+)$/m);
  const descMatch = projectSection.match(/^  description:\s*(.+)$/m);
  const domainMatch = projectSection.match(/^  domain:\s*(.+)$/m);
  const slugMatch = projectSection.match(/^  slug:\s*(.+)$/m);

  // entities 段：统计顶层条目（2 空格缩进的 `  - name:`，排除 6 空格的字段 `- name:`）
  let entityCount = 0;
  const entitiesSection = sections['entities'] || '';
  if (entitiesSection) {
    entityCount = (entitiesSection.match(/^  - name:/gm) || []).length;
  }

  // pages 段：统计顶层条目（2 空格缩进的 `  - ` 列表项）
  let pageCount = 0;
  const pagesSection = sections['pages'] || '';
  if (pagesSection) {
    pageCount = (pagesSection.match(/^  - /gm) || []).length;
  }

  // roles 段：抽取顶层条目的 name 字段
  let rolesList = '-';
  const rolesSection = sections['roles'] || '';
  if (rolesSection) {
    const roleNames = (rolesSection.match(/^  - name:\s*(.+)$/gm) || [])
      .map(s => s.replace(/^  - name:\s*/, '').trim().replace(/^["']|["']$/g, ''))
      .filter(s => s);
    if (roleNames.length > 0) rolesList = roleNames.join('、');
  }

  // v5.11：抽取 project.slug，校验 + 自动生成兜底
  const rawProjectName = (nameMatch ? nameMatch[1].trim() : fallbackName).replace(/^["']|["']$/g, '');
  let projectSlug = slugMatch ? slugMatch[1].trim().replace(/^["']|["']$/g, '') : '';
  // 校验 PM 手工输入的 slug；不合法则丢弃改用自动生成
  if (projectSlug && !isValidSlug(projectSlug)) {
    process.stderr.write(`[WARN] project.slug "${projectSlug}" 格式不合法（需小写字母开头，仅含小写字母/数字/连字符，3-64 字符），改用自动生成\n`);
    projectSlug = '';
  }
  if (!projectSlug) {
    projectSlug = generateSlugFromName(rawProjectName);
  }

  return {
    projectName: rawProjectName,
    projectSlug,
    projectDescription: descMatch ? descMatch[1].trim().replace(/^["']|["']$/g, '') : '',
    domain: domainMatch ? domainMatch[1].trim() : '-',
    rolesList,
    pageCount: pageCount > 0 ? String(pageCount) : '-',
    entityCount: entityCount > 0 ? String(entityCount) : '-',
    raw: text,
    ...bgFields,
  };
}

/**
 * 净化项目名为合法目录名（保留中文，替换非法字符）
 */
function sanitizeProjectName(name) {
  return name.replace(/[\/\\:*?"<>|]/g, '-').trim() || 'unnamed-project';
}

/**
 * v5.11 新增：从中文项目名生成英文 slug
 * 策略（决策 5-C 组合）：
 *   - 优先从 requirement-model.yaml 的 project.slug 字段读取（PM 手工输入）
 *   - 若未提供，则从此字典映射查找常见行业 slug
 *   - 字典未命中时，回退为 'project-<时间戳后 6 位>' 兜底
 * 字典覆盖 demora 常见 audit 场景与典型业务领域
 */
const SLUG_DICT = {
  // audit 场景
  '旅游行程预订系统': 'travel-booking',
  '餐饮点餐系统': 'restaurant-order',
  '诊所预约挂号系统': 'clinic-appointment',
  // 通用业务
  '客户关系管理': 'crm',
  '订单管理': 'order-mgmt',
  '库存管理': 'inventory',
  '人事管理': 'hr',
  '财务管理': 'finance',
  '项目管理': 'project-mgmt',
  '内容管理': 'cms',
  '电商': 'ecommerce',
  '支付': 'payment',
  '物流': 'logistics',
};

function generateSlugFromName(projectName) {
  if (!projectName) return 'project-' + Date.now().toString(36).slice(-6);
  // 1. 字典精确匹配
  if (SLUG_DICT[projectName]) return SLUG_DICT[projectName];
  // 2. 字典包含匹配（项目名含字典 key）
  for (const [k, v] of Object.entries(SLUG_DICT)) {
    if (projectName.includes(k)) return v;
  }
  // 3. 提取项目名中的英文字母/数字（如 "CRM 系统" → "crm"）
  const en = projectName.match(/[A-Za-z][A-Za-z0-9]+/);
  if (en && en[0].length >= 2) return en[0].toLowerCase();
  // 4. 兜底：project-<短时间戳>
  return 'project-' + Date.now().toString(36).slice(-6);
}

/**
 * 校验 slug 格式：小写字母开头，仅含小写字母/数字/连字符，3-64 字符
 */
function isValidSlug(slug) {
  return typeof slug === 'string' && /^[a-z][a-z0-9-]{2,63}$/.test(slug);
}

/**
 * 查找交付网站模板（构建包与源码通用）
 * 构建包：scripts/ → ../assets/delivery-site-template.html
 * 源码：  scripts/ → ../assets/delivery-site-template.html
 */
function findDeliveryTemplate() {
  const candidate = path.join(__dirname, '..', 'assets', 'delivery-site-template.html');
  if (fs.existsSync(candidate)) return candidate;
  return null;
}

/**
 * 从 SKILL.md frontmatter 抽取 Skill 版本（name 字段）
 */
function extractSkillVersion(root) {
  // 优先从 .demora/model-lock.yaml 读取 skillName
  const lockFile = path.join(root, '.demora', 'model-lock.yaml');
  if (fs.existsSync(lockFile)) {
    const t = fs.readFileSync(lockFile, { encoding: 'utf-8' });
    const m = t.match(/^skillName:\s*(.+)$/m);
    if (m) return m[1].trim();
  }
  return 'oc-demora';
}

/**
 * 渲染交付网站 index.html（占位符替换）
 * v5.6 增强：
 *   1. 新增 5 个 PROJECT BACKGROUND 占位符替换
 *      - {{businessBackground}} / {{corePainPoints}} / {{solutionOverview}}
 *      - {{pmRequirementBrief}} / {{pmRequirementWordCount}}
 *   2. 新增条件渲染：{{#if field}}...{{/if}} 语法
 *      - field 为空时移除整个块（含标记）
 *      - field 非空时保留块内容（移除标记）
 */
function renderDeliveryIndex(templatePath, info, generatedAt, skillVersion) {
  let html = fs.readFileSync(templatePath, { encoding: 'utf-8' });

  // 1. 处理条件渲染：{{#if field}}...{{/if}}
  //    field 为空时移除整个块；非空时保留内容（移除标记）
  const conditionalFields = [
    'businessBackground',
    'corePainPoints',
    'solutionOverview',
    'pmRequirementBrief',
  ];
  for (const field of conditionalFields) {
    const value = info[field];
    const isEmpty = !value || String(value).trim() === '';
    // 匹配 {{#if field}}...{{/if}}（非贪婪，允许跨行）
    const regex = new RegExp(
      '\\{\\{#if\\s+' + field + '\\}\\}([\\s\\S]*?)\\{\\{/if\\}\\}',
      'g'
    );
    if (isEmpty) {
      // 移除整个条件块
      html = html.replace(regex, '');
    } else {
      // 保留块内容，移除条件标记
      html = html.replace(regex, '$1');
    }
  }

  // 2. 标准占位符替换
  const replacements = {
    '{{projectName}}': info.projectName,
    '{{projectSlug}}': info.projectSlug || '',
    '{{projectDescription}}': info.projectDescription || '（无描述）',
    '{{domain}}': info.domain,
    '{{rolesList}}': info.rolesList,
    '{{pageCount}}': info.pageCount,
    '{{entityCount}}': info.entityCount,
    '{{generatedAt}}': generatedAt,
    '{{skillVersion}}': skillVersion,
    // v5.6 新增：PROJECT BACKGROUND 增强字段
    '{{businessBackground}}': info.businessBackground || '',
    '{{corePainPoints}}': info.corePainPoints || '',
    '{{solutionOverview}}': info.solutionOverview || '',
    '{{pmRequirementBrief}}': info.pmRequirementBrief || '',
    '{{pmRequirementWordCount}}': info.pmRequirementWordCount || '0',
  };
  for (const [k, v] of Object.entries(replacements)) {
    html = html.split(k).join(String(v));
  }

  // v5.13.7: 双视角替换逻辑已移除 — 模板内置单 Demo 卡片 + 给客户 checkbox
  // v5.13.5 曾将单个 Demo 入口替换为客户/产研双视角入口，v5.13.7 改为单 Demo + checkbox 方案
  // checkbox 默认勾选（给客户）→ demo/index.html?annotations=0（无标注）
  // checkbox 取消勾选 → demo/index.html?annotations=1（含标注）
  // 模板已内置 checkbox JS 逻辑，无需此处替换

  return html;
}

/**
 * 主入口
 * @param {object} args - { root?: string }
 */
export async function main(args = {}) {
  const root = args.root || process.cwd();
  // v5.23：隐式根防护——解析根无 .demora/state.yaml 时硬 FAIL，禁止在错误 cwd 隐式创建项目根
  //   根因：UAT0824 opencode-ox- 案例 AI 以工作根为 cwd 调用写入型脚本，工作根残留空 delivery/
  //         （此守卫先于下方 state.yaml 门禁，消息区分"根无效"与"状态门禁未通过"两种场景）
  if (!fs.existsSync(path.join(root, '.demora', 'state.yaml'))) {
    process.stderr.write('[FAIL] 项目根无效: ' + root + '（缺少 .demora/state.yaml）\n');
    process.stderr.write('       请在项目目录内运行，或用 --project-root 显式指定；禁止在错误目录隐式创建项目结构\n');
    process.exit(1);
  }
  // v5.14 P2-12：临时目录追踪，异常退出时 finally 块强制清理（防御 F9 残留）
  const tmpDirsToCleanup = new Set();

  try {
    // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
    try {
      const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
      const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
      if (!integrity.ok && !integrity.skipped) {
        process.stderr.write(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}\n`);
        process.stderr.write('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本\n');
        process.exit(1);
      }
    } catch (e) { /* gate-baseline.mjs 不可用时跳过（开发态兼容） */ }

  process.stdout.write('======================================================================\n');
  process.stdout.write('打包交付（v5.3 交付网站 + 三种角色下载包）\n');
  process.stdout.write('======================================================================\n');

  // 1. 校验状态机门禁（v5.14.16 根治：软门禁升级为硬门禁）
  // v5.5 缺陷：仅检查 demo_protected: true，但该字段在 lock-model.mjs 阶段就设为 true
  //           （demo 仍是空骨架），导致 package-delivery 在 AI 阶段 2 之前执行，
  //           把空壳 demo 打包到 delivery/
  // v5.6 修复：audit 模式要求 runtime_audit_passed: true；非 audit 模式保留 demo_protected 软分支
  // v5.14 修复 F5：demo_protected 不再单独放行，但保留 UNVERIFIED-LABEL 软警告分支
  // v5.14.16 根治：删除 demo_protected 软分支 + UNVERIFIED-LABEL 软警告
  //   根因：A/B 测试 wb-dsf-0731-2 在 D 评级下利用软分支"标注未审计后继续打包"，
  //         AI 自行合理化违规（"在测试场景中可能允许打包但有警告"），违反 Phase 3 门禁
  //   修复：runtime_audit_passed !== true 且 final_approved !== true 时硬 FAIL 退出码 1
  //         AI 无法再通过"标注未审计"绕过门禁，必须返回 Phase 2 修复 demo 重跑 run-audit
  //   设计原则：任何门禁都不能停留在"AI 应该遵守 SKILL.md 文字"层面，必须脚本硬阻断
  const isAuditMode = process.env.DEMORA_AUDIT_MODE === '1';
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) {
    process.stderr.write('[FAIL] state.yaml 不存在\n');
    process.exit(1);
  }
  // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
  //   后续 R-8 跳验检测、V-13 哈希绑定均复用 stateText，缓存命中可省 1 次 IO
  const stateText = readStateYaml(root);

  if (isAuditMode) {
    // audit 模式：严格要求 runtime_audit_passed: true
    if (!/runtime_audit_passed:\s*true/.test(stateText)) {
      process.stderr.write('[FAIL] audit 模式（DEMORA_AUDIT_MODE=1）下 runtime_audit_passed != true，禁止打包\n');
      process.stderr.write('       v5.6 门禁：package-delivery 必须在 AI 阶段 5（run-audit.mjs A/B 评级）之后执行\n');
      process.exit(1);
    }
    process.stdout.write('  [OK]   runtime_audit_passed: true（audit 模式门禁通过）\n');
  } else {
    // 非 audit 模式：v5.14.16 硬门禁
    //   runtime_audit_passed: true（run-audit A/B 评级通过）或 final_approved: true（Phase 3 完成）任一即可
    //   demo_protected 单独不再放行（v5.14.16 删除软分支），AI 必须先跑 run-audit 至 A/B 级
    const hasFinalApproved = /final_approved:\s*true/.test(stateText);
    const hasRuntimeAudit = /runtime_audit_passed:\s*true/.test(stateText);

    if (hasFinalApproved) {
      process.stdout.write('  [OK]   final_approved: true（Phase 3 已完成）\n');
    } else if (hasRuntimeAudit) {
      // runtime_audit_passed: true（run-audit A/B 评级通过）也视为通过
      process.stdout.write('  [OK]   runtime_audit_passed: true（运行时审计已通过，允许打包）\n');
    } else {
      // v5.14.16 硬 FAIL：不再有 UNVERIFIED-LABEL 软分支
      process.stderr.write('[FAIL] state.yaml 无 runtime_audit_passed: true 也无 final_approved: true，禁止打包\n');
      process.stderr.write('       v5.14.16 硬门禁：run-audit.mjs 评级非 A/B 禁止进入 Phase 3\n');
      process.stderr.write('       修复方案：返回 Phase 2 修复 demo 后重跑 run-audit.mjs 直至 A/B 级\n');
      process.exit(1);
    }
  }

  // v5.14.17 批次4 R-8（P0）— 状态机硬门禁：跳验检测（硬阻断）
  //   根因：修复 A 认可 delivery_packaged=true + final_approved=false + current_phase=2 中间态后，
  //         agent 可跳过 verify-delivery 直接再次运行 package-delivery 覆盖交付物。
  //         这会导致 delivery 产物物理存在但未通过 V-1~V-13 任何校验。
  //   修复 R-8：package-delivery 启动时检测"已打包但未验证"状态，硬 FAIL 退出码 1
  //   防御链：
  //     1. package-delivery 硬阻断（此处）— 防 agent 跳验后再次打包覆盖
  //     2. verify-delivery 告警（非阻断）— verify 本身就是来推进状态的，不阻断
  //     3. 消费点检测（verify-delivery V-13）— 防跳验后直接取用 delivery 产物
  //   例外：首次打包时 delivery_packaged 不存在或为 false，不触发此检测
  // v5.18 P0-A2：demo 已变化（修复后重打包）时放行 R-8，实现幂等重打包
  //   根因：verify-delivery V-4 打回后 AI 返回 Phase 2 修复 demo，需重新打包；但 R-8 原硬阻断
  //         "已打包未验证"，把合法修复流程也挡死 → agent 被迫对旧 delivery 跑 verify →
  //         V-3/V-11 哈希不一致连锁二次失败（green 案实证）
  //   修复：比较当前 sim demo/ 哈希与打包时记录的 source_demo_hash，不同则判定"修复后重打包"放行；
  //         相同（demo 未动却仍要重打包）才维持原硬阻断，防 agent 跳验覆盖
  const simDemoDirForR8 = path.join(root, 'demo');
  const currentSourceHash = fs.existsSync(simDemoDirForR8) ? computeDirHash(simDemoDirForR8) : null;
  const recordedSourceHashMatch = stateText.match(/^source_demo_hash:\s*(\S+)\s*$/m);
  const recordedSourceHash = recordedSourceHashMatch ? recordedSourceHashMatch[1] : null;
  const sourceDemoChanged = !!(recordedSourceHash && currentSourceHash && recordedSourceHash !== currentSourceHash);
  {
    const r8StateText = stateText;  // 复用前面已读取的 stateText
    const r8Packaged = /delivery_packaged:\s*true/.test(r8StateText);
    const r8Verified = /delivery_consistency_verified:\s*true/.test(r8StateText);
    if (r8Packaged && !r8Verified && !sourceDemoChanged) {
      process.stderr.write('[FAIL] 检测到"已打包但未验证"状态（delivery_packaged=true && delivery_consistency_verified=false）\n');
      process.stderr.write('       v5.14.17 R-8 硬门禁：禁止在未通过 verify-delivery 的情况下再次打包\n');
      process.stderr.write('       防御：agent 跳过 verify-delivery 后 delivery 产物物理存在但未通过 V-1~V-13 校验\n');
      process.stderr.write('       修复方案：运行 node scripts/verify-delivery.mjs 完成验证后再打包\n');
      process.exit(1);
    } else if (r8Packaged && !r8Verified && sourceDemoChanged) {
      process.stdout.write('  [INFO] demo 已修改（source_demo_hash 变化），判定为修复后重打包，放行 R-8（幂等重同步 delivery/）\n');
    }
  }
  const qReportFile = path.join(root, '.demora', 'quality-report.yaml');
  if (fs.existsSync(qReportFile)) {
    const qText = fs.readFileSync(qReportFile, { encoding: 'utf-8' });
    if (!/^passed:\s*true\s*$/m.test(qText)) {
      process.stderr.write('[FAIL] 质量门禁未通过，禁止打包\n');
      process.exit(1);
    }
    process.stdout.write('  [OK]   质量门禁通过\n');
  }

  // 2. 抽取项目元数据
  const info = extractProjectInfo(root);
  const projectName = sanitizeProjectName(info.projectName);
  process.stdout.write(`  [OK]   项目名: ${projectName}\n`);
  if (info.projectDescription) {
    process.stdout.write(`  [INFO] 描述: ${info.projectDescription.slice(0, 60)}${info.projectDescription.length > 60 ? '...' : ''}\n`);
  }

  // 3. 准备交付网站目录 delivery/<项目名>/
  const deliveryRoot = path.join(root, 'delivery');
  const siteDir = path.join(deliveryRoot, projectName);
  // 清理旧交付网站（含旧 delivery-package.zip 与旧 <项目名> 目录）
  // v5.14.16 修复 H（批次1）：使用 platform-utils 的 safeRemoveDirSync 替代 fs.rmSync
  //   根因：WorkBuddy safe-delete shim 对 rmSync FAIL_CLOSED，清理被吞掉导致旧交付物残留
  //   修复：多策略降级（重命名轮转 → rmSync → 逐个 unlink），shim 拦截时自动降级
  if (fs.existsSync(deliveryRoot)) {
    const removeResult = safeRemoveDirSync(deliveryRoot, { recursive: true, force: true });
    if (!removeResult.ok) {
      process.stdout.write(`  [WARN] 旧 delivery/ 清理失败（shim 拦截或文件锁），策略: ${removeResult.strategy}\n`);
      process.stdout.write(`         原因: ${removeResult.reason || '未知'}\n`);
      process.stdout.write(`         将尝试重命名旧目录后继续打包（不阻塞流程）\n`);
      // 降级：重命名旧目录（不删除，避免阻塞）
      try {
        const backupName = `.delivery-old-${Date.now()}`;
        fs.renameSync(deliveryRoot, path.join(path.dirname(deliveryRoot), backupName));
        process.stdout.write(`  [WARN] 旧 delivery/ 已重命名为 ${backupName}/（需手动清理）\n`);
      } catch (e) {
        process.stderr.write(`[FAIL] 旧 delivery/ 清理与重命名均失败: ${e.message}\n`);
        process.exit(1);
      }
    }
  }
  fs.mkdirSync(siteDir, { recursive: true });

  // 4. 复制 demo/ 与 docs/ 到交付网站
  const demoDir = path.join(root, 'demo');
  const docsDir = path.join(root, 'docs');
  let totalFiles = 0;

  if (fs.existsSync(demoDir)) {
    // v5.14.16 修复 D（批次1）：多级过滤复制（调试文件 + 失败截图 + 历史 label）
    const demoResult = copyDemoDirWithScreenshotFilter(demoDir, path.join(siteDir, 'demo'));
    totalFiles += demoResult.count;
    if (demoResult.filtered > 0) {
      const reasons = demoResult.filterReasons || {};
      process.stdout.write(`  [WARN] 交付物过滤: ${demoResult.filtered} 个文件未复制到交付包\n`);
      process.stdout.write(`         调试文件: ${reasons.debug || 0}, 失败截图: ${reasons.blacklist || 0}, 历史 label: ${reasons.label || 0}\n`);
      for (const name of demoResult.filteredNames.slice(0, 10)) {
        process.stdout.write(`         - ${name}\n`);
      }
      if (demoResult.filteredNames.length > 10) {
        process.stdout.write(`         ... 共 ${demoResult.filteredNames.length} 个\n`);
      }
    }
    process.stdout.write(`  [OK]   demo/ 文件数: ${demoResult.count}\n`);
  } else {
    process.stderr.write('[FAIL] demo/ 目录不存在\n');
    process.exit(1);
  }

  if (fs.existsSync(docsDir)) {
    const docsFiles = walkRelative(docsDir, docsDir);
    totalFiles += docsFiles.length;
    copyDir(docsDir, path.join(siteDir, 'docs'));
    process.stdout.write(`  [OK]   docs/ 文件数: ${docsFiles.length}\n`);
  } else {
    process.stderr.write('[FAIL] docs/ 目录不存在\n');
    process.exit(1);
  }

  // 5. 生成 project-info.json
  const skillVersion = extractSkillVersion(root);
  const generatedAt = new Date().toISOString().slice(0, 10);
  const projectInfo = {
    projectName: info.projectName,
    projectSlug: info.projectSlug,
    projectNameEn: info.projectSlug, // 英文名 = slug，便于服务端索引
    version: '1.0.0',                // 默认版本，发布时由 release 表单覆盖
    description: info.projectDescription,
    domain: info.domain,
    roles: info.rolesList === '-' ? [] : info.rolesList.split('、'),
    pageCount: info.pageCount === '-' ? null : Number(info.pageCount),
    entityCount: info.entityCount === '-' ? null : Number(info.entityCount),
    generatedAt,
    skillVersion,
  };
  fs.writeFileSync(
    path.join(siteDir, 'project-info.json'),
    JSON.stringify(projectInfo, null, 2),
    { encoding: 'utf-8' }
  );
  process.stdout.write('  [OK]   project-info.json 已生成\n');

  // 6. 渲染交付网站 index.html
  const templatePath = findDeliveryTemplate();
  if (!templatePath) {
    process.stderr.write('[WARN] delivery-site-template.html 未找到，跳过 index.html 生成\n');
    process.stderr.write('       （预期位置: assets/delivery-site-template.html）\n');
  } else {
    const html = renderDeliveryIndex(templatePath, info, generatedAt, skillVersion);
    fs.writeFileSync(path.join(siteDir, 'index.html'), html, { encoding: 'utf-8' });
    process.stdout.write('  [OK]   index.html 已渲染（IP 风格交付网站）\n');
  }

  // 7. 生成三个下载包
  //    关键：先打 full-delivery.zip（此时 downloads/ 尚未创建，天然排除）
  //         再创建 downloads/ 并放入三个 zip
  const downloadsDir = path.join(siteDir, 'downloads');
  fs.mkdirSync(downloadsDir, { recursive: true });

  // 7.1 full-delivery.zip — 完整交付网站（排除 downloads/）
  //     用临时目录：复制 siteDir 内容（不含 downloads）到临时目录再压缩
  // v5.14.16 根治：临时目录从 delivery/.tmp-full 迁移到 .demora/.tmp-full-package/
  //   根因：A/B 测试 wb-dsf-0731-2 的 WorkBuddy safe-delete 因路径格式（/c/ vs C:\）失败，
  //         导致 .tmp-full 残留在 delivery/ 目录下污染交付物
  //   修复：临时目录放在 .demora/ 下，即使清理失败也不会污染 delivery/ 目录
  //   .demora/ 是项目元数据目录，不进入交付包，残留在此处对客户不可见
  const tmpFullDir = path.join(root, '.demora', '.tmp-full-package');
  // v5.14 P2-12：注册到清理集合，异常退出时 finally 块强制清理
  tmpDirsToCleanup.add(tmpFullDir);
  if (fs.existsSync(tmpFullDir)) {
    // v5.16 S-8 修复：使用 safeRemoveDirSync 替代 fs.rmSync
    safeRemoveDirSync(tmpFullDir, { recursive: true, force: true });
  }
  fs.mkdirSync(tmpFullDir, { recursive: true });
  // 复制 siteDir 下所有项（排除 downloads/）到临时目录
  for (const entry of fs.readdirSync(siteDir, { withFileTypes: true })) {
    if (entry.name === 'downloads') continue;
    const src = path.join(siteDir, entry.name);
    const dst = path.join(tmpFullDir, entry.name);
    if (entry.isDirectory()) {
      copyDir(src, dst);
    } else {
      fs.copyFileSync(src, dst);
    }
  }
  const fullZipPath = path.join(downloadsDir, 'full-delivery.zip');
  const fullSize = packToZipStandard(tmpFullDir, fullZipPath);
  // v5.16 S-8 修复：使用 safeRemoveDirSync 替代 fs.rmSync，应对 WorkBuddy shim 拦截
  //   根因：shim 拦截 fs.rmSync → .tmp-full-package 残留 → Q-7 检出
  //   修复：多策略降级（重命名轮转 → rmSync → 逐个 unlink）
  {
    const removeResult = safeRemoveDirSync(tmpFullDir, { recursive: true, force: true, maxRetries: 3, retryDelay: 500 });
    if (removeResult.ok) {
      tmpDirsToCleanup.delete(tmpFullDir);  // 已正常清理，从清理集合移除
    } else {
      process.stderr.write(`[WARN] .tmp-full 清理失败（策略: ${removeResult.strategy}, 原因: ${removeResult.reason || '未知'}）\n`);
    }
  }
  process.stdout.write(`  [OK]   full-delivery.zip (${(fullSize / 1024).toFixed(2)} KB) — 产品研发团队\n`);

  // 7.2 demo-only.zip — 仅 demo/
  const demoZipPath = path.join(downloadsDir, 'demo-only.zip');
  const demoSize = packToZipStandard(path.join(siteDir, 'demo'), demoZipPath);
  process.stdout.write(`  [OK]   demo-only.zip (${(demoSize / 1024).toFixed(2)} KB) — 客户\n`);

  // v5.9：移除 docs-only.zip（测试开发文档包），仅保留 demo-only.zip + full-delivery.zip

  // 7.3 v5.21 新增：项目根 delivery.zip — 整个交付站点（zip 根 = 站点根），
  //     供交付页"发布到公网"按钮自动上传（http 上下文经 fetch('../../delivery.zip') 直读）
  //     注意：必须在 release-payload.js 写入之前创建（payload 内嵌本 zip 的 base64，天然排除防递归膨胀）
  const rootZipPath = path.join(root, 'delivery.zip');
  const rootZipSize = packToZipStandard(siteDir, rootZipPath);
  process.stdout.write(`  [OK]   delivery.zip (${(rootZipSize / 1024).toFixed(2)} KB) — 项目根整站打包（发布用）\n`);

  // 7.4 v5.21 新增：站点根 release-payload.js — delivery.zip 的 base64 内嵌，
  //     供 file:// 双击打开的交付页动态 <script> 加载后解码上传（file:// 下 fetch/XHR 均被阻止）
  //     顺序约束：写在 delivery.zip 之后，确保不进入任何 zip（delivery.zip 与 full-delivery.zip 均天然排除）
  try {
    const zipBuf = fs.readFileSync(rootZipPath);
    const b64 = zipBuf.toString('base64');
    fs.writeFileSync(path.join(siteDir, 'release-payload.js'),
      '// v5.21: 自动生成 — delivery.zip 的 base64 内嵌（发布按钮 file:// 兜底加载用），请勿手工编辑\n' +
      'window.__DELIVERY_ZIP_B64__ = "' + b64 + '";\n',
      { encoding: 'utf-8' });
    process.stdout.write(`  [OK]   release-payload.js (${(b64.length / 1024 / 1024).toFixed(2)} MB base64) — 发布 file:// 兜底\n`);
  } catch (e) {
    process.stderr.write(`[WARN] release-payload.js 生成失败: ${e.message}（file:// 发布兜底不可用，http 发布不受影响）\n`);
  }

  // 8. 更新 state.yaml
  let updatedState = stateText;
  if (/delivery_packaged:\s*false/.test(updatedState)) {
    updatedState = updatedState.replace(/delivery_packaged:\s*false/, 'delivery_packaged: true');
  } else if (!/delivery_packaged:/.test(updatedState)) {
    updatedState = updatedState.trimEnd() + '\ndelivery_packaged: true\n';
  }

  // v5.14.16 修复 B（批次1）：写入 delivery_demo_hash 到 state.yaml
  //   用途：verify-delivery.mjs V-13 校验 4 比对此哈希，闭合修复 A 认可中间态后的检测空窗
  //   实现：计算 delivery/<项目名>/demo/ 全目录归一化 SHA-256 哈希，写入 state.yaml
  //   防御：agent 手动写 final_approved=true 绕过 verify → V-13 检出 delivery_demo_hash 缺失
  //         agent 重算哈希伪造 → 提高绕过成本（从"改一个布尔值"到"改值+重算哈希"）
  const deliveryDemoHash = computeDirHash(path.join(siteDir, 'demo'));
  if (deliveryDemoHash) {
    if (/^delivery_demo_hash:\s*.*$/m.test(updatedState)) {
      updatedState = updatedState.replace(/^delivery_demo_hash:\s*.*$/m, `delivery_demo_hash: ${deliveryDemoHash}`);
    } else {
      updatedState = updatedState.trimEnd() + `\ndelivery_demo_hash: ${deliveryDemoHash}\n`;
    }
    process.stdout.write(`  [OK]   delivery_demo_hash 已写入 (${deliveryDemoHash.slice(0, 12)}...)\n`);
  } else {
    process.stdout.write('  [WARN] delivery_demo_hash 写入失败（delivery/<项目名>/demo/ 不存在或为空）\n');
  }

  // v5.25 P0-1：记录打包时间戳，供 verify-delivery.mjs V-16 检测"打包后继续改写 demo"
  //   根因：oc-demora-0828 轮 tw-glm53f 两案在打包完成后 7~51 分钟继续改写 demo，
  //         demo 与 delivery SHA 分叉（V-3/V-13 哈希绑定失效），交付物为旧版 demo
  const packagedAt = new Date().toISOString();
  if (/^delivery_packaged_at:\s*.*$/m.test(updatedState)) {
    updatedState = updatedState.replace(/^delivery_packaged_at:\s*.*$/m, `delivery_packaged_at: ${packagedAt}`);
  } else {
    updatedState = updatedState.trimEnd() + `\ndelivery_packaged_at: ${packagedAt}\n`;
  }
  process.stdout.write(`  [OK]   delivery_packaged_at 已写入 (${packagedAt})\n`);

  // v5.18 P0-A2：记录 sim demo/ 源哈希，供 R-8 判断"demo 是否已修改"（修复后重打包放行依据）
  //   currentSourceHash 在 R-8 检测处已计算（sim demo/ 全目录归一化哈希），此处直接复用
  if (currentSourceHash) {
    if (/^source_demo_hash:\s*.*$/m.test(updatedState)) {
      updatedState = updatedState.replace(/^source_demo_hash:\s*.*$/m, `source_demo_hash: ${currentSourceHash}`);
    } else {
      updatedState = updatedState.trimEnd() + `\nsource_demo_hash: ${currentSourceHash}\n`;
    }
    process.stdout.write(`  [OK]   source_demo_hash 已写入 (${currentSourceHash.slice(0, 12)}...)\n`);
  }

  fs.writeFileSync(stateFile, updatedState, { encoding: 'utf-8' });
  // v5.16 Task 8.2：写入 state.yaml 后主动失效缓存（spec.md Requirement: 脚本间状态共享缓存）
  //   防御：同进程内若后续再次 readStateYaml(root)，需拿到刚写入的新值（delivery_packaged/delivery_demo_hash）
  //   跨进程场景：Phase 3 各脚本独立进程，本 invalidate 主要作用于本进程"先读后写"场景
  invalidate(root);
  process.stdout.write('  [OK]   state.yaml 已更新（delivery_packaged: true + delivery_demo_hash）\n');

  // 汇总
  process.stdout.write('\n======================================================================\n');
  process.stdout.write('[SUMMARY] 交付网站打包汇总\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`  交付网站:   ${path.relative(root, siteDir)}/\n`);
  process.stdout.write(`  入口文件:   ${path.relative(root, path.join(siteDir, 'index.html'))}\n`);
  process.stdout.write(`  打包文件数: ${totalFiles}（demo + docs）\n`);
  process.stdout.write(`  下载包:\n`);
  process.stdout.write(`    - demo-only.zip      ${(demoSize / 1024).toFixed(2)} KB（客户）\n`);
  process.stdout.write(`    - full-delivery.zip  ${(fullSize / 1024).toFixed(2)} KB（产品研发）\n`);
  process.stdout.write(`  发布包:     ${path.relative(root, rootZipPath)}（${(rootZipSize / 1024).toFixed(2)} KB，项目根）\n`);
  process.stdout.write(`  发布兜底:   ${path.relative(root, path.join(siteDir, 'release-payload.js'))}（file:// 自动上传用）\n`);

  process.stdout.write('\n>>> 打包完成\n');

  // v5.25 P0-1：打包成功后冻结 demo/（全部文件只读）
  //   技术阻断"final_approved 后继续改写 demo"——后续对 demo 的写入直接 EPERM 失败，
  //   不依赖 SKILL.md 文字契约（纯文字约束对 AI 100% 失效，tw-dsf-v3 RC3 实证）。
  //   合法修复路径：--unfreeze-demo 解冻 → 修复 → 重跑 run-audit → 重打包（重新冻结）。
  const freezeResult = freezeDemoDir(root);
  if (freezeResult.total === 0) {
    process.stdout.write('  [WARN] demo/ 不存在或为空，跳过冻结\n');
  } else if (freezeResult.failed === 0) {
    process.stdout.write(`  [OK]   demo/ 已冻结（${freezeResult.frozen} 文件只读；修复前先执行 --unfreeze-demo）\n`);
  } else {
    process.stdout.write(`  [WARN] demo/ 冻结部分失败（${freezeResult.failed}/${freezeResult.total}），verify-delivery V-16 mtime 校验兜底\n`);
  }

  return {
    ok: true,
    siteDir,
    zipPaths: { demo: demoZipPath, full: fullZipPath, root: rootZipPath },
    fileCount: totalFiles,
  };
  } finally {
    // v5.14 P2-12：异常退出时强制清理临时目录（防御 F9 .tmp-full 残留 ×4 复现）
    // 正常流程已在 packToZipStandard 后清理，此处仅兜底异常情况
    // v5.14 修正：添加 maxRetries/retryDelay 防御 Windows 文件锁
    if (tmpDirsToCleanup.size > 0) {
      process.stderr.write('[WARN] 检测到未清理的临时目录，执行强制清理:\n');
      for (const tmpDir of tmpDirsToCleanup) {
        if (fs.existsSync(tmpDir)) {
          // v5.16 S-8 修复：使用 safeRemoveDirSync 替代 fs.rmSync
          const removeResult = safeRemoveDirSync(tmpDir, { recursive: true, force: true, maxRetries: 3, retryDelay: 500 });
          if (removeResult.ok) {
            process.stderr.write(`  [OK]   已清理: ${tmpDir}（策略: ${removeResult.strategy}）\n`);
          } else {
            process.stderr.write(`  [FAIL] 清理失败: ${tmpDir}（策略: ${removeResult.strategy}, 原因: ${removeResult.reason || '未知'}）\n`);
          }
        }
      }
    }
  }
}

// ===== v5.25 P0-1：demo 打包后冻结 / 显式解冻 =====
// 冻结机制：demo/ 全部文件 chmod 0o444（Windows 映射为 FILE_ATTRIBUTE_READONLY），
//           打包后任何对 demo 的写操作直接 EPERM 失败；chmod 只改 ctime 不改 mtime，V-16 校验不受影响。
// 解冻逃生口：--unfreeze-demo（唯一官方路径），解冻后必须重跑 run-audit → package-delivery → verify-delivery。
// 冻结标记写 .demora/demo-frozen.yaml（不在 demo/ 内，避免 V-13 洁净度检出），用于 AI 困惑时自解释。
function walkDemoFiles(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...walkDemoFiles(p));
    else if (entry.isFile()) out.push(p);
  }
  return out;
}

export function freezeDemoDir(root) {
  const demoDir = path.join(root, 'demo');
  const files = walkDemoFiles(demoDir);
  let frozen = 0;
  let failed = 0;
  for (const p of files) {
    try {
      fs.chmodSync(p, 0o444);
      frozen++;
    } catch (e) {
      failed++;
    }
  }
  const marker = path.join(root, '.demora', 'demo-frozen.yaml');
  try {
    fs.writeFileSync(marker, [
      '# v5.25 P0-1：demo 打包后冻结标记（package-delivery.mjs 自动写入）',
      'frozen: true',
      `frozen_at: ${new Date().toISOString()}`,
      '# demo/ 已全部只读——修复 demo 前必须先解冻：',
      '#   node scripts/package-delivery.mjs --unfreeze-demo',
      '# 解冻后修复 demo 必须重跑：run-audit.mjs → package-delivery.mjs → verify-delivery.mjs',
      '',
    ].join('\n'), { encoding: 'utf-8' });
  } catch (e) { /* 标记写入失败不影响冻结本身 */ }
  return { frozen, failed, total: files.length };
}

export function unfreezeDemoDir(root) {
  const demoDir = path.join(root, 'demo');
  const files = walkDemoFiles(demoDir);
  let unfrozen = 0;
  let failed = 0;
  for (const p of files) {
    try {
      fs.chmodSync(p, 0o666);
      unfrozen++;
    } catch (e) {
      failed++;
    }
  }
  const marker = path.join(root, '.demora', 'demo-frozen.yaml');
  if (fs.existsSync(marker)) {
    try {
      fs.chmodSync(marker, 0o666);
      fs.rmSync(marker, { force: true });
    } catch (e) { /* 清理失败不影响解冻本身 */ }
  }
  return { unfrozen, failed, total: files.length };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  // v5.25 P0-1：--unfreeze-demo 显式解冻（合法修复路径的唯一逃生口，不执行打包）
  if (process.argv.includes('--unfreeze-demo')) {
    const unfreezeRoot = process.cwd();
    const r = unfreezeDemoDir(unfreezeRoot);
    if (r.total === 0) {
      process.stdout.write('[OK] demo/ 不存在或为空，无需解冻（冻结标记已清理）\n');
    } else if (r.failed === 0) {
      process.stdout.write(`[OK] demo/ 已解冻（${r.unfrozen} 文件恢复可写）\n`);
      process.stdout.write('     修复后必须重跑：run-audit.mjs → package-delivery.mjs → verify-delivery.mjs\n');
    } else {
      process.stderr.write(`[WARN] demo/ 解冻部分失败（${r.failed}/${r.total}）——请手动检查文件只读属性\n`);
    }
    process.exit(0);
  }
  main().catch(e => { console.error(e); process.exit(1); });
}
