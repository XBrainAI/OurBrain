# 运行时契约（详版）

> SKILL.md「运行时契约」的详版参考：AI 生成 Demo 时必须遵守的约定，避免与标注引擎冲突或导致功能失效。

## 1. 10 个运行时陷阱

| # | 陷阱 | 后果 | 规避方式 |
|---|------|------|---------|
| 1 | 全局作用域 `const` 冲突 | 标注引擎 IIFE 内部变量与 AI 全局变量同名时，AI 代码可能覆盖标注引擎行为 | 避免在全局作用域使用 `const app =`、`const state =` 等常见变量名，改用模块作用域或命名空间（如 `const myApp = {}`） |
| 2 | `focusZoneCard` 副作用 | 点击 `.l2-marker` 会自动打开标注面板并切换到 L2 Tab | AI 的交互逻辑不应依赖标注面板的显隐状态；面板由标注引擎独立管理 |
| 3 | L2 marker 元素缺失 | 标注引擎通过 `closest('.l2-marker')` 查找标记，若 AI 未添加则 L2 点击高亮失效 | v5.14.6 起引擎 `ensureMarkers()` 自动创建；AI 只需保证 `data-zone-id` 容器存在且可见 |
| 4 | Vue Router 4 同路径导航 | `router.push('/current-path')` 抛 NavigationDuplicated | 导航前检查目标路径，或用 `router.replace()` |
| 5 | `display:flex/grid` 覆盖 `hidden` 属性 | CSS `display:flex` 覆盖 `hidden` 的 UA `display:none`，元素无法隐藏 | 用 `.xxx:not([hidden]) { display: flex }`；或依赖全局 `[hidden] { display: none !important }` 防御（enhance 已注入） |
| 6 | 页面显隐双轨混用 | CSS 类切换与 JS `hidden` 属性切换错配导致所有页面永久隐藏 | 禁止双轨混用，统一单轨制（推荐 JS hidden 属性 + display 双同步，骨架 route() 已内置）。S-14 强制检测 |
| 7 | D3 弹窗触发属性定向修补 | 仅加 `data-open-modal` 不绑定事件骗过 D3 | D3 闭环验证：触发→显示→关闭→隐藏，缺一即 FAIL |
| 8 | D6 disabled 按钮移除定向修补 | 移除 `disabled` 过 D6 但功能未实现 | D6 豁免 disabled/aria-disabled/.disabled/pointer-events:none 按钮，仅检查启用按钮响应；**禁用按钮仍须带 data-action（P1-1-e ③，P045 检测）** |
| 9 | S-11/D8 静态 HTML 预放 L3 元件 | DOMContentLoaded 重渲染替换带 data-element-id 的静态行 | S-11 静态初筛 + D8 运行时 DOM 断言交互意图；动态替换后调用 `window.__ANNOTATION_ENGINE__.refresh()` |
| 10 | D9 标注面板与页面协同缺失 | 面板不显示/遮挡内容/zone 不高亮/dot 不激活 | D9 闭环验证全部协同点；标注开关 `[data-annotation-toggle]` 必须由 AI 放置（引擎只绑定事件） |

## 2. D9 L3 时序排查指引

1. `document.querySelectorAll('.l3-dot').length` 确认数量与 data-element-id 一致；为 0 则检查锚点是否被 init 重渲染替换
2. Console 手动 `.click()` 观察面板是否切换；确认 `window.__ANNOTATION_ENGINE__` 已初始化
3. AI 的 DOM 替换操作应在同步 init 中完成，或替换后调用 `window.__ANNOTATION_ENGINE__.refresh()`
4. `JSON.stringify(window.__ANNOTATION_DATA__)` 检查 L3 数据完整性

## 3. 按钮绑定自检（v5.14.16 批次3，warn 级）

D6 按钮无 onclick/data-action 且点击无 DOM 变化时输出 warn。排查清单：
1. 事件委托 selector 匹配失败
2. init 序列异常中断（getElementById null 后续绑定全部跳过）
3. 异步绑定延迟（D6 500ms 窗口不够）
4. CSS 透明 overlay 遮挡

warn 不直接判 fail（事件委托合法）；响应率 <50% 才判 fail。

## 4. AI 必须添加的 4 项 HTML 元素

1. `data-zone-id` — L2 区域容器
2. `data-element-id` — L3 元件包裹层（**必须块级容器；INPUT/SELECT 等内联元素须包 div**，引擎 C4 也会自动修正）
3. `.l2-marker` — v5.14.6 起引擎自动创建，无需手写（手写会 P001 FAIL）
4. `window.__ANNOTATION_DATA__` — **必须内联在 index.html 的 `<script>` 中**（P004；放 app.js 会令 check-business-fill 降级）

## 5. 标注开关与面板

- 标注开关 `[data-annotation-toggle]` 由 AI 在页面顶部工具栏放置（**缺失会被 diagnose D10 判 ANNOTATION_PANEL_ACTIVATE_FAIL**）
- 标注面板 `.annotation-panel` 由 enhance-prototype 自动注入，禁止重复绑定 click（引擎已绑定，重复绑定会状态抵消）
- 仅通过 `window.__ANNOTATION_ENGINE__.refresh()` 通知数据变化

## 6. Footer 与 body 布局契约（R-7）

1. 每个 page-view 内含 `<footer>`（版权信息 + 版本/日期标记），内容流最底部，禁止 `position: fixed`
2. **禁止** `body { display: flex }`（默认 row 会把注入 footer 挤到右侧）或 `body { display: grid; grid-template-columns: ... }`；body 保持默认 block 或 `flex-direction: column`
3. 横向布局用 `.layout`/`.app-shell` 容器承载；app-shell 布局下 `.app-shell` 之外不得出现 in-flow 块级元素（document.scrollHeight === clientHeight）
4. 自检：`getComputedStyle(document.body).display` 为 flex 时须确认 flex-direction: column
