# audit 高频失败模式自查清单（详版）

> SKILL.md「audit 高频失败模式自查清单」的详版参考。背景：A/B 测试显示 40m+ 运行时长中 30-40m 耗费在 audit 失败重试。AI 若在 demo 生成阶段按本清单自查，可前置消除 80% 重试。配合 pre-audit-check.mjs 硬拦截，重试次数从 4 轮降至 1-2 轮。

## D3 弹窗闭环失败自查（对应 P008/P012）

- 每个弹窗触发按钮必须有事件绑定：`onclick` 属性 / `data-action` 属性 / app.js 引用，三者至少其一（骨架事件委托自动覆盖 data-open-modal/data-close）
- 自检：`document.querySelectorAll('[data-open-modal]')` 逐个确认绑定
- 常见错误：只写 `data-open-modal` 不绑定（骨架委托已兜底，但按钮同时在 `.modal-box` 外层被遮挡时会点击失败）
- v2.2 决策A：无弹窗设计记 n/a 不计 warn；需求要求弹窗交互时必须实现真实闭环
- 每个弹窗必须有 `data-close` 关闭按钮（闭环的关闭→隐藏段）

## D8 元件覆盖率失败自查（对应 P045，v5.29 新增——p10 轮实证）

- **禁用态行按钮必须与启用态共用同一 `data-action`**：disabled 仅阻断点击派发，不影响 D8 语义分组（aria-label → data-action → 文本）。禁用按钮缺失 data-action 会被文本键拆成独立小组——≤4 组要求全标、>4 组要求 DOM 首实例标注，首实例漂移至禁用行 → FAIL
- 结构一致性（终态行按钮以禁用态呈现）与语义分组（全组同 data-action）**必须同时满足**：
  ```html
  <!-- 正确：禁用按钮保留 data-action -->
  <button type="button" class="btn-ghost" disabled title="仅草稿可提交" data-action="submitSubsidy">提交</button>
  <!-- 错误：禁用按钮丢失 data-action（拆组） -->
  <button type="button" class="btn-ghost" disabled title="仅草稿可提交">提交</button>
  ```
- 首实例标注位置：>4 实例组标注 **DOM 顺序第一个**实例（若第一个恰为禁用按钮，data-element-id 挂在它上面同样有效——data-action 属性即构成 D8 交互意图）
- 同页 L3 id 唯一（P029）；每页 data-element-id 数与 `__ANNOTATION_DATA__` L3 数一致（P018）
- 行内按钮 >4 实例：只标首个可见实例，卡片 element 名含"（同类首个，其余 N 个实例共用本说明）"

## D9.4 L3 协同失败自查（对应 P007/P014）

- 标注开关 `[data-annotation-toggle]` 必须由 AI 放置（缺失 → diagnose ANNOTATION_PANEL_ACTIVATE_FAIL）
- `.l3-dot` 激活规则由引擎注入 CSS 提供；禁止在 demo CSS 重复定义 `.l3-dot`（S-6 FAIL）
- 面板显示后左侧内容不被遮挡（body padding-right 协同，footer 不得 fixed）

## D10 L3 激活失败自查（对应 P006）

- main 内容区不能 `display:none` / `visibility:hidden`；color ≠ background
- 标注元素放在 `[data-page-id]` 内（P020）
- 隐藏元素（弹窗/抽屉内部）不得挂 `data-element-id`（引擎 C9 自动剥离；锁定前由 validate-model P0-2b 硬拦截）

## D5 多页锚点失败自查（对应 P003/P019）

- 每页 `data-page-id` 与导航 `data-nav` 一一对应；nav href 与 data-nav 一致（P027 typo FAIL）且**全库唯一**（P019：重复 href FAIL——顶栏与侧栏指向同页时，其一改用 `data-action="gotoPage" data-target="Pxx"` 按钮）
- 导航项只显示业务名称（P035 研发编码检测）

## L3 卡片三元组重复自查（对应 P009）

- `(element, function, response)` 三元组不能完全相同（R-6 判重）；同类重置按钮等应按页面差异化命名（如"重置筛选按钮·专利清洗分级"）

## L3 id 唯一性自查（P009/L-3）

- 同页无重复 `data-element-id` 值：`grep -o 'data-element-id="[^"]*"' demo/index.html | sort | uniq -d` 应无输出

## 跨页联动枚举一致性（对应 P037，R-10）

- HTML 中经 `getAttribute/dataset` 消费、用于过滤/匹配的 `data-*` 值必须与 app.js 字面量完全一致
- 行句柄/展示用途的属性统一用 `data-code`（框架语义豁免）；业务枚举在 app.js 以字面量注册表落地（`var CHANNELS = {...}`）

## 反模式禁止（L-5）

- 禁止 hidden/disabled 切换页面可见性（用路由函数 + display/hidden 双同步，骨架 route() 已内置）
- 禁止全局 querySelector 查找标注（限定 `[data-page-id]:not([hidden])`）
- 禁止读取 `style.display` 反推业务状态（P033；显隐一律由独立 `data-*` 状态位全量重算）

## 状态文件回写门禁（P2-1）

package-delivery 前检查：decisions.yaml `decisions[]` ≥1 条；context.yaml `design_methodology_read: true`；conversation-log.yaml ≥3 条。空置 → WARN 并记 quality-report Q-8。

## conversation-log 即时追加规范（v5.23）

条目必须在事件发生时经 `append-conversation-log.mjs` 即时追加真实时间戳；事后批量补记会被 Q-8 检出（≥3 条相同时间戳 → WARN），0828 轮因此出现 81~98 分钟不可归因黑洞。
