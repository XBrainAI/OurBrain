// install-deps.mjs
// 依赖环境一键检测与安装指引（v5.14.9 新增）
//
// 设计目标：
//   - 检测 playwright JS 是否可用（dist 预装或项目目录 npm install）
//   - 检测 chromium 二进制是否可用（或系统 Edge 兜底）
//   - 检测 htmlhint 是否可用（v5.23 新增：Q-5 质量门禁依赖，
//     缺失时 quality-check Q-5 降级为正则弱检查，质量门禁强度随环境漂移）
//   - 缺失时给出明确安装命令，不静默通过
//   - 不自动执行 npm install（避免"考生改考卷"风险 + CI 环境卡死）
//
// 用法：
//   node scripts/install-deps.mjs          # 检测 + 提示
//   node scripts/install-deps.mjs --install # 检测 + 自动安装（可选）
//
// 退出码：0 环境就绪，1 环境缺失

import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { createRequire } from 'module';
import { execSync } from 'child_process';
import { findProjectRoot } from './lib/platform-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const cwdRequire = createRequire(path.join(process.cwd(), 'dummy.js'));

function log(msg) { process.stdout.write(msg + '\n'); }

// ===== 检测 playwright JS 是否可用 =====
async function checkPlaywrightJS() {
  // 方式1：从脚本位置解析（dist 预装路径）
  try {
    const pw = await import('playwright');
    const chromium = pw.chromium || (pw.default && pw.default.chromium);
    if (chromium) return { ok: true, source: 'bundled', chromium };
  } catch (e) { /* 继续尝试其他路径 */ }

  // 方式2：从 cwd（项目目录）解析
  try {
    const playwrightEntry = cwdRequire.resolve('playwright');
    const pw = await import(pathToFileURL(playwrightEntry).href);
    const chromium = pw.chromium || (pw.default && pw.default.chromium);
    if (chromium) return { ok: true, source: 'project:' + path.dirname(cwdRequire.resolve('playwright/package.json')), chromium };
  } catch (e) { /* 继续尝试其他路径 */ }

  return { ok: false, source: null, chromium: null };
}

// ===== 检测 chromium 二进制是否可用 =====
async function checkChromiumBinary(chromium) {
  if (!chromium) return { ok: false, reason: 'no chromium module' };

  // Windows：检测系统 Edge
  if (process.platform === 'win32') {
    try {
      const browser = await chromium.launch({ headless: true, channel: 'msedge' });
      await browser.close();
      return { ok: true, reason: 'msedge (system)' };
    } catch (e) { /* Edge 不可用，继续检测 chromium */ }
  }

  // 检测下载的 chromium
  try {
    const browser = await chromium.launch({ headless: true });
    await browser.close();
    return { ok: true, reason: process.platform === 'win32' ? 'chromium (downloaded)' : 'chromium (downloaded)' };
  } catch (e) {
    return { ok: false, reason: 'chromium binary not downloaded' };
  }
}

// ===== 检测 htmlhint 是否可用（v5.23 新增：Q-5 质量门禁依赖） =====
// 探测顺序：技能包内 → 项目根 → cwd
// 根因：htmlhint 不随技能包分发时，quality-check Q-5 降级为正则弱检查，
//       质量门禁强度随环境漂移（UAT0824 opencode 环境 3/3 Q-5 降级）
function checkHtmlhint() {
  const projectRoot = findProjectRoot();
  // 注意：htmlhint 1.9.x 的 CLI 入口是 dist/cli/htmlhint.js（不是 dist/cli.js）
  const candidates = [
    { p: path.join(__dirname, '..', 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'), source: '技能包内' },
    { p: path.join(projectRoot, 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'), source: '项目根' },
    { p: path.join(process.cwd(), 'node_modules', 'htmlhint', 'dist', 'cli', 'htmlhint.js'), source: 'cwd' },
  ];
  for (const c of candidates) {
    if (fs.existsSync(c.p)) {
      return { ok: true, source: c.source + ': ' + c.p, probed: candidates.map(c => c.p) };
    }
  }
  return { ok: false, source: null, probed: candidates.map(c => c.p) };
}

// ===== 主流程 =====
async function main() {
  const autoInstall = process.argv.includes('--install');

  log('======================================================================');
  log('install-deps.mjs — 依赖环境检测 (v5.14.9 / v5.23 增 htmlhint 检测)');
  log('======================================================================');
  log('  平台: ' + process.platform);
  log('  cwd:  ' + process.cwd());

  // 1. 检测 playwright JS
  log('\n[1/3] 检测 Playwright JS 模块...');
  const jsCheck = await checkPlaywrightJS();
  if (jsCheck.ok) {
    log('  [OK] Playwright JS 可用（来源: ' + jsCheck.source + '）');
  } else {
    log('  [FAIL] Playwright JS 不可用');
    log('         dist 包应预装 node_modules/playwright，但未找到');
    log('         手动安装：npm install playwright');
    if (autoInstall) {
      log('  [INFO] --install 模式：尝试 npm install playwright...');
      try {
        execSync('npm install playwright', { stdio: 'inherit', cwd: process.cwd() });
        log('  [OK] npm install playwright 完成');
      } catch (e) {
        log('  [FAIL] npm install 失败: ' + e.message);
        process.exit(1);
      }
    } else {
      log('  [INFO] 自动安装：node scripts/install-deps.mjs --install');
      process.exit(1);
    }
  }

  // 2. 检测 chromium 二进制（或系统 Edge）
  log('\n[2/3] 检测浏览器二进制（chromium 或系统 Edge）...');
  // 重新检测 JS（可能刚装完）
  const jsCheck2 = jsCheck.ok ? jsCheck : await checkPlaywrightJS();
  const binCheck = await checkChromiumBinary(jsCheck2.chromium);
  if (binCheck.ok) {
    log('  [OK] 浏览器可用（' + binCheck.reason + '）');
  } else {
    log('  [FAIL] 浏览器二进制不可用: ' + binCheck.reason);
    if (process.platform === 'win32') {
      log('         Windows 应有系统 Edge，但检测失败');
      log('         备选：npx playwright install chromium（约 170MB）');
    } else {
      log('         安装：npx playwright install chromium（约 170MB）');
    }
    if (autoInstall) {
      log('  [INFO] --install 模式：尝试 npx playwright install chromium...');
      try {
        execSync('npx playwright install chromium', { stdio: 'inherit', cwd: process.cwd() });
        log('  [OK] chromium 二进制下载完成');
      } catch (e) {
        log('  [FAIL] npx playwright install 失败: ' + e.message);
        process.exit(1);
      }
    } else {
      log('  [INFO] 自动安装：node scripts/install-deps.mjs --install');
      process.exit(1);
    }
  }

  // 3. 检测 htmlhint（v5.23 新增：Q-5 质量门禁依赖）
  //   注意：htmlhint 缺失不立即退出（playwright 是 run-audit 硬依赖，htmlhint 仅导致
  //         quality-check Q-5 降级），打完 SUMMARY 后按退出码 1 结束
  log('\n[3/3] 检测 htmlhint（Q-5 质量门禁依赖）...');
  const hhCheck = checkHtmlhint();
  let htmlhintOk = hhCheck.ok;
  if (htmlhintOk) {
    log('  [OK] htmlhint 可用（来源: ' + hhCheck.source + '）');
  } else {
    log('  [FAIL] htmlhint 不可用');
    log('         已探测路径:');
    [...new Set(hhCheck.probed)].forEach(p => log('           - ' + p));
    log('         手动安装：npm install htmlhint（建议安装到技能包目录）');
    if (!autoInstall) {
      log('  [INFO] 自动安装：node scripts/install-deps.mjs --install');
    }
    if (autoInstall) {
      // 技能包目录 = path.resolve(__dirname, '..')；需有 package.json 才能在该目录 npm install
      const skillPkgDir = path.resolve(__dirname, '..');
      if (fs.existsSync(path.join(skillPkgDir, 'package.json'))) {
        log('  [INFO] --install 模式：在技能包目录执行 npm install htmlhint...');
        try {
          execSync('npm install htmlhint', { stdio: 'inherit', cwd: skillPkgDir });
          log('  [OK] npm install htmlhint 完成（技能包目录）');
          htmlhintOk = true;
        } catch (e) {
          log('  [FAIL] npm install htmlhint 失败: ' + e.message);
        }
      } else {
        log('  [INFO] 技能包目录无 package.json（' + skillPkgDir + '），改装到 cwd: ' + process.cwd());
        try {
          execSync('npm install htmlhint', { stdio: 'inherit', cwd: process.cwd() });
          log('  [OK] npm install htmlhint 完成（cwd）');
          htmlhintOk = true;
        } catch (e) {
          log('  [FAIL] npm install htmlhint 失败: ' + e.message);
        }
      }
    }
  }

  log('\n======================================================================');
  log('[SUMMARY] ' + (htmlhintOk ? '环境就绪' : '环境部分就绪'));
  log('======================================================================');
  log('  Playwright JS:  ' + (jsCheck.ok ? 'OK' : 'OK (刚安装)'));
  log('  浏览器二进制:   ' + (binCheck.ok ? 'OK' : 'OK (刚安装)'));
  log('  htmlhint:       ' + (htmlhintOk ? 'OK' : '缺失'));
  if (!htmlhintOk) {
    log('\n>>> 环境检测部分通过：htmlhint 缺失，quality-check Q-5 将降级为基本 HTML 检查（正则弱检查）');
    process.exit(1);
  }
  log('\n>>> 环境检测通过，可运行 run-audit.mjs / verify-demo-runtime.mjs');
  process.exit(0);
}

main().catch(e => {
  log('[FAIL] ' + e.message);
  process.exit(1);
});
