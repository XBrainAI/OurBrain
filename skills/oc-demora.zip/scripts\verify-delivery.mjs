// verify-delivery.mjs
// Delivery 产物一致性校验（v5.7 — mermaid 资产 + 三大 Flow + 受众 Tab）
//
// 设计目标：
//   修复 v5.5 "5 个 audit 场景 A 级通过，但 delivery/<项目名>/demo/ 是空骨架" 的审计盲区。
//   verify-delivery 是 delivery 内容一致性的最后一道防线，确保：
//   1. delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html 哈希一致
//   2. delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
//   3. delivery/<项目名>/demo/screenshots/ 截图完整
//   4. delivery/<项目名>/docs/ 24 md + 5 HTML 齐全
//   5. delivery/<项目名>/downloads/ 2 个 zip 大小达标（v5.9：移除 docs-only.zip）
//
// 校验项：
//   V-1: delivery/<项目名>/index.html 存在且非空（>= 5000 bytes，v5.6 阈值提升）
//   V-2: delivery/<项目名>/demo/index.html 存在且非空骨架（>= 5000 bytes + 不含 "Demo - 待 AI 设计"）
//   V-3: delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html SHA-256 一致
//   V-4: delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
//   V-5: delivery/<项目名>/demo/screenshots/ 截图数量 >= 5 张
//   V-6: delivery/<项目名>/docs/ >=20 md + 5 HTML 齐全 + 4 子页面含重定向脚本（v5.6 增强）
//   V-7: delivery/<项目名>/downloads/ 2 个 zip 大小 >= 10 KB（v5.9：移除 docs-only.zip，仅校验 demo-only + full-delivery）
//   V-8: delivery/<项目名>/project-info.json 字段完整
//   V-9: v5.6 新增 — delivery index.html 占位符已替换 + docs/index.html 含章节锚点 + size >= 15000
//        v5.7 调整：V-9b 锚点新增 tldr/non-goals/business-flow；V-9c 阈值 15000→25000
//        v5.10 新增：V-9d §2 PM 原始需求非空（不含"暂未提供"）；V-9e §4 业务流程含三大 Flow 标题
//   V-10: v5.7 新增 — docs/assets/mermaid/ 存在 + 含 mermaid.min.js + mermaid-init.js
//   V-11: v5.14 新增 — DIST 前 sim/demo/ ↔ delivery/<项目名>/demo/ 全目录 SHA-256 终检
//        防御 F10（验收后产物漂移）：sim demo 被批量改写后 delivery 仍可被发现不一致
//   V-12: v5.14.16 修复 A（批次1）— state.yaml 状态机一致性校验（消除设计死锁）
//        原死锁：旧校验要求 delivery_packaged=true 时 final_approved=true + phase=3
//               但这两个字段只能由 verify-delivery 自己在 fail===0 时写入 → 永远无法通过
//        修复 A：认可 delivery_packaged=true + final_approved=false + current_phase=2 为合法中间态
//        新校验点：
//          1. delivery_consistency_verified=true 时 final_approved 必须为 true
//          2. delivery_consistency_verified=true 时 current_phase 必须为 3
//          3. delivery_consistency_verified=true 时 delivery_packaged 必须为 true
//          4. final_approved=true 时 current_phase 必须为 3
//   V-13: v5.14.16 修复 B+C（批次1）— 交付物洁净度检测 + 哈希绑定
//        防御：W-1（调试文件残留）/ W-2（失败截图入库）/ G-6（V-11 哈希失配）
//        闭合修复 A 认可中间态后的检测空窗（agent 手动写 final_approved=true 时哈希绑定检出）
//        校验点：
//          1. delivery/<项目名>/demo/ 无调试文件残留（_*.js / _*.tmp / _annotation_data.js）
//          2. delivery/<项目名>/demo/screenshots/ 无失败截图（黑名单正则与 package-delivery 一致）
//          3. delivery/ 无 delivery-stash/ 目录残留
//          4. state.yaml 中 delivery_demo_hash 与实际计算值一致（哈希绑定，package-delivery 写入）
//   V-14: v5.21 新增 — 项目根 delivery.zip 存在且非空（发布到公网依赖）
//   V-15: v5.23 新增 — Q-5 环境降级披露校验：quality-report.yaml 含 q5_degraded: true 时，
//        要求 delivery/ 下 README/交付说明标注 "环境降级" 或 "htmlhint" 字样（未标注 FAIL）
//   V-16: v5.25 新增 — demo 打包后冻结校验：demo/** 任一文件 mtime > delivery_packaged_at(+5s 容差)
//        即 FAIL（打包后改写 demo 使 V-3/V-13 哈希绑定失效，交付物为旧版 demo；
//        配套 package-delivery.mjs 打包后自动冻结 demo/，--unfreeze-demo 显式解冻）
//
// 调用方式：
//   node scripts/verify-delivery.mjs             # cwd=sim-project，自动找 delivery/<项目名>/
//   node scripts/verify-delivery.mjs --project <name>  # 指定项目名（delivery/<name>/）
//
// 退出码：0 全部通过，1 有 FAIL
//
// 由谁调用：
//   1. runAutoPhasesPhase3（在 quality-check + package-delivery 之后）— v5.6 新增
//   2. aggregateResults（在 aggregate 验收末尾）— v5.6 新增
//   3. subagent 在 AI 阶段 5 完成后调用 --run-phase3 时自动执行

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { findProjectRoot } from './lib/platform-utils.mjs';
import { readStateYaml, invalidate } from './lib/state-cache.mjs';
import { computeDirHash, SCREENSHOT_BLACKLIST_REGEX, SHELL_SIGNATURES } from './lib/hash-utils.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

/**
 * 计算 SHA-256 哈希
 */
function sha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

// v5.16 Task 9.4：SHELL_SIGNATURES 已抽取到 lib/hash-utils.mjs（删除本地定义）
//   原本地定义 L79-83 与 quality-check.mjs SHELL_SIGNATURES_Q1 元素相同（顺序略异，.some() 与顺序无关）
//   lib/hash-utils.mjs 导出的 SHELL_SIGNATURES 与本处原实现行为等价

function isShellHtml(htmlContent) {
  return SHELL_SIGNATURES.some(sig => htmlContent.includes(sig));
}

/**
 * 期望的 5 个 HTML 产品文档
 */
const EXPECTED_HTML_DOCS = [
  'index.html', 'product-overview.html', 'page-spec.html',
  'data-model.html', 'role-permission.html',
];

/**
 * 统计 docs/ 下所有 md 文件（v5.6 修复：扩展范围，兼容小项目）
 *
 * v5.5 缺陷：仅统计 docs/prd/ 下的 md 文件，对于 2 页面项目只有 13+2=15 md < 20 阈值
 * v5.6 修复：统计 docs/ 下所有子目录（prd/、spec/、test/、handoff/）的 md 文件
 *           最小项目也含：13 PRD + 1 page-details + 7 Spec + 3 Test + 1 Handoff = 25 md
 *
 * @param {string} docsDir docs/ 目录
 * @returns {{ prd: number, total: number, html: number }}
 *   - prd: docs/prd/ 下的 md 数（向后兼容）
 *   - total: docs/ 下所有 md 数（v5.6 新增）
 *   - html: docs/ 下的 HTML 数
 */
function countDocsMd(docsDir) {
  if (!fs.existsSync(docsDir)) return { prd: 0, total: 0, html: 0 };

  // 统计 docs/prd/ 下的 md（向后兼容）
  const prdDir = path.join(docsDir, 'prd');
  let prdMd = 0;
  if (fs.existsSync(prdDir)) {
    function walkPrd(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const full = path.join(d, e.name);
        if (e.isDirectory()) walkPrd(full);
        else if (e.name.endsWith('.md')) prdMd++;
      }
    }
    walkPrd(prdDir);
  }

  // v5.6：统计 docs/ 下所有 md 文件
  let totalMd = 0;
  function walkAll(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, e.name);
      if (e.isDirectory()) walkAll(full);
      else if (e.name.endsWith('.md')) totalMd++;
    }
  }
  walkAll(docsDir);

  const htmlCount = EXPECTED_HTML_DOCS.filter(f => fs.existsSync(path.join(docsDir, f))).length;
  return { prd: prdMd, total: totalMd, html: htmlCount };
}

/**
 * 主入口
 */
export async function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const deliveryRoot = path.join(projectRoot, 'delivery');

  // v5.23：隐式根防护——解析根无 .demora/state.yaml 时硬 FAIL，禁止在错误 cwd 隐式创建项目根
  //   根因：UAT0824 opencode-ox- 案例 AI 以工作根为 cwd 调用写入型脚本，工作根残留空 delivery/
  if (!fs.existsSync(path.join(projectRoot, '.demora', 'state.yaml'))) {
    log('[FAIL] 项目根无效: ' + projectRoot + '（缺少 .demora/state.yaml）');
    log('       请在项目目录内运行，或用 --project-root 显式指定；禁止在错误目录隐式创建项目结构');
    process.exit(1);
  }

  // P2-10 门禁脚本完整性自检（防御"考生改考卷"）
  try {
    const { verifyGateScriptIntegrity } = await import('./gate-baseline.mjs');
    const integrity = verifyGateScriptIntegrity(fileURLToPath(import.meta.url));
    if (!integrity.ok && !integrity.skipped) {
      log(`[FAIL] 门禁脚本完整性校验失败: ${integrity.reason}`);
      log('       请从 BUILD 重跑，禁止在流水线会话内修改门禁脚本');
      process.exit(1);
    }
  } catch (e) { /* gate-baseline.mjs 不可用时跳过（开发态兼容） */ }

  process.stdout.write('======================================================================\n');
  process.stdout.write('Delivery 产物一致性校验（v5.6）\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`  sim-project: ${projectRoot}\n`);

  if (!fs.existsSync(deliveryRoot)) {
    log('[FAIL] delivery/ 目录不存在（package-delivery.mjs 未运行）');
    process.exit(1);
  }

  // 找 delivery/<项目名>/ 子目录
  let projectName = args.project;
  if (!projectName) {
    const subDirs = fs.readdirSync(deliveryRoot, { withFileTypes: true })
      .filter(e => e.isDirectory() && !e.name.startsWith('.'))
      .map(e => e.name);
    if (subDirs.length === 0) {
      log('[FAIL] delivery/<项目名>/ 子目录不存在');
      process.exit(1);
    }
    if (subDirs.length === 1) {
      projectName = subDirs[0];
    } else {
      // 多个项目目录时，优先选含 index.html 的
      projectName = subDirs.find(n => fs.existsSync(path.join(deliveryRoot, n, 'index.html'))) || subDirs[0];
    }
  }
  const projectDir = path.join(deliveryRoot, projectName);
  if (!fs.existsSync(projectDir)) {
    log(`[FAIL] delivery/${projectName}/ 不存在`);
    process.exit(1);
  }
  log(`  项目名:     ${projectName}`);
  log(`  交付目录:   ${projectDir}\n`);

  let pass = 0, fail = 0, warn = 0;

  // v5.14.17 批次4 R-8（P0）— 状态机硬门禁：跳验检测
  //   根因：修复 A 认可 delivery_packaged=true + final_approved=false + current_phase=2 中间态后，
  //         agent 可停在"已打包未验证"状态——delivery 产物物理存在但未通过任何校验，
  //         若被人直接取用会绕过 V-1~V-13 全部校验。
  //         V-13 哈希绑定只在 verify-delivery 运行时触发，跳验场景下 V-13 不发挥作用。
  //   修复 R-8：verify-delivery 启动时检测"已打包但未验证"状态，输出告警（非阻断，因 verify 本身就是来推进状态的）
  //   注意：verify-delivery 自身不阻断跳验状态——它的运行正是为了消除跳验状态。
  //         真正的阻断在 package-delivery.mjs（防 agent 跳过 verify 后再次打包覆盖）
  //         和消费点检测（防 agent 跳验后直接取用 delivery 产物）
  {
    const r8StateFile = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(r8StateFile)) {
      // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
      const r8StateText = readStateYaml(projectRoot);
      const r8Packaged = /delivery_packaged:\s*true/.test(r8StateText);
      const r8Verified = /delivery_consistency_verified:\s*true/.test(r8StateText);
      if (r8Packaged && !r8Verified) {
        log('[INFO] R-8: 检测到"已打包未验证"中间态——verify-delivery 将推进状态机到终态');
        log('       防御：package-delivery 再次启动时会硬阻断此状态；消费点检测会校验 delivery_demo_hash');
      }
    }
  }

  // v5.14.17 批次4 R-8（P0）— 消费点检测：state.yaml 与 delivery 实物哈希交叉验证
  //   防御：agent 手动复制文件到 delivery 目录 + 手写 state.yaml 所有字段（极端绕过）
  //   实现：在 verify-delivery 推进状态机之前，重新计算 delivery demo 哈希并与 state.yaml 比对
  //   注意：此检测在 V-13 校验 4 已实现，但 V-13 检测的是"state.yaml 哈希与 delivery 实物哈希是否一致"
  //         R-8 消费点检测额外校验"delivery 实物是否被改动"——通过比对 delivery demo 哈希与 package-delivery 写入时的哈希
  //   降级：若 state.yaml 无 delivery_demo_hash 字段（package-delivery 未运行），跳过此检测（V-13 校验 4 会检出）

  // V-1: delivery/<项目名>/index.html 存在且非空（>= 5000 bytes）
  // v5.6 阈值提升：因 PROJECT BACKGROUND 板块增强（业务背景/痛点/解决方案/PM 需求折叠面板）
  //   原 1000 bytes 阈值无法检测空 PROJECT BACKGROUND，提升到 5000 bytes 确保叙事板块完整
  const siteIndexPath = path.join(projectDir, 'index.html');
  if (!fs.existsSync(siteIndexPath)) {
    log('[FAIL] V-1: delivery/<项目名>/index.html 缺失');
    fail++;
  } else {
    const size = fs.statSync(siteIndexPath).size;
    if (size < 5000) {
      log(`[FAIL] V-1: delivery/<项目名>/index.html 大小 ${size} bytes < 5000（疑似 PROJECT BACKGROUND 板块未渲染）`);
      fail++;
    } else {
      log(`[OK]   V-1: index.html 存在 (${(size / 1024).toFixed(2)} KB)`);
      pass++;
    }
  }

  // V-2: delivery/<项目名>/demo/index.html 存在且非空骨架（>= 5000 bytes + 不含空骨架特征）
  const deliveryDemoHtmlPath = path.join(projectDir, 'demo', 'index.html');
  if (!fs.existsSync(deliveryDemoHtmlPath)) {
    log('[FAIL] V-2: delivery/<项目名>/demo/index.html 缺失');
    fail++;
  } else {
    const size = fs.statSync(deliveryDemoHtmlPath).size;
    const content = fs.readFileSync(deliveryDemoHtmlPath, 'utf-8');
    const isShell = isShellHtml(content);
    if (size < 5000) {
      log(`[FAIL] V-2: delivery demo/index.html 大小 ${size} bytes < 5000（疑似空骨架）`);
      fail++;
    } else if (isShell) {
      log(`[FAIL] V-2: delivery demo/index.html 含空骨架特征字符串（"Demo - 待 AI 设计" 等）`);
      fail++;
    } else {
      log(`[OK]   V-2: delivery demo/index.html 是真实 HTML (${(size / 1024).toFixed(2)} KB)`);
      pass++;
    }
  }

  // V-3: delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html SHA-256 一致
  const simDemoHtmlPath = path.join(projectRoot, 'demo', 'index.html');
  if (!fs.existsSync(simDemoHtmlPath)) {
    log('[WARN] V-3: sim-project/demo/index.html 不存在，跳过哈希一致性校验');
    warn++;
  } else if (!fs.existsSync(deliveryDemoHtmlPath)) {
    log('[FAIL] V-3: delivery demo/index.html 缺失，无法校验哈希一致性');
    fail++;
  } else {
    const simHash = sha256(simDemoHtmlPath);
    const deliveryHash = sha256(deliveryDemoHtmlPath);
    if (simHash === deliveryHash) {
      log(`[OK]   V-3: delivery demo/index.html 与 sim-project 一致（SHA-256: ${simHash.slice(0, 12)}...）`);
      pass++;
    } else {
      log(`[FAIL] V-3: 哈希不一致 — sim=${simHash.slice(0, 12)}... delivery=${deliveryHash.slice(0, 12)}...`);
      log(`       说明：package-delivery.mjs 可能使用了过期的 demo 源`);
      fail++;
    }
  }

  // V-4: delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
  // v5.14.16 修复 G（批次2）：B 级门禁区分 warn 严重性
  //   根因：原 V-4 仅校验 overall=A/B，B 级（有 warn）一律放行，导致 D0_console error/404
  //         等"不可接受 warn"混入交付物。文档 §6.3 修复 G 要求定义不可接受 warn 清单。
  //   修复：overall=B 时，扫描 dimensions 识别不可接受 warn，若有则 V-4 降级 FAIL
  //   不可接受 warn 清单（文档明确）：
  //     - D0_console warn: console 有 error/404（功能缺陷信号）
  //     - D6_button_responsiveness warn: 按钮无响应或全 disabled（功能缺陷信号）
  //   可接受 warn（清单外，B 级可放行）：
  //     - D3_modal_close skip/warn: no modal / no testable triggers（无弹窗属正常）
  //     - D4_l2_flicker warn: L2 探测异常（非功能缺陷）
  //     - D7_visual_heuristics warn: 视觉启发式问题（非功能缺陷）
  //     - D8_l3_interactive warn: 无 data-element-id 或部分未交互（非功能缺陷）
  //     - D9_* warn: 标注面板探测异常（非功能缺陷）
  //     - D10_full_activation warn: no annotations found（无标注属配置问题，非功能缺陷）
  //   注意：fail 不是 warn，/D\d+.*fail/i 模式永不命中，不纳入 warn 清单
  //         fail 由 overall=C/D 拦截（V-4 原逻辑已拒绝 < B）
  const UNACCEPTABLE_WARN_DIMENSIONS = {
    D0_console: { pattern: /^warn:/i, reason: 'console 含 error/404（功能缺陷）' },
    D6_button_responsiveness: { pattern: /^warn:/i, reason: '按钮无响应或全 disabled（功能缺陷）' },
  };
  const deliveryAuditPath = path.join(projectDir, 'demo', 'audit-result.json');
  if (!fs.existsSync(deliveryAuditPath)) {
    log('[FAIL] V-4: delivery demo/audit-result.json 缺失');
    fail++;
  } else {
    try {
      const auditData = JSON.parse(fs.readFileSync(deliveryAuditPath, 'utf-8'));
      const overall = auditData.overall;
      if (overall !== 'A' && overall !== 'B') {
        log(`[FAIL] V-4: delivery audit-result.json overall = ${overall}（< B）`);
        fail++;
      } else if (overall === 'A') {
        log(`[OK]   V-4: delivery audit-result.json overall = A（无 warn）`);
        pass++;
      } else {
        // overall === 'B'：需区分 warn 严重性（修复 G）
        const dimensions = auditData.dimensions || {};
        const unacceptableWarns = [];
        for (const [dim, rule] of Object.entries(UNACCEPTABLE_WARN_DIMENSIONS)) {
          const value = dimensions[dim];
          if (typeof value === 'string' && rule.pattern.test(value)) {
            unacceptableWarns.push({ dim, value, reason: rule.reason });
          }
        }
        if (unacceptableWarns.length > 0) {
          log(`[FAIL] V-4: delivery audit-result.json overall = B 但含 ${unacceptableWarns.length} 个不可接受 warn：`);
          unacceptableWarns.forEach(w => {
            log(`       - ${w.dim}: ${w.value.substring(0, 80)} — ${w.reason}`);
          });
          log(`       需修复至 A 级才可放行（清单外 warn 如 D3 skip 可放行）`);
          fail++;
        } else {
          log(`[OK]   V-4: delivery audit-result.json overall = B（warn 均为可接受类型：D3 skip / D4 / D7 / D8 / D9 / D10）`);
          pass++;
        }
      }
    } catch (e) {
      log(`[FAIL] V-4: delivery audit-result.json 解析失败: ${e.message}`);
      fail++;
    }
  }

  // V-5: delivery/<项目名>/demo/screenshots/ 截图数量 >= 5 张
  const screenshotsDir = path.join(projectDir, 'demo', 'screenshots');
  if (!fs.existsSync(screenshotsDir)) {
    log('[FAIL] V-5: delivery demo/screenshots/ 目录缺失');
    fail++;
  } else {
    const screenshots = fs.readdirSync(screenshotsDir).filter(f => /\.(png|jpg|jpeg)$/i.test(f));
    if (screenshots.length >= 5) {
      log(`[OK]   V-5: 截图数量 ${screenshots.length} 张（>= 5）`);
      pass++;
    } else {
      log(`[FAIL] V-5: 截图数量 ${screenshots.length} < 5`);
      fail++;
    }
  }

  // V-6: delivery/<项目名>/docs/ 全部 md + 5 HTML 齐全 + 4 子页面含重定向脚本
  // v5.6 修复：从仅统计 docs/prd/ 改为统计 docs/ 下所有 md（含 prd/spec/test/handoff）
  //   原因：v5.5 仅统计 prd/ 时，2 页面项目只有 13+2=15 md < 20 阈值，导致 V-6 误报
  //   修复后：最小项目含 13 PRD + 1 page-details + 7 Spec + 3 Test + 1 Handoff = 25 md
  //   阈值：>= 20 md（向后兼容）+ 5 HTML
  // v5.6 增强：4 个子页面（product-overview/page-spec/data-model/role-permission.html）
  //   必须含重定向脚本 `window.location.href = 'index.html#` —— 单页 PRD 重构后的产物契约
  const deliveryDocsDir = path.join(projectDir, 'docs');
  const { prd: prdMdCount, total: totalMdCount, html: htmlCount } = countDocsMd(deliveryDocsDir);

  // V-6a: md + HTML 数量校验
  let v6aOk = false;
  if (totalMdCount >= 20 && htmlCount === 5) {
    v6aOk = true;
  }

  // V-6b: 4 个子页面重定向脚本校验
  //   v5.9：product-overview.html 重定向目标从 #metadata 改为 #tldr（metadata 章节已删除）
  const redirectStubs = [
    { file: 'product-overview.html', anchor: '#tldr' },
    { file: 'page-spec.html',        anchor: '#pages' },
    { file: 'data-model.html',       anchor: '#data' },
    { file: 'role-permission.html',  anchor: '#roles' },
  ];
  let v6bMissing = [];
  let v6bNoRedirect = [];
  for (const stub of redirectStubs) {
    const stubPath = path.join(deliveryDocsDir, stub.file);
    if (!fs.existsSync(stubPath)) {
      v6bMissing.push(stub.file);
    } else {
      const content = fs.readFileSync(stubPath, 'utf-8');
      // 校验含 `window.location.href = 'index.html#<anchor>'` 或 meta refresh
      const hasRedirectScript = content.includes(`window.location.href = 'index.html${stub.anchor}'`) ||
                                 content.includes(`window.location.href="index.html${stub.anchor}"`);
      const hasMetaRefresh = content.includes(`url=index.html${stub.anchor}`);
      if (!hasRedirectScript && !hasMetaRefresh) {
        v6bNoRedirect.push(stub.file);
      }
    }
  }

  if (v6aOk && v6bMissing.length === 0 && v6bNoRedirect.length === 0) {
    log(`[OK]   V-6: docs/ ${totalMdCount} md（prd=${prdMdCount}）+ ${htmlCount} HTML + 4 子页面重定向脚本齐全`);
    pass++;
  } else {
    if (!v6aOk) {
      log(`[FAIL] V-6a: docs/ ${totalMdCount} md（prd=${prdMdCount}）+ ${htmlCount} HTML（期望 >=20 md + 5 HTML）`);
    }
    if (v6bMissing.length > 0) {
      log(`[FAIL] V-6b: 重定向存根缺失: ${v6bMissing.join(', ')}`);
    }
    if (v6bNoRedirect.length > 0) {
      log(`[FAIL] V-6b: 重定向脚本缺失: ${v6bNoRedirect.join(', ')}（应含 window.location.href = 'index.html#<anchor>'）`);
    }
    fail++;
  }

  // V-7: delivery/<项目名>/downloads/ 2 个 zip 大小 >= 10 KB（v5.9：移除 docs-only.zip）
  const downloadsDir = path.join(projectDir, 'downloads');
  const expectedZips = ['demo-only.zip', 'full-delivery.zip'];
  let zipOk = true;
  for (const zipName of expectedZips) {
    const zipPath = path.join(downloadsDir, zipName);
    if (!fs.existsSync(zipPath)) {
      log(`[FAIL] V-7: downloads/${zipName} 缺失`);
      zipOk = false;
    } else {
      const size = fs.statSync(zipPath).size;
      if (size < 10 * 1024) {
        log(`[FAIL] V-7: downloads/${zipName} 大小 ${(size / 1024).toFixed(2)} KB < 10 KB`);
        zipOk = false;
      }
    }
  }
  if (zipOk) {
    log(`[OK]   V-7: 2 个 zip 全部存在且 >= 10 KB`);
    pass++;
  } else {
    fail++;
  }

  // V-8: delivery/<项目名>/project-info.json 字段完整
  const projectInfoPath = path.join(projectDir, 'project-info.json');
  if (!fs.existsSync(projectInfoPath)) {
    log('[FAIL] V-8: project-info.json 缺失');
    fail++;
  } else {
    try {
      const info = JSON.parse(fs.readFileSync(projectInfoPath, 'utf-8'));
      const required = ['projectName', 'pageCount', 'entityCount'];
      const missing = required.filter(k => info[k] === undefined || info[k] === null || info[k] === '');
      if (missing.length > 0) {
        log(`[FAIL] V-8: project-info.json 缺字段: ${missing.join(', ')}`);
        fail++;
      } else {
        log(`[OK]   V-8: project-info.json 字段完整 (projectName=${info.projectName}, pages=${info.pageCount}, entities=${info.entityCount})`);
        pass++;
      }
    } catch (e) {
      log(`[FAIL] V-8: project-info.json 解析失败: ${e.message}`);
      fail++;
    }
  }

  // V-9: v5.6 新增 — 单页 PRD 完整性校验
  //   V-9a: delivery/<项目名>/index.html 不含未替换的 {{ }} 占位符
  //   V-9b: delivery/<项目名>/docs/index.html 含 11 大章节锚点
  //         v5.7：从 8 锚点扩展到 11 锚点（新增 tldr/non-goals/business-flow）
  //         v5.9：移除 metadata/solution，新增 scope/pm-requirement（仍为 11 锚点）
  //   V-9c: delivery/<项目名>/docs/index.html size >= 28000 bytes
  //         v5.7：阈值从 15000 提升到 25000（因新增 TL;DR + 三大 Flow + 受众 Tab + Mermaid 引用）
  //         v5.8：25000 → 21000（移除 §12 详细文档下载 + 9 处信源标注）
  //         v5.9：21000 → 28000（新增 Ourchem × Demora 联合版权 footer ~12 KB inline SVG）
  let v9aOk = false, v9bOk = false, v9cOk = false, v9dOk = false, v9eOk = false, v9fOk = false;

  // V-9a: 占位符替换校验
  if (!fs.existsSync(siteIndexPath)) {
    log('[FAIL] V-9a: delivery index.html 缺失，无法校验占位符');
  } else {
    const siteContent = fs.readFileSync(siteIndexPath, 'utf-8');
    // 查找未替换的 {{xxx}} 占位符（排除注释和样式中的 CSS {{ }})
    // 匹配形如 {{fieldName}} 或 {{#if xxx}}...{{/if}} 的未处理模板标记
    const placeholderMatches = siteContent.match(/\{\{[a-zA-Z_#\/][a-zA-Z0-9_\/\s]*\}\}/g);
    if (placeholderMatches && placeholderMatches.length > 0) {
      log(`[FAIL] V-9a: delivery index.html 含未替换占位符: ${placeholderMatches.slice(0, 5).join(', ')}${placeholderMatches.length > 5 ? '...' : ''}`);
    } else {
      v9aOk = true;
    }
  }

  // V-9b + V-9c: docs/index.html 章节 + 大小校验
  const docsIndexPath = path.join(deliveryDocsDir, 'index.html');
  if (!fs.existsSync(docsIndexPath)) {
    log('[FAIL] V-9b: delivery docs/index.html 缺失，无法校验章节锚点');
    log('[FAIL] V-9c: delivery docs/index.html 缺失，无法校验大小');
  } else {
    const docsIndexSize = fs.statSync(docsIndexPath).size;
    const docsIndexContent = fs.readFileSync(docsIndexPath, 'utf-8');

    // V-9b: 11 大章节锚点校验
    //   v5.7：8 → 11（新增 tldr/non-goals/business-flow）
    //   v5.8：锚点列表不变 — 主导航从 14 精简到 8，但 section id 仍保留在 body
    //   v5.9：移除 metadata/solution（章节已删除），新增 scope/pm-requirement（仍在 body）
    //         最终锚点列表 11 个：tldr/non-goals/problem/users/business-flow/pages/data/roles/metrics/scope/pm-requirement
    const expectedAnchors = [
      'tldr', 'non-goals', 'problem', 'users',
      'business-flow', 'pages', 'data', 'roles',
      'metrics', 'scope', 'pm-requirement'
    ];
    const missingAnchors = expectedAnchors.filter(a => {
      // 匹配 id="metadata" 或 id='metadata'（含引号变体）
      const regex = new RegExp(`id=["']${a}["']`);
      return !regex.test(docsIndexContent);
    });
    if (missingAnchors.length > 0) {
      log(`[FAIL] V-9b: docs/index.html 缺章节锚点: ${missingAnchors.map(a => `id="${a}"`).join(', ')}`);
    } else {
      v9bOk = true;
    }

    // V-9c: 大小校验
    //   v5.7：阈值 15000 → 25000（新增 TL;DR + 三大 Flow + 受众 Tab + Mermaid 引用）
    //   v5.8：25000 → 21000（移除 §12 详细文档下载 + 9 处信源标注，净减 ~4 KB）
    //   v5.9：21000 → 28000（新增 Ourchem × Demora 联合版权 footer ~12 KB inline SVG）
    if (docsIndexSize < 28000) {
      log(`[FAIL] V-9c: docs/index.html 大小 ${docsIndexSize} bytes < 28000（v5.9 阈值，疑似 Ourchem × Demora 联合版权 footer 缺失）`);
    } else {
      v9cOk = true;
    }

    // V-9d: v5.10 新增 — §2 PM 原始需求 内容非空校验
    //   v5.11 增强：校验同时含 requirement-scenario-brief.md 与 requirement-input.md 两个折叠面板，
    //   且 brief 在 input 之前（按时间顺序展示需求导入与迭代过程）
    //   根因：generate-product-docs.mjs 在 main process Phase 2 执行（AI 阶段 1 之前），
    //         此时 inbox/text/requirement-input.md 尚未生成，导致 §2 渲染为"暂未提供"
    //   修复：AI 阶段 1 写入 requirement-input.md 后必须重跑 generate-product-docs.mjs
    const pmReqSectionRegex = /<section id="pm-requirement"[\s\S]*?<\/section>/;
    const pmReqMatch = docsIndexContent.match(pmReqSectionRegex);
    if (!pmReqMatch) {
      log('[FAIL] V-9d: docs/index.html 缺少 §2 PM 原始需求 section');
    } else if (pmReqMatch[0].includes('暂未提供')) {
      log('[FAIL] V-9d: docs/index.html §2 PM 原始需求 显示"暂未提供"（需在 AI 阶段 1 写入 requirement-input.md 后重跑 generate-product-docs.mjs）');
    } else {
      // v5.11：检查两份文档 + 顺序
      const pmReqHtml = pmReqMatch[0];
      const hasBrief = pmReqHtml.includes('requirement-scenario-brief.md');
      const hasInput = pmReqHtml.includes('requirement-input.md');
      const briefIdx = pmReqHtml.indexOf('requirement-scenario-brief.md');
      const inputIdx = pmReqHtml.indexOf('requirement-input.md');
      const orderOk = hasBrief && hasInput && briefIdx < inputIdx;
      if (!hasBrief || !hasInput) {
        log(`[FAIL] V-9d: docs/index.html §2 PM 原始需求 缺少 ${!hasBrief ? 'requirement-scenario-brief.md' : ''} ${!hasInput ? 'requirement-input.md' : ''}（v5.11 要求两份文档均展示）`);
      } else if (!orderOk) {
        log('[FAIL] V-9d: docs/index.html §2 PM 原始需求 顺序错误（v5.11 要求 brief 在 input 之前）');
      } else {
        v9dOk = true;
      }
    }

    // V-9e: v5.10 新增 — §4 业务流程 含三大 Flow 标题校验
    //   校验 docs/index.html 的 business-flow section 含 Task Flow / Data Flow / Page Flow
    //   根因：extractMarkdownSection 使用精确匹配正则 `^##\s+sectionTitle\s*$`，
    //         但 v5.10 的 04-business-flow.md 标题含 ", BPMN 2.0" 等业界标准后缀导致匹配失败
    //   修复：extractMarkdownSection 改为前缀匹配 `^##\s+sectionTitle.*$`
    const bfSectionRegex = /<section id="business-flow"[\s\S]*?<\/section>/;
    const bfMatch = docsIndexContent.match(bfSectionRegex);
    const bfContent = bfMatch ? bfMatch[0] : '';
    const expectedFlows = ['Task Flow（任务流）', 'Data Flow（数据流）', 'Page Flow（页面流）'];
    const missingFlows = expectedFlows.filter(f => !bfContent.includes(f));
    if (missingFlows.length > 0) {
      log(`[FAIL] V-9e: docs/index.html §4 业务流程 缺失 Flow: ${missingFlows.join(', ')}（extractMarkdownSection 前缀匹配失败）`);
    } else {
      v9eOk = true;
    }

    // V-9f: v5.11 新增 — §4 mermaid 语法风险校验
    //   根因：generate-prd.mjs 生成的 mermaid 节点标签含未转义特殊字符（() / :）
    //         导致 Mermaid 11.16.0 严格模式解析失败：Syntax error in text
    //   修复：所有节点标签加双引号；<-.-> 改为 -.->
    //   校验点：
    //     1. mermaid 块中不存在 <-.-> 非法箭头
    //     2. mermaid 块中的 (label) / [label] / [[label]] / {label} 节点标签如含特殊字符应加双引号
    //        简化校验：检测 P1(label 含 () 这类内嵌括号场景，且 label 未用双引号包裹
    const mermaidBlockRegex = /<div class="mermaid">([\s\S]*?)<\/div>/g;
    let mermaidBlocks = [];
    let mMatch;
    while ((mMatch = mermaidBlockRegex.exec(docsIndexContent)) !== null) {
      mermaidBlocks.push(mMatch[1]);
    }
    let v9fIssues = [];
    if (mermaidBlocks.length === 0) {
      // 非强制：可能 docs/index.html 用 <pre><code class="language-mermaid"> 包裹
      const altRegex = /class="language-mermaid">([\s\S]*?)<\/code>/g;
      while ((mMatch = altRegex.exec(docsIndexContent)) !== null) {
        mermaidBlocks.push(mMatch[1]);
      }
    }
    mermaidBlocks.forEach((block, idx) => {
      // 校验 1：非法箭头 <-.->
      if (/<-\.-\->/.test(block)) {
        v9fIssues.push(`mermaid 块 #${idx + 1} 含非法箭头 \`<-.->\`（应为 \`-.->\`）`);
      }
      // 校验 2：未加双引号的节点标签含内嵌括号
      //   匹配模式：P1(label containing ())，即圆角矩形节点 (label) 中 label 含 () 但未用双引号包裹
      //   双引号包裹形式为 ("label")，故未加双引号的 label 形如 (xxx(yyy)zzz)
      //   正则匹配：左括号后紧跟非双引号的字符序列，且该序列含 ( 或 )
      //   实现：提取所有 (...) 形式，检查内部是否含 () 且未以 " 开头
      const procNodeRegex = /\b([A-Za-z][A-Za-z0-9_]*)\(([^"]*?)\)/g;
      let nodeMatch;
      while ((nodeMatch = procNodeRegex.exec(block)) !== null) {
        const label = nodeMatch[2];
        // 跳过 (( )) 圆形节点（circle，单独处理）
        // 例：Start((用户登录)) 会被非贪婪正则匹配为 Start((用户登录) 导致 label="(用户登录" 误报
        if (nodeMatch[0].includes('((')) continue;
        // 标签内含 ( 或 ) 即为问题（未加双引号）
        if (/[()]/.test(label)) {
          v9fIssues.push(`mermaid 块 #${idx + 1} 节点 \`${nodeMatch[0]}\` 标签含未转义括号，应加双引号：\`("${label}")\``);
        }
      }
      // 校验 3：未加双引号的 [label] 含特殊字符
      const rectNodeRegex = /\b([A-Za-z][A-Za-z0-9_]*)\[([^\]]*?)\]/g;
      while ((nodeMatch = rectNodeRegex.exec(block)) !== null) {
        const label = nodeMatch[2];
        // 跳过 [[ ]] 双线节点（DataStore，单独处理）
        if (nodeMatch[0].includes('[[')) continue;
        // v5.20 P0-2：跳过 [( )] 圆柱节点（cylinder）——形状括号属形状语法而非标签内容，
        //   由下方校验 3b 单独处理（原实现把 DB[("…")] 误判为"含未转义括号的矩形标签"，
        //   连引号转义的正确形态也误报，迫使 agent 把圆柱降级为矩形迁就检查器——U13 口径修正）
        if (nodeMatch[0].includes('[(')) continue;
        // v5.11.1：仅 () 会触发 Mermaid 11.16.0 严格模式解析失败
        //   （/ 和 : 在 [] 标签中合法，无需加双引号）
        if (/[()]/.test(label) && !label.startsWith('"')) {
          v9fIssues.push(`mermaid 块 #${idx + 1} 节点 \`${nodeMatch[0]}\` 标签含未转义括号，应加双引号：\`["${label}"]\``);
        }
      }
      // 校验 3b（v5.20 P0-2 新增）：[( )] 圆柱节点单独校验——仅检查内层标签
      //   合法形态：DB[(标签)] / DB[("标签")]（引号包裹）；非法形态：DB[(a(b))]（内层标签含裸括号未转义）
      const cylNodeRegex = /\b([A-Za-z][A-Za-z0-9_]*)\[\((.+?)\)\]/g;
      while ((nodeMatch = cylNodeRegex.exec(block)) !== null) {
        const label = nodeMatch[2];
        if (/[()]/.test(label) && !label.startsWith('"')) {
          v9fIssues.push(`mermaid 块 #${idx + 1} 节点 \`${nodeMatch[0]}\` 圆柱标签含未转义括号，应加双引号：\`[("${label}")]\``);
        }
      }
    });
    if (v9fIssues.length > 0) {
      log(`[FAIL] V-9f: docs/index.html §4 mermaid 存在语法风险（${v9fIssues.length} 处）：`);
      v9fIssues.slice(0, 5).forEach(issue => log(`       - ${issue}`));
      if (v9fIssues.length > 5) log(`       ... 共 ${v9fIssues.length} 处`);
    } else {
      v9fOk = true;
    }
  }

  if (v9aOk && v9bOk && v9cOk && v9dOk && v9eOk && v9fOk) {
    log(`[OK]   V-9: 单页 PRD 完整性通过（占位符已替换 + 11 章节锚点齐全 + size >= 28000 + §2 PM 需求双文档顺序正确 + §4 三大 Flow 齐全 + §4 mermaid 语法无风险）`);
    pass++;
  } else {
    fail++;
  }

  // V-10: v5.7 新增 — docs/assets/mermaid/ 资产校验
  //   校验 delivery/<项目名>/docs/assets/mermaid/ 目录存在且含两个核心文件：
  //     - mermaid.min.js（核心库，~3.4 MB）
  //     - mermaid-init.js（初始化脚本，~1 KB）
  //   缺失时 docs/index.html 中的 Mermaid 流程图将无法渲染（mermaid-init.js 内部会降级为 fallback 显示源码）
  const mermaidDir = path.join(deliveryDocsDir, 'assets', 'mermaid');
  let v10Missing = [];
  let v10SizeOk = false;

  if (!fs.existsSync(mermaidDir)) {
    v10Missing.push('assets/mermaid/ 目录');
  } else {
    // 校验 mermaid.min.js（核心库，应 > 100 KB）
    const minJsPath = path.join(mermaidDir, 'mermaid.min.js');
    if (!fs.existsSync(minJsPath)) {
      v10Missing.push('mermaid.min.js');
    } else {
      const minJsSize = fs.statSync(minJsPath).size;
      if (minJsSize < 100 * 1024) {
        log(`[WARN] V-10: mermaid.min.js 大小 ${(minJsSize / 1024).toFixed(2)} KB < 100 KB（疑似截断或损坏）`);
        warn++;
      }
    }
    // 校验 mermaid-init.js（初始化脚本，应 > 200 bytes）
    const initJsPath = path.join(mermaidDir, 'mermaid-init.js');
    if (!fs.existsSync(initJsPath)) {
      v10Missing.push('mermaid-init.js');
    } else {
      const initJsSize = fs.statSync(initJsPath).size;
      v10SizeOk = initJsSize > 200;
    }
  }

  if (v10Missing.length === 0 && v10SizeOk) {
    log(`[OK]   V-10: docs/assets/mermaid/ 资产完整（mermaid.min.js + mermaid-init.js）`);
    pass++;
  } else {
    if (v10Missing.length > 0) {
      log(`[FAIL] V-10: docs/assets/mermaid/ 缺失: ${v10Missing.join(', ')}`);
    }
    if (!v10SizeOk && v10Missing.length === 0) {
      log(`[FAIL] V-10: mermaid-init.js 大小异常（疑似损坏）`);
    }
    fail++;
  }

  // V-11: v5.14 新增 — DIST 前 sim/demo/ ↔ delivery/<项目名>/demo/ 全目录 SHA-256 终检
  //   防御 F10（验收后产物漂移）：07-27 06:20 十个 sim demo 被批量改写后 manifest 仍示一致
  //   实现：递归计算两目录的归一化哈希（路径 + 内容），写入 .demora/delivery-hash-baseline.json
  //   风险控制：与 V-3（仅 index.html 单文件哈希）互补，V-11 覆盖整个 demo/ 目录树
  // v5.14.16 修复 D（批次1）：V-11 双侧同步过滤
  //   根因：package-delivery 过滤了黑名单截图但 V-11 比对未同步过滤，导致哈希失配（G-6）
  //         agent 被迫删除源数据对齐 → 削足适履
  //   修复：computeDirHash 计算时对 sim/demo/ 和 delivery/<项目名>/demo/ 双方应用相同过滤
  //         （调试文件 + 失败截图黑名单 + 历史 label 过滤），过滤后哈希再比对
  //         注意：delivery_demo_hash（V-13 校验 4 比对）仍用未过滤的实际哈希，
  //              因为 package-delivery 写入的是过滤后 delivery 实物的哈希
  const simDemoDir = path.join(projectRoot, 'demo');
  const deliveryDemoDir = path.join(projectDir, 'demo');
  const baselineFile = path.join(projectRoot, '.demora', 'delivery-hash-baseline.json');

  // v5.16 Task 9.2/9.3：computeDirHash / SCREENSHOT_BLACKLIST_REGEX 已抽取到 lib/hash-utils.mjs
  //   原本地定义 V11_BLACKLIST_REGEX（L714）与 lib 的 SCREENSHOT_BLACKLIST_REGEX 字符级一致
  //   原本地定义 V11_DEBUG_FILE_REGEX / readAuditLabelForV11 是 computeDirHash 的内部辅助，
  //     已由 lib/hash-utils.mjs 内部的 DEBUG_FILE_BLACKLIST_REGEX / readAuditLabel 取代（不导出）
  //   原本地定义 computeDirHash（L733-777，含 filtered 选项）已被 lib 的 computeDirHash 取代
  //   lib 实现支持 filtered 选项，filtered=true 行为与原 V-11 双侧同步过滤完全等价
  //   调用方代码不变：computeDirHash(dir, { filtered: true }) 直接复用 lib 实现

  // V-11 比对：使用 filtered=true（双侧同步过滤后哈希）
  const simHash = computeDirHash(simDemoDir, { filtered: true });
  const deliveryHash = computeDirHash(deliveryDemoDir, { filtered: true });
  const baseline = {
    generatedAt: new Date().toISOString(),
    project: projectName,
    sim_demo_dir: simDemoDir,
    delivery_demo_dir: deliveryDemoDir,
    sim_hash: simHash,
    delivery_hash: deliveryHash,
    consistent: simHash !== null && deliveryHash !== null && simHash === deliveryHash,
    filterApplied: true,  // 标记本次比对应用了双侧同步过滤
    filterRules: ['debug-files', 'screenshot-blacklist', 'historical-label'],
  };
  try {
    fs.writeFileSync(baselineFile, JSON.stringify(baseline, null, 2), 'utf-8');
    log(`[INFO] V-11: 哈希基线已写入 ${baselineFile}（双侧同步过滤后哈希）`);
  } catch (e) {
    log(`[WARN] V-11: 哈希基线写入失败: ${e.message}`);
  }

  if (simHash === null) {
    log(`[FAIL] V-11: sim/demo/ 目录不存在（${simDemoDir}）`);
    fail++;
  } else if (deliveryHash === null) {
    log(`[FAIL] V-11: delivery/<项目名>/demo/ 目录不存在（${deliveryDemoDir}）`);
    fail++;
  } else if (simHash !== deliveryHash) {
    log(`[FAIL] V-11: sim/demo/ 哈希 (${simHash.slice(0, 12)}) 与 delivery/<项目名>/demo/ 哈希 (${deliveryHash.slice(0, 12)}) 不一致`);
    log(`       防御 F10：sim demo 可能在交付后被改写，请核查 sim/demo/ 文件修改时间`);
    fail++;
  } else {
    log(`[OK]   V-11: sim/demo/ ↔ delivery/<项目名>/demo/ 全目录哈希一致 (${simHash.slice(0, 12)})`);
    pass++;
  }

  // V-12: v5.14.16 修复 A（批次1）— state.yaml 状态机一致性校验（消除设计死锁）
  //   原死锁根因：旧校验要求 delivery_packaged=true 时 final_approved=true + current_phase=3
  //              但这两个字段只能由 verify-delivery 在 fail===0（即 V-12 已通过）时写入
  //              → 第一次 verify-delivery 必然触发 V-12 FAIL，且永远无法自行通过
  //              → 三案例均被逼入手动编辑 state.yaml
  //   修复 A：认可 delivery_packaged=true + final_approved=false + current_phase=2 为合法中间态
  //           （打包后、验证前的正常状态），仅在 verify-delivery 通过后由脚本推进到
  //           final_approved=true + current_phase=3
  //   修复 B（同批）：V-12 不再单靠字段值区分"脚本推进"与"agent 手动写入"，由 V-13 哈希绑定
  //                  闭合检测空窗——若 agent 手动写入 final_approved=true 绕过 verify-delivery，
  //                  V-13 会因 state.yaml 中 delivery_demo_hash 缺失或不一致检出
  //   新校验点（消除死锁 + 保留防绕过）：
  //     1. delivery_consistency_verified=true 时 final_approved 必须为 true（保留）
  //     2. delivery_consistency_verified=true 时 current_phase 必须为 3（新增，对齐校验 1）
  //     3. delivery_consistency_verified=true 时 delivery_packaged 必须为 true（防止跳过打包）
  //     4. final_approved=true 时 current_phase 必须为 3（防止状态不一致）
  //   说明：delivery_packaged=true + final_approved=false + current_phase=2 是合法中间态
  const v12StateFile = path.join(projectRoot, '.demora', 'state.yaml');
  let v12Ok = false;
  let v12Issues = [];

  if (!fs.existsSync(v12StateFile)) {
    v12Issues.push('state.yaml 不存在（package-delivery 未运行或状态机未初始化）');
  } else {
    // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
    const v12StateText = readStateYaml(projectRoot);
    const hasDeliveryPackaged = /delivery_packaged:\s*true/.test(v12StateText);
    const hasFinalApproved = /final_approved:\s*true/.test(v12StateText);
    const hasConsistencyVerified = /delivery_consistency_verified:\s*true/.test(v12StateText);
    const phaseMatch = v12StateText.match(/^current_phase:\s*(\d+)/m);
    const currentPhase = phaseMatch ? parseInt(phaseMatch[1], 10) : null;

    // 校验 1：delivery_consistency_verified=true 时 final_approved 必须为 true
    //   不会死锁：delivery_consistency_verified 由 verify-delivery 在 fail===0 时写入，
    //            写入同时推进 final_approved=true，二者原子性共存
    if (hasConsistencyVerified && !hasFinalApproved) {
      v12Issues.push('delivery_consistency_verified=true 但 final_approved != true（状态机不一致）');
    }
    // 校验 2：delivery_consistency_verified=true 时 current_phase 必须为 3
    //   不会死锁：同上，verify-delivery 同时推进 current_phase=3
    if (hasConsistencyVerified && currentPhase !== null && currentPhase < 3) {
      v12Issues.push(`delivery_consistency_verified=true 但 current_phase=${currentPhase}（应为 3）`);
    }
    // 校验 3：delivery_consistency_verified=true 时 delivery_packaged 必须为 true
    //   防止跳过 package-delivery 直接 verify
    if (hasConsistencyVerified && !hasDeliveryPackaged) {
      v12Issues.push('delivery_consistency_verified=true 但 delivery_packaged != true（跳过打包直接 verify）');
    }
    // 校验 4：final_approved=true 时 current_phase 必须为 3
    //   防止 agent 手动写入 final_approved=true 但 current_phase 未推进
    if (hasFinalApproved && currentPhase !== null && currentPhase < 3) {
      v12Issues.push(`final_approved=true 但 current_phase=${currentPhase}（应为 3，疑似手动写入绕过 verify）`);
    }
    // 合法中间态：delivery_packaged=true + final_approved=false + current_phase=2（打包后验证前）
    //   不再视为非法，消除死锁

    if (v12Issues.length === 0) {
      v12Ok = true;
    }
  }

  if (v12Ok) {
    log(`[OK]   V-12: state.yaml 状态机一致（认可 packaged+approved=false+phase=2 中间态）`);
    pass++;
  } else {
    log(`[FAIL] V-12: state.yaml 状态机不一致（${v12Issues.length} 处矛盾）：`);
    v12Issues.forEach(issue => log(`       - ${issue}`));
    log(`       防御：V-13 哈希绑定会交叉验证实物，手动编辑 state.yaml 仍可被检出`);
    fail++;
  }

  // V-13: v5.14.16 修复 B+C（批次1）— 交付物洁净度检测 + 哈希绑定
  //   防御 W-1（调试文件残留）/ W-2（失败截图入库）/ G-6（V-11 哈希失配）
  //   根因：package-delivery 过滤不完整 + V-11 双侧未同步过滤
  //   修复 B：检测 delivery 目录实物（调试文件/失败截图/delivery-stash/）+ 哈希绑定
  //   修复 C：与 B 合并实现，避免重复定义漂移
  //   校验点：
  //     1. delivery/<项目名>/demo/ 无调试文件残留（_*.js / _*.tmp / _annotation_data.js）
  //     2. delivery/<项目名>/demo/screenshots/ 无失败截图（黑名单正则）
  //     3. delivery/ 无 delivery-stash/ 目录（重复目录残留）
  //     4. state.yaml 中 delivery_demo_hash 与实际计算的 delivery/<项目名>/demo/ 哈希一致
  //        （哈希绑定，闭合修复 A 认可中间态后的检测空窗）
  const v13DebugFilePattern = /^_.*\.(js|tmp)$|^_annotation_data\.js$/i;
  // 失败截图黑名单（与 package-delivery.mjs 修复 D 保持一致）
  const v13ScreenshotBlacklist = /(failed|final-fail|\bfail\b|no-coop|activation-failed|load-fail|\berror\b|unresponsive|overlap)/i;
  let v13Ok = true;
  const v13Issues = [];

  // 1. 扫描调试文件残留
  function scanDebugFiles(dir, base) {
    if (!fs.existsSync(dir)) return [];
    const found = [];
    function walk(d) {
      for (const entry of fs.readdirSync(d, { withFileTypes: true })) {
        const full = path.join(d, entry.name);
        if (entry.isDirectory()) {
          walk(full);
        } else if (v13DebugFilePattern.test(entry.name)) {
          found.push(path.relative(base, full).replace(/\\/g, '/'));
        }
      }
    }
    walk(dir);
    return found;
  }
  const debugFiles = scanDebugFiles(deliveryDemoDir, deliveryDemoDir);
  if (debugFiles.length > 0) {
    v13Issues.push(`调试文件残留 ${debugFiles.length} 个: ${debugFiles.slice(0, 5).join(', ')}${debugFiles.length > 5 ? ' ...' : ''}`);
  }

  // 2. 扫描失败截图残留
  const v13ScreenshotsDir = path.join(deliveryDemoDir, 'screenshots');
  const failedShots = [];
  if (fs.existsSync(v13ScreenshotsDir)) {
    for (const entry of fs.readdirSync(v13ScreenshotsDir, { withFileTypes: true })) {
      if (!entry.isFile()) continue;
      if (!/\.(png|jpg|jpeg)$/i.test(entry.name)) continue;
      if (v13ScreenshotBlacklist.test(entry.name)) {
        failedShots.push(entry.name);
      }
    }
  }
  if (failedShots.length > 0) {
    v13Issues.push(`失败截图残留 ${failedShots.length} 张: ${failedShots.slice(0, 5).join(', ')}${failedShots.length > 5 ? ' ...' : ''}`);
  }

  // 3. 检测 delivery-stash 目录残留
  const deliveryStashDir = path.join(projectRoot, 'delivery', 'delivery-stash');
  if (fs.existsSync(deliveryStashDir)) {
    v13Issues.push(`delivery-stash/ 目录残留（重复打包残留）: ${deliveryStashDir}`);
  }
  // 兼容：检测 delivery/<项目名>/ 同级是否有 stash
  const deliveryDir = path.join(projectRoot, 'delivery');
  if (fs.existsSync(deliveryDir)) {
    for (const entry of fs.readdirSync(deliveryDir, { withFileTypes: true })) {
      if (entry.isDirectory() && /stash/i.test(entry.name)) {
        v13Issues.push(`delivery/${entry.name}/ 目录残留（疑似 stash）`);
      }
    }
  }

  // 4. 哈希绑定：比对 state.yaml 中 delivery_demo_hash 与实际计算值
  //   闭合修复 A 认可中间态后的检测空窗：
  //   - agent 手动写 final_approved=true 绕过 verify → V-12 校验 4 可能漏检（current_phase 也手动改）
  //   - 但 state.yaml 中无 delivery_demo_hash（package-delivery 写入）→ V-13 校验 4 检出
  //   - 或 agent 重算哈希伪造 → 提高绕过成本（从"改一个布尔值"到"改值+重算哈希"）
  const actualDeliveryDemoHash = computeDirHash(deliveryDemoDir);
  let stateHash = null;
  if (fs.existsSync(v12StateFile)) {
    // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
    const v13StateText = readStateYaml(projectRoot);
    const hashMatch = v13StateText.match(/^delivery_demo_hash:\s*([a-f0-9]+)/m);
    if (hashMatch) stateHash = hashMatch[1];
  }
  if (stateHash === null) {
    v13Issues.push('state.yaml 无 delivery_demo_hash 字段（package-delivery 未写入哈希绑定，无法防御手动编辑 state.yaml 绕过 verify）');
  } else if (actualDeliveryDemoHash === null) {
    v13Issues.push('delivery/<项目名>/demo/ 不存在，无法计算哈希');
  } else if (stateHash !== actualDeliveryDemoHash) {
    v13Issues.push(`delivery_demo_hash 不一致（state.yaml=${stateHash.slice(0, 12)}, 实际=${actualDeliveryDemoHash.slice(0, 12)}）— 疑似打包后被改写或手动伪造哈希`);
  }

  if (v13Issues.length > 0) {
    v13Ok = false;
  }

  if (v13Ok) {
    log(`[OK]   V-13: 交付物洁净度 + 哈希绑定一致（无调试文件/失败截图/delivery-stash 残留）`);
    pass++;
  } else {
    log(`[FAIL] V-13: 交付物洁净度或哈希绑定异常（${v13Issues.length} 处问题）：`);
    v13Issues.forEach(issue => log(`       - ${issue}`));
    log(`       防御：W-1（调试文件残留）/ W-2（失败截图）/ G-6（哈希失配）— 修复 B+C 合并实现`);
    fail++;
  }

  // V-14: v5.21 新增 — 项目根 delivery.zip 存在且非空（发布到公网依赖）
  //   背景：交付页"发布到公网"按钮自动上传整站包（http 上下文经 fetch('../../delivery.zip') 直读；
  //         file:// 上下文经 release-payload.js 内嵌 base64 兜底）
  //   顺带校验 delivery/<项目名>/release-payload.js 存在（缺失记 [WARN] 不计 fail）
  const v14RootZipPath = path.join(projectRoot, 'delivery.zip');
  const v14RootZipSize = fs.existsSync(v14RootZipPath) ? fs.statSync(v14RootZipPath).size : 0;
  if (v14RootZipSize > 0) {
    log(`[OK]   V-14: 项目根 delivery.zip 存在 (${(v14RootZipSize / 1024).toFixed(2)} KB，发布用整站包)`);
    pass++;
  } else {
    log(`[FAIL] V-14: 项目根 delivery.zip 缺失或为空（v5.21 起发布到公网依赖该文件）`);
    fail++;
  }
  if (!fs.existsSync(path.join(projectDir, 'release-payload.js'))) {
    log(`[WARN] V-14: delivery/${projectName}/release-payload.js 缺失（file:// 发布兜底不可用，http 发布不受影响）`);
    warn++;
  }

  // V-15: v5.23 新增 — Q-5 环境降级事实的交付披露校验
  //   根因：htmlhint 可达性随环境漂移（UAT0824 opencode 环境 3/3 Q-5 降级，codex 环境正常），
  //         降级交付若不在交付说明中披露，下游会误以为经过了 htmlhint 全量校验
  //   逻辑：.demora/quality-report.yaml 含 q5_degraded: true 时，
  //         要求 delivery/ 下 README 或交付说明文件标注 "环境降级" 或 "htmlhint" 字样
  {
    const v15QualityReportPath = path.join(projectRoot, '.demora', 'quality-report.yaml');
    const v15ReportText = fs.existsSync(v15QualityReportPath)
      ? fs.readFileSync(v15QualityReportPath, 'utf-8')
      : '';
    const v15Q5Degraded = /q5_degraded:\s*true/.test(v15ReportText);
    if (!v15Q5Degraded) {
      log('[OK]   V-15: htmlhint 全量校验，无环境降级');
      pass++;
    } else {
      // 扫描 delivery/ 与 delivery/<项目名>/ 下的 README / 交付说明文件
      const v15ReadmePattern = /^(readme\.(txt|md)|交付说明.*\.(txt|md)|delivery-notes\.(txt|md))$/i;
      const v15FoundFiles = [];
      for (const v15Dir of [deliveryRoot, projectDir]) {
        if (!fs.existsSync(v15Dir)) continue;
        for (const entry of fs.readdirSync(v15Dir, { withFileTypes: true })) {
          if (entry.isFile() && v15ReadmePattern.test(entry.name)) {
            v15FoundFiles.push(path.join(v15Dir, entry.name));
          }
        }
      }
      let v15DisclosureText = '';
      for (const f of v15FoundFiles) {
        try { v15DisclosureText += fs.readFileSync(f, 'utf-8') + '\n'; } catch (e) { /* 读取失败按未标注处理 */ }
      }
      if (v15DisclosureText.includes('环境降级') || v15DisclosureText.includes('htmlhint')) {
        log(`[OK]   V-15: Q-5 降级事实已在交付说明中标注（${v15FoundFiles.map(f => path.relative(projectRoot, f)).join(', ')}）`);
        pass++;
      } else {
        log('[FAIL] V-15: Q-5 为 htmlhint 降级模式，交付说明未标注环境降级事实');
        if (v15FoundFiles.length === 0) {
          log('       delivery/ 下未找到 README.txt / README.md / 交付说明文件');
        } else {
          log(`       已检查: ${v15FoundFiles.map(f => path.relative(projectRoot, f)).join(', ')}`);
        }
        log('       修复：在交付说明中注明 "环境降级：htmlhint 不可用，Q-5 已降级为基本 HTML 检查"');
        fail++;
      }
    }
  }

  // V-16: v5.25 新增 — demo 打包后冻结校验（mtime > delivery_packaged_at 即 FAIL）
  //   根因：oc-demora-0828 轮 tw-glm53f 两案在 package-delivery 完成后 7~51 分钟继续改写 demo，
  //         demo 与 delivery SHA 分叉（V-3/V-13 哈希绑定失效），交付物为旧版 demo
  //   逻辑：state.yaml 含 delivery_packaged_at 时，扫描 <root>/demo/** 全部文件 mtime，
  //         任一 mtime > delivery_packaged_at + 5s 容差 → FAIL（列出越界文件，最多 5 个）
  //   降级：无 delivery_packaged_at（旧版本打包产物）→ WARN 跳过（向后兼容）
  //   配套：package-delivery.mjs 打包成功后自动冻结 demo/（只读），--unfreeze-demo 显式解冻
  {
    const v16StateText = readStateYaml(projectRoot);
    const v16PackagedAtMatch = v16StateText.match(/^delivery_packaged_at:\s*['"]?([^'"\s]+)['"]?\s*$/m);
    if (!v16PackagedAtMatch) {
      log('[WARN] V-16: state.yaml 无 delivery_packaged_at（旧版本打包产物），跳过 demo 冻结校验');
      warn++;
    } else {
      const v16PackagedMs = Date.parse(v16PackagedAtMatch[1]);
      const v16ToleranceMs = 5000; // 5s 容差：文件系统时间戳精度与时钟偏移防御
      const v16DemoDir = path.join(projectRoot, 'demo');
      const v16Offenders = [];
      const v16Walk = (dir) => {
        if (!fs.existsSync(dir)) return;
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const p = path.join(dir, entry.name);
          if (entry.isDirectory()) v16Walk(p);
          else if (entry.isFile()) {
            try {
              if (fs.statSync(p).mtimeMs > v16PackagedMs + v16ToleranceMs) v16Offenders.push(p);
            } catch (e) { /* stat 失败忽略，不计违规 */ }
          }
        }
      };
      v16Walk(v16DemoDir);
      if (v16Offenders.length === 0) {
        log('[OK]   V-16: demo 冻结校验通过（无文件晚于 delivery_packaged_at）');
        pass++;
      } else {
        log(`[FAIL] V-16: 检测到 ${v16Offenders.length} 个 demo 文件在打包（delivery_packaged_at）之后被改写：`);
        for (const p of v16Offenders.slice(0, 5)) {
          log(`       - ${path.relative(projectRoot, p)}`);
        }
        log('       后果：demo 与 delivery 哈希已分叉（V-3/V-13 失效），交付物为旧版 demo');
        log('       修复：node scripts/package-delivery.mjs --unfreeze-demo 解冻 → 修复 demo → 重跑 run-audit.mjs → package-delivery.mjs → verify-delivery.mjs');
        fail++;
      }
    }
  }

  // 汇总
  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
  log('======================================================================');

  // 写 delivery_consistency_verified + current_phase + final_approved 到 state.yaml
  // v5.14.15 根治修复：状态机推进缺陷
  //   根因：current_phase: 3 和 final_approved: true 无任何脚本写入
  //         - current_phase 由 lock-model 推进到 2，之后无脚本推进到 3
  //         - final_approved 设计依赖 render-card 人工写入，但 A/B 跑自动化测试无 PM 介入
  //         - 导致 state.yaml 出现"delivery_packaged=true 但 current_phase=2/final_approved=false"不一致
  //   修复：verify-delivery 是 Phase 3 最后一步，V-1~V-11 全通过即代表交付完整性 + 一致性 + demo 哈希一致
  //         = 实质上的"PM（agent）验收通过"，此时推进 current_phase: 3 + final_approved: true
  //   影响：消除 A/B 跑自动化测试场景下 state.yaml 状态机不一致问题
  if (fail === 0) {
    const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(stateFile)) {
      // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
      let text = readStateYaml(projectRoot);
      // 写入 delivery_consistency_verified: true
      const consistencyRegex = /^(\s*delivery_consistency_verified:\s*).*$/m;
      if (consistencyRegex.test(text)) {
        text = text.replace(consistencyRegex, '$1true');
      } else {
        text = text.trimEnd() + '\ndelivery_consistency_verified: true\n';
      }
      // 推进 current_phase: 3（Phase 3 最后一步完成）
      const phaseRegex = /^(\s*current_phase:\s*).*$/m;
      if (phaseRegex.test(text)) {
        text = text.replace(phaseRegex, '$13');
      } else {
        text = text.trimEnd() + '\ncurrent_phase: 3\n';
      }
      // 写入 final_approved: true（V-1~V-11 全通过代表 agent 验收通过）
      const approvedRegex = /^(\s*final_approved:\s*).*$/m;
      if (approvedRegex.test(text)) {
        text = text.replace(approvedRegex, '$1true');
      } else {
        text = text.trimEnd() + '\nfinal_approved: true\n';
      }
      fs.writeFileSync(stateFile, text, 'utf-8');
      // v5.16 Task 8.2：写入 state.yaml 后主动失效缓存（同进程内后续读取需拿到新值）
      invalidate(projectRoot);
      log('[OK] state.yaml: delivery_consistency_verified = true, current_phase = 3, final_approved = true');
    }
    // v5.16 S-3 修复：verify-delivery 成功后刷新 quality-report.yaml 的 Q-4 状态
    //   根因：quality-check 在 verify-delivery 之前运行，那时 final_approved=false → Q-4 必 warn
    //         verify-delivery 通过后写 final_approved=true 但不刷新 quality-report → 12/12 陈旧
    const qualityReportPath = path.join(projectRoot, '.demora', 'quality-report.yaml');
    if (fs.existsSync(qualityReportPath)) {
      let qrText = fs.readFileSync(qualityReportPath, 'utf-8');
      qrText = qrText.replace(
        /(- name: Q-4\s*\n\s*result: )warn(\s*\n\s*detail: ).*/,
        `$1pass$2final_approved = true（verify-delivery 通过后刷新）`
      );
      qrText = qrText.replace(
        /generated_at:\s*["'][^"']+["']/,
        `generated_at: "${new Date().toISOString()}"`
      );
      fs.writeFileSync(qualityReportPath, qrText, 'utf-8');
      log('[OK] quality-report.yaml: Q-4 已刷新（verify-delivery 通过，final_approved=true）');
    }
    log('>>> Delivery 一致性校验通过');
    process.exit(0);
  } else {
    // 标记为 false
    const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(stateFile)) {
      // v5.16 Task 8.3：state.yaml 读取改用 lib/state-cache.mjs（按 mtime 失效缓存）
      let text = readStateYaml(projectRoot);
      const regex = /^(\s*delivery_consistency_verified:\s*).*$/m;
      if (regex.test(text)) {
        text = text.replace(regex, '$1false');
      } else {
        text = text.trimEnd() + '\ndelivery_consistency_verified: false\n';
      }
      fs.writeFileSync(stateFile, text, 'utf-8');
      // v5.16 Task 8.2：写入 state.yaml 后主动失效缓存（同进程内后续读取需拿到新值）
      invalidate(projectRoot);
    }
    log('>>> Delivery 一致性校验失败，请修正后重新运行');
    process.exit(1);
  }
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('verify-delivery.mjs') || process.argv[1].endsWith('verify-delivery'));
if (isDirectRun) {
  const args = {};
  for (let i = 2; i < process.argv.length; i++) {
    if (process.argv[i] === '--project' && process.argv[i + 1]) {
      args.project = process.argv[++i];
    }
  }
  main(args).catch(e => { console.error(e); process.exit(1); });
}
