// app.js for p008-fail-demo
// 故意不绑定 btnOpen 的任何事件（无 onclick / data-action / addEventListener / $() / .onclick=）
// 触发 P008 FAIL：弹窗触发按钮无任何事件绑定线索
//
// 注：下面的代码故意只处理其他无关按钮，确保 P008 检测到 btnOpen 无绑定

document.addEventListener('DOMContentLoaded', () => {
  // 绑定无关按钮（不应被 P008 识别为 btnOpen 的线索）
  const otherBtn = document.querySelector('.close-btn');
  if (otherBtn) {
    otherBtn.addEventListener('click', () => {
      const modal = document.getElementById('m1');
      if (modal) modal.hidden = true;
    });
  }
});
