// verify-delivery.mjs
// Delivery 产物一致性校验（v5.7 — mermaid 资产 + 三大 Flow + 受众 Tab）
//
// 设计目标：
//   修复 v5.5 "5 个 audit 场景 A 级通过，但 delivery/<项目名>/demo/ 是空骨架" 的审计盲区。
//   verify-delivery 是 delivery 内容一致性的最后一道防线，确保：
//   1. delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html 哈希一致
//   2. delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
//   3. delivery/<项目名>/demo/screenshots/ 截图完整
//   4. delivery/<项目名>/docs/ 24 md + 5 HTML 齐全
//   5. delivery/<项目名>/downloads/ 2 个 zip 大小达标（v5.9：移除 docs-only.zip）
//
// 校验项：
//   V-1: delivery/<项目名>/index.html 存在且非空（>= 5000 bytes，v5.6 阈值提升）
//   V-2: delivery/<项目名>/demo/index.html 存在且非空骨架（>= 5000 bytes + 不含 "Demo - 待 AI 设计"）
//   V-3: delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html SHA-256 一致
//   V-4: delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
//   V-5: delivery/<项目名>/demo/screenshots/ 截图数量 >= 5 张
//   V-6: delivery/<项目名>/docs/ >=20 md + 5 HTML 齐全 + 4 子页面含重定向脚本（v5.6 增强）
//   V-7: delivery/<项目名>/downloads/ 2 个 zip 大小 >= 10 KB（v5.9：移除 docs-only.zip，仅校验 demo-only + full-delivery）
//   V-8: delivery/<项目名>/project-info.json 字段完整
//   V-9: v5.6 新增 — delivery index.html 占位符已替换 + docs/index.html 含章节锚点 + size >= 15000
//        v5.7 调整：V-9b 锚点新增 tldr/non-goals/business-flow；V-9c 阈值 15000→25000
//        v5.10 新增：V-9d §2 PM 原始需求非空（不含"暂未提供"）；V-9e §4 业务流程含三大 Flow 标题
//   V-10: v5.7 新增 — docs/assets/mermaid/ 存在 + 含 mermaid.min.js + mermaid-init.js
//
// 调用方式：
//   node scripts/verify-delivery.mjs             # cwd=sim-project，自动找 delivery/<项目名>/
//   node scripts/verify-delivery.mjs --project <name>  # 指定项目名（delivery/<name>/）
//
// 退出码：0 全部通过，1 有 FAIL
//
// 由谁调用：
//   1. runAutoPhasesPhase3（在 quality-check + package-delivery 之后）— v5.6 新增
//   2. aggregateResults（在 aggregate 验收末尾）— v5.6 新增
//   3. subagent 在 AI 阶段 5 完成后调用 --run-phase3 时自动执行

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

/**
 * 计算 SHA-256 哈希
 */
function sha256(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const content = fs.readFileSync(filePath);
  return crypto.createHash('sha256').update(content).digest('hex');
}

/**
 * 空骨架特征检测
 */
const SHELL_SIGNATURES = [
  'Demo - 待 AI 设计',
  'AI 基于 frontend-design skill 方法论从零设计',
  'AI: 基于 frontend-design skill 方法论从零设计',
];

function isShellHtml(htmlContent) {
  return SHELL_SIGNATURES.some(sig => htmlContent.includes(sig));
}

/**
 * 期望的 5 个 HTML 产品文档
 */
const EXPECTED_HTML_DOCS = [
  'index.html', 'product-overview.html', 'page-spec.html',
  'data-model.html', 'role-permission.html',
];

/**
 * 统计 docs/ 下所有 md 文件（v5.6 修复：扩展范围，兼容小项目）
 *
 * v5.5 缺陷：仅统计 docs/prd/ 下的 md 文件，对于 2 页面项目只有 13+2=15 md < 20 阈值
 * v5.6 修复：统计 docs/ 下所有子目录（prd/、spec/、test/、handoff/）的 md 文件
 *           最小项目也含：13 PRD + 1 page-details + 7 Spec + 3 Test + 1 Handoff = 25 md
 *
 * @param {string} docsDir docs/ 目录
 * @returns {{ prd: number, total: number, html: number }}
 *   - prd: docs/prd/ 下的 md 数（向后兼容）
 *   - total: docs/ 下所有 md 数（v5.6 新增）
 *   - html: docs/ 下的 HTML 数
 */
function countDocsMd(docsDir) {
  if (!fs.existsSync(docsDir)) return { prd: 0, total: 0, html: 0 };

  // 统计 docs/prd/ 下的 md（向后兼容）
  const prdDir = path.join(docsDir, 'prd');
  let prdMd = 0;
  if (fs.existsSync(prdDir)) {
    function walkPrd(d) {
      for (const e of fs.readdirSync(d, { withFileTypes: true })) {
        const full = path.join(d, e.name);
        if (e.isDirectory()) walkPrd(full);
        else if (e.name.endsWith('.md')) prdMd++;
      }
    }
    walkPrd(prdDir);
  }

  // v5.6：统计 docs/ 下所有 md 文件
  let totalMd = 0;
  function walkAll(d) {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const full = path.join(d, e.name);
      if (e.isDirectory()) walkAll(full);
      else if (e.name.endsWith('.md')) totalMd++;
    }
  }
  walkAll(docsDir);

  const htmlCount = EXPECTED_HTML_DOCS.filter(f => fs.existsSync(path.join(docsDir, f))).length;
  return { prd: prdMd, total: totalMd, html: htmlCount };
}

/**
 * 主入口
 */
export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const deliveryRoot = path.join(projectRoot, 'delivery');

  process.stdout.write('======================================================================\n');
  process.stdout.write('Delivery 产物一致性校验（v5.6）\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`  sim-project: ${projectRoot}\n`);

  if (!fs.existsSync(deliveryRoot)) {
    log('[FAIL] delivery/ 目录不存在（package-delivery.mjs 未运行）');
    process.exit(1);
  }

  // 找 delivery/<项目名>/ 子目录
  let projectName = args.project;
  if (!projectName) {
    const subDirs = fs.readdirSync(deliveryRoot, { withFileTypes: true })
      .filter(e => e.isDirectory() && !e.name.startsWith('.'))
      .map(e => e.name);
    if (subDirs.length === 0) {
      log('[FAIL] delivery/<项目名>/ 子目录不存在');
      process.exit(1);
    }
    if (subDirs.length === 1) {
      projectName = subDirs[0];
    } else {
      // 多个项目目录时，优先选含 index.html 的
      projectName = subDirs.find(n => fs.existsSync(path.join(deliveryRoot, n, 'index.html'))) || subDirs[0];
    }
  }
  const projectDir = path.join(deliveryRoot, projectName);
  if (!fs.existsSync(projectDir)) {
    log(`[FAIL] delivery/${projectName}/ 不存在`);
    process.exit(1);
  }
  log(`  项目名:     ${projectName}`);
  log(`  交付目录:   ${projectDir}\n`);

  let pass = 0, fail = 0, warn = 0;

  // V-1: delivery/<项目名>/index.html 存在且非空（>= 5000 bytes）
  // v5.6 阈值提升：因 PROJECT BACKGROUND 板块增强（业务背景/痛点/解决方案/PM 需求折叠面板）
  //   原 1000 bytes 阈值无法检测空 PROJECT BACKGROUND，提升到 5000 bytes 确保叙事板块完整
  const siteIndexPath = path.join(projectDir, 'index.html');
  if (!fs.existsSync(siteIndexPath)) {
    log('[FAIL] V-1: delivery/<项目名>/index.html 缺失');
    fail++;
  } else {
    const size = fs.statSync(siteIndexPath).size;
    if (size < 5000) {
      log(`[FAIL] V-1: delivery/<项目名>/index.html 大小 ${size} bytes < 5000（疑似 PROJECT BACKGROUND 板块未渲染）`);
      fail++;
    } else {
      log(`[OK]   V-1: index.html 存在 (${(size / 1024).toFixed(2)} KB)`);
      pass++;
    }
  }

  // V-2: delivery/<项目名>/demo/index.html 存在且非空骨架（>= 5000 bytes + 不含空骨架特征）
  const deliveryDemoHtmlPath = path.join(projectDir, 'demo', 'index.html');
  if (!fs.existsSync(deliveryDemoHtmlPath)) {
    log('[FAIL] V-2: delivery/<项目名>/demo/index.html 缺失');
    fail++;
  } else {
    const size = fs.statSync(deliveryDemoHtmlPath).size;
    const content = fs.readFileSync(deliveryDemoHtmlPath, 'utf-8');
    const isShell = isShellHtml(content);
    if (size < 5000) {
      log(`[FAIL] V-2: delivery demo/index.html 大小 ${size} bytes < 5000（疑似空骨架）`);
      fail++;
    } else if (isShell) {
      log(`[FAIL] V-2: delivery demo/index.html 含空骨架特征字符串（"Demo - 待 AI 设计" 等）`);
      fail++;
    } else {
      log(`[OK]   V-2: delivery demo/index.html 是真实 HTML (${(size / 1024).toFixed(2)} KB)`);
      pass++;
    }
  }

  // V-3: delivery/<项目名>/demo/index.html 与 sim-project/demo/index.html SHA-256 一致
  const simDemoHtmlPath = path.join(projectRoot, 'demo', 'index.html');
  if (!fs.existsSync(simDemoHtmlPath)) {
    log('[WARN] V-3: sim-project/demo/index.html 不存在，跳过哈希一致性校验');
    warn++;
  } else if (!fs.existsSync(deliveryDemoHtmlPath)) {
    log('[FAIL] V-3: delivery demo/index.html 缺失，无法校验哈希一致性');
    fail++;
  } else {
    const simHash = sha256(simDemoHtmlPath);
    const deliveryHash = sha256(deliveryDemoHtmlPath);
    if (simHash === deliveryHash) {
      log(`[OK]   V-3: delivery demo/index.html 与 sim-project 一致（SHA-256: ${simHash.slice(0, 12)}...）`);
      pass++;
    } else {
      log(`[FAIL] V-3: 哈希不一致 — sim=${simHash.slice(0, 12)}... delivery=${deliveryHash.slice(0, 12)}...`);
      log(`       说明：package-delivery.mjs 可能使用了过期的 demo 源`);
      fail++;
    }
  }

  // V-4: delivery/<项目名>/demo/audit-result.json 存在且 overall A/B
  const deliveryAuditPath = path.join(projectDir, 'demo', 'audit-result.json');
  if (!fs.existsSync(deliveryAuditPath)) {
    log('[FAIL] V-4: delivery demo/audit-result.json 缺失');
    fail++;
  } else {
    try {
      const auditData = JSON.parse(fs.readFileSync(deliveryAuditPath, 'utf-8'));
      const overall = auditData.overall;
      if (overall === 'A' || overall === 'B') {
        log(`[OK]   V-4: delivery audit-result.json overall = ${overall}`);
        pass++;
      } else {
        log(`[FAIL] V-4: delivery audit-result.json overall = ${overall}（< B）`);
        fail++;
      }
    } catch (e) {
      log(`[FAIL] V-4: delivery audit-result.json 解析失败: ${e.message}`);
      fail++;
    }
  }

  // V-5: delivery/<项目名>/demo/screenshots/ 截图数量 >= 5 张
  const screenshotsDir = path.join(projectDir, 'demo', 'screenshots');
  if (!fs.existsSync(screenshotsDir)) {
    log('[FAIL] V-5: delivery demo/screenshots/ 目录缺失');
    fail++;
  } else {
    const screenshots = fs.readdirSync(screenshotsDir).filter(f => /\.(png|jpg|jpeg)$/i.test(f));
    if (screenshots.length >= 5) {
      log(`[OK]   V-5: 截图数量 ${screenshots.length} 张（>= 5）`);
      pass++;
    } else {
      log(`[FAIL] V-5: 截图数量 ${screenshots.length} < 5`);
      fail++;
    }
  }

  // V-6: delivery/<项目名>/docs/ 全部 md + 5 HTML 齐全 + 4 子页面含重定向脚本
  // v5.6 修复：从仅统计 docs/prd/ 改为统计 docs/ 下所有 md（含 prd/spec/test/handoff）
  //   原因：v5.5 仅统计 prd/ 时，2 页面项目只有 13+2=15 md < 20 阈值，导致 V-6 误报
  //   修复后：最小项目含 13 PRD + 1 page-details + 7 Spec + 3 Test + 1 Handoff = 25 md
  //   阈值：>= 20 md（向后兼容）+ 5 HTML
  // v5.6 增强：4 个子页面（product-overview/page-spec/data-model/role-permission.html）
  //   必须含重定向脚本 `window.location.href = 'index.html#` —— 单页 PRD 重构后的产物契约
  const deliveryDocsDir = path.join(projectDir, 'docs');
  const { prd: prdMdCount, total: totalMdCount, html: htmlCount } = countDocsMd(deliveryDocsDir);

  // V-6a: md + HTML 数量校验
  let v6aOk = false;
  if (totalMdCount >= 20 && htmlCount === 5) {
    v6aOk = true;
  }

  // V-6b: 4 个子页面重定向脚本校验
  //   v5.9：product-overview.html 重定向目标从 #metadata 改为 #tldr（metadata 章节已删除）
  const redirectStubs = [
    { file: 'product-overview.html', anchor: '#tldr' },
    { file: 'page-spec.html',        anchor: '#pages' },
    { file: 'data-model.html',       anchor: '#data' },
    { file: 'role-permission.html',  anchor: '#roles' },
  ];
  let v6bMissing = [];
  let v6bNoRedirect = [];
  for (const stub of redirectStubs) {
    const stubPath = path.join(deliveryDocsDir, stub.file);
    if (!fs.existsSync(stubPath)) {
      v6bMissing.push(stub.file);
    } else {
      const content = fs.readFileSync(stubPath, 'utf-8');
      // 校验含 `window.location.href = 'index.html#<anchor>'` 或 meta refresh
      const hasRedirectScript = content.includes(`window.location.href = 'index.html${stub.anchor}'`) ||
                                 content.includes(`window.location.href="index.html${stub.anchor}"`);
      const hasMetaRefresh = content.includes(`url=index.html${stub.anchor}`);
      if (!hasRedirectScript && !hasMetaRefresh) {
        v6bNoRedirect.push(stub.file);
      }
    }
  }

  if (v6aOk && v6bMissing.length === 0 && v6bNoRedirect.length === 0) {
    log(`[OK]   V-6: docs/ ${totalMdCount} md（prd=${prdMdCount}）+ ${htmlCount} HTML + 4 子页面重定向脚本齐全`);
    pass++;
  } else {
    if (!v6aOk) {
      log(`[FAIL] V-6a: docs/ ${totalMdCount} md（prd=${prdMdCount}）+ ${htmlCount} HTML（期望 >=20 md + 5 HTML）`);
    }
    if (v6bMissing.length > 0) {
      log(`[FAIL] V-6b: 重定向存根缺失: ${v6bMissing.join(', ')}`);
    }
    if (v6bNoRedirect.length > 0) {
      log(`[FAIL] V-6b: 重定向脚本缺失: ${v6bNoRedirect.join(', ')}（应含 window.location.href = 'index.html#<anchor>'）`);
    }
    fail++;
  }

  // V-7: delivery/<项目名>/downloads/ 2 个 zip 大小 >= 10 KB（v5.9：移除 docs-only.zip）
  const downloadsDir = path.join(projectDir, 'downloads');
  const expectedZips = ['demo-only.zip', 'full-delivery.zip'];
  let zipOk = true;
  for (const zipName of expectedZips) {
    const zipPath = path.join(downloadsDir, zipName);
    if (!fs.existsSync(zipPath)) {
      log(`[FAIL] V-7: downloads/${zipName} 缺失`);
      zipOk = false;
    } else {
      const size = fs.statSync(zipPath).size;
      if (size < 10 * 1024) {
        log(`[FAIL] V-7: downloads/${zipName} 大小 ${(size / 1024).toFixed(2)} KB < 10 KB`);
        zipOk = false;
      }
    }
  }
  if (zipOk) {
    log(`[OK]   V-7: 2 个 zip 全部存在且 >= 10 KB`);
    pass++;
  } else {
    fail++;
  }

  // V-8: delivery/<项目名>/project-info.json 字段完整
  const projectInfoPath = path.join(projectDir, 'project-info.json');
  if (!fs.existsSync(projectInfoPath)) {
    log('[FAIL] V-8: project-info.json 缺失');
    fail++;
  } else {
    try {
      const info = JSON.parse(fs.readFileSync(projectInfoPath, 'utf-8'));
      const required = ['projectName', 'pageCount', 'entityCount'];
      const missing = required.filter(k => info[k] === undefined || info[k] === null || info[k] === '');
      if (missing.length > 0) {
        log(`[FAIL] V-8: project-info.json 缺字段: ${missing.join(', ')}`);
        fail++;
      } else {
        log(`[OK]   V-8: project-info.json 字段完整 (projectName=${info.projectName}, pages=${info.pageCount}, entities=${info.entityCount})`);
        pass++;
      }
    } catch (e) {
      log(`[FAIL] V-8: project-info.json 解析失败: ${e.message}`);
      fail++;
    }
  }

  // V-9: v5.6 新增 — 单页 PRD 完整性校验
  //   V-9a: delivery/<项目名>/index.html 不含未替换的 {{ }} 占位符
  //   V-9b: delivery/<项目名>/docs/index.html 含 11 大章节锚点
  //         v5.7：从 8 锚点扩展到 11 锚点（新增 tldr/non-goals/business-flow）
  //         v5.9：移除 metadata/solution，新增 scope/pm-requirement（仍为 11 锚点）
  //   V-9c: delivery/<项目名>/docs/index.html size >= 28000 bytes
  //         v5.7：阈值从 15000 提升到 25000（因新增 TL;DR + 三大 Flow + 受众 Tab + Mermaid 引用）
  //         v5.8：25000 → 21000（移除 §12 详细文档下载 + 9 处信源标注）
  //         v5.9：21000 → 28000（新增 Ourchem × Demora 联合版权 footer ~12 KB inline SVG）
  let v9aOk = false, v9bOk = false, v9cOk = false, v9dOk = false, v9eOk = false, v9fOk = false;

  // V-9a: 占位符替换校验
  if (!fs.existsSync(siteIndexPath)) {
    log('[FAIL] V-9a: delivery index.html 缺失，无法校验占位符');
  } else {
    const siteContent = fs.readFileSync(siteIndexPath, 'utf-8');
    // 查找未替换的 {{xxx}} 占位符（排除注释和样式中的 CSS {{ }})
    // 匹配形如 {{fieldName}} 或 {{#if xxx}}...{{/if}} 的未处理模板标记
    const placeholderMatches = siteContent.match(/\{\{[a-zA-Z_#\/][a-zA-Z0-9_\/\s]*\}\}/g);
    if (placeholderMatches && placeholderMatches.length > 0) {
      log(`[FAIL] V-9a: delivery index.html 含未替换占位符: ${placeholderMatches.slice(0, 5).join(', ')}${placeholderMatches.length > 5 ? '...' : ''}`);
    } else {
      v9aOk = true;
    }
  }

  // V-9b + V-9c: docs/index.html 章节 + 大小校验
  const docsIndexPath = path.join(deliveryDocsDir, 'index.html');
  if (!fs.existsSync(docsIndexPath)) {
    log('[FAIL] V-9b: delivery docs/index.html 缺失，无法校验章节锚点');
    log('[FAIL] V-9c: delivery docs/index.html 缺失，无法校验大小');
  } else {
    const docsIndexSize = fs.statSync(docsIndexPath).size;
    const docsIndexContent = fs.readFileSync(docsIndexPath, 'utf-8');

    // V-9b: 11 大章节锚点校验
    //   v5.7：8 → 11（新增 tldr/non-goals/business-flow）
    //   v5.8：锚点列表不变 — 主导航从 14 精简到 8，但 section id 仍保留在 body
    //   v5.9：移除 metadata/solution（章节已删除），新增 scope/pm-requirement（仍在 body）
    //         最终锚点列表 11 个：tldr/non-goals/problem/users/business-flow/pages/data/roles/metrics/scope/pm-requirement
    const expectedAnchors = [
      'tldr', 'non-goals', 'problem', 'users',
      'business-flow', 'pages', 'data', 'roles',
      'metrics', 'scope', 'pm-requirement'
    ];
    const missingAnchors = expectedAnchors.filter(a => {
      // 匹配 id="metadata" 或 id='metadata'（含引号变体）
      const regex = new RegExp(`id=["']${a}["']`);
      return !regex.test(docsIndexContent);
    });
    if (missingAnchors.length > 0) {
      log(`[FAIL] V-9b: docs/index.html 缺章节锚点: ${missingAnchors.map(a => `id="${a}"`).join(', ')}`);
    } else {
      v9bOk = true;
    }

    // V-9c: 大小校验
    //   v5.7：阈值 15000 → 25000（新增 TL;DR + 三大 Flow + 受众 Tab + Mermaid 引用）
    //   v5.8：25000 → 21000（移除 §12 详细文档下载 + 9 处信源标注，净减 ~4 KB）
    //   v5.9：21000 → 28000（新增 Ourchem × Demora 联合版权 footer ~12 KB inline SVG）
    if (docsIndexSize < 28000) {
      log(`[FAIL] V-9c: docs/index.html 大小 ${docsIndexSize} bytes < 28000（v5.9 阈值，疑似 Ourchem × Demora 联合版权 footer 缺失）`);
    } else {
      v9cOk = true;
    }

    // V-9d: v5.10 新增 — §2 PM 原始需求 内容非空校验
    //   v5.11 增强：校验同时含 requirement-scenario-brief.md 与 requirement-input.md 两个折叠面板，
    //   且 brief 在 input 之前（按时间顺序展示需求导入与迭代过程）
    //   根因：generate-product-docs.mjs 在 main process Phase 2 执行（AI 阶段 1 之前），
    //         此时 inbox/text/requirement-input.md 尚未生成，导致 §2 渲染为"暂未提供"
    //   修复：AI 阶段 1 写入 requirement-input.md 后必须重跑 generate-product-docs.mjs
    const pmReqSectionRegex = /<section id="pm-requirement"[\s\S]*?<\/section>/;
    const pmReqMatch = docsIndexContent.match(pmReqSectionRegex);
    if (!pmReqMatch) {
      log('[FAIL] V-9d: docs/index.html 缺少 §2 PM 原始需求 section');
    } else if (pmReqMatch[0].includes('暂未提供')) {
      log('[FAIL] V-9d: docs/index.html §2 PM 原始需求 显示"暂未提供"（需在 AI 阶段 1 写入 requirement-input.md 后重跑 generate-product-docs.mjs）');
    } else {
      // v5.11：检查两份文档 + 顺序
      const pmReqHtml = pmReqMatch[0];
      const hasBrief = pmReqHtml.includes('requirement-scenario-brief.md');
      const hasInput = pmReqHtml.includes('requirement-input.md');
      const briefIdx = pmReqHtml.indexOf('requirement-scenario-brief.md');
      const inputIdx = pmReqHtml.indexOf('requirement-input.md');
      const orderOk = hasBrief && hasInput && briefIdx < inputIdx;
      if (!hasBrief || !hasInput) {
        log(`[FAIL] V-9d: docs/index.html §2 PM 原始需求 缺少 ${!hasBrief ? 'requirement-scenario-brief.md' : ''} ${!hasInput ? 'requirement-input.md' : ''}（v5.11 要求两份文档均展示）`);
      } else if (!orderOk) {
        log('[FAIL] V-9d: docs/index.html §2 PM 原始需求 顺序错误（v5.11 要求 brief 在 input 之前）');
      } else {
        v9dOk = true;
      }
    }

    // V-9e: v5.10 新增 — §4 业务流程 含三大 Flow 标题校验
    //   校验 docs/index.html 的 business-flow section 含 Task Flow / Data Flow / Page Flow
    //   根因：extractMarkdownSection 使用精确匹配正则 `^##\s+sectionTitle\s*$`，
    //         但 v5.10 的 04-business-flow.md 标题含 ", BPMN 2.0" 等业界标准后缀导致匹配失败
    //   修复：extractMarkdownSection 改为前缀匹配 `^##\s+sectionTitle.*$`
    const bfSectionRegex = /<section id="business-flow"[\s\S]*?<\/section>/;
    const bfMatch = docsIndexContent.match(bfSectionRegex);
    const bfContent = bfMatch ? bfMatch[0] : '';
    const expectedFlows = ['Task Flow（任务流）', 'Data Flow（数据流）', 'Page Flow（页面流）'];
    const missingFlows = expectedFlows.filter(f => !bfContent.includes(f));
    if (missingFlows.length > 0) {
      log(`[FAIL] V-9e: docs/index.html §4 业务流程 缺失 Flow: ${missingFlows.join(', ')}（extractMarkdownSection 前缀匹配失败）`);
    } else {
      v9eOk = true;
    }

    // V-9f: v5.11 新增 — §4 mermaid 语法风险校验
    //   根因：generate-prd.mjs 生成的 mermaid 节点标签含未转义特殊字符（() / :）
    //         导致 Mermaid 11.16.0 严格模式解析失败：Syntax error in text
    //   修复：所有节点标签加双引号；<-.-> 改为 -.->
    //   校验点：
    //     1. mermaid 块中不存在 <-.-> 非法箭头
    //     2. mermaid 块中的 (label) / [label] / [[label]] / {label} 节点标签如含特殊字符应加双引号
    //        简化校验：检测 P1(label 含 () 这类内嵌括号场景，且 label 未用双引号包裹
    const mermaidBlockRegex = /<div class="mermaid">([\s\S]*?)<\/div>/g;
    let mermaidBlocks = [];
    let mMatch;
    while ((mMatch = mermaidBlockRegex.exec(docsIndexContent)) !== null) {
      mermaidBlocks.push(mMatch[1]);
    }
    let v9fIssues = [];
    if (mermaidBlocks.length === 0) {
      // 非强制：可能 docs/index.html 用 <pre><code class="language-mermaid"> 包裹
      const altRegex = /class="language-mermaid">([\s\S]*?)<\/code>/g;
      while ((mMatch = altRegex.exec(docsIndexContent)) !== null) {
        mermaidBlocks.push(mMatch[1]);
      }
    }
    mermaidBlocks.forEach((block, idx) => {
      // 校验 1：非法箭头 <-.->
      if (/<-\.-\->/.test(block)) {
        v9fIssues.push(`mermaid 块 #${idx + 1} 含非法箭头 \`<-.->\`（应为 \`-.->\`）`);
      }
      // 校验 2：未加双引号的节点标签含内嵌括号
      //   匹配模式：P1(label containing ())，即圆角矩形节点 (label) 中 label 含 () 但未用双引号包裹
      //   双引号包裹形式为 ("label")，故未加双引号的 label 形如 (xxx(yyy)zzz)
      //   正则匹配：左括号后紧跟非双引号的字符序列，且该序列含 ( 或 )
      //   实现：提取所有 (...) 形式，检查内部是否含 () 且未以 " 开头
      const procNodeRegex = /\b([A-Za-z][A-Za-z0-9_]*)\(([^"]*?)\)/g;
      let nodeMatch;
      while ((nodeMatch = procNodeRegex.exec(block)) !== null) {
        const label = nodeMatch[2];
        // 跳过 (( )) 圆形节点（circle，单独处理）
        // 例：Start((用户登录)) 会被非贪婪正则匹配为 Start((用户登录) 导致 label="(用户登录" 误报
        if (nodeMatch[0].includes('((')) continue;
        // 标签内含 ( 或 ) 即为问题（未加双引号）
        if (/[()]/.test(label)) {
          v9fIssues.push(`mermaid 块 #${idx + 1} 节点 \`${nodeMatch[0]}\` 标签含未转义括号，应加双引号：\`("${label}")\``);
        }
      }
      // 校验 3：未加双引号的 [label] 含特殊字符
      const rectNodeRegex = /\b([A-Za-z][A-Za-z0-9_]*)\[([^\]]*?)\]/g;
      while ((nodeMatch = rectNodeRegex.exec(block)) !== null) {
        const label = nodeMatch[2];
        // 跳过 [[ ]] 双线节点（DataStore，单独处理）
        if (nodeMatch[0].includes('[[')) continue;
        // v5.11.1：仅 () 会触发 Mermaid 11.16.0 严格模式解析失败
        //   （/ 和 : 在 [] 标签中合法，无需加双引号）
        if (/[()]/.test(label) && !label.startsWith('"')) {
          v9fIssues.push(`mermaid 块 #${idx + 1} 节点 \`${nodeMatch[0]}\` 标签含未转义括号，应加双引号：\`["${label}"]\``);
        }
      }
    });
    if (v9fIssues.length > 0) {
      log(`[FAIL] V-9f: docs/index.html §4 mermaid 存在语法风险（${v9fIssues.length} 处）：`);
      v9fIssues.slice(0, 5).forEach(issue => log(`       - ${issue}`));
      if (v9fIssues.length > 5) log(`       ... 共 ${v9fIssues.length} 处`);
    } else {
      v9fOk = true;
    }
  }

  if (v9aOk && v9bOk && v9cOk && v9dOk && v9eOk && v9fOk) {
    log(`[OK]   V-9: 单页 PRD 完整性通过（占位符已替换 + 11 章节锚点齐全 + size >= 28000 + §2 PM 需求双文档顺序正确 + §4 三大 Flow 齐全 + §4 mermaid 语法无风险）`);
    pass++;
  } else {
    fail++;
  }

  // V-10: v5.7 新增 — docs/assets/mermaid/ 资产校验
  //   校验 delivery/<项目名>/docs/assets/mermaid/ 目录存在且含两个核心文件：
  //     - mermaid.min.js（核心库，~3.4 MB）
  //     - mermaid-init.js（初始化脚本，~1 KB）
  //   缺失时 docs/index.html 中的 Mermaid 流程图将无法渲染（mermaid-init.js 内部会降级为 fallback 显示源码）
  const mermaidDir = path.join(deliveryDocsDir, 'assets', 'mermaid');
  let v10Missing = [];
  let v10SizeOk = false;

  if (!fs.existsSync(mermaidDir)) {
    v10Missing.push('assets/mermaid/ 目录');
  } else {
    // 校验 mermaid.min.js（核心库，应 > 100 KB）
    const minJsPath = path.join(mermaidDir, 'mermaid.min.js');
    if (!fs.existsSync(minJsPath)) {
      v10Missing.push('mermaid.min.js');
    } else {
      const minJsSize = fs.statSync(minJsPath).size;
      if (minJsSize < 100 * 1024) {
        log(`[WARN] V-10: mermaid.min.js 大小 ${(minJsSize / 1024).toFixed(2)} KB < 100 KB（疑似截断或损坏）`);
        warn++;
      }
    }
    // 校验 mermaid-init.js（初始化脚本，应 > 200 bytes）
    const initJsPath = path.join(mermaidDir, 'mermaid-init.js');
    if (!fs.existsSync(initJsPath)) {
      v10Missing.push('mermaid-init.js');
    } else {
      const initJsSize = fs.statSync(initJsPath).size;
      v10SizeOk = initJsSize > 200;
    }
  }

  if (v10Missing.length === 0 && v10SizeOk) {
    log(`[OK]   V-10: docs/assets/mermaid/ 资产完整（mermaid.min.js + mermaid-init.js）`);
    pass++;
  } else {
    if (v10Missing.length > 0) {
      log(`[FAIL] V-10: docs/assets/mermaid/ 缺失: ${v10Missing.join(', ')}`);
    }
    if (!v10SizeOk && v10Missing.length === 0) {
      log(`[FAIL] V-10: mermaid-init.js 大小异常（疑似损坏）`);
    }
    fail++;
  }

  // 汇总
  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
  log('======================================================================');

  // 写 delivery_consistency_verified 到 state.yaml
  if (fail === 0) {
    const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(stateFile)) {
      let text = fs.readFileSync(stateFile, 'utf-8');
      const regex = /^(\s*delivery_consistency_verified:\s*).*$/m;
      if (regex.test(text)) {
        text = text.replace(regex, '$1true');
      } else {
        text = text.trimEnd() + '\ndelivery_consistency_verified: true\n';
      }
      fs.writeFileSync(stateFile, text, 'utf-8');
      log('[OK] state.yaml: delivery_consistency_verified = true');
    }
    log('>>> Delivery 一致性校验通过');
    process.exit(0);
  } else {
    // 标记为 false
    const stateFile = path.join(projectRoot, '.demora', 'state.yaml');
    if (fs.existsSync(stateFile)) {
      let text = fs.readFileSync(stateFile, 'utf-8');
      const regex = /^(\s*delivery_consistency_verified:\s*).*$/m;
      if (regex.test(text)) {
        text = text.replace(regex, '$1false');
      } else {
        text = text.trimEnd() + '\ndelivery_consistency_verified: false\n';
      }
      fs.writeFileSync(stateFile, text, 'utf-8');
    }
    log('>>> Delivery 一致性校验失败，请修正后重新运行');
    process.exit(1);
  }
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('verify-delivery.mjs') || process.argv[1].endsWith('verify-delivery'));
if (isDirectRun) {
  const args = {};
  for (let i = 2; i < process.argv.length; i++) {
    if (process.argv[i] === '--project' && process.argv[i + 1]) {
      args.project = process.argv[++i];
    }
  }
  main(args);
}
