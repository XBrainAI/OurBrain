# 05 - API 接口契约 (技术规格)

> 本文档定义前后端接口契约，包括 RESTful API 的请求/响应格式、参数规范、错误码等。
>
> 模板版本：v5.7
> 章节契约：本模板章节结构与 `generate-prd.mjs::genApiContractDraft` 严格对齐

---

## 文档说明

本文档定义前后端接口契约，作为前后端联调、Mock 数据生成、接口测试的依据。

---

## API 总览

### 模块分组

```mermaid
flowchart LR
    API[API 根] --> Auth[认证模块]
    API --> User[用户模块]
    API --> Biz[业务模块]
    API --> Sys[系统模块]
```

### 通用规范

- **协议**：HTTPS
- **数据格式**：JSON
- **字符编码**：UTF-8
- **认证方式**：Bearer Token（Authorization 头）

---

## 接口详细定义

### 认证模块

| Method | URL | 描述 | 入参 | 出参 |
|--------|-----|------|------|------|
| POST | /api/auth/login | 登录 | username, password | token, userInfo |
| POST | /api/auth/logout | 登出 | - | - |
| GET | /api/auth/profile | 获取当前用户 | - | userInfo |

### 业务模块

| Method | URL | 描述 | 入参 | 出参 |
|--------|-----|------|------|------|
| [待填充] | [待填充] | [待填充] | [待填充] | [待填充] |

---

## 通用请求头与响应格式

### 请求头

```
Authorization: Bearer <token>
Content-Type: application/json
X-Request-Id: <uuid>
```

### 响应格式

```json
{
  "code": 0,
  "message": "success",
  "data": {},
  "requestId": "uuid"
}
```

---

## 分页参数规范

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| page | number | 1 | 页码 |
| pageSize | number | 20 | 每页数量 |
| sort | string | - | 排序字段 |
| order | string | desc | 排序方向 |

---

## 错误码定义

| 错误码 | 含义 | 处理建议 |
|--------|------|----------|
| 0 | 成功 | - |
| 400 | 参数错误 | 检查请求参数 |
| 401 | 未认证 | 跳转登录 |
| 403 | 无权限 | 提示无权限 |
| 404 | 资源不存在 | 检查 URL |
| 500 | 服务器错误 | 联系运维 |

---

## 接口鉴权方式

- Bearer Token：所有 `/api/*` 接口必须携带
- Refresh Token：access token 过期时使用 refresh token 换取

---

## Mock 数据方案

- 开发环境：本地 Mock 服务
- 测试环境：Mock 平台
- 演示环境：内置 Mock 数据（demo-only.zip）
