# 交付确认卡

用于 Phase 2 完成、PM 说"打包交付"时，展示交付物清单与部署信息，PM 确认后生成交付包。

## 触发场景

- 阶段：Phase 2（完善与文档生成）末尾
- 触发词："打包交付"
- 前置条件：Phase 2 已完成（demo/ 完善 + docs/ 24 个文档生成 + 质量校验通过）
- 安全检查：`safety.require_quality_gate_before_delivery`

## 卡片内容

```
━━━ 📦 交付确认 ━━━
项目名称：{{project_name}}
交付版本：{{delivery_version}}

交付物清单：
  1. 可交互 Demo
     位置：demo/
     入口：demo/index.html（双击或执行 demo/start.bat 启动本地预览）
     技术栈：由 AI 基于 frontend-design skill 自由选择（代码无关原则）
     标注系统：L1/L2/L3 三层标注（顶栏开关控制）

  2. 配套文档（共 24 个 + 1 个评审记录）
     PRD 产品需求文档（14 个）：docs/prd/00-overview.md ~ 13-open-questions.md
     Spec 技术规格文档（7 个）：docs/spec/00-project-overview.md ~ 06-error-and-empty-states.md
     Test 测试建议文档（3 个）：docs/test/00-acceptance-criteria.md ~ 02-permission-matrix.md
     评审记录模板（1 个）：docs/handoff/review-notes.md

  3. 追溯矩阵
     位置：.demora/traceability.yaml
     内容：需求模型 → Demo 页面 → 文档章节 的全链路追溯

  4. 交付网站（v5.3 三种角色一键分发）
     位置：delivery/<项目名>/index.html（交付总入口页面）
     在线浏览：demo/ + docs/（直接浏览器打开）
     下载包（delivery/<项目名>/downloads/）：
       - demo-only.zip          仅 Demo（客户确认需求用）
       - full-delivery.zip      完整交付网站（产品研发团队用）
       - docs-only.zip          仅文档（测试开发团队用）

部署信息：
  本地预览：执行 demo/start.bat
  分支：{{branch_name}}
  构建命令：无需构建，纯静态资源可直接部署

请回复"确认交付"打包，或提出修改意见。
```

## 占位符说明

| 占位符 | 含义 | 数据来源 |
|--------|------|----------|
| `{{project_name}}` | 项目名称 | `.demora/requirement-model.yaml` 的 `project.name` |
| `{{delivery_version}}` | 交付版本号 | `.demora/state.yaml` 中记录的版本（如 v1.0） |
| `{{branch_name}}` | 工作分支名 | 当前 Git 分支（无 Git 环境时为"无"） |

## 渲染后行为

1. `package-delivery.mjs` 读取本模板并渲染，输出到 AI 对话界面
2. PM 回复"确认交付"后，`package-delivery.mjs` 执行以下操作（v5.3）：
   - 创建 `delivery/<项目名>/` 交付网站目录
   - 渲染 `delivery/<项目名>/index.html`（基于 `assets/delivery-site-template.html`）
   - 复制 `demo/` + `docs/` 到交付网站（在线可浏览）
   - 生成 `downloads/demo-only.zip`（仅 demo，面向客户）
   - 生成 `downloads/full-delivery.zip`（完整交付网站，面向产品研发）
   - 生成 `downloads/docs-only.zip`（仅文档，面向测试开发）
   - 在 `.demora/state.yaml` 标记 `delivery_packaged: true`
3. PM 提出修改意见时，不打包，回到 Phase 2 继续完善

## 关联状态文件

- 读：`.demora/requirement-model.yaml`、`.demora/state.yaml`、`.demora/traceability.yaml`
- 写：`delivery/<项目名>/index.html`、`delivery/<项目名>/downloads/*.zip`、`.demora/state.yaml`
