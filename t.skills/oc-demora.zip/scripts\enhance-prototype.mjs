// enhance-prototype.mjs
// Phase 2 Demo 增强：注入标注三件套（v5.1 Shadow DOM 隔离版）+ 版权 Footer（v5.10）
//
// 设计理念：
//   标注系统作为"独立叠加层"，通过 data-* 属性约定与 AI 生成的 HTML 对接。
//   面板用 Shadow DOM 封装，避免 .anno-card / .l2-tag 等通用类名污染主页面。
//
// 注入方式（v5.1 Shadow DOM 隔离）：
//   1. annotation-styles.css 主页面部分 → demo/index.html <head> 末尾
//   2. Shadow DOM 宿主 <div id="demora-annotation-host"> → <body> 末尾
//   3. annotation-styles.css 面板部分 + annotation-panel.html → Shadow DOM 内
//   4. annotation-engine.js → <body> 末尾（通过 host.shadowRoot 访问面板）
//   5. v5.10 新增：Ourchem × Demora 联合版权 Footer → <body> 末尾（项目级统一标识）
//
// 幂等：使用标记注释包裹注入内容，重复运行不会重复注入。
// 退出码：0 成功，1 失败

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

function findReferencesDir() {
  const candidates = [
    path.join(__dirname, '..', 'references'),
    path.join(__dirname, '..', '..', '..', 'src', 'reference'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// v5.10 新增：查找 Ourchem 白色 logo SVG 文件
// 搜索路径（按优先级）：
//   1. dist/oc-demora/assets/logo/logo-ourchem/奥凯logo-长-白.svg（dist 运行时）
//   2. src/assets/IP/logo/logo-ourchem/奥凯logo-长-白.svg（dev 运行时）
function findOurchemWhiteLogo() {
  const candidates = [
    path.join(__dirname, '..', 'assets', 'logo', 'logo-ourchem', '奥凯logo-长-白.svg'),
    path.join(__dirname, '..', '..', '..', '..', 'src', 'assets', 'IP', 'logo', 'logo-ourchem', '奥凯logo-长-白.svg'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

/**
 * v5.10 新增：从 SVG 文件提取内部内容（<svg>...</svg> 之间的部分）
 * 用于将完整 SVG 文件内联到 HTML 中，并设置正确的 viewBox
 */
function extractSvgInner(svgContent) {
  const match = svgContent.match(/<svg[^>]*>([\s\S]*)<\/svg>/);
  if (!match) return null;
  return match[1].trim();
}

/**
 * v5.10 新增：构建 Ourchem × Demora 联合版权 Footer HTML
 * 含 Ourchem 白色 logo（inline SVG）+ Demora logo + 版权声明
 * 使用 demora-footer-* 前缀 CSS 类，避免与 AI 生成 CSS 冲突
 */
function buildCopyrightFooter(whiteLogoSvgPath) {
  let ourchemInlineSvg = '';
  if (whiteLogoSvgPath) {
    const svgContent = fs.readFileSync(whiteLogoSvgPath, 'utf-8');
    const inner = extractSvgInner(svgContent);
    if (inner) {
      ourchemInlineSvg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 133.24 25.6">\n${inner}\n      </svg>`;
    }
  }

  const generatedAt = new Date().toISOString().slice(0, 10);

  return `
<!-- [demora-copyright-footer] start -->
<style>
  /* v5.10: Ourchem × Demora 联合版权 Footer（项目级统一标识） */
  .demora-footer {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 12px;
    padding: 24px 20px;
    margin-top: 40px;
    background: #0a0e14;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
    color: rgba(255, 255, 255, 0.6);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  }
  .demora-footer-coop {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 16px;
  }
  .demora-footer-brand-logo {
    display: flex;
    align-items: center;
    height: 28px;
  }
  .demora-footer-brand-ourchem svg {
    height: 28px;
    width: auto;
    opacity: 0.95;
  }
  .demora-footer-brand-demora svg {
    height: 24px;
    width: auto;
  }
  .demora-footer-coop-x {
    font-size: 18px;
    font-weight: 300;
    color: rgba(255, 255, 255, 0.4);
  }
  .demora-footer-copyright {
    font-size: 12px;
    color: rgba(255, 255, 255, 0.5);
    line-height: 1.7;
    text-align: center;
    margin: 0;
  }
  .demora-footer-meta {
    display: inline-block;
    margin-top: 4px;
    font-family: "SF Mono", Monaco, Consolas, monospace;
    font-size: 11px;
    color: rgba(255, 255, 255, 0.35);
  }
  @media (max-width: 640px) {
    .demora-footer { padding: 20px 16px; }
    .demora-footer-coop { gap: 12px; }
    .demora-footer-brand-ourchem svg, .demora-footer-brand-demora svg { height: 22px; }
    .demora-footer-coop-x { font-size: 16px; }
  }
</style>
<footer class="demora-footer">
  <div class="demora-footer-coop">
    <div class="demora-footer-brand-logo demora-footer-brand-ourchem" aria-label="Ourchem">
      ${ourchemInlineSvg}
    </div>
    <span class="demora-footer-coop-x" aria-hidden="true">×</span>
    <div class="demora-footer-brand-logo demora-footer-brand-demora" aria-label="Demora">
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 170 32" fill="none">
        <g transform="translate(0, 2)">
          <rect x="4" y="0" width="12" height="6" rx="3" fill="#14B8A6" opacity="0.4"/>
          <rect x="6" y="11" width="20" height="6" rx="3" fill="#14B8A6" opacity="0.7"/>
          <rect x="0" y="22" width="36" height="6" rx="3" fill="#14B8A6"/>
        </g>
        <text x="48" y="23" font-family="Inter, -apple-system, sans-serif" font-weight="700" font-size="20" fill="#F5F5F7">Demora</text>
      </svg>
    </div>
  </div>
  <p class="demora-footer-copyright">
    © 2026 Ourchem × Demora · 保留所有权利<br>
    <span class="demora-footer-meta">本交付物由 Demora 自动生成 · 生成于 ${generatedAt}</span>
  </p>
</footer>
<!-- [demora-copyright-footer] end -->
`;
}

// v5.6 状态机字段写入：annotation_injected: true
// 表示 AI 阶段 3（标注系统注入）已完成
function markAnnotationInjected(root) {
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) return false;
  let text = fs.readFileSync(stateFile, 'utf-8');
  const regex = /^(\s*annotation_injected:\s*).*$/m;
  if (regex.test(text)) {
    text = text.replace(regex, '$1true');
  } else {
    text = text.trimEnd() + '\nannotation_injected: true\n';
  }
  fs.writeFileSync(stateFile, text, 'utf-8');
  return true;
}

/**
 * 从 CSS 内容中按标记提取区段
 * 标记格式：/* >>> [section-name:begin] <<< *​/ ... /* >>> [section-name:end] <<< *​/
 * @param {string} css 完整 CSS 内容
 * @param {string} sectionName 区段名（如 'demora-main-page-styles'）
 * @returns {string} 区段内容（不含标记行），未找到则返回空字符串
 */
function extractCssSection(css, sectionName) {
  const beginMarker = `>>> [${sectionName}:begin]`;
  const endMarker = `>>> [${sectionName}:end]`;
  const beginIdx = css.indexOf(beginMarker);
  const endIdx = css.indexOf(endMarker);
  if (beginIdx === -1 || endIdx === -1 || endIdx < beginIdx) {
    return '';
  }
  // 截取 begin 行结束位置到 end 标记开始位置之间的内容
  const beginLineEnd = css.indexOf('\n', beginIdx);
  const content = css.slice(beginLineEnd + 1, endIdx).trim();
  return content;
}

const INJECT_CSS_START = '<!-- [demora-annotation-css] start -->';
const INJECT_CSS_END = '<!-- [demora-annotation-css] end -->';
const INJECT_PANEL_START = '<!-- [demora-annotation-panel] start -->';
const INJECT_PANEL_END = '<!-- [demora-annotation-panel] end -->';
const INJECT_JS_START = '<!-- [demora-annotation-js] start -->';
const INJECT_JS_END = '<!-- [demora-annotation-js] end -->';

// v5.2.7：CSS 内部标记（用于 check-structure.mjs S-6 排除正则匹配）
// 原因：HTML 注释标记位于 <style> 标签外，readAllCss() 仅提取 <style> 内的 CSS 文本，
//       导致 injectedBlockRegex 无法匹配，注入的保留类名规则被误判为 AI 重复定义。
// 修复：在 <style> 标签内额外添加 CSS 注释包裹标记，使 S-6 能正确识别注入块。
const INJECT_CSS_INNER_START = '/* [demora-injected-css] start */';
const INJECT_CSS_INNER_END = '/* [demora-injected-css] end */';
const INJECT_PANEL_CSS_INNER_START = '/* [demora-injected-panel-css] start */';
const INJECT_PANEL_CSS_INNER_END = '/* [demora-injected-panel-css] end */';

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');
  const refsDir = findReferencesDir();

  log('======================================================================');
  log('enhance-prototype.mjs — 注入标注三件套 (v5.1 Shadow DOM 隔离)');
  log('======================================================================');

  if (!fs.existsSync(indexPath)) {
    log('[FAIL] demo/index.html 不存在，请先运行 generate-demo.mjs 并让 AI 填充内容');
    return { ok: false, error: 'demo/index.html not found' };
  }

  if (!refsDir) {
    log('[FAIL] 未找到 references 目录');
    return { ok: false, error: 'references dir not found' };
  }

  const annotationDir = path.join(refsDir, 'annotation');
  const cssPath = path.join(annotationDir, 'annotation-styles.css');
  const panelPath = path.join(annotationDir, 'annotation-panel.html');
  const jsPath = path.join(annotationDir, 'annotation-engine.js');

  for (const [label, fp] of [['CSS', cssPath], ['Panel', panelPath], ['JS', jsPath]]) {
    if (!fs.existsSync(fp)) {
      log(`[FAIL] 标注 ${label} 文件不存在: ${fp}`);
      return { ok: false, error: `annotation ${label} not found` };
    }
  }

  // 读取并分割 CSS（v5.1：主页面样式 + 面板样式）
  const fullCss = fs.readFileSync(cssPath, 'utf-8');
  const mainPageCss = extractCssSection(fullCss, 'demora-main-page-styles');
  const panelCss = extractCssSection(fullCss, 'demora-panel-styles');

  if (!mainPageCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-main-page-styles] 区段');
    return { ok: false, error: 'CSS section demora-main-page-styles not found' };
  }
  if (!panelCss) {
    log('[FAIL] CSS 分割失败：未找到 [demora-panel-styles] 区段');
    return { ok: false, error: 'CSS section demora-panel-styles not found' };
  }
  log('  [OK] CSS 分割完成: 主页面 ' + mainPageCss.length + ' 字符, 面板 ' + panelCss.length + ' 字符');

  const panelHtml = fs.readFileSync(panelPath, 'utf-8').trim();

  let html = fs.readFileSync(indexPath, 'utf-8');
  let injectCount = 0;

  // 1. 注入主页面 CSS 到 <head> 末尾（标记样式 + 激活态 padding）
  // v5.2.7：在 <style> 内额外添加 CSS 注释包裹标记，配合 check-structure.mjs S-6 排除正则
  if (!html.includes(INJECT_CSS_START)) {
    const cssBlock = `\n${INJECT_CSS_START}\n<style>\n${INJECT_CSS_INNER_START}\n${mainPageCss}\n${INJECT_CSS_INNER_END}\n</style>\n${INJECT_CSS_END}\n`;
    if (html.includes('</head>')) {
      html = html.replace('</head>', cssBlock + '</head>');
      injectCount++;
      log('  [OK] 注入主页面标记样式 -> <head>（含 S-6 内部标记）');
    } else {
      log('  [WARN] 未找到 </head>，跳过主页面 CSS 注入');
    }
  } else {
    log('  [INFO] 主页面 CSS 已注入（幂等跳过）');
  }

  // 2. 注入 Shadow DOM 宿主 + 面板内容到 </body> 前
  //    使用 <template> 元素承载面板 CSS+HTML，避免 </script> 字符串转义问题
  // v5.2.7：在面板 <style> 内额外添加 CSS 注释包裹标记
  if (!html.includes(INJECT_PANEL_START)) {
    const panelBlock = `\n${INJECT_PANEL_START}\n<template id="demora-annotation-panel-tpl"><style>\n${INJECT_PANEL_CSS_INNER_START}\n${panelCss}\n${INJECT_PANEL_CSS_INNER_END}\n</style>\n${panelHtml}\n</template>\n<div id="demora-annotation-host"></div>\n<script>(function(){var h=document.getElementById('demora-annotation-host');var t=document.getElementById('demora-annotation-panel-tpl');if(!h||!t){return;}var s=h.attachShadow({mode:'open'});s.appendChild(t.content.cloneNode(true));})();</script>\n${INJECT_PANEL_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', panelBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板（template + 宿主 + bootstrap，含 S-6 内部标记）');
    } else {
      html += panelBlock;
      injectCount++;
      log('  [OK] 注入 Shadow DOM 面板 -> 末尾（含 S-6 内部标记）');
    }
  } else {
    log('  [INFO] Shadow DOM 面板已注入（幂等跳过）');
  }

  // 3. 注入标注引擎 JS 到 </body> 前
  if (!html.includes(INJECT_JS_START)) {
    const jsContent = fs.readFileSync(jsPath, 'utf-8');
    const jsBlock = `\n${INJECT_JS_START}\n<script>\n${jsContent}\n</script>\n${INJECT_JS_END}\n`;
    if (html.includes('</body>')) {
      html = html.replace('</body>', jsBlock + '</body>');
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> <body>');
    } else {
      html += jsBlock;
      injectCount++;
      log('  [OK] 注入 annotation-engine.js -> 末尾');
    }
  } else {
    log('  [INFO] JS 已注入（幂等跳过）');
  }

  // 4. v5.10 新增：注入 Ourchem × Demora 联合版权 Footer
  //    项目级统一标识，所有 demo HTML 均需带上
  //    幂等：使用 [demora-copyright-footer] 标记包裹
  const FOOTER_MARKER = '[demora-copyright-footer] start';
  if (!html.includes(FOOTER_MARKER)) {
    const whiteLogoPath = findOurchemWhiteLogo();
    if (whiteLogoPath) {
      const footerBlock = buildCopyrightFooter(whiteLogoPath);
      if (html.includes('</body>')) {
        html = html.replace('</body>', footerBlock + '\n</body>');
        injectCount++;
        log('  [OK] 注入 Ourchem × Demora 联合版权 Footer -> <body>（v5.10）');
      } else {
        html += footerBlock;
        injectCount++;
        log('  [OK] 注入 Ourchem × Demora 联合版权 Footer -> 末尾（v5.10）');
      }
    } else {
      log('  [WARN] 未找到 Ourchem 白色 logo SVG，跳过版权 Footer 注入（路径搜索失败）');
    }
  } else {
    log('  [INFO] 版权 Footer 已注入（幂等跳过）');
  }

  if (injectCount > 0) {
    fs.writeFileSync(indexPath, html, 'utf-8');
    log(`\n  [OK] demo/index.html 已更新（${injectCount} 项注入）`);
  }

  log('\n======================================================================');
  log('[SUMMARY] 标注三件套 + 版权 Footer 注入完成（v5.10）');
  log('======================================================================');
  log('  主页面样式（标记 + 激活态 padding）-> <head>');
  log('  面板样式 + 面板 HTML -> Shadow DOM');
  log('  标注引擎 JS -> <body>（通过 host.shadowRoot 访问面板）');
  log('  Ourchem × Demora 联合版权 Footer -> <body>（v5.10 项目级统一标识）');
  log('  AI 代码零侵入 — 标注系统通过 data-* 属性约定工作');

  // v5.6 状态机：标记 AI 阶段 3 已完成
  markAnnotationInjected(projectRoot);
  log('  [OK] state.yaml: annotation_injected = true');

  // v5.11 新增：同步注入 Ourchem × Demora 联合版权 Footer 到 website HTML 文件
  // 决策 2-B：自动注入（替代手工嵌入），保证后续流水线及 skill 运行同步更新
  injectFooterToWebsite(projectRoot);

  return { ok: true, injected: injectCount };
}

/**
 * v5.11 新增：将 Ourchem × Demora 联合版权 Footer 注入到 website HTML 文件
 *
 * 决策 2-B：自动注入（替代手工嵌入），保证 website footer 与 demo/docs footer 一致
 *
 * 处理目标：
 *   - src/assets/website/index.html
 *   - src/assets/website/getting-started.html
 *   - src/assets/website/docs.html（若存在）
 *
 * 注入策略：
 *   1. 优先替换旧的 <footer class="footer">...</footer> 块（仅 Demora logo 的旧 footer）
 *   2. 兜底注入到 </body> 前（无 </body> 时追加到文件末尾）
 *   3. 幂等：检测 [demora-copyright-footer] start 标记，已注入则跳过
 */
export function injectFooterToWebsite(projectRoot) {
  log('\n----------------------------------------------------------------------');
  log('[v5.11] 同步注入 Ourchem × Demora 联合版权 Footer 到 website HTML');
  log('----------------------------------------------------------------------');

  // 查找 website 目录（dev 路径优先，dist 路径兜底）
  const candidates = [
    path.join(__dirname, '..', '..', '..', '..', 'src', 'assets', 'website'),
    path.join(__dirname, '..', 'assets', 'website'),
  ];
  let websiteDir = null;
  for (const p of candidates) {
    if (fs.existsSync(p)) { websiteDir = p; break; }
  }
  if (!websiteDir) {
    log('  [INFO] 未找到 website 目录，跳过 website footer 注入');
    return { ok: false, reason: 'website dir not found' };
  }
  log(`  [OK] website 目录: ${websiteDir}`);

  // 查找 Ourchem 白色 logo
  const whiteLogoPath = findOurchemWhiteLogo();
  if (!whiteLogoPath) {
    log('  [WARN] 未找到 Ourchem 白色 logo SVG，跳过 website footer 注入');
    return { ok: false, reason: 'logo not found' };
  }

  const footerBlock = buildCopyrightFooter(whiteLogoPath);
  const targetFiles = ['index.html', 'getting-started.html', 'docs.html'];
  let injectCount = 0;
  let skipCount = 0;

  for (const fname of targetFiles) {
    const fp = path.join(websiteDir, fname);
    if (!fs.existsSync(fp)) {
      log(`  [INFO] ${fname} 不存在，跳过`);
      continue;
    }

    let html = fs.readFileSync(fp, 'utf-8');
    const FOOTER_MARKER = '[demora-copyright-footer] start';

    // 幂等检测
    if (html.includes(FOOTER_MARKER)) {
      log(`  [INFO] ${fname} 已注入联合版权 Footer（幂等跳过）`);
      skipCount++;
      continue;
    }

    let updated = false;

    // 策略 1：替换旧 footer 块（class="footer" 或类似）
    // 匹配 <footer class="footer">...</footer>（含可能的属性变体）
    const oldFooterRegex = /<footer[^>]*class=["'][^"']*\bfooter\b[^"']*["'][^>]*>[\s\S]*?<\/footer>/i;
    if (oldFooterRegex.test(html)) {
      html = html.replace(oldFooterRegex, footerBlock.trim());
      updated = true;
      log(`  [OK] ${fname} 替换旧 footer 为联合版权 Footer`);
    }

    // 策略 2：兜底注入到 </body> 前
    if (!updated && html.includes('</body>')) {
      html = html.replace('</body>', footerBlock + '\n</body>');
      updated = true;
      log(`  [OK] ${fname} 注入联合版权 Footer -> </body> 前`);
    }

    // 策略 3：追加到文件末尾
    if (!updated) {
      html += footerBlock;
      updated = true;
      log(`  [OK] ${fname} 追加联合版权 Footer -> 末尾`);
    }

    if (updated) {
      fs.writeFileSync(fp, html, 'utf-8');
      injectCount++;
    }
  }

  log(`\n  [SUMMARY] website footer 注入完成: ${injectCount} 个文件已更新, ${skipCount} 个文件已跳过`);
  return { ok: true, injected: injectCount, skipped: skipCount };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('enhance-prototype.mjs') || process.argv[1].endsWith('enhance-prototype'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
