// derive-project-name.mjs
// v5.12 新增：AI 自动提炼项目名候选
//
// 功能：
//   - 扫描 inbox/text/ 下所有 .md 文件，读取内容
//   - 提取标题（第一个 # 标题）作为候选项目名
//   - 从文本中匹配行业关键词，生成候选英文 slug
//   - 输出 3-5 个候选 { chineseName, englishSlug, confidence, reason }
//   - 输出建议命令：node scripts/scaffold-project.mjs --project-slug <slug> --project-name "<name>"
//
// 调用约定：node derive-project-name.mjs，cwd 为用户工作目录（含 inbox/）
// 退出码：0 成功，1 失败
//
// 输出标记：[OK] / [FAIL] / [WARN] / [INFO] / [SUMMARY]，禁止 emoji

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// 字典：中文行业关键词 -> 英文 slug 映射
// 用于从文本中识别行业特征，生成候选 slug
const INDUSTRY_DICT = {
  '专利': 'patent',
  '订单': 'order',
  '库存': 'inventory',
  '预约': 'appointment',
  '挂号': 'appointment',
  '点餐': 'order',
  '旅游': 'travel',
  '行程': 'travel',
  '客户': 'crm',
  '人事': 'hr',
  '财务': 'finance',
  '项目': 'project',
  '内容': 'cms',
  '电商': 'ecommerce',
  '支付': 'payment',
  '物流': 'logistics',
  '餐饮': 'restaurant',
  '诊所': 'clinic',
  '医疗': 'healthcare',
  '教育': 'edu',
  '航空': 'aviation',
};

// 字典：中文项目名 -> 英文 slug
// 与 package-delivery.mjs SLUG_DICT 保持一致 + 适度扩展
// 用于精确匹配标题，提供高置信度候选
const SLUG_DICT = {
  // audit 场景（与 package-delivery.mjs 完全一致）
  '旅游行程预订系统': 'travel-booking',
  '餐饮点餐系统': 'restaurant-order',
  '诊所预约挂号系统': 'clinic-appointment',
  // 通用业务（与 package-delivery.mjs 完全一致）
  '客户关系管理': 'crm',
  '订单管理': 'order-mgmt',
  '库存管理': 'inventory',
  '人事管理': 'hr',
  '财务管理': 'finance',
  '项目管理': 'project-mgmt',
  '内容管理': 'cms',
  '电商': 'ecommerce',
  '支付': 'payment',
  '物流': 'logistics',
  // 扩展候选（derive 专属，覆盖更多常见命名）
  '旅游预订': 'travel-booking',
  '行程预订': 'travel-booking',
  '餐饮管理': 'restaurant-mgmt',
  '点餐系统': 'restaurant-order',
  '诊所管理': 'clinic-mgmt',
  '预约挂号': 'clinic-appointment',
  '客户管理': 'crm',
  '订单系统': 'order-mgmt',
  '库存系统': 'inventory',
  '人事系统': 'hr',
  '财务系统': 'finance',
  '项目系统': 'project-mgmt',
  '内容系统': 'cms',
};

/**
 * 读取 inbox/text/ 下所有 .md 文件内容
 * @param {string} inboxTextDir - inbox/text 目录绝对路径
 * @returns {Array<{filename: string, content: string}>} 文件列表
 */
function readInboxTextFiles(inboxTextDir) {
  if (!fs.existsSync(inboxTextDir)) {
    return [];
  }
  const entries = fs.readdirSync(inboxTextDir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (!entry.isFile()) continue;
    if (!entry.name.toLowerCase().endsWith('.md')) continue;
    // 跳过 .gitkeep 等隐藏文件
    if (entry.name.startsWith('.')) continue;
    const fullPath = path.join(inboxTextDir, entry.name);
    const content = fs.readFileSync(fullPath, { encoding: 'utf-8' });
    files.push({ filename: entry.name, content });
  }
  return files;
}

/**
 * 从 markdown 文本中提取标题
 * 优先级：第一个 # 标题 > 第一行非空文本 > null
 * @param {string} content - markdown 文本
 * @returns {string|null} 标题文本（去除 # 前缀和首尾空白）
 */
function extractTitle(content) {
  const lines = content.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    // 匹配 markdown 一级标题 # xxx
    const h1Match = trimmed.match(/^#\s+(.+)$/);
    if (h1Match) {
      return h1Match[1].trim();
    }
  }
  // 兜底：取第一行非空文本（去掉其他级别标题的 # 前缀）
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const hMatch = trimmed.match(/^#+\s+(.+)$/);
    if (hMatch) return hMatch[1].trim();
    // 非标题文本，但作为首行兜底
    return trimmed;
  }
  return null;
}

/**
 * 从文本中匹配行业关键词，统计出现频次
 * @param {string} content - 文本内容
 * @returns {Array<{keyword: string, slug: string, count: number}>} 命中关键词列表（按 count 降序）
 */
function matchIndustryKeywords(content) {
  const hits = [];
  for (const [keyword, slug] of Object.entries(INDUSTRY_DICT)) {
    // 统计关键词在文本中出现次数
    let count = 0;
    let idx = 0;
    while ((idx = content.indexOf(keyword, idx)) !== -1) {
      count++;
      idx += keyword.length;
    }
    if (count > 0) {
      hits.push({ keyword, slug, count });
    }
  }
  hits.sort((a, b) => b.count - a.count);
  return hits;
}

/**
 * 置信度等级
 * HIGH: 字典精确命中标题，或标题包含字典 key
 * MEDIUM: 行业关键词多次出现（>=2 次）
 * LOW: 行业关键词仅出现 1 次
 */
function confidenceLevel(score) {
  if (score >= 3) return 'HIGH';
  if (score >= 2) return 'MEDIUM';
  return 'LOW';
}

/**
 * 去重候选列表（按 englishSlug + chineseName 组合去重）
 * 保留 confidence 更高的条目
 * @param {Array} candidates - 候选列表
 * @returns {Array} 去重后的候选列表
 */
function dedupCandidates(candidates) {
  const map = new Map();
  for (const c of candidates) {
    const key = `${c.chineseName}||${c.englishSlug}`;
    const existing = map.get(key);
    if (!existing || c.score > existing.score) {
      map.set(key, c);
    }
  }
  return Array.from(map.values());
}

/**
 * 主函数：分析 inbox/text/ 资料提炼项目名候选
 * @param {object} args - { root?: string } 工作目录，默认 process.cwd()
 * @returns {{ ok: boolean, candidates: Array }}
 */
export function main(args = {}) {
  const cwd = args.root || process.cwd();
  const inboxTextDir = path.join(cwd, 'inbox', 'text');

  process.stdout.write('======================================================================\n');
  process.stdout.write(`[INFO] 扫描目录: ${inboxTextDir}\n`);
  process.stdout.write('======================================================================\n');

  const files = readInboxTextFiles(inboxTextDir);
  if (files.length === 0) {
    process.stderr.write('[FAIL] inbox/text/ 下未找到任何 .md 文件\n');
    process.stderr.write('[WARN] 请先在 inbox/text/ 放置需求文档后再执行本脚本\n');
    process.exit(1);
  }

  process.stdout.write(`[OK] 发现 ${files.length} 个 .md 文件: ${files.map(f => f.filename).join(', ')}\n`);

  // 收集所有标题与合并文本
  const titles = [];
  const allContent = [];
  for (const f of files) {
    const title = extractTitle(f.content);
    if (title) titles.push(title);
    allContent.push(f.content);
  }
  const mergedText = allContent.join('\n\n');

  if (titles.length === 0) {
    process.stderr.write('[FAIL] 未能从任何文件中提取到标题\n');
    process.stderr.write('[WARN] 请确保 .md 文件包含 # 一级标题\n');
    process.exit(1);
  }

  process.stdout.write(`[OK] 提取到 ${titles.length} 个标题: ${titles.join(' | ')}\n`);

  // 候选列表
  const candidates = [];

  // 策略 1：标题 -> SLUG_DICT 精确匹配（confidence: HIGH）
  for (const title of titles) {
    if (SLUG_DICT[title]) {
      candidates.push({
        chineseName: title,
        englishSlug: SLUG_DICT[title],
        score: 4, // 精确匹配最高分
        reason: '标题命中 SLUG_DICT 精确匹配',
      });
    }
  }

  // 策略 2：标题包含 SLUG_DICT key（confidence: HIGH/MEDIUM）
  for (const title of titles) {
    for (const [k, v] of Object.entries(SLUG_DICT)) {
      if (title === k) continue; // 已在策略 1 处理
      if (title.includes(k)) {
        candidates.push({
          chineseName: title,
          englishSlug: v,
          score: 3,
          reason: `标题包含字典 key "${k}"`,
        });
      }
    }
  }

  // 策略 3：行业关键词匹配 -> 生成组合名（confidence: MEDIUM/LOW）
  const industryHits = matchIndustryKeywords(mergedText);
  for (const title of titles) {
    for (const hit of industryHits.slice(0, 3)) { // 取前 3 个高频关键词
      // 若标题与该关键词相关（标题包含关键词，或使用关键词作为项目名前缀）
      const isRelevant = title.includes(hit.keyword);
      const score = isRelevant ? 2 + Math.min(hit.count, 3) * 0.5 : 1 + Math.min(hit.count, 5) * 0.3;
      // 生成中文候选名：若标题已含关键词，用标题本身；否则拼「关键词 + 系统」
      const chineseName = isRelevant ? title : `${hit.keyword}系统`;
      candidates.push({
        chineseName,
        englishSlug: hit.slug,
        score: Number(score.toFixed(2)),
        reason: `行业关键词 "${hit.keyword}" 出现 ${hit.count} 次${isRelevant ? '（标题命中）' : ''}`,
      });
    }
  }

  // 策略 4：兜底 - 直接用标题作为中文名，slug 用第一个行业关键词
  if (candidates.length === 0 && titles.length > 0) {
    const fallbackSlug = industryHits.length > 0 ? industryHits[0].slug : 'project';
    for (const title of titles.slice(0, 2)) {
      candidates.push({
        chineseName: title,
        englishSlug: fallbackSlug,
        score: 1,
        reason: '兜底候选：标题 + 首个行业关键词',
      });
    }
  }

  // 去重 + 排序
  const deduped = dedupCandidates(candidates);
  deduped.sort((a, b) => b.score - a.score);

  // 限制输出 3-5 个
  const finalCandidates = deduped.slice(0, Math.min(5, Math.max(3, deduped.length)));

  if (finalCandidates.length === 0) {
    process.stderr.write('[FAIL] 未能生成任何候选项目名\n');
    process.exit(1);
  }

  // 输出候选列表
  process.stdout.write('\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`[INFO] 项目名候选（共 ${finalCandidates.length} 个，按 confidence 降序）\n`);
  process.stdout.write('======================================================================\n');
  finalCandidates.forEach((c, i) => {
    const confidence = confidenceLevel(c.score);
    process.stdout.write(`\n  [${i + 1}] 中文名: ${c.chineseName}\n`);
    process.stdout.write(`      slug:  ${c.englishSlug}\n`);
    process.stdout.write(`      confidence: ${confidence}\n`);
    process.stdout.write(`      reason: ${c.reason}\n`);
  });

  // 取第一个候选作为建议命令
  const top = finalCandidates[0];
  process.stdout.write('\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write('[INFO] 建议命令（PM 选择后执行）\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`  node scripts/scaffold-project.mjs --project-slug ${top.englishSlug} --project-name "${top.chineseName}"\n`);

  // 同时输出所有候选的命令（便于 PM 复制其他候选）
  if (finalCandidates.length > 1) {
    process.stdout.write('\n  [INFO] 其他候选命令：\n');
    finalCandidates.slice(1).forEach((c, i) => {
      process.stdout.write(`  # 候选 ${i + 2}: node scripts/scaffold-project.mjs --project-slug ${c.englishSlug} --project-name "${c.chineseName}"\n`);
    });
  }

  process.stdout.write('\n');
  process.stdout.write('======================================================================\n');
  process.stdout.write(`[SUMMARY] 共 ${finalCandidates.length} 个候选，PM 请选择一个执行上述命令\n`);
  process.stdout.write('======================================================================\n');

  return { ok: true, candidates: finalCandidates };
}

// 直接运行入口
const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  // 解析 CLI 参数（预留 --root，便于测试）
  const args = {};
  for (let i = 2; i < process.argv.length; i++) {
    const a = process.argv[i];
    if (a === '--root') args.root = process.argv[++i];
  }
  main(args);
}
