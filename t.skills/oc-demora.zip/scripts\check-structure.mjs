// check-structure.mjs
// Demo 结构完整性校验（v5.2.6 — 10 项）
//
// 校验项：
//   S-1: demo/ 目录存在性
//   S-2: demo/index.html 存在且内容充实（>= 2000 bytes，排除 AI 未填充场景）
//   S-3: 标注面板 DOM 结构完整性（.annotation-panel + .panel-body + .panel-header 三件套）
//   S-4: 标注数据属性存在性（data-zone-id 或 data-element-id 至少 1 个）
//   S-5: 无 ZONE 残留标记（LAYOUT_ZONE/COMPONENT_ZONE/ANNOTATION_PANEL_ZONE）
//   S-6 (v5.2.6): demo CSS 未重复定义保留类名（.l3-dot / .l2-marker / .anno-zone）
//   S-7 (v5.2.6): 多页面 SPA 必须实现 hashchange 监听 + page 切换逻辑
//   S-8 (v5.2.6): 弹窗关闭按钮必须绑定事件（modalClose onclick 检测）
//   S-9 (v5.2.6): inbox/text/ 必须有 PM 输入文档
//   S-10 (v5.2.6): demo 初始路由必须为首页（多页面 SPA 默认 hash 不应跳到非首页）
//
// 退出码：0 全部通过，1 有 FAIL

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function log(msg) { process.stdout.write(msg + '\n'); }

function findProjectRoot() {
  let dir = __dirname;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, '.demora'))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return process.cwd();
}

// v5.6 状态机字段写入：ai_html_designed: true + structure_check_passed: true
// 表示 AI 阶段 2（HTML 设计）+ 阶段 4（结构校验 10/10 PASS）已完成
// 设计依据：check-structure 通过 = demo 满足 4 项最小契约 = ai_html_designed
function markStructurePassed(root) {
  const stateFile = path.join(root, '.demora', 'state.yaml');
  if (!fs.existsSync(stateFile)) return false;
  let text = fs.readFileSync(stateFile, 'utf-8');
  const updates = { ai_html_designed: 'true', structure_check_passed: 'true' };
  for (const [key, value] of Object.entries(updates)) {
    const regex = new RegExp('^(\\s*' + key + ':\\s*).*$', 'm');
    if (regex.test(text)) {
      text = text.replace(regex, '$1' + value);
    } else {
      text = text.trimEnd() + '\n' + key + ': ' + value + '\n';
    }
  }
  fs.writeFileSync(stateFile, text, 'utf-8');
  return true;
}

// v5.2.6：读取 demo 所有 CSS 内容（index.html 内联 + assets/*.css）
function readAllCss(demoDir, indexHtml) {
  let cssContent = '';
  // 提取 <style>...</style> 块
  const styleRegex = /<style[^>]*>([\s\S]*?)<\/style>/gi;
  let m;
  while ((m = styleRegex.exec(indexHtml)) !== null) {
    cssContent += '\n' + m[1];
  }
  // 读取 assets/*.css
  const assetsDir = path.join(demoDir, 'assets');
  if (fs.existsSync(assetsDir)) {
    for (const entry of fs.readdirSync(assetsDir, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith('.css')) {
        cssContent += '\n' + fs.readFileSync(path.join(assetsDir, entry.name), 'utf-8');
      }
    }
  }
  return cssContent;
}

// v5.2.6：读取 demo 所有 JS 内容（index.html 内联 + assets/*.js）
function readAllJs(demoDir, indexHtml) {
  let jsContent = '';
  // 提取 <script>...</script> 内联块（排除 src 引用）
  const scriptRegex = /<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi;
  let m;
  while ((m = scriptRegex.exec(indexHtml)) !== null) {
    jsContent += '\n' + m[1];
  }
  // 读取 assets/*.js
  const assetsDir = path.join(demoDir, 'assets');
  if (fs.existsSync(assetsDir)) {
    for (const entry of fs.readdirSync(assetsDir, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.endsWith('.js')) {
        jsContent += '\n' + fs.readFileSync(path.join(assetsDir, entry.name), 'utf-8');
      }
    }
  }
  return jsContent;
}

export function main(args = {}) {
  const projectRoot = args.projectRoot || findProjectRoot();
  const demoDir = path.join(projectRoot, 'demo');
  const indexPath = path.join(demoDir, 'index.html');

  log('======================================================================');
  log('check-structure.mjs — 结构完整性校验 (v5.2.6)');
  log('======================================================================');

  let pass = 0, fail = 0, warn = 0;

  // S-1: demo/ 目录存在性
  if (fs.existsSync(demoDir)) {
    log('  [OK] S-1: demo/ 目录存在');
    pass++;
  } else {
    log('  [FAIL] S-1: demo/ 目录不存在');
    fail++;
  }

  // S-2: demo/index.html 存在且内容充实（>= 2000 bytes）
  if (fs.existsSync(indexPath)) {
    const stat = fs.statSync(indexPath);
    if (stat.size >= 2000) {
      log('  [OK] S-2: demo/index.html 存在且内容充实 (' + stat.size + ' bytes)');
      pass++;
    } else {
      log('  [FAIL] S-2: demo/index.html 内容过少 (' + stat.size + ' bytes < 2000)，AI 可能未填充');
      fail++;
    }
  } else {
    log('  [FAIL] S-2: demo/index.html 不存在');
    fail++;
  }

  // 后续校验依赖 index.html
  if (!fs.existsSync(indexPath)) {
    log('\n======================================================================');
    log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
    log('======================================================================');
    if (fail > 0) {
      log('>>> 结构校验失败，请修正后重新运行');
      return { ok: false, pass, fail, warn };
    }
    log('>>> 结构校验通过');
    return { ok: true, pass, fail, warn };
  }

  const html = fs.readFileSync(indexPath, 'utf-8');
  const cssContent = readAllCss(demoDir, html);
  const jsContent = readAllJs(demoDir, html);

  // S-3: 标注面板 DOM 结构完整性（.annotation-panel + .panel-body + .panel-header 三件套）
  {
    const hasPanel = html.includes('annotation-panel');
    const hasBody = html.includes('panel-body');
    const hasHeader = html.includes('panel-header');
    if (hasPanel && hasBody && hasHeader) {
      log('  [OK] S-3: 标注面板 DOM 结构完整（.annotation-panel + .panel-body + .panel-header）');
      pass++;
    } else {
      const missing = [];
      if (!hasPanel) missing.push('.annotation-panel');
      if (!hasBody) missing.push('.panel-body');
      if (!hasHeader) missing.push('.panel-header');
      log('  [FAIL] S-3: 标注面板 DOM 结构不完整，缺失: ' + missing.join(', '));
      fail++;
    }
  }

  // S-4: 标注数据属性存在性（data-zone-id 或 data-element-id 至少 1 个）
  {
    const hasZoneId = /data-zone-id\s*=/.test(html);
    const hasElementId = /data-element-id\s*=/.test(html);
    if (hasZoneId || hasElementId) {
      log('  [OK] S-4: 标注数据属性存在（data-zone-id: ' + hasZoneId + ', data-element-id: ' + hasElementId + '）');
      pass++;
    } else {
      log('  [FAIL] S-4: 未检测到 data-zone-id 或 data-element-id 属性，AI 可能未添加标注数据');
      fail++;
    }
  }

  // S-5: 无 ZONE 残留标记
  {
    const zoneResidual = /LAYOUT_ZONE|COMPONENT_ZONE|ANNOTATION_PANEL_ZONE/.test(html);
    if (!zoneResidual) {
      log('  [OK] S-5: 无 ZONE 残留标记');
      pass++;
    } else {
      log('  [FAIL] S-5: 检测到 ZONE 残留标记（LAYOUT_ZONE/COMPONENT_ZONE/ANNOTATION_PANEL_ZONE）');
      fail++;
    }
  }

  // S-6 (v5.2.6): demo CSS 未重复定义保留类名
  // 根因：audit-trainer-v5.2 在 style.css 重复定义 .l3-dot { pointer-events: none } 导致 dot 无法点击
  {
    const reservedClasses = ['\\.l3-dot', '\\.l2-marker', '\\.anno-zone', '\\.annotation-panel'];
    // 排除标注系统注入块（<!-- [demora-...] start -->...end -->）
    // v5.2.7：匹配两种注入标记形式：
    //   1) HTML 注释（在 <style> 标签外，作为分隔标记）：<!-- [demora-...] start --> ... <!-- [demora-...] end -->
    //   2) CSS 注释（在 <style> 标签内，配合 v5.2.7 enhance-prototype.mjs 自动注入）：
    //      /* [demora-injected-...] start */ ... /* [demora-injected-...] end */
    // 原因：readAllCss() 仅提取 <style> 内的 CSS 文本，HTML 注释标记丢失导致 S-6 误判。
    const injectedBlockRegex =
      /(?:\/\*\s*\[demora-(?:injected-)?[^\]]*\]\s*start\s*\*\/[\s\S]*?\/\*\s*\[demora-(?:injected-)?[^\]]*\]\s*end\s*\*\/)|(?:<!--\s*\[demora-[^\]]*\]\s*start\s*-->[\s\S]*?<!--\s*\[demora-[^\]]*\]\s*end\s*-->)/g;
    const userCss = cssContent.replace(injectedBlockRegex, '');
    const offenders = [];
    for (const cls of reservedClasses) {
      const re = new RegExp(cls + '\\s*\\{', 'g');
      if (re.test(userCss)) {
        offenders.push(cls.replace(/\\\\/g, ''));
      }
    }
    if (offenders.length === 0) {
      log('  [OK] S-6: demo CSS 未重复定义保留类名（.l3-dot / .l2-marker / .anno-zone / .annotation-panel）');
      pass++;
    } else {
      log('  [FAIL] S-6: demo CSS 重复定义了保留类名: ' + offenders.join(', '));
      log('         详情: 这些类名由标注系统注入，AI 重复定义会破坏交互（如 pointer-events: none 导致 dot 无法点击）');
      log('         修复: 删除 demo style.css / <style> 中这些类名的规则块，视觉定制通过外层包裹元素实现');
      fail++;
    }
  }

  // S-7 (v5.2.6): 多页面 SPA 必须实现 hashchange 监听 + page 切换逻辑
  // 根因：audit-coffee-v5.2 / audit-carwash-v5.2 有多个 [data-page-id] 但完全没有路由切换 JS
  // v5.2.6 改进：接受 hidden 属性切换 OR class 切换（.active / .is-active）两种主流模式
  {
    const pageMatches = html.match(/data-page-id\s*=\s*"[^"]+"/g) || [];
    const pageCount = pageMatches.length;
    if (pageCount >= 2) {
      // 多页面 demo：必须检测 hashchange + page 切换
      const hasHashchange = /hashchange/.test(jsContent);
      // 接受两种页面切换模式：
      //   模式 A（hidden 属性）：page.hidden = true / page.classList.add('hidden')
      //   模式 B（class 切换）：page.classList.add('active') / page.classList.toggle('active')
      //   模式 C（style 切换）：page.style.display = 'none' / page.style.visibility = 'hidden'
      const hasHiddenSwitch = /\.(hidden|style\.display)\s*=|\.classList\.(add|remove|toggle)\s*\(\s*['"]hidden['"]/.test(jsContent);
      const hasClassSwitch = /\.classList\.(add|remove|toggle)\s*\(\s*['"](active|is-active|is-hidden|hidden)['"]/.test(jsContent);
      const hasStyleSwitch = /\.style\.(display|visibility)\s*=/.test(jsContent);
      const hasPageSwitch = hasHiddenSwitch || hasClassSwitch || hasStyleSwitch;
      // 也接受引用 [data-page-id] 的查询（说明 demo 知道要切换页面）
      const hasPageQuery = /querySelectorAll\s*\(\s*['"]?\[?data-page-id/.test(jsContent) ||
        /getElementsByClassName\s*\(\s*['"]?page/.test(jsContent);
      if (hasHashchange && (hasPageSwitch || hasPageQuery)) {
        log('  [OK] S-7: 多页面 SPA 已实现 hashchange 监听 + page 切换（' + pageCount + ' 页面）');
        pass++;
      } else {
        const missing = [];
        if (!hasHashchange) missing.push('hashchange 监听');
        if (!hasPageSwitch && !hasPageQuery) missing.push('page hidden/class 切换');
        log('  [FAIL] S-7: 多页面 SPA（' + pageCount + ' 页面）缺少路由切换逻辑: ' + missing.join(', '));
        log('         详情: 导航 <a href="#/xxx"> 会改变 URL hash，但若无 hashchange 监听器切换 [data-page-id] 的 hidden/active 属性，用户点击导航后页面内容不会切换');
        log('         修复: 在 demo JS 中实现 handleRoute() 函数 + window.addEventListener(\'hashchange\', handleRoute)');
        log('         支持模式: hidden 属性切换 / .active 类切换 / style.display 切换 三选一');
        fail++;
      }
    } else {
      log('  [OK] S-7: 单页面 demo 或无 [data-page-id]，跳过路由切换检测');
      pass++;
    }
  }

  // S-8 (v5.2.6): 弹窗关闭按钮必须绑定事件
  // 根因：audit-printing-v5.2 的 modalClose 按钮 onclick 未绑定
  {
    const hasModal = /\bclass\s*=\s*['"][^'"]*modal/.test(html) ||
      /\bid\s*=\s*['"][^'"]*modal/i.test(html);
    if (hasModal) {
      // 检测是否有 modalClose / modal-close 等关闭按钮，并在 JS 中绑定 click
      const closeBtnPatterns = [
        /id\s*=\s*['"]modalClose['"]/i,
        /class\s*=\s*['"][^'"]*\bmodal-close\b[^'"]*['"]/i,
        /class\s*=\s*['"][^'"]*\bclose-btn\b[^'"]*['"]/i
      ];
      const hasCloseBtn = closeBtnPatterns.some(re => re.test(html));
      if (hasCloseBtn) {
        // 检测 JS 中是否绑定了 click 事件
        const closeBound = /(?:modalClose|modal-close|close-btn|closeBtn)\b[\s\S]{0,200}?(?:addEventListener\s*\(\s*['"]click['"]|\.onclick\s*=)/i.test(jsContent) ||
          /(?:addEventListener\s*\(\s*['"]click['"]\s*,\s*closeModal|\.onclick\s*=\s*closeModal)/i.test(jsContent);
        if (closeBound) {
          log('  [OK] S-8: 弹窗关闭按钮已绑定 click 事件');
          pass++;
        } else {
          log('  [FAIL] S-8: 检测到弹窗关闭按钮（modalClose / .modal-close），但 JS 中未绑定 click 事件');
          log('         详情: 关闭按钮 × 无法点击关闭弹窗，用户反馈 audit-printing 弹窗无法关闭');
          log('         修复: 在 init 中 closeBtn.addEventListener(\'click\', closeModal)');
          fail++;
        }
      } else {
        log('  [OK] S-8: 检测到弹窗但未发现显式关闭按钮，跳过');
        pass++;
      }
    } else {
      log('  [OK] S-8: 无弹窗，跳过关闭按钮检测');
      pass++;
    }
  }

  // S-9 (v5.2.6): inbox/text/ 必须有 PM 输入文档
  // 根因：并发 agent 模式未生成 inbox 下的 PM 原始需求文档
  // v5.2.7：命名规范化，区分 requirement-input.md（当前输入详版）与 requirement-scenario-brief.md（场景模板简版）
  {
    const inboxTextDir = path.join(projectRoot, 'inbox', 'text');
    if (fs.existsSync(inboxTextDir)) {
      const pmDocs = fs.readdirSync(inboxTextDir)
        .filter(name => name.endsWith('.md') && !name.startsWith('.'));
      if (pmDocs.length > 0) {
        // v5.2.7：优先展示规范命名的文件，便于审计识别
        const hasInput = pmDocs.includes('requirement-input.md');
        const hasBrief = pmDocs.includes('requirement-scenario-brief.md');
        const detail = hasInput
          ? 'requirement-input.md (当前输入)'
          : (hasBrief ? 'requirement-scenario-brief.md (仅模板简版)' : pmDocs[0]);
        log('  [OK] S-9: inbox/text/ 含 ' + pmDocs.length + ' 个 PM 输入文档（' + detail + ' 等）');
        pass++;
      } else {
        log('  [FAIL] S-9: inbox/text/ 目录存在但无 .md 文档');
        log('         详情: PM 输入原始需求文档缺失，影响需求追溯');
        log('         修复: 在 sim-runner / 并发 agent 模式下生成 inbox/text/requirement-input.md');
        fail++;
      }
    } else {
      log('  [WARN] S-9: inbox/text/ 目录不存在，可能是 sim-runner 未生成');
      warn++;
    }
  }

  // S-10 (v5.2.6): demo 初始路由必须为首页（多页面 SPA 默认 hash 不应跳到非首页）
  // 根因：audit-printing-v5.2 默认路由 /orders 而非首页 /overview
  // v5.2.6 改进：扩展检测模式，覆盖 `location.hash.replace(...) || "/orders"` 等隐蔽写法
  {
    const pageMatches = html.match(/data-page-id\s*=\s*"[^"]+"/g) || [];
    if (pageMatches.length >= 2) {
      // 多种默认路由检测模式（覆盖 AI 多样化写法）
      const defaultRoutePatterns = [
        // 显式变量定义：var DEFAULT_ROUTE = '/orders'
        /(?:var|let|const)\s+(?:DEFAULT_ROUTE|defaultRoute|defaultHash|homeRoute)\s*=\s*['"]([^'"]+)['"]/,
        // 短路兜底：location.hash || '/orders'  或  hash = hash || '/orders'
        /location\.hash\s*\|\|\s*['"]([^'"]+)['"]/,
        /hash\s*=\s*hash\s*\|\|\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：replace 后短路：var hash = location.hash.replace(/^#/, "") || "/orders"
        /location\.hash\.replace\([^)]*\)\s*\|\|\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：if (!location.hash) location.hash = '/orders'
        /if\s*\(\s*!location\.hash\s*\)\s*location\.hash\s*=\s*['"]([^'"]+)['"]/,
        // v5.2.6 新增：未知路由回退：location.hash = '/orders'
        /(?:^|[\s;])location\.hash\s*=\s*['"]([^'"]+)['"]/m,
      ];
      let detectedDefault = null;
      for (const re of defaultRoutePatterns) {
        const m = jsContent.match(re);
        if (m && m[1]) { detectedDefault = m[1]; break; }
      }
      const firstPageMatch = html.match(/data-page-id\s*=\s*"([^"]+)"/);
      const firstPageId = firstPageMatch && firstPageMatch[1];
      if (detectedDefault) {
        // 简单判断：默认路由不应是 /orders、/dashboard 等明确非首页路径
        // 注意：P01 可能确实是门店列表（stores/list），所以这只是 WARN 不是 FAIL
        const nonHomeKeywords = ['order', 'dashboard', 'list', 'detail', 'board'];
        const isLikelyNonHome = nonHomeKeywords.some(kw => detectedDefault.toLowerCase().includes(kw));
        if (isLikelyNonHome) {
          log('  [WARN] S-10: 默认路由 "' + detectedDefault + '" 看起来不是首页（含 order/dashboard/list 等关键字）');
          log('         详情: 用户反馈 audit-printing 默认跳订单页而非首页；建议默认路由指向 P01（首页/概览页）');
          log('         修复: 将 DEFAULT_ROUTE 改为 P01 对应的首页路由（如 /overview 或 /home），P01 应是概览/首页而非订单/详情页');
          warn++;
        } else {
          log('  [OK] S-10: 默认路由 "' + detectedDefault + '"（首页: ' + firstPageId + '）');
          pass++;
        }
      } else {
        log('  [OK] S-10: 未检测到显式默认路由设置（可能由 demo 自行处理）');
        pass++;
      }
    } else {
      log('  [OK] S-10: 单页面 demo，跳过初始路由检测');
      pass++;
    }
  }

  log('\n======================================================================');
  log(`[SUMMARY] 通过: ${pass}, 失败: ${fail}, 警告: ${warn}`);
  log('======================================================================');

  if (fail > 0) {
    log('>>> 结构校验失败，请修正后重新运行');
    return { ok: false, pass, fail, warn };
  }
  log('>>> 结构校验通过');
  // v5.6 状态机：标记 AI 阶段 2 + 阶段 4 已完成
  markStructurePassed(projectRoot);
  log('  [OK] state.yaml: ai_html_designed = true, structure_check_passed = true');
  return { ok: true, pass, fail, warn };
}

const isDirectRun = process.argv[1] &&
  (process.argv[1].endsWith('check-structure.mjs') || process.argv[1].endsWith('check-structure'));
if (isDirectRun) {
  const result = main();
  process.exit(result.ok ? 0 : 1);
}
